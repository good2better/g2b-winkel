// G2B Bedrijfsmiddelen — frontend logica (vanilla JS, geen framework)
"use strict";

// ---------- helpers ------------------------------------------------------
const $ = id => document.getElementById(id);

function toast(msg, err = false) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show" + (err ? " err" : "");
  setTimeout(() => { t.className = "toast"; }, 3200);
}

function kopieer(btn) {
  const inp = btn.parentElement.querySelector("input");
  inp.select();
  navigator.clipboard?.writeText(inp.value)
    .then(() => toast("Bedankt-link gekopieerd"))
    .catch(() => { document.execCommand("copy"); toast("Gekopieerd"); });
}

async function post(url, body) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    const d = data.detail;
    throw new Error(typeof d === "string" ? d :
      (Array.isArray(d) ? d.map(x => x.msg).join("; ") : "fout " + r.status));
  }
  return data;
}

function resultHtml(file, url, extra = "") {
  return `<div class="result"><div class="titel">✔ Klaar</div>` +
    `<a href="${url}" download>${file}</a> — klik om te downloaden.` +
    extra + `</div>`;
}

// ---------- tabs ---------------------------------------------------------
document.querySelectorAll("nav button").forEach(b => {
  b.onclick = () => {
    document.querySelectorAll("nav button").forEach(x => x.classList.remove("on"));
    b.classList.add("on");
    document.querySelectorAll("main section").forEach(s => s.classList.add("hidden"));
    $("tab-" + b.dataset.tab).classList.remove("hidden");
    if (b.dataset.tab === "bestanden") loadExports();
    if (b.dataset.tab === "winkel") loadWinkel();
    if (b.dataset.tab === "royalty") loadRoyalty();
    if (b.dataset.tab === "videoboek") loadVideoboeken();
    if (b.dataset.tab === "kleurboek") loadKleurboek();
  };
});

// ---------- contract -----------------------------------------------------
async function maakContract() {
  const naam = $("cNaam").value.trim();
  const product = $("cProduct").value.trim();
  if (!naam || !product) { toast("Vul naam en product in", true); return; }
  try {
    const r = await post("/api/contract", {
      koper_naam: naam,
      koper_email: $("cEmail").value.trim(),
      product: product,
      licentie_type: $("cLicentie").value,
      vergoeding: parseFloat($("cPrijs").value) || 0,
      duur: $("cDuur").value,
    });
    $("cResult").innerHTML = resultHtml(r.file, r.url);
    toast("Contract gemaakt");
  } catch (e) { toast(e.message, true); }
}

// ---------- beschrijving -------------------------------------------------
async function maakBeschrijving(skipSave = false) {
  const product = $("bProduct").value.trim();
  if (!product) { toast("Vul een productnaam in", true); return; }
  const eig = $("bEigenschappen").value.split("\n")
    .map(s => s.trim()).filter(Boolean);
  try {
    const r = await post("/api/beschrijving", {
      product: product,
      type: $("bType").value,
      eigenschappen: eig,
      prijs: $("bPrijs").value.trim(),
      doelgroep: $("bDoelgroep").value.trim(),
      opslaan: !skipSave,
    });
    const dl = r.url ?
      `<div class="titel">✔ Opgeslagen als <a href="${r.url}" download>${r.file}</a></div>` : "";
    $("bResult").innerHTML = `<div class="result">${dl}
      <div class="titel">LANGE VERSIE
        <button class="ghost sm" style="float:right" onclick="copyEl('bLang')">kopieer</button>
      </div>
      <pre class="tekst" id="bLang"></pre>
      <div class="titel" style="margin-top:10px">KORTE VERSIE
        <button class="ghost sm" style="float:right" onclick="copyEl('bKort')">kopieer</button>
      </div>
      <pre class="tekst" id="bKort"></pre></div>`;
    $("bLang").textContent = r.lang;
    $("bKort").textContent = r.kort;
    toast("Beschrijving gemaakt");
  } catch (e) { toast(e.message, true); }
}

function copyEl(id) {
  navigator.clipboard.writeText($(id).textContent)
    .then(() => toast("Gekopieerd"))
    .catch(() => toast("Kopiëren mislukt", true));
}

// ---------- merk ---------------------------------------------------------
async function maakMerk() {
  try {
    const r = await post("/api/merkassets", { tagline: $("mTagline").value });
    let imgs = r.files.map(f =>
      `<div class="item"><img src="/api/download/${f}" alt="${f}">
       <div class="nm">${f}</div>
       <a href="/api/download/${f}" download class="pill merk">download</a></div>`
    ).join("");
    $("mResult").innerHTML = `<div class="result">
      <div class="titel">✔ Merk-kit klaar —
        <a href="${r.zip_url}" download>${r.zip}</a></div>
      <div class="merkgrid">${imgs}</div></div>`;
    toast("Merkbestanden gemaakt");
  } catch (e) { toast(e.message, true); }
}

// ---------- factuur ------------------------------------------------------
async function maakFactuur() {
  const naam = $("fNaam").value.trim();
  const oms = $("fOms").value.trim();
  const bedrag = parseFloat($("fBedrag").value);
  if (!naam || !oms) { toast("Vul naam en omschrijving in", true); return; }
  if (!bedrag || bedrag <= 0) { toast("Vul een bedrag in", true); return; }
  try {
    const r = await post("/api/factuur", {
      klant_naam: naam,
      klant_email: $("fEmail").value.trim(),
      omschrijving: oms,
      bedrag: bedrag,
      datum: $("fDatum").value.trim() || null,
      btw_pct: parseFloat($("fBtw").value),
      incl_btw: $("fIncl").checked,
    });
    $("fResult").innerHTML = resultHtml(r.file, r.url);
    toast("Factuur gemaakt");
  } catch (e) { toast(e.message, true); }
}

async function maakDeal() {
  const naam = $("fNaam").value.trim();
  const oms = $("fOms").value.trim();
  const bedrag = parseFloat($("fBedrag").value);
  if (!naam || !oms) { toast("Vul naam en omschrijving in", true); return; }
  if (!bedrag || bedrag <= 0) { toast("Vul een bedrag in", true); return; }
  try {
    const r = await post("/api/deal", {
      klant_naam: naam,
      klant_email: $("fEmail").value.trim(),
      omschrijving: oms,
      bedrag: bedrag,
      datum: $("fDatum").value.trim() || null,
      btw_pct: parseFloat($("fBtw").value),
      incl_btw: $("fIncl").checked,
      licentie_type: $("fLicentie").value,
      duur: $("fDuur").value,
    });
    $("fResult").innerHTML = resultHtml(
      r.factuur.file, r.factuur.url,
      `<br><a href="${r.contract.url}" download>${r.contract.file}</a>` +
      ` — het bijbehorende contract.`);
    toast("Factuur + contract gemaakt");
  } catch (e) { toast(e.message, true); }
}

// ---------- voorwaarden ----------------------------------------------------
async function maakVoorwaarden() {
  try {
    const r = await post("/api/voorwaarden", {});
    $("vResult").innerHTML = resultHtml(r.file, r.url);
    toast("Voorwaarden gemaakt");
  } catch (e) { toast(e.message, true); }
}

// ---------- settings (mijn bedrijfsgegevens) ------------------------------
async function loadSettings() {
  try {
    const s = await fetch("/api/settings").then(x => x.json());
    if (s.bedrijfsnaam) $("vNaam").value = s.bedrijfsnaam;
    if (s.naam && $("vPersoon")) $("vPersoon").value = s.naam;
    if (s.email) $("vEmail").value = s.email;
    if (s.kvk) $("vKvk").value = s.kvk;
    if (s.btw_nr) $("vBtw").value = s.btw_nr;
    if (s.iban) $("vIban").value = s.iban;
  } catch (e) { /* geen settings = defaults laten staan */ }
}

async function saveSettings() {
  try {
    await post("/api/settings", {
      bedrijfsnaam: $("vNaam").value.trim(),
      naam: $("vPersoon") ? $("vPersoon").value.trim() : "",
      adres: "Nederland",
      email: $("vEmail").value.trim(),
      kvk: $("vKvk").value.trim(),
      btw_nr: $("vBtw").value.trim(),
      iban: $("vIban").value.trim(),
    });
    toast("Bedrijfsgegevens opgeslagen");
  } catch (e) { toast(e.message, true); }
}

loadSettings();

// ---------- bestanden ----------------------------------------------------
function fmtSize(n) {
  if (n < 1024) return n + " B";
  if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
  return (n / 1048576).toFixed(1) + " MB";
}
function fmtTime(t) {
  return new Date(t * 1000).toLocaleString("nl-NL",
    { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

async function loadExports() {
  try {
    const r = await fetch("/api/exports").then(x => x.json());
    $("eCount").textContent = r.files.length;
    $("eRows").innerHTML = r.files.map(f =>
      `<tr><td><a href="${f.url}" download style="color:var(--txt)">${f.name}</a>
           <div class="note" style="margin:0">${fmtTime(f.mtime)}</div></td>
       <td><span class="pill ${f.kind}">${f.kind}</span></td>
       <td>${fmtSize(f.size)}</td>
       <td><a class="pill" href="${f.url}" download>↓</a>
           <button class="ghost sm" onclick="delExport('${f.name}')">✕</button></td></tr>`
    ).join("") || `<tr><td colspan="4" class="note">Nog geen bestanden —
      maak eerst iets in een van de andere tabbladen.</td></tr>`;
  } catch (e) { toast(e.message, true); }
}

async function delExport(name) {
  if (!confirm(`"${name}" verwijderen?`)) return;
  try {
    await fetch("/api/exports/" + encodeURIComponent(name), { method: "DELETE" });
    loadExports();
    toast("Verwijderd");
  } catch (e) { toast(e.message, true); }
}

// ---------- winkel ------------------------------------------------------
let WINKEL = { producten: [], inbox: [], instellingen: {} };

async function loadWinkel() {
  try {
    const r = await fetch("/api/winkel").then(x => x.json());
    WINKEL = r;
    const i = r.instellingen;
    if (!$("wRepo").value) $("wRepo").value = i.repo || "";
    if (!$("wBranch").value) $("wBranch").value = i.branch || "main";
    if (!$("wToken").value) $("wToken").value = i.github_token || "";
    if (!$("wTitel").value) $("wTitel").value = i.site_titel || "";
    if (!$("wOndertitel").value)
      $("wOndertitel").value = i.site_ondertitel || "";
    if ($("wAccent")) $("wAccent").value = i.accent || "#2fbf71";
    if (!$("wStats").value) $("wStats").value = i.stats_url || "";
    renderInbox();
    renderProducten();
    loadStats();
  } catch (e) { toast(e.message, true); }
}

async function slaWinkelInstellingen() {
  try {
    await post("/api/winkel/settings", {
      repo: $("wRepo").value.trim(),
      branch: $("wBranch").value.trim() || "main",
      site_titel: $("wTitel").value.trim(),
      site_ondertitel: $("wOndertitel").value.trim(),
      accent: $("wAccent") ? $("wAccent").value : "",
      github_token: $("wToken").value.trim(),
      stats_url: $("wStats").value.trim(),
    });
    toast("Instellingen opgeslagen");
  } catch (e) { toast(e.message, true); }
}

async function bouwWinkel() {
  try {
    const r = await post("/api/winkel/build", {});
    $("wResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Voorbeeld gebouwd — ${r.producten} product(en)</div>
      <a href="${r.preview_url}" target="_blank">Open de winkel-voorvertoning</a>
      — zo zien bezoekers hem.</div>`;
    toast("Voorbeeld gebouwd");
  } catch (e) { toast(e.message, true); }
}

async function publiceerWinkel() {
  $("wResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Bezig met publiceren naar GitHub…</div></div>`;
  try {
    const r = await post("/api/winkel/publish", {});
    $("wResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Gepubliceerd! (${r.bestanden} bestanden, commit ${r.commit})</div>
      Je winkel is zo live op:
      <a href="${r.url}" target="_blank">${r.url}</a><br>
      <span class="note">Eerste keer? Pages staat aan op
      Settings → Pages → Branch: main. Duurt ~1 minuut.</span></div>`;
    toast("Winkel gepubliceerd");
  } catch (e) {
    $("wResult").innerHTML = "";
    toast(e.message, true);
  }
}

// --- inbox / upload ------------------------------------------------------
function renderInbox() {
  $("wInboxCount").textContent = WINKEL.inbox.length;
  $("wInboxRows").innerHTML = WINKEL.inbox.map(f =>
    `<tr><td>${f.bestand}${f.bron === "gedeeld"
        ? ' <span class="pill" title="Afkomstig uit de gedeelde G2B-INBOX-map '
        + '(andere G2B-app)">📥 app</span>' : ""}</td>
     <td><span class="pill">${f.soort}</span></td>
     <td>${fmtSize(f.grootte)}</td>
     <td><button class="sm" onclick="inboxNaarWinkel('${f.bestand}','${f.soort}','${f.bron||'inbox'}')">
       ➜ in winkel zetten</button></td></tr>`
  ).join("") || `<tr><td colspan="4" class="note">Leeg — sleep een
    bestand hierboven in de dropzone, of zet er één in de gedeelde
    G2B-INBOX-map.</td></tr>`;
}

async function uploadNaarInbox(files) {
  for (const f of files) {
    const fd = new FormData();
    fd.append("bestand", f);
    try {
      await fetch("/api/winkel/upload", { method: "POST", body: fd })
        .then(async r => {
          if (!r.ok) throw new Error((await r.json()).detail || "fout");
        });
      toast(`${f.name} in inbox`);
    } catch (e) { toast(e.message, true); }
  }
  loadWinkel();
}

async function inboxNaarWinkel(bestand, soort, bron = "inbox") {
  const titel = bestand.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ");
  try {
    await post("/api/winkel/import", {
      bestand, titel, soort, prijs: "", beschrijving: "", bron });
    toast("Product aangemaakt — vul prijs en kooplink hieronder in");
    loadWinkel();
  } catch (e) { toast(e.message, true); }
}

const wDrop = $("wDrop");
wDrop.ondragover = e => { e.preventDefault(); wDrop.classList.add("over"); };
wDrop.ondragleave = () => wDrop.classList.remove("over");
wDrop.ondrop = e => {
  e.preventDefault(); wDrop.classList.remove("over");
  uploadNaarInbox(e.dataTransfer.files);
};
$("wFile").onchange = e => uploadNaarInbox(e.target.files);

// --- producten -----------------------------------------------------------
function renderProducten() {
  $("wProdCount").textContent = WINKEL.producten.length;
  $("wProdList").innerHTML = WINKEL.producten.map(p => {
    const cover = p.cover_eigen || p.cover || "";
    const prev = p.preview
      ? `<audio controls preload="none" style="width:100%;height:34px"
           src="/api/winkel/media/${p.id}/${p.preview}"></audio>`
      : `<span class="note">geen preview (digitaal product)</span>`;
    const splits = (p.splits || []).map((s, i) =>
      `<div class="splitsrow">
        <input data-pid="${p.id}" data-i="${i}" data-f="naam"
               value="${s.naam}" placeholder="naam">
        <input class="pct" data-pid="${p.id}" data-i="${i}" data-f="pct"
               type="number" min="0" max="100" value="${s.pct}">
        <span>%</span>
        <button class="ghost sm" onclick="splitWeg('${p.id}',${i})">✕</button>
      </div>`).join("");
    return `<div class="prodcard" id="prod-${p.id}">
      <div class="kop">
        <img class="cover" title="klik om eigen hoes te uploaden"
             src="/api/winkel/media/${p.id}/${cover}?v=${Date.now()}"
             onclick="$('cover-${p.id}').click()">
        <input type="file" id="cover-${p.id}" accept="image/*"
               class="hidden" onchange="uploadCover('${p.id}',this)">
        <div style="flex:1">
          <div class="row">
            <input id="t-${p.id}" value="${p.titel}" style="flex:2"
                   placeholder="titel">
            <input id="pr-${p.id}" value="${p.prijs || ""}"
                   placeholder="prijs, bv. € 14,95" style="flex:1">
            <label class="pill"><input type="checkbox" id="z-${p.id}"
              ${p.zichtbaar ? "checked" : ""}> zichtbaar</label>
          </div>
          <input id="b-${p.id}" value="${p.beschrijving || ""}"
                 placeholder="korte beschrijving voor op de winkelkaart"
                 style="width:100%;margin-top:6px">
          <div class="row" style="margin-top:6px">
            <label class="fl" style="max-width:240px"><span>Herkomst
              (voor jezelf)</span>
              <select id="h-${p.id}">
                <option value="eigen" ${p.herkomst === "eigen" ? "selected" : ""}>
                  100% eigen sound</option>
                <option value="samples" ${p.herkomst === "samples" ? "selected" : ""}>
                  met samples (bv. Cymatics)</option>
                <option value="mix" ${p.herkomst === "mix" ? "selected" : ""}>
                  mix / samenwerking</option>
              </select></label>
            <label class="fl" style="max-width:240px"><span>Vibe/groep
              (voor afspeellijsten)</span>
              <input id="g-${p.id}" value="${p.groep || ""}"
                     placeholder="bv. rustig, trap, soul"></label>
          </div>
        </div>
      </div>
      <div style="margin-top:8px">${prev}</div>
      <div class="velden">
        <label class="fl"><span>Kooplink (algemeen)</span>
          <input id="l-koop-${p.id}" value="${p.links?.koop || ""}"
                 placeholder="https://… betaallink"></label>
        <label class="fl"><span>Link MP3-lease · prijs</span>
          <input id="l-mp3-${p.id}" value="${p.links?.mp3 || ""}"
                 placeholder="betaallink"></label>
        <label class="fl"><span></span>
          <input id="p-mp3-${p.id}" value="${p.prijzen?.mp3 || ""}"
                 placeholder="bv. € 14,95"></label>
        <label class="fl"><span>Link WAV-licentie · prijs</span>
          <input id="l-wav-${p.id}" value="${p.links?.wav || ""}"
                 placeholder="betaallink"></label>
        <label class="fl"><span></span>
          <input id="p-wav-${p.id}" value="${p.prijzen?.wav || ""}"
                 placeholder="bv. € 29,95"></label>
        <label class="fl"><span>Link Exclusief (buy-out) · prijs</span>
          <input id="l-exc-${p.id}" value="${p.links?.exclusief || ""}"
                 placeholder="betaallink"></label>
        <label class="fl"><span></span>
          <input id="p-exc-${p.id}" value="${p.prijzen?.exclusief || ""}"
                 placeholder="bv. € 149,95"></label>
        <label class="fl"><span>Eigen download-URL (optioneel)</span>
          <input id="d-${p.id}" value="${p.download_url || ""}"
                 placeholder="bv. FileJump-deellink — leeg = auto-zip uit de winkel"></label>
      </div>
      <div class="bedankt">
        <span class="note" style="margin:0"><b>Bedankt-links</b> — plak bij
        je betaallink in Stripe/ChargeKeep bij "na betaling doorsturen".
        Koper landt dan op jouw downloadpagina.</span>
        ${["mp3","wav","exclusief"].map(k => `
          <div class="brow"><span>${k === "mp3" ? "MP3-lease" : k === "wav" ? "WAV" : "Exclusief"}</span>
            <input readonly value="${WINKEL.instellingen?.site_url || ""}bedankt.html?k=${p.sleutels?.[k] || ""}">
            <button class="ghost sm" onclick="kopieer(this)">📋</button>
          </div>`).join("")}
      </div>
      <div class="row" style="margin-top:10px;align-items:flex-start">
        <div style="flex:1;min-width:220px">
          <span class="note" style="margin:0"><b>Splits (royalties)</b>
          — samen 100%:</span>
          <div id="splits-${p.id}">${splits}</div>
          <button class="ghost sm" style="margin-top:4px"
                  onclick="splitBij('${p.id}')">+ persoon</button>
        </div>
        <div style="align-self:end">
          <button class="ghost sm" onclick="slaProduct('${p.id}')">
            Opslaan</button>
          <button class="ghost sm" onclick="delProduct('${p.id}')">
            ✕ verwijder</button>
        </div>
      </div>
    </div>`;
  }).join("") || `<div class="note">Nog geen producten — zet er een uit
    de inbox hierboven.</div>`;
}

function splitsLezen(pid) {
  const el = $(`splits-${pid}`);
  const rows = [...el.querySelectorAll(".splitsrow")];
  const naamEls = {}, pctEls = {};
  document.querySelectorAll(`input[data-pid="${pid}"]`).forEach(i => {
    (i.dataset.f === "naam" ? naamEls : pctEls)[i.dataset.i] = i;
  });
  return Object.keys(naamEls).map(i => ({
    naam: naamEls[i].value.trim(), pct: parseFloat(pctEls[i].value) || 0,
  }));
}

function splitBij(pid) {
  const el = $(`splits-${pid}`);
  const i = el.querySelectorAll(".splitsrow").length;
  el.insertAdjacentHTML("beforeend",
    `<div class="splitsrow">
      <input data-pid="${pid}" data-i="${i}" data-f="naam"
             placeholder="naam">
      <input class="pct" data-pid="${pid}" data-i="${i}" data-f="pct"
             type="number" min="0" max="100" value="0">
      <span>%</span>
      <button class="ghost sm" onclick="splitWeg('${pid}',${i},true)">✕</button>
    </div>`);
}

function splitWeg(pid, i, alleenRij) {
  const el = $(`splits-${pid}`);
  const rows = [...el.querySelectorAll(".splitsrow")];
  if (rows.length <= 1) { toast("Minstens 1 persoon nodig", true); return; }
  rows[i].remove();
  // indexen opnieuw nummeren
  [...el.querySelectorAll(".splitsrow")].forEach((r, j) => {
    r.querySelectorAll("input").forEach(inp => inp.dataset.i = j);
    r.querySelector("button").setAttribute(
      "onclick", `splitWeg('${pid}',${j})`);
  });
  if (!alleenRij) slaProduct(pid);   // meteen opslaan
}

async function slaProduct(pid) {
  try {
    await fetch(`/api/winkel/product/${pid}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        titel: $(`t-${pid}`).value.trim(),
        beschrijving: $(`b-${pid}`).value.trim(),
        prijs: $(`pr-${pid}`).value.trim(),
        zichtbaar: $(`z-${pid}`).checked,
        download_url: $(`d-${pid}`).value.trim(),
        herkomst: $(`h-${pid}`).value,
        groep: $(`g-${pid}`).value.trim(),
        prijzen: {
          mp3: $(`p-mp3-${pid}`).value.trim(),
          wav: $(`p-wav-${pid}`).value.trim(),
          exclusief: $(`p-exc-${pid}`).value.trim(),
        },
        links: {
          koop: $(`l-koop-${pid}`).value.trim(),
          mp3: $(`l-mp3-${pid}`).value.trim(),
          wav: $(`l-wav-${pid}`).value.trim(),
          exclusief: $(`l-exc-${pid}`).value.trim(),
        },
        splits: splitsLezen(pid),
      }),
    }).then(async r => {
      if (!r.ok) throw new Error((await r.json()).detail || "fout");
    });
    toast("Product opgeslagen");
    loadWinkel();
  } catch (e) { toast(e.message, true); }
}

async function uploadCover(pid, input) {
  const f = input.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append("bestand", f);
  try {
    await fetch(`/api/winkel/product/${pid}/cover`,
                { method: "POST", body: fd })
      .then(async r => {
        if (!r.ok) throw new Error((await r.json()).detail || "fout");
      });
    toast("Hoes opgeslagen");
    loadWinkel();
  } catch (e) { toast(e.message, true); }
}

async function delProduct(pid) {
  if (!confirm("Dit product uit de winkel halen? (bestand wordt ook " +
               "verwijderd — downloaden uit Bestanden blijft)")) return;
  try {
    await fetch(`/api/winkel/product/${pid}`, { method: "DELETE" });
    toast("Product verwijderd — publiceer opnieuw om live te zetten");
    loadWinkel();
  } catch (e) { toast(e.message, true); }
}

// ---------- royalties ----------------------------------------------------
let ROYALTY = { verkopen: [], saldi: {}, uitbetalingen: [], producten: [] };

async function loadRoyalty() {
  try {
    const r = await fetch("/api/royalty").then(x => x.json());
    ROYALTY = r;
    // product-dropdown voor verkoop-invoer
    $("rProduct").innerHTML =
      `<option value="">— overige / losse verkoop —</option>` +
      r.producten.map(p =>
        `<option value="${p.id}">${p.titel}</option>`).join("");
    // saldi
    const namen = Object.keys(r.saldi);
    $("rSaldi").innerHTML = namen.map(n => {
      const s = r.saldi[n];
      return `<tr><td><b>${n}</b></td>
        <td>€ ${s.verdiend.toFixed(2)}</td>
        <td>€ ${s.uitbetaald.toFixed(2)}</td>
        <td><b>€ ${s.tegoed.toFixed(2)}</b></td>
        <td>${s.tegoed > 0
          ? `<button class="sm" onclick="betaalUit('${n}')">
              Betaal uit + PDF</button>` : ""}</td></tr>`;
    }).join("") || `<tr><td colspan="5" class="note">Nog geen
      royalties — boek je eerste verkoop hieronder.</td></tr>`;
    // verkopen
    $("rCount").textContent = r.verkopen.length;
    $("rVerkopen").innerHTML = r.verkopen.slice().reverse().map(v =>
      `<tr><td>${v.datum}</td><td>${v.titel}</td>
       <td>€ ${v.brutto.toFixed(2)}</td><td>€ ${v.netto.toFixed(2)}</td>
       <td>${v.verdeling.map(d => `${d.naam} €${d.bedrag.toFixed(2)}`)
         .join("<br>")}</td>
       <td><button class="ghost sm"
         onclick="delVerkoop(${v.id})">✕</button></td></tr>`
    ).join("") || `<tr><td colspan="6" class="note">Nog geen
      verkopen.</td></tr>`;
    // uitbetalingen
    $("rUitbetalingen").innerHTML = r.uitbetalingen.map(u =>
      `<tr><td>${u.datum}</td><td>${u.persoon}</td>
       <td>€ ${u.bedrag.toFixed(2)}</td>
       <td><a class="pill" href="/api/download/${u.pdf}" download>
         ${u.pdf}</a></td></tr>`
    ).join("") || `<tr><td colspan="4" class="note">Nog geen
      uitbetalingen.</td></tr>`;
  } catch (e) { toast(e.message, true); }
}

async function boekVerkoop() {
  const brutto = parseFloat($("rBrutto").value);
  if (!brutto || brutto <= 0) { toast("Vul een brutobedrag in", true); return; }
  try {
    const r = await post("/api/royalty/verkoop", {
      datum: $("rDatum").value.trim(),
      product_id: $("rProduct").value,
      titel: $("rProduct").selectedOptions[0]?.textContent
             .replace("— overige / losse verkoop —", "") || "",
      brutto, fee: parseFloat($("rFee").value) || 0,
      notitie: $("rNotitie").value.trim(),
    });
    const v = r.verkoop;
    $("rResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Verkoop geboekt — netto € ${v.netto.toFixed(2)}</div>
      ${v.verdeling.map(d => `${d.naam}: € ${d.bedrag.toFixed(2)}`)
        .join(" · ")}</div>`;
    $("rBrutto").value = ""; $("rFee").value = ""; $("rNotitie").value = "";
    loadRoyalty();
    toast("Verkoop geboekt");
  } catch (e) { toast(e.message, true); }
}

async function importeerCsv() {
  const f = $("rCsv").files[0];
  if (!f) { toast("Kies eerst een CSV-bestand", true); return; }
  const fd = new FormData();
  fd.append("bestand", f);
  try {
    const r = await fetch("/api/royalty/import",
                          { method: "POST", body: fd })
      .then(async x => {
        const d = await x.json();
        if (!x.ok) throw new Error(d.detail || "fout");
        return d;
      });
    $("rCsvResult").innerHTML = `<div class="result"><div class="titel">
      ✔ ${r.toegevoegd} verkopen geïmporteerd
      ${r.overgeslagen ? `· ${r.overgeslagen} overgeslagen` : ""}</div>
      </div>`;
    loadRoyalty();
    toast("CSV geïmporteerd");
  } catch (e) { toast(e.message, true); }
}

async function betaalUit(naam) {
  if (!confirm(`Tegoed van ${naam} uitbetalen en royalty-PDF maken?`))
    return;
  try {
    const r = await post("/api/royalty/uitbetaling", { persoon: naam });
    $("rResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Uitbetaling geboekt — € ${r.bedrag.toFixed(2)}</div>
      <a href="${r.url}" download>${r.pdf}</a> — stuur dit overzicht
      mee aan ${naam}.</div>`;
    loadRoyalty();
    toast("Uitbetaling geboekt");
  } catch (e) { toast(e.message, true); }
}

async function delVerkoop(vid) {
  if (!confirm("Deze verkoop verwijderen?")) return;
  try {
    await fetch(`/api/royalty/verkoop/${vid}`, { method: "DELETE" });
    loadRoyalty();
    toast("Verkoop verwijderd");
  } catch (e) { toast(e.message, true); }
}

// ---------- backup / restore ----------------------------------------------
function downloadBackup() {
  window.location = "/api/backup";
  toast("Backup-ZIP wordt gedownload");
}

$("restoreFile")?.addEventListener("change", async e => {
  const f = e.target.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append("file", f);
  try {
    const r = await fetch("/api/restore", { method: "POST", body: fd });
    const d = await r.json();
    if (!r.ok) throw new Error(d.detail || "fout " + r.status);
    toast(`Teruggezet: ${d.aantal} bestanden`);
    loadExports();
    loadSettings();
  } catch (err) { toast(err.message, true); }
  e.target.value = "";
});

// ---------- luistercijfers (echte views) ----------------------------------
function _fmtSec(sec) {
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return m + ":" + String(s).padStart(2, "0");
}

async function loadStats() {
  try {
    const r = await fetch("/api/winkel/stats").then(x => x.json());
    // product-dropdown vullen
    const sel = $("stProduct");
    if (sel) {
      sel.innerHTML =
        WINKEL.producten.map(p =>
          `<option value="${p.id}">${p.titel}</option>`).join("") +
        `<option value="overig">— overig/vrije naam —</option>`;
    }
    $("stRows").innerHTML = r.rijen.map(x =>
      `<tr><td>${x.titel}</td><td>${x.plays}</td>
       <td>${_fmtSec(x.seconden)} (${x.minuten} min)</td>
       <td>${_fmtSec(x.gemiddeld)}</td><td>${_fmtSec(x.langste)}</td></tr>`
    ).join("") || `<tr><td colspan="5" class="note">Nog geen
      luister-data — voeg een beurt toe of importeer je
      stats-bestand.</td></tr>`;
    const tot = r.totaal_plays ? ` — <b>${r.totaal_plays}</b> plays ·
      <b>${r.totaal_minuten} min</b> echt geluisterd` : "";
    $("stRows").innerHTML += tot
      ? `<tr class="totaal"><td><b>Totaal</b></td><td><b>${r.totaal_plays}</b></td>
         <td><b>${_fmtSec(r.totaal_seconden)}</b></td><td colspan="2"></td></tr>`
      : "";
  } catch (e) { /* stats-tab hoeft niet te falen */ }
}

async function voegStatToe() {
  const sel = $("stProduct");
  let product = sel.value;
  if (product === "overig") {
    product = prompt("Naam van de track/product:") || "onbekend";
  }
  const sec = parseFloat($("stSeconden").value);
  if (!sec || sec <= 0) {
    toast("Vul het aantal écht geluisterde seconden in", true); return;
  }
  try {
    await post("/api/winkel/stats", { product, seconden: sec });
    $("stSeconden").value = "";
    toast("Luisterbeurt opgeslagen");
    loadStats();
  } catch (e) { toast(e.message, true); }
}

$("stFile")?.addEventListener("change", async e => {
  const f = e.target.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append("bestand", f);
  try {
    const r = await fetch("/api/winkel/stats/import",
      { method: "POST", body: fd }).then(x => x.json());
    toast(`Stats: ${r.toegevoegd} regels toegevoegd` +
      (r.overgeslagen ? ` (${r.overgeslagen} overgeslagen)` : ""));
    loadStats();
  } catch (err) { toast(err.message, true); }
  e.target.value = "";
});

async function maakStatsRapport() {
  try {
    const r = await post("/api/winkel/stats/rapport", {});
    $("stResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Sponsor-rapport klaar</div>
      <a href="${r.url}" download>${r.file}</a> — stuur deze PDF naar je
      sponsor of partner.</div>`;
    toast("Rapport gemaakt");
    loadExports();
  } catch (e) { toast(e.message, true); }
}

// ---------- videoboek -----------------------------------------------------
let VIDEOBOEKEN = [];

$("vbBoek")?.addEventListener("change", e => {
  $("vbBoekNaam").textContent = e.target.files[0]?.name || "";
});
$("vbAudio")?.addEventListener("change", e => {
  $("vbAudioNaam").textContent = e.target.files[0]?.name || "";
});
$("vbIntBoek")?.addEventListener("change", e => {
  $("vbIntBoekNaam").textContent = e.target.files[0]?.name || "";
});

async function loadVideoboeken() {
  try {
    const r = await fetch("/api/videoboek").then(x => x.json());
    VIDEOBOEKEN = r.videoboeken || [];
    $("vbCount").textContent = VIDEOBOEKEN.length;
    $("vbRows").innerHTML = VIDEOBOEKEN.map(v =>
      `<tr><td>${v.titel}</td>
       <td>${v.paginas}</td>
       <td>${v.gemaakt}</td>
       <td>
        <a class="pill" href="/videoboeken/${v.id}/index.html"
           target="_blank" style="text-decoration:none">▶ speel af</a>
        <button class="ghost sm" onclick="videoboekZip('${v.id}')">⬇ ZIP</button>
        ${v.interactief ? "" :
        `<button class="ghost sm" onclick="videoboekMp4('${v.id}')">🎬 mp4</button>`}
        <button class="ghost sm" onclick="videoboekSite('${v.id}')"
          title="Publiceer op GS Books">🌐 site</button>
        ${v.site_url ? `<a class="pill" href="${v.site_url}"
          target="_blank" style="text-decoration:none">🔗</a>` : ""}
        <button class="ghost sm" onclick="videoboekWinkel('${v.id}')"
          title="Verkoopproduct in de winkel">🛒</button>
        ${v.site_url ? `<button class="ghost sm" onclick="videoboekVanSite('${v.id}')"
          title="Haal dit videoboek ook van GS Books af">🌐✕</button>` : ""}
        <button class="ghost sm" onclick="videoboekDel('${v.id}')">🗑</button>
       </td></tr>`
    ).join("") || `<tr><td colspan="4" class="note">Nog geen
      videoboeken — maak er hierboven één van je boek + audio.</td></tr>`;
  } catch (e) { toast(e.message, true); }
}

async function maakVideoboek() {
  const boek = $("vbBoek").files[0];
  const audio = $("vbAudio").files[0];
  if (!boek) return toast("Kies eerst je boek (.epub of .zip)", true);
  if (!audio) return toast("Kies je voorlees-audio (mp3)", true);
  const fd = new FormData();
  fd.append("titel", $("vbTitel").value.trim() || boek.name);
  fd.append("plaatjes", parseInt($("vbPlaatjes")?.value || "0") || 0);
  fd.append("boek", boek);
  fd.append("audio", audio);
  $("vbResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Bezig: boekpagina's eruit halen en speler bouwen…</div></div>`;
  try {
    const r = await fetch("/api/videoboek", { method: "POST", body: fd })
      .then(async x => {
        const j = await x.json();
        if (!x.ok) throw new Error(j.detail || "mislukt");
        return j;
      });
    $("vbResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Videoboek klaar — ${r.videoboek.paginas} pagina's!</div>
      <a href="${r.preview}" target="_blank">▶ Bekijk je videoboek</a>
      <span class="note">— of download de ZIP bij "Gemaakte videoboeken"
      voor op je site of als verkoopproduct.</span></div>`;
    toast("Videoboek gemaakt");
    loadVideoboeken();
  } catch (e) {
    $("vbResult").innerHTML = "";
    toast(e.message, true);
  }
}

const VB_VOORBEELD = `# Kies-je-eigen-avontuur verhaal
# platen: nummers van de plaatjes uit je boek (1 = eerste plaatje)
# SCENE zonder KEUZE = einde

SCENE start
platen: 1, 2
tekst: Keesje vindt een spoor in het bos. Welke kant gaat hij op?
KEUZE "🏞️ Naar de rivier" -> rivier
KEUZE "⛰️ De berg op" -> berg

SCENE rivier
platen: 3, 4
tekst: Bij de rivier vindt Keesje de verdwenen eend — veilig thuis gebracht!

SCENE berg
platen: 3, 4
tekst: Op de berg vindt Keesje een adelaar met het eende-ei — ook veilig!
`;

const VB_VOORBEELD_INTERVIEW = `# "Vraag het aan"-interview verhaal
# De hub-scene heeft de vragen; elk antwoord-scene eindigt met
# TERUG: hub — dan komt de "↩ Stel nog een vraag"-knop.
# Zo loopt het gesprek door tot het kind op "🔁 Opnieuw" drukt.

SCENE hub
platen: 1
tekst: Stel jouw held een vraag! Kies er een:
KEUZE "Hoe ben jij een held geworden?" -> v1
KEUZE "Ben jij wel eens bang?" -> v2
KEUZE "Wat is jouw beste raad?" -> v3
KEUZE "Wil jij mijn vriend zijn?" -> v4

SCENE v1
platen: 2
tekst: Door altijd te helpen, ook als het spannend is!
TERUG: hub

SCENE v2
platen: 3
tekst: Natuurlijk! Maar echte helden gaan toch verder.
TERUG: hub

SCENE v3
platen: 4
tekst: Vraag hulp als je het niet alleen kunt — dat is slim, niet zwak.
TERUG: hub

SCENE v4
platen: 2
tekst: Ja! Elke held heeft een vriend zoals jij nodig.
TERUG: hub
`;

function vbVoorbeeld(interview) {
  $("vbIntVerhaal").value = interview ? VB_VOORBEELD_INTERVIEW : VB_VOORBEELD;
  toast("Voorbeeld gevuld — pas de tekst aan voor jouw boek");
}

function vbVerhaalDownload() {
  const txt = $("vbIntVerhaal").value || VB_VOORBEELD;
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([txt], { type: "text/plain" }));
  a.download = "verhaal.txt"; a.click();
}

async function maakInteractief() {
  const boek = $("vbIntBoek").files[0];
  const verhaalTxt = $("vbIntVerhaal").value.trim();
  if (!boek) return toast("Kies eerst je boek (.epub of .zip)", true);
  if (!verhaalTxt) return toast("Schrijf of plak eerst je verhaal met SCENE's en KEUZE's", true);
  const fd = new FormData();
  fd.append("titel", $("vbIntTitel").value.trim() || boek.name);
  fd.append("boek", boek);
  fd.append("verhaal", new Blob([verhaalTxt], { type: "text/plain" }), "verhaal.txt");
  fd.append("stem", $("vbIntStem")?.checked ? "true" : "false");
  $("vbIntResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Bezig: scène's + stem + speler bouwen…</div></div>`;
  try {
    const r = await fetch("/api/videoboek/interactief", { method: "POST", body: fd })
      .then(async x => {
        const j = await x.json();
        if (!x.ok) throw new Error(j.detail || "mislukt");
        return j;
      });
    $("vbIntResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Interactief videoboek klaar — ${r.videoboek.paginas} scène's!</div>
      <a href="${r.preview}" target="_blank">▶ Speel je interactieve videoboek</a>
      <span class="note">— kijkers kiezen zelf het pad. ZIP staat bij
      "Gemaakte videoboeken".</span></div>`;
    toast("Interactief videoboek gemaakt");
    loadVideoboeken();
  } catch (e) {
    $("vbIntResult").innerHTML = "";
    toast(e.message, true);
  }
}

async function videoboekZip(vid) {
  try {
    const r = await fetch(`/api/videoboek/${vid}/zip`).then(x => x.json());
    if (r.url) {
      const a = document.createElement("a");
      a.href = r.url; a.download = r.file; a.click();
      toast("ZIP gedownload — staat ook bij BESTANDEN");
    }
  } catch (e) { toast(e.message, true); }
}

async function videoboekMp4(vid) {
  toast("MP4-render gestart — dit duurt even (elke pagina wordt een clip)");
  try {
    await fetch(`/api/videoboek/${vid}/mp4`, { method: "POST" });
    const t = setInterval(async () => {
      const r = await fetch(`/api/videoboek/${vid}/mp4`).then(x => x.json());
      if (r.status && r.status.startsWith("klaar")) {
        clearInterval(t);
        const a = document.createElement("a");
        a.href = r.url; a.download = r.file; a.click();
        toast("MP4 klaar — gedownload, staat ook bij BESTANDEN");
      } else if (r.status && r.status.startsWith("fout")) {
        clearInterval(t);
        toast("MP4 mislukt: " + (r.fout || ""), true);
      }
    }, 3000);
  } catch (e) { toast(e.message, true); }
}

async function videoboekSite(vid) {
  toast("Publiceren naar GS Books — even wachten…");
  try {
    const r = await fetch(`/api/videoboek/${vid}/site`,
                          { method: "POST" }).then(async x => {
      const j = await x.json();
      if (!x.ok) throw new Error(j.detail || "mislukt");
      return j;
    });
    toast("Live op GS Books!");
    window.open(r.url, "_blank");
    loadVideoboeken();
  } catch (e) { toast(e.message, true); }
}

async function videoboekWinkel(vid) {
  const prijs = prompt("Prijs voor dit videoboek? (bv. 4.99 — leeg = later invullen)");
  if (prijs === null) return;
  try {
    const fd = new FormData();
    fd.append("prijs", prijs);
    const r = await fetch(`/api/videoboek/${vid}/winkel`,
                          { method: "POST", body: fd }).then(async x => {
      const j = await x.json();
      if (!x.ok) throw new Error(j.detail || "mislukt");
      return j;
    });
    toast("In de winkel gezet — check tab WINKEL en publiceer");
    loadInbox?.(); loadProducten?.();
  } catch (e) { toast(e.message, true); }
}

async function videoboekDel(vid) {
  const v = (VIDEOBOEKEN || []).find(x => x.id === vid) || {};
  if (!confirm("Dit videoboek verwijderen?")) return;
  try {
    if (v.site_url && confirm(
        "Hij staat ook op GS Books — daar ook weghalen?")) {
      const r = await fetch(`/api/videoboek/${vid}/van-site`,
                            { method: "POST" });
      if (!r.ok) toast("Van site halen mislukte — lokaal gaat door", true);
    }
    await fetch(`/api/videoboek/${vid}`, { method: "DELETE" });
    toast("Verwijderd");
    loadVideoboeken();
  } catch (e) { toast(e.message, true); }
}

async function videoboekVanSite(vid) {
  if (!confirm("Dit videoboek van GS Books halen?\n\n" +
               "Het bestand blijft hier staan — alleen de site-versie " +
               "verdwijnt.")) return;
  try {
    const r = await fetch(`/api/videoboek/${vid}/van-site`,
                          { method: "POST" });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || "mislukt");
    toast(`Van site gehaald (${j.verwijderd} bestanden)`);
    loadVideoboeken();
  } catch (e) { toast(e.message, true); }
}

// ---------- kleurboek -----------------------------------------------------
let KLEURPLATEN = [];

async function loadKleurboek() {
  try {
    const r = await fetch("/api/kleurboek").then(x => x.json());
    KLEURPLATEN = r.paginas || [];
    // bewaar de aangevinkte selectie over een herlaad heen (bijv. na een
    // 🖼/🚫-kaft-klik) — eerst geladen = alles aan zoals voorheen
    const wasAan = new Set(
      [...document.querySelectorAll(".kbChk:checked")].map(c => c.value));
    const eersteLading = !document.querySelector(".kbChk");
    // AI-tekenrij alleen tonen als een GPU-worker is ingesteld
    if ($("kbGenRow")) $("kbGenRow").style.display =
      r.genereer ? "" : "none";
    $("kbCount").textContent = KLEURPLATEN.length;
    $("kbGrid").innerHTML = KLEURPLATEN.map(p =>
      `<div class="item">
        <img src="/api/kleurboek/media/${p.naam}" loading="lazy">
        <label style="display:flex;gap:6px;align-items:center;margin-top:6px">
          <input type="checkbox" class="kbChk" value="${p.id}"
                 ${eersteLading || wasAan.has(p.id) ? "checked" : ""}
                 style="width:auto">
          <span class="nm">${p.bron}${p.boek ? " · " + p.boek : ""}</span>
        </label>
        <button class="ghost sm" onclick="kbKaftUit('${p.id}', ${!p.kaft_uit})"
                title="${p.kaft_uit ? 'weer TOELATEN op de kaft' : 'NIET op de kaft gebruiken (wel als kleurplaat)'}">${p.kaft_uit ? '🚫 uit kaft' : '🖼 kaft'}</button>
        <button class="ghost sm" onclick="delKleurplaat('${p.id}')"
                title="kleurplaat verwijderen">🗑</button>
      </div>`
    ).join("") || `<div class="note">Nog geen kleurplaten — kies
      hierboven boekplaten om te beginnen.</div>`;
  } catch (e) { toast(e.message, true); }
}

function kbAlle(aan) {
  document.querySelectorAll(".kbChk").forEach(c => c.checked = aan);
}

// plaat uit de kaft houden (wel als kleurplaat binnenin) — voor
// auteur/promo-platen of platen die jij niet mooi vindt voor de kaft
async function kbKaftUit(pid, uit) {
  await fetch("/api/kleurboek/kaft-uit", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: pid, uit }),
  }).then(x => x.json());
  loadKleurboek();
}

async function uploadKleurplaten(files) {
  if (!files.length) return;
  const fd = new FormData();
  for (const f of files) fd.append("bestanden", f);
  fd.append("boek", $("kbBoek").value.trim());
  $("kbStatus").textContent = "⏳ bezig met lijntekeningen maken…";
  try {
    const r = await fetch("/api/kleurboek/upload", { method: "POST", body: fd })
      .then(async x => {
        const j = await x.json();
        if (!x.ok) throw new Error(j.detail || "mislukt");
        return j;
      });
    $("kbStatus").textContent = `✔ ${r.nieuw.length} kleurplaat(s) gemaakt`;
    toast("Kleurplaten gemaakt");
    loadKleurboek();
  } catch (e) {
    $("kbStatus").textContent = "❌ " + e.message;
    toast(e.message, true);
  }
}

$("kbPlaten").onchange = e => uploadKleurplaten(e.target.files);

// boek-kaft gekozen? dan de pagina-teller laten zien (rugdikte)
$("kbSoort").onchange = () => {
  const boek = ($("kbSoort").value || "").startsWith("boek");
  $("kbPagWrap").hidden = !boek;
  $("kbBlurbWrap").hidden = !boek;
};

// zelf-maak-stap: beschrijf een plaat → de pod tekent hem (FLUX-schnell)
async function genereerPlaat() {
  const prompt = $("kbPrompt").value.trim();
  if (!prompt) return toast("Beschrijf eerst de plaat", true);
  $("kbGenStatus").textContent =
    "⏳ de Fabriek tekent… (~1 min, pod-centen)";
  try {
    const r = await fetch("/api/kleurboek/genereer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, boek: $("kbBoek").value.trim() }),
    }).then(async x => {
      const j = await x.json();
      if (!x.ok) throw new Error(j.detail || "mislukt");
      return j;
    });
    $("kbGenStatus").textContent =
      `✔ ${r.nieuw.length} eigen plaat(jes) getekend`;
    $("kbPrompt").value = "";
    toast("Eigen plaat getekend!");
    loadKleurboek();
  } catch (e) {
    $("kbGenStatus").textContent = "❌ " + e.message;
    toast(e.message, true);
  }
}

function boekKleurboek() {
  // 1-klik verzamel-kleurboek: alle platen van het ingevulde boek/serie
  const boek = $("kbBoek").value.trim();
  if (!boek) return toast("Vul eerst een boek/serie in");
  const ids = KLEURPLATEN.filter(p =>
    (p.boek || "").toLowerCase().includes(boek.toLowerCase())).map(p => p.id);
  if (!ids.length) return toast(`Geen platen gevonden voor "${boek}"`);
  document.querySelectorAll(".kbChk").forEach(c => {
    c.checked = ids.includes(c.value);
  });
  if (!$("kbTitel").value.trim()) $("kbTitel").value = `${boek} Kleurboek`;
  maakKleurboek();
}

// 📦 bundel: alle boeken samen in één verzamel-kleurboek — de machine
// zet er per boek een hoofdstuk-scheidingspagina bij + bundel-kaft-tint
function kbBundel() {
  const ids = KLEURPLATEN.filter(p => (p.boek || "").trim()).map(p => p.id);
  const boeken = new Set(KLEURPLATEN.map(p => (p.boek || "").trim())
    .filter(Boolean));
  if (boeken.size < 2) {
    return toast("Upload eerst platen van 2 of meer boeken voor een bundel",
                 true);
  }
  document.querySelectorAll(".kbChk").forEach(c => {
    c.checked = ids.includes(c.value);
  });
  if (!$("kbTitel").value.trim()) {
    $("kbTitel").value = "Animal Heroes Verzamelkleurboek";
  }
  maakKleurboek();
}

// 📖 boek-binnenkant: aangevinkte platen (volgorde = volgorde in het
// raster) + je verhaal-alinea's → print-klare A5/6x9 binnenkant.
// Het echte pagina-aantal vult meteen de kaft-rugdikte.
async function maakBoekPdf() {
  const paginas = [...document.querySelectorAll(".kbChk:checked")]
    .map(c => c.value);
  const verhaal = ($("kbVerhaal")?.value || "").trim();
  if (!paginas.length && !verhaal) {
    return toast("Vink platen aan én/of schrijf je verhaal erboven", true);
  }
  // kaft-keuze = boek? gebruik dat formaat; anders standaard A5
  // (een echte boek-binnenkant is geen A4-kleurboekformaat)
  const ks = kbKaftSoort();
  const formaat = ks.soort === "boek" ? ks.formaat : "a5";
  const r = await fetch("/api/kleurboek/boek", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      titel: $("kbTitel").value.trim() || "Animal Heroes",
      ondertitel: $("kbSub").value.trim(),
      merk: $("kbMerk").value, formaat, verhaal, paginas,
    }),
  }).then(async x => {
    const j = await x.json();
    if (!x.ok) throw new Error(j.detail || "mislukt");
    return j;
  }).catch(e => { toast(e.message, true); });
  if (!r) return;
  // echte pagina-telling → kaft krijgt de juiste rugdikte
  if ($("kbPaginas")) $("kbPaginas").value = r.paginas;
  $("kbResult").innerHTML = `
    <div class="ok">✔ Boek-binnenkant klaar — ${r.paginas} pagina's!
    <a href="${r.download}">⬇ ${r.bestand}</a>
    <span class="note">— zet "Kaft voor" op ${formaat === "6x9" ?
      "Boek 6×9" : "Boek A5"} en maak de 🖨️ Print-kaft: de rug is nu
      automatisch ${r.paginas} pagina's dik.</span></div>`;
  toast("Boek-binnenkant gemaakt");
}

// "Kaft opnieuw": elke klik bouwt een ANDERE kaft — eerst alle scenes in
// dezelfde stijl doorlopen, daarna de volgende stijl (jij klikt tot hij
// mooi is; het templet kies je zelf, de scene wisselt de machine).
const KAFT_STIJLEN = ["geheel", "cozy", "feest", "stripboek"];
let kaftSeed = 0;
let kbSeed = 0;

function kaftOpnieuw() {
  kaftSeed++;
  return maakKaft();
}

function kbBoekOpnieuw() {
  kbSeed++;
  return maakKleurboek();
}

function kaftStijlWissel() {
  const sel = $("kbStyle");
  sel.value = KAFT_STIJLEN[(KAFT_STIJLEN.indexOf(sel.value) + 1)
                           % KAFT_STIJLEN.length];
  return maakKaft();
}

// Kaft voor: 'kleurboek:a4' of 'boek:a5' / 'boek:6x9' → soort + formaat
function kbKaftSoort() {
  const [soort, formaat] = ($("kbSoort").value || "kleurboek:a4").split(":");
  return { soort, formaat,
           pagina_aantal: soort === "boek"
             ? (parseInt($("kbPaginas").value) || 48) : null,
           blurb: soort === "boek" ? $("kbBlurb").value.trim() : "" };
}

async function maakKaft() {
  const paginas = [...document.querySelectorAll(".kbChk:checked")]
    .map(c => c.value);
  if (!paginas.length) return toast("Vink eerst kleurplaten aan", true);
  $("kbResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Print-kaft wordt gebouwd…</div></div>`;
  try {
    const ks = kbKaftSoort();
    const r = await fetch("/api/kleurboek/kaft", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        titel: $("kbTitel").value.trim() || "G2B Kleurboek",
        ondertitel: $("kbSub").value.trim(),
        boek: $("kbBoek").value.trim(),
        merk: $("kbMerk").value,
        variant: $("kbStyle").value,
        seed: kaftSeed,
        soort: ks.soort, formaat: ks.formaat,
        pagina_aantal: ks.pagina_aantal, blurb: ks.blurb,
        paginas,
      }),
    }).then(async x => {
      const j = await x.json();
      if (!x.ok) throw new Error(j.detail || "mislukt");
      return j;
    });
    $("kbResult").innerHTML = `<div class="result"><div class="titel">
      🖨️ Print-kaft klaar!</div>
      <div>achterkant + rug + voorkant, met afsnijmarge — klaar voor drukker</div>
      <a href="${r.download}" class="dl">⬇️ Download kaft-PDF</a>
      ${r.voorkant ? `<a href="${r.voorkant}" class="dl">⬇️ Voorkant als plaatje (winkel)</a>` : ""}
      </div>`;
    toast("Print-kaft klaar!");
  } catch (e) {
    $("kbResult").innerHTML = `<div class="result fout">⚠️ ${e.message}</div>`;
  }
}

async function maakKleurboek() {
  const paginas = [...document.querySelectorAll(".kbChk:checked")]
    .map(c => c.value);
  if (!paginas.length) return toast("Vink eerst kleurplaten aan", true);
  if (paginas.length < 10)
    toast("Tip: minder dan 10 platen voelt dun — echte kleurboeken hebben er ~20-50", false);
  $("kbResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Kleurboek-PDF wordt gebouwd…</div></div>`;
  try {
    const r = await fetch("/api/kleurboek/pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        titel: $("kbTitel").value.trim() || "G2B Kleurboek",
        ondertitel: $("kbSub").value.trim(),
        boek: $("kbBoek").value.trim(),
        merk: $("kbMerk").value,
        variant: $("kbStyle").value,
        seed: kbSeed,
        paginas,
      }),
    }).then(async x => {
      const j = await x.json();
      if (!x.ok) throw new Error(j.detail || "mislukt");
      return j;
    });
    $("kbResult").innerHTML = `<div class="result"><div class="titel">
      ✔ Kleurboek klaar — ${paginas.length} kleurplaten!</div>
      <a href="${r.download}">⬇ Download ${r.bestand}</a>
      <span class="note">— staat ook bij tab 📁 BESTANDEN.</span></div>`;
    toast("Kleurboek gebouwd");
  } catch (e) {
    $("kbResult").innerHTML = "";
    toast(e.message, true);
  }
}

// 1-klik verkoop: kleurboek + print-kaft + voorkant als ZIP in de winkel
async function kbNaarWinkel() {
  const paginas = [...document.querySelectorAll(".kbChk:checked")]
    .map(c => c.value);
  if (!paginas.length) return toast("Vink eerst kleurplaten aan", true);
  const prijs = prompt("Verkoopprijs in euro (bijv. 9,95) — leeg = later invullen", "9,95");
  if (prijs === null) return;
  $("kbResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Winkel-pakket wordt gebouwd…</div></div>`;
  try {
    const r = await fetch("/api/kleurboek/winkel", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        titel: $("kbTitel").value.trim() || "G2B Kleurboek",
        ondertitel: $("kbSub").value.trim(),
        boek: $("kbBoek").value.trim(),
        merk: $("kbMerk").value,
        variant: $("kbStyle").value,
        seed: kaftSeed,
        prijs: prijs.trim(),
        soort: "kleurboek", formaat: "a4",   // winkel = altijd kleurboek
        paginas,
      }),
    }).then(async x => {
      const j = await x.json();
      if (!x.ok) throw new Error(j.detail || "mislukt");
      return j;
    });
    $("kbResult").innerHTML = `<div class="result"><div class="titel">
      🛒 "${r.product.titel}" staat in de winkel!</div>
      <div>Kleurboek + print-kaft + voorkant als één ZIP, met de kaft als
      productfoto. Publiceer je winkel via de 🎵 WINKEL-tab.</div></div>`;
    toast("Kleurboek staat in de winkel!");
  } catch (e) {
    $("kbResult").innerHTML = `<div class="result fout">⚠️ ${e.message}</div>`;
  }
}

async function kbNaarKleurStudio() {
  // 1 klik: álle kleurplaten als webversie naar GS Books KleurStudio
  // (gsbooks/kleur/platen + platen.json via dezelfde GitHub-publish
  // als videoboeken — repo + token uit WINKEL-instellingen).
  if (!confirm("Alle kleurplaten als webversie naar GS Books KleurStudio?\n\n" +
               "Dit overschrijft platen/ + platen.json op de site.")) return;
  $("kbResult").innerHTML = `<div class="result"><div class="titel">
    ⏳ Platen naar KleurStudio…</div></div>`;
  try {
    const r = await fetch("/api/kleurboek/kleurstudio", { method: "POST" })
      .then(async x => {
        const j = await x.json();
        if (!x.ok) throw new Error(j.detail || "mislukt");
        return j;
      });
    $("kbResult").innerHTML = `<div class="result"><div class="titel">
      🎨 ${r.platen} kleurplaten staan nu in de KleurStudio!</div>
      <div>Online inkleuren op:
      <a href="${r.url}" target="_blank" style="color:var(--accent)">${r.url}</a>
      (GitHub Pages doet er enkele minuten over)</div></div>`;
    toast("KleurStudio bijgewerkt!");
  } catch (e) {
    $("kbResult").innerHTML = `<div class="result fout">⚠️ ${e.message}</div>`;
  }
}

async function delKleurplaat(pid) {
  try {
    await fetch(`/api/kleurboek/pagina/${pid}`, { method: "DELETE" });
    toast("Verwijderd");
    loadKleurboek();
  } catch (e) { toast(e.message, true); }
}
