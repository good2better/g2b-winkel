"""G2B Bedrijfsmiddelen — FastAPI backend.

- /                          → static UI (geen Node nodig)
- POST /api/contract         → licentie-contract PDF
- POST /api/beschrijving     → verkooptekst NL (lang + kort)
- POST /api/merkassets       → G2B merkbestanden (PNG's + merk-kit zip)
- POST /api/factuur          → particuliere factuur PDF
- GET  /api/exports          → lijst van gegenereerde bestanden
- GET  /api/download/{name}  → bestand downloaden
- DELETE /api/exports/{name} → bestand verwijderen
- GET  /api/health           → status

Winkel (eigen muziekwinkel op GitHub Pages):
- GET    /api/winkel                 → catalogus + inbox + instellingen
- POST   /api/winkel/settings        → instellingen opslaan
- POST   /api/winkel/upload          → bestand in de inbox zetten
- POST   /api/winkel/import          → inbox-bestand → product
- PATCH  /api/winkel/product/{id}    → product bijwerken
- POST   /api/winkel/product/{id}/cover → eigen hoes uploaden
- DELETE /api/winkel/product/{id}    → product verwijderen
- POST   /api/winkel/build           → site lokaal bouwen
- POST   /api/winkel/publish         → publiceren naar GitHub Pages
- GET    /api/winkel/media/{id}/{f}  → preview/cover afspelen

Royalties:
- GET    /api/royalty                → verkopen + saldi + uitbetalingen
- POST   /api/royalty/verkoop        → verkoop invoeren (auto-split)
- POST   /api/royalty/import         → CSV-import (Stripe e.d.)
- POST   /api/royalty/uitbetaling    → saldo uitbetalen + royalty-PDF
- DELETE /api/royalty/verkoop/{id}   → verkoop verwijderen

Alles lokaal, geen GPU, geen AI, geen cloud (alleen GitHub Pages voor
de publieke winkel), geen kosten.
Regel 1: zie LICENSES.md — alleen open-source/commercieel-vrije deps.
"""
from __future__ import annotations

import io
import json
import re
import secrets
import zipfile
from datetime import date
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from .generators import (beschrijving, contract, factuur, merkassets,
                         kleurboek, royalty, videoboek, voorwaarden, winkel)

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent                      # backend/
STATIC = APP_DIR / "static"
STORAGE_DIR = ROOT / "storage"
OUT_DIR = STORAGE_DIR / "exports"
OUT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="G2B Bedrijfsmiddelen")


@app.middleware("http")
async def geen_stale_cache(request, call_next):
    """HTML/JS nooit uit cache serveren: een al-open tab hield anders
    een oude app.js vast waardoor nieuwe knoppen 'dood' leken."""
    resp = await call_next(request)
    p = request.url.path
    if p.endswith((".html", ".js")) or p == "/":
        resp.headers["Cache-Control"] = "no-cache"
    return resp


# ------------------------------------------------------------- health ---
@app.get("/api/health")
def health():
    return {"ok": True, "app": "G2B Bedrijfsmiddelen",
            "exports": len(list(OUT_DIR.iterdir()))}


# ------------------------------------------------------------ contract --
class ContractReq(BaseModel):
    koper_naam: str = Field(min_length=1)
    koper_email: str = ""
    product: str = Field(min_length=1)
    licentie_type: str = "personal"        # personal|commercial|beat|exclusief|buyout
    vergoeding: float = 0.0                # eenmalige licentievergoeding €
    duur: str = "3 jaar"                   # 1 jaar|3 jaar|10 jaar|volle auteursrecht-duur


@app.post("/api/contract")
def maak_contract(r: ContractReq):
    if r.licentie_type not in contract.LICENTIES:
        raise HTTPException(400, "licentie_type: personal, commercial, beat, exclusief of buyout")
    if r.duur not in contract.DUREN:
        raise HTTPException(400, "duur: " + ", ".join(contract.DUREN))
    try:
        uit = contract.maak_contract(
            r.koper_naam.strip(), r.koper_email.strip(),
            r.product.strip(), r.licentie_type, OUT_DIR,
            vergoeding=r.vergoeding, duur=r.duur,
            verkoper=_laad_settings())
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "file": uit.name, "url": f"/api/download/{uit.name}"}


# --------------------------------------------------------- beschrijving --
class BeschrijvingReq(BaseModel):
    product: str = Field(min_length=1)
    type: str = "overig"                   # beat|samplepack|app|ebook|overig
    eigenschappen: list[str] = []
    prijs: str = ""
    doelgroep: str = ""
    opslaan: bool = True


@app.post("/api/beschrijving")
def maak_beschrijving(r: BeschrijvingReq):
    teksten = beschrijving.maak_teksten(
        r.product.strip(), r.type, r.eigenschappen, r.prijs, r.doelgroep,
        verkoper=_laad_settings())
    out: dict = {"ok": True, **teksten}
    if r.opslaan:
        uit = beschrijving.sla_op(r.product.strip(), teksten, OUT_DIR)
        out["file"] = uit.name
        out["url"] = f"/api/download/{uit.name}"
    return out


@app.get("/api/beschrijving/types")
def beschrijving_types():
    return {"types": [{"id": k, "naam": v["naam"]}
                      for k, v in beschrijving.TYPES.items()]}


# ----------------------------------------------------------- merkassets --
class MerkReq(BaseModel):
    tagline: str = ""


@app.post("/api/merkassets")
def maak_merkassets(r: MerkReq):
    res = merkassets.genereer_alle(OUT_DIR, r.tagline.strip() or "G2B")
    return {"ok": True, **res,
            "zip_url": f"/api/download/{res['zip']}"}


# -------------------------------------------------------------- settings -
SETTINGS_FILE = STORAGE_DIR / "settings.json"


def _laad_settings() -> dict:
    if SETTINGS_FILE.exists():
        try:
            return json.loads(SETTINGS_FILE.read_text("utf-8"))
        except Exception:
            return {}
    return {}


@app.get("/api/settings")
def get_settings():
    return _laad_settings()


class SettingsReq(BaseModel):
    bedrijfsnaam: str = ""
    naam: str = ""
    adres: str = ""
    kvk: str = ""
    btw_nr: str = ""
    iban: str = ""
    email: str = ""


@app.post("/api/settings")
def save_settings(r: SettingsReq):
    SETTINGS_FILE.write_text(
        json.dumps(r.model_dump(), ensure_ascii=False, indent=2), "utf-8")
    return {"ok": True}


# -------------------------------------------------------------- factuur --
class FactuurReq(BaseModel):
    klant_naam: str = Field(min_length=1)
    klant_email: str = ""
    omschrijving: str = Field(min_length=1)
    bedrag: float = Field(gt=0)
    datum: str | None = None               # dd-mm-jjjj, leeg = vandaag
    betaal_info: str = ""
    btw_pct: float = 0                     # 0 = particulier, 9, 21
    incl_btw: bool = False                 # bedrag is incl. BTW ingevoerd


@app.post("/api/factuur")
def maak_factuur(r: FactuurReq):
    if r.btw_pct not in (0, 9, 21):
        raise HTTPException(400, "btw_pct: 0, 9 of 21")
    try:
        uit = factuur.maak_factuur(
            r.klant_naam.strip(), r.bedrag, r.omschrijving.strip(),
            OUT_DIR, r.klant_email.strip(), r.datum, r.betaal_info.strip(),
            verkoper=_laad_settings(), btw_pct=r.btw_pct,
            incl_btw=r.incl_btw)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "file": uit.name, "url": f"/api/download/{uit.name}"}


# -------------------------------------------------------------- winkel --
class WinkelSettingsReq(BaseModel):
    repo: str = ""
    branch: str = ""
    site_titel: str = ""
    site_ondertitel: str = ""
    accent: str = ""
    github_token: str = ""
    betaal_dienst: str = ""
    stats_url: str = ""


@app.get("/api/winkel")
def winkel_status():
    data = winkel.laad()
    inst = dict(data["instellingen"])
    inst["github_token"] = "•" * 8 if inst.get("github_token") else ""
    inst["ingesteld"] = bool(data["instellingen"].get("github_token"))
    inst["site_url"] = winkel.site_url(inst)
    gewijzigd = False
    for p in data["producten"]:
        if "sleutels" not in p or len(p["sleutels"]) < 3:
            winkel.bedankt_links(data, p)   # zorgt dat sleutels bestaan
            gewijzigd = True
    if gewijzigd:
        winkel.sla(data)
    return {"instellingen": inst, "producten": data["producten"],
            "inbox": winkel.inbox_scan()}


@app.post("/api/winkel/settings")
def winkel_settings(r: WinkelSettingsReq):
    data = winkel.laad()
    for k, v in r.model_dump().items():
        if k == "github_token":
            if v and not v.startswith("•"):
                data["instellingen"][k] = v
            continue
        if k == "accent":
            if re.fullmatch(r"#[0-9a-fA-F]{6}", v):
                data["instellingen"][k] = v
            continue
        if v != "" or k == "stats_url":
            data["instellingen"][k] = v     # stats_url leeg = uit
    winkel.sla(data)
    return {"ok": True}


@app.post("/api/winkel/upload")
def winkel_upload(bestand: UploadFile = File(...)):
    if not bestand.filename:
        raise HTTPException(400, "geen bestand gekozen")
    tijdelijk = winkel.WINKEL_DIR / ("_upl_" + Path(bestand.filename).name)
    tijdelijk.write_bytes(bestand.file.read())
    naam = winkel.naar_inbox(tijdelijk, bestand.filename)
    tijdelijk.unlink(missing_ok=True)
    return {"ok": True, "bestand": naam}


class WinkelImportReq(BaseModel):
    bestand: str = Field(min_length=1)
    titel: str = Field(min_length=1)
    soort: str = "audio"              # audio | digitaal
    prijs: str = ""
    beschrijving: str = ""
    bron: str = "inbox"               # inbox | gedeeld (G2B-INBOX-map)


@app.post("/api/winkel/import")
def winkel_import(r: WinkelImportReq):
    data = winkel.laad()
    try:
        p = winkel.importeer(data, r.bestand, r.titel.strip(),
                             r.soort, r.prijs.strip(),
                             r.beschrijving.strip(), r.bron)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "product": p}


class WinkelBewerkReq(BaseModel):
    titel: str | None = None
    beschrijving: str | None = None
    prijs: str | None = None
    soort: str | None = None
    download_url: str | None = None
    herkomst: str | None = None
    groep: str | None = None
    prijzen: dict | None = None
    links: dict | None = None
    splits: list[dict] | None = None
    zichtbaar: bool | None = None


@app.patch("/api/winkel/product/{pid}")
def winkel_bewerk(pid: str, r: WinkelBewerkReq):
    data = winkel.laad()
    velden = {k: v for k, v in r.model_dump().items() if v is not None}
    try:
        p = winkel.werk_bij(data, pid, velden)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "product": p}


@app.post("/api/winkel/product/{pid}/cover")
def winkel_cover(pid: str, bestand: UploadFile = File(...)):
    data = winkel.laad()
    tijdelijk = winkel.WINKEL_DIR / (
        "_cov_" + Path(bestand.filename or "cover.png").name)
    tijdelijk.write_bytes(bestand.file.read())
    try:
        p = winkel.zet_cover(data, pid, tijdelijk)
    except Exception as e:
        tijdelijk.unlink(missing_ok=True)
        raise HTTPException(400, f"hoes niet verwerkt: {e}")
    tijdelijk.unlink(missing_ok=True)
    return {"ok": True, "product": p}


@app.delete("/api/winkel/product/{pid}")
def winkel_delete(pid: str):
    data = winkel.laad()
    try:
        winkel.verwijder(data, pid)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return {"ok": True}


@app.post("/api/winkel/build")
def winkel_build():
    data = winkel.laad()
    site = winkel.bouw_site(data)
    n = len(winkel.catalogus_aan(data))
    return {"ok": True, "producten": n,
            "preview_url": "/winkel-preview/index.html",
            "pad": str(site)}


@app.post("/api/winkel/publish")
def winkel_publish():
    data = winkel.laad()
    try:
        res = winkel.publiceer(data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, **res}


@app.get("/api/winkel/media/{pid}/{naam}")
def winkel_media(pid: str, naam: str):
    p = winkel.PRODUCTEN_DIR / pid / Path(naam).name
    if not p.exists() or p.name not in (
            "preview.mp3", "cover.png", "cover_eigen.png"):
        raise HTTPException(404, "bestand niet gevonden")
    return FileResponse(p)


# ------------------------------------------------------ winkel: stats --
class StatsReq(BaseModel):
    product: str = Field(min_length=1)   # product-id of titel
    seconden: float = Field(gt=0)


@app.get("/api/winkel/stats")
def winkel_stats():
    data = winkel.laad()
    return winkel.stats_samenvatting(data)


@app.post("/api/winkel/stats")
def winkel_stats_post(r: StatsReq):
    data = winkel.laad()
    e = winkel.stats_toevoegen(data, r.product.strip(), r.seconden)
    return {"ok": True, "entry": e}


@app.post("/api/winkel/stats/import")
async def winkel_stats_import(bestand: UploadFile = File(...)):
    data = winkel.laad()
    text = (await bestand.read()).decode("utf-8", errors="replace")
    res = winkel.stats_import(data, text)
    return {"ok": True, **res}


@app.post("/api/winkel/stats/rapport")
def winkel_stats_rapport():
    data = winkel.laad()
    uit = winkel.stats_rapport(data, OUT_DIR)
    return {"ok": True, "file": uit.name,
            "url": f"/api/download/{uit.name}"}


# ------------------------------------------------------------ royalty ---
class VerkoopReq(BaseModel):
    datum: str = ""                   # jjjj-mm-dd, leeg = vandaag
    product_id: str = ""
    titel: str = ""
    brutto: float = Field(gt=0)
    fee: float = 0.0
    notitie: str = ""


@app.get("/api/royalty")
def royalty_status():
    data = royalty.laad()
    return {"verkopen": data["verkopen"], "saldi": royalty.saldi(),
            "uitbetalingen": data["uitbetalingen"],
            "producten": [{"id": p["id"], "titel": p["titel"],
                           "splits": p["splits"]}
                          for p in winkel.laad()["producten"]]}


@app.post("/api/royalty/verkoop")
def royalty_verkoop(r: VerkoopReq):
    try:
        v = royalty.verkoop_toevoegen(
            r.datum or None, r.product_id, r.titel.strip(),
            r.brutto, r.fee, r.notitie.strip())
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "verkoop": v}


@app.post("/api/royalty/import")
def royalty_import(bestand: UploadFile = File(...)):
    try:
        res = royalty.importeer_csv(bestand.file.read())
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, **res}


class UitbetalingReq(BaseModel):
    persoon: str = Field(min_length=1)


@app.post("/api/royalty/uitbetaling")
def royalty_uitbetaling(r: UitbetalingReq):
    try:
        res = royalty.uitbetaling(r.persoon.strip(), OUT_DIR)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, **res,
            "url": f"/api/download/{res['pdf']}"}


@app.delete("/api/royalty/verkoop/{vid}")
def royalty_verwijder(vid: int):
    royalty.verwijder_verkoop(vid)
    return {"ok": True}



# ----------------------------------------------------------------- deal --
class DealReq(FactuurReq):
    licentie_type: str = "beat"            # welk contract erbij hoort
    duur: str = "3 jaar"                   # looptijd van het contract


@app.post("/api/deal")
def maak_deal(r: DealReq):
    """Factuur + licentie-contract in één klik voor dezelfde verkoop."""
    if r.btw_pct not in (0, 9, 21):
        raise HTTPException(400, "btw_pct: 0, 9 of 21")
    if r.licentie_type not in contract.LICENTIES:
        raise HTTPException(400, "licentie_type: personal, commercial, beat, exclusief of buyout")
    if r.duur not in contract.DUREN:
        raise HTTPException(400, "duur: " + ", ".join(contract.DUREN))
    try:
        f_uit = factuur.maak_factuur(
            r.klant_naam.strip(), r.bedrag, r.omschrijving.strip(),
            OUT_DIR, r.klant_email.strip(), r.datum,
            r.betaal_info.strip(), verkoper=_laad_settings(),
            btw_pct=r.btw_pct, incl_btw=r.incl_btw)
        c_uit = contract.maak_contract(
            r.klant_naam.strip(), r.klant_email.strip(),
            r.omschrijving.strip(), r.licentie_type, OUT_DIR,
            vergoeding=r.bedrag, duur=r.duur,
            verkoper=_laad_settings())
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True,
            "factuur": {"file": f_uit.name,
                        "url": f"/api/download/{f_uit.name}"},
            "contract": {"file": c_uit.name,
                         "url": f"/api/download/{c_uit.name}"}}


# ----------------------------------------------------------- voorwaarden --
@app.post("/api/voorwaarden")
def maak_voorwaarden():
    uit = voorwaarden.maak_voorwaarden(_laad_settings(), OUT_DIR)
    return {"ok": True, "file": uit.name,
            "url": f"/api/download/{uit.name}"}


# ---------------------------------------------------------- videoboek ----
@app.get("/api/videoboek")
def videoboek_lijst():
    return {"videoboeken": videoboek.laad()["videoboeken"]}


@app.post("/api/videoboek")
async def videoboek_maken(titel: str = Form("Videoboek"),
                          plaatjes: int = Form(0),
                          boek: UploadFile = File(...),
                          audio: UploadFile = File(...)):
    tmp = STORAGE_DIR / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    bp = tmp / Path(boek.filename or "boek.epub").name
    ap = tmp / Path(audio.filename or "audio.mp3").name
    bp.write_bytes(await boek.read())
    ap.write_bytes(await audio.read())
    try:
        rec = videoboek.maak(titel.strip() or "Videoboek", bp, ap,
                             max_plaatjes=max(0, plaatjes))
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        bp.unlink(missing_ok=True)
        ap.unlink(missing_ok=True)
    return {"ok": True, "videoboek": rec,
            "preview": f"/videoboeken/{rec['id']}/index.html"}


@app.post("/api/videoboek/interactief")
async def videoboek_interactief(titel: str = Form("Videoboek"),
                                stem: bool = Form(True),
                                boek: UploadFile = File(...),
                                verhaal: UploadFile = File(...)):
    """Kies-je-eigen-avontuur videoboek: boek (epub/pdf) + verhaal.txt
    in het SCENE/KEUZE mini-formaat."""
    tmp = STORAGE_DIR / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    # unieke tmp-naam: gelijke upload-bestandsnamen botsen niet
    bp = tmp / (f"{secrets.token_hex(6)}-"
                f"{Path(boek.filename or 'boek.epub').name}")
    bp.write_bytes(await boek.read())
    vt = (await verhaal.read()).decode("utf-8", errors="replace")
    try:
        # threadpool: TTS per scène kan tot 60s duren — event loop
        # blijft vrij voor andere requests
        rec = await run_in_threadpool(
            videoboek.maak_interactief_van_boek,
            titel.strip() or "Videoboek", bp, vt, stem)
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        bp.unlink(missing_ok=True)
    return {"ok": True, "videoboek": rec,
            "preview": f"/videoboeken/{rec['id']}/index.html"}


@app.get("/api/videoboek/{vid}/zip")
def videoboek_zip(vid: str):
    try:
        uit = videoboek.maak_zip(vid)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return {"ok": True, "file": uit.name,
            "url": f"/api/download/{uit.name}"}


@app.post("/api/videoboek/{vid}/mp4")
def videoboek_mp4_start(vid: str):
    data = videoboek.laad()
    try:
        videoboek.vind(data, vid)
    except ValueError as e:
        raise HTTPException(404, str(e))
    videoboek.mp4_start(vid)
    return {"ok": True, "status": "busy"}


@app.get("/api/videoboek/{vid}/mp4")
def videoboek_mp4_status(vid: str):
    st = videoboek.mp4_status(vid)
    out = {"status": st}
    if st.startswith("klaar:"):
        out["file"] = st.split(":", 1)[1]
        out["url"] = f"/api/download/{out['file']}"
    elif st.startswith("fout:"):
        out["fout"] = st.split(":", 1)[1]
    return out


@app.post("/api/videoboek/{vid}/site")
def videoboek_naar_site(vid: str):
    try:
        r = videoboek.publiceer_site(vid)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, **r}


@app.post("/api/videoboek/{vid}/winkel")
def videoboek_naar_winkel(vid: str, prijs: str = Form("")):
    """Maak van het videoboek een verkoopproduct in de G2B Winkel
    (ZIP als digitaal product, echte boek-cover erbij)."""
    try:
        uit = videoboek.maak_zip(vid)
        naam = winkel.naar_inbox(uit)
        data = winkel.laad()
        rec = videoboek.vind(videoboek.laad(), vid)
        p = winkel.importeer(
            data, naam, rec["titel"] + " — videoboek",
            soort="digitaal", prijs=prijs,
            beschrijving="Videoboek: boekpagina's die meebewegen met de "
                         "voorleesstem — open index.html en druk play.")
        cover = videoboek.VB_DIR / vid / "cover.jpg"
        if cover.exists():
            winkel.zet_cover(data, p["id"], cover)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "product": p}


@app.post("/api/videoboek/{vid}/van-site")
def videoboek_van_site(vid: str):
    """Verwijder een gepubliceerd videoboek ook van GS Books:
    de hele gsbooks/vb/<slug>-map uit de repo + uit index.json."""
    try:
        return videoboek.verwijder_van_site(vid)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.delete("/api/videoboek/{vid}")
def videoboek_delete(vid: str):
    data = videoboek.laad()
    try:
        videoboek.verwijder(data, vid)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return {"ok": True}


# --------------------------------------------------------------- backup --
@app.get("/api/backup")
def backup():
    """ZIP van de hele storage-map: bedrijfsgegevens, factuur-teller
    en alle gegenereerde bestanden — voor een nieuwe pc of als reserve."""
    naam = f"g2b-backup-{date.today():%Y%m%d}.zip"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(STORAGE_DIR.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(STORAGE_DIR))
    return Response(buf.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition":
                             f'attachment; filename="{naam}"'})


@app.post("/api/restore")
async def restore(file: UploadFile = File(...)):
    """Backup-zip terugzetten in storage/ (overschrijft wat er staat)."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(await file.read()))
    except zipfile.BadZipFile:
        raise HTTPException(400, "dit is geen geldige backup-zip")
    n = 0
    for info in zf.infolist():
        if info.is_dir():
            continue
        doel = (STORAGE_DIR / info.filename).resolve()
        if not doel.is_relative_to(STORAGE_DIR.resolve()):
            continue                       # nooit buiten storage schrijven
        doel.parent.mkdir(parents=True, exist_ok=True)
        doel.write_bytes(zf.read(info))
        n += 1
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return {"ok": True, "aantal": n}


# -------------------------------------------------------------- exports --
KIND_PREFIX = {
    "contract_": "contract", "factuur_": "factuur",
    "beschrijving_": "beschrijving", "g2b_": "merk",
    "royalty_": "royalty",
    "algemene-voorwaarden": "voorwaarden",
}


def _kind(name: str) -> str:
    for pref, k in KIND_PREFIX.items():
        if name.startswith(pref):
            return k
    return "bestand"


@app.get("/api/exports")
def exports():
    files = []
    for p in sorted(OUT_DIR.iterdir(), key=lambda x: x.stat().st_mtime,
                    reverse=True):
        if p.is_file() and not p.name.startswith("."):
            files.append({
                "name": p.name,
                "size": p.stat().st_size,
                "kind": _kind(p.name),
                "mtime": p.stat().st_mtime,
                "url": f"/api/download/{p.name}",
            })
    return {"files": files}


@app.delete("/api/exports/{name}")
def delete_export(name: str):
    p = OUT_DIR / Path(name).name
    if not p.exists():
        raise HTTPException(404, "bestand niet gevonden")
    p.unlink()
    return {"ok": True}


@app.get("/api/download/{name}")
def download(name: str):
    p = OUT_DIR / Path(name).name
    if not p.exists():
        raise HTTPException(404, "bestand niet gevonden")
    return FileResponse(p, filename=p.name)


# ---------------------------------------------------------- kleurboek ----


class KleurboekPdfReq(BaseModel):
    titel: str = "G2B Kleurboek"
    ondertitel: str = ""
    boek: str = ""
    merk: str = "ah"                       # ah|g2b
    variant: str = "cozy"                  # cozy|stripboek|feest|geheel
    seed: int = 0                          # retry-teller: andere scene-rotatie
    prijs: str = ""                        # alleen /winkel: verkoopprijs
    formaat: str = "a4"                    # a4|a5|6x9 — kaft-papierformaat
    pagina_aantal: int | None = None       # boek: echte paginatelling → rug
    soort: str = "kleurboek"               # kleurboek|boek — kaft-type
    blurb: str = ""                        # eigen flaptekst achterkant (optie)
    paginas: list[str]


@app.get("/api/kleurboek")
def kleurboek_lijst():
    return {"paginas": kleurboek.lijst_paginas(),
            "genereer": kleurboek.genereer_actief()}


class GenereerReq(BaseModel):
    prompt: str
    boek: str = ""
    batch: int = 2


@app.post("/api/kleurboek/genereer")
def kleurboek_genereer(r: GenereerReq):
    """Zelf-maak-stap: tekst → eigen boekplaatjes via de ImageLab-pod
    (FLUX.1-schnell, Apache-2.0). Duurt ~30-90s; pod-centen per klik."""
    try:
        nieuwe = kleurboek.genereer_plaat(r.prompt, r.boek, r.batch)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "nieuw": nieuwe,
            "totaal": len(kleurboek.lijst_paginas())}


@app.post("/api/kleurboek/upload")
async def kleurboek_upload(bestanden: list[UploadFile] = File(...),
                           boek: str = Form("")):
    batch = [(f.filename or "plaat.png", await f.read()) for f in bestanden]
    nieuwe = kleurboek.voeg_toe(batch, boek=boek)
    if not nieuwe:
        raise HTTPException(400, "geen bruikbare plaatjes (jpg/png/webp)")
    return {"ok": True, "nieuw": nieuwe, "totaal": len(kleurboek.lijst_paginas())}


@app.get("/api/kleurboek/media/{naam}")
def kleurboek_media(naam: str):
    p = kleurboek.PAG_DIR / Path(naam).name
    if not p.exists():
        raise HTTPException(404, "kleurplaat niet gevonden")
    return FileResponse(p)


@app.post("/api/kleurboek/pdf")
def kleurboek_pdf(r: KleurboekPdfReq):
    try:
        dst = kleurboek.maak_kleurboek_pdf(r.paginas, r.titel, r.ondertitel,
                                         r.boek, r.merk, r.variant,
                                         seed=r.seed)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "bestand": dst.name,
            "download": f"/api/download/{dst.name}"}


class BoekReq(BaseModel):
    titel: str = ""
    ondertitel: str = ""
    auteur: str = ""
    merk: str = "ah"
    formaat: str = "a5"                    # a5|6x9 — binnenkant-formaat
    verhaal: str = ""                      # lege regel = nieuwe pagina
    paginas: list[str] = []


@app.post("/api/kleurboek/boek")
def kleurboek_boek(r: BoekReq):
    """Print-klare boek-binnenkant: per pagina een plaat met tekstregel.
    `verhaal` splitst op lege regels (of elke regel = 1 pagina).
    Geeft ook het echte pagina-aantal → dat voert de kaft-rugdikte."""
    teksten = [t.strip() for t in re.split(r"\n\s*\n+", r.verhaal)
               if t.strip()]
    if len(teksten) <= 1 and "\n" in r.verhaal:
        teksten = [t.strip() for t in r.verhaal.split("\n") if t.strip()]
    try:
        dst, n = kleurboek.maak_boek_pdf(r.paginas, teksten, r.titel,
                                         r.ondertitel, r.auteur, r.merk,
                                         r.formaat)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "bestand": dst.name, "paginas": n,
            "download": f"/api/download/{dst.name}"}


class KaftUitReq(BaseModel):
    id: str
    uit: bool = True


@app.post("/api/kleurboek/kaft-uit")
def kleurboek_kaft_uit(r: KaftUitReq):
    if not kleurboek.kaft_uit_zetten(r.id, r.uit):
        raise HTTPException(404, "kleurplaat niet gevonden")
    return {"ok": True}


@app.post("/api/kleurboek/kleurstudio")
def kleurboek_naar_kleurstudio():
    """1-klik-naar-site: alle kleurplaten als webversie naar
    gsbooks/kleur/ op GS Books (platen/ + platen.json)."""
    try:
        r = kleurboek.publiceer_kleurstudio()
    except ValueError as e:
        raise HTTPException(400, str(e))
    return r


@app.post("/api/kleurboek/kaft")
def kleurboek_kaft(r: KleurboekPdfReq):
    """Print-klare omslag (achter + rug + voor) + voorkant-PNG voor de winkel."""
    try:
        dst, png = kleurboek.maak_kaft_pdf(r.paginas, r.titel, r.ondertitel,
                                           r.boek, r.merk, r.variant,
                                           seed=r.seed, formaat=r.formaat,
                                           pagina_aantal=r.pagina_aantal,
                                           soort=r.soort, blurb=r.blurb)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "bestand": dst.name,
            "download": f"/api/download/{dst.name}",
            "voorkant": f"/api/download/{png.name}" if png else ""}


@app.post("/api/kleurboek/winkel")
def kleurboek_naar_winkel(r: KleurboekPdfReq):
    """1-klik verkoop-pakket: kleurboek-PDF + print-kaft + voorkant-PNG
    als ZIP in de G2B Winkel — cover = de kaft-voorkant."""
    try:
        pdf = kleurboek.maak_kleurboek_pdf(r.paginas, r.titel, r.ondertitel,
                                         r.boek, r.merk, r.variant,
                                         seed=r.seed)
        kaft, voorkant = kleurboek.maak_kaft_pdf(
            r.paginas, r.titel, r.ondertitel, r.boek, r.merk, r.variant,
            seed=r.seed, formaat=r.formaat,
            pagina_aantal=r.pagina_aantal, soort=r.soort, blurb=r.blurb)
        pakket = kleurboek.EXPORT_DIR / (
            f"Kleurboek-{kleurboek._slug(r.titel) or 'g2b'}-pakket.zip")
        with zipfile.ZipFile(pakket, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(pdf, pdf.name)
            z.write(kaft, kaft.name)
            if voorkant and voorkant.exists():
                z.write(voorkant, voorkant.name)
        naam = winkel.naar_inbox(pakket)
        data = winkel.laad()
        p = winkel.importeer(
            data, naam, r.titel + " — kleurboek",
            soort="digitaal", prijs=r.prijs,
            beschrijving="Kleurboek-pakket: print-kleurboek (PDF) + "
                         "print-klare kaft (PDF) + voorkant-plaatje. "
                         "Printen en kleuren maar!")
        if voorkant and voorkant.exists():
            winkel.zet_cover(data, p["id"], voorkant)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "product": p}


@app.delete("/api/kleurboek/pagina/{pid}")
def kleurboek_delete(pid: str):
    if not kleurboek.verwijder_pagina(pid):
        raise HTTPException(404, "kleurplaat niet gevonden")
    return {"ok": True}


# ------------------------------------------------------------- static ---
# lokale voorvertoning van de gebouwde winkel
(winkel.SITE_DIR).mkdir(parents=True, exist_ok=True)
app.mount("/winkel-preview",
          StaticFiles(directory=winkel.SITE_DIR, html=True),
          name="winkel-preview")
videoboek.VB_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/videoboeken",
          StaticFiles(directory=videoboek.VB_DIR, html=True),
          name="videoboeken")
app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
