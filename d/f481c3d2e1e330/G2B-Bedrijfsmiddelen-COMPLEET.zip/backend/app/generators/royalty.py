"""G2B Royalties — verkoop bijhouden en opbrengsten verdelen.

Het 'wallet'-model: elke verkoop wordt opgeslagen, de netto-opbrengst
wordt automatisch verdeeld over de splits van het product
(bijv. eigenaar 70% / medewerker 30%), en per persoon houdt de app een
lopend saldo bij. Met één druk op de knop maak je een royalty-PDF
(overzicht) en boek je de uitbetaling.

Verkopen kun je handmatig invoeren of importeren uit een CSV-export
(bijv. Stripe/ChargeKeep export).
"""
from __future__ import annotations

import csv
import io
import json
import re
from datetime import date
from pathlib import Path

from reportlab.platypus import SimpleDocTemplate

from .contract import slug
from .pdfstyle import (GROEN, LIJN, Paragraph, Spacer, Table, TableStyle,
                       colors, footer_canvas, info_box, kop_blok, mm,
                       stijlen)
from .winkel import WINKEL_DIR, laad as laad_winkel

ROYALTY_FILE = WINKEL_DIR / "royalty.json"


# ---------------------------------------------------------------- state

def laad() -> dict:
    WINKEL_DIR.mkdir(parents=True, exist_ok=True)
    if ROYALTY_FILE.exists():
        try:
            data = json.loads(ROYALTY_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {"verkopen": [], "uitbetalingen": []}
    else:
        data = {"verkopen": [], "uitbetalingen": []}
    data.setdefault("verkopen", [])
    data.setdefault("uitbetalingen", [])
    return data


def sla(data: dict) -> None:
    WINKEL_DIR.mkdir(parents=True, exist_ok=True)
    ROYALTY_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _euro(bedrag: float) -> str:
    return "€ " + f"{bedrag:,.2f}".replace(",", "X").replace(
        ".", ",").replace("X", ".")


# ---------------------------------------------------------------- verkopen

def splits_van(product_id: str) -> list[dict]:
    """Splits van een product uit de winkel-catalogus; onbekend product
    → alles voor de eigenaar."""
    if product_id:
        for p in laad_winkel()["producten"]:
            if p["id"] == product_id:
                return p["splits"]
    return [{"naam": "Ik", "pct": 100.0}]


def verkoop_toevoegen(datum: str, product_id: str, titel: str,
                      brutto: float, fee: float = 0.0,
                      notitie: str = "") -> dict:
    if brutto <= 0:
        raise ValueError("Brutobedrag moet groter zijn dan 0")
    if fee < 0 or fee >= brutto:
        raise ValueError("Fee moet 0 of groter zijn en kleiner dan "
                         "het brutobedrag")
    data = laad()
    netto = round(brutto - fee, 2)
    splits = splits_van(product_id)
    verdeling = []
    rest = netto
    for i, s in enumerate(splits):
        if i == len(splits) - 1:
            deel = rest  # laatste vangt afronding op
        else:
            deel = round(netto * s["pct"] / 100, 2)
            rest = round(rest - deel, 2)
        verdeling.append({"naam": s["naam"], "pct": s["pct"],
                          "bedrag": deel})
    v = {
        "id": len(data["verkopen"]) + 1,
        "datum": datum or date.today().isoformat(),
        "product_id": product_id,
        "titel": titel or "Verkoop",
        "brutto": round(brutto, 2),
        "fee": round(fee, 2),
        "netto": netto,
        "verdeling": verdeling,
        "notitie": notitie,
    }
    data["verkopen"].append(v)
    sla(data)
    return v


def verwijder_verkoop(vid: int) -> None:
    data = laad()
    data["verkopen"] = [v for v in data["verkopen"] if v["id"] != vid]
    sla(data)


# ---------------------------------------------------------------- CSV-import

_KOLOM_ALIASSEN = {
    "datum": ["created", "created (utc)", "date", "datum",
              "payment date", "transferred"],
    "titel": ["description", "product", "item", "titel", "name",
              "product name"],
    "brutto": ["amount", "gross", "brutto", "total", "bedrag",
               "amount (gross)"],
    "fee": ["fee", "application fee", "processing fee", "kosten",
            "stripe fee"],
    "netto": ["net", "netto", "net amount"],
}


def _getal(tekst: str) -> float | None:
    """'€ 19,95' / '19.95' / '1.234,56' → float. None als het geen
    getal is."""
    s = (tekst or "").strip().replace("€", "").replace(" ", "")
    if not s:
        return None
    if re.match(r"^-?\d{1,3}(\.\d{3})*(,\d+)?$", s):  # NL-notatie
        s = s.replace(".", "").replace(",", ".")
    elif "," in s and "." in s and s.rfind(",") < s.rfind("."):
        s = s.replace(",", "")
    elif "," in s and "." not in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def importeer_csv(csv_bytes: bytes) -> dict:
    """Importeer verkopen uit een CSV (Stripe/ChargeKeep/bank-export).
    Kolommen worden automatisch herkend; onbekende producten gaan
    100% naar de eigenaar als 'overige verkoop'."""
    tekst = csv_bytes.decode("utf-8-sig", errors="replace")
    proef = csv.Sniffer().sniff(tekst[:4000], delimiters=";,\t")
    rdr = csv.DictReader(io.StringIO(tekst), dialect=proef)
    koppen = {c.lower().strip(): c for c in (rdr.fieldnames or [])}

    def kolom(alias):
        for k in _KOLOM_ALIASSEN[alias]:
            if k in koppen:
                return koppen[k]
        return None

    k_datum, k_titel = kolom("datum"), kolom("titel")
    k_bruto, k_fee, k_netto = kolom("brutto"), kolom("fee"), kolom("netto")
    if not (k_bruto or k_netto):
        raise ValueError(
            "Geen bedragskolom gevonden in de CSV (gezocht op "
            "amount/gross/net/bedrag)")

    winkel = laad_winkel()
    titels = {p["titel"].lower(): p["id"] for p in winkel["producten"]}

    toegevoegd, overgeslagen = 0, 0
    data = laad()
    for row in rdr:
        brutto = _getal(row.get(k_bruto, "")) if k_bruto else None
        netto_c = _getal(row.get(k_netto, "")) if k_netto else None
        fee = _getal(row.get(k_fee, "")) if k_fee else None
        if netto_c is not None and brutto is None:
            brutto = netto_c
            fee = 0.0
        if brutto is None or brutto <= 0:
            overgeslagen += 1
            continue
        fee = fee or 0.0
        titel = (row.get(k_titel, "") if k_titel else "").strip()
        pid = None
        tl = titel.lower()
        for t, i in titels.items():
            if t and (t in tl or tl in t):
                pid = i
                break
        datum = (row.get(k_datum, "") if k_datum else "").strip()
        v = verkoop_toevoegen(
            datum[:10] or None, pid, titel or "CSV-verkoop",
            brutto, fee, notitie="import")
        toegevoegd += 1
    return {"toegevoegd": toegevoegd, "overgeslagen": overgeslagen,
            "herkend": bool(k_bruto or k_netto)}


# ---------------------------------------------------------------- saldi

def saldi() -> dict:
    """Per persoon: verdiend, al uitbetaald, en openstaand tegoed."""
    data = laad()
    per = {}
    for v in data["verkopen"]:
        for d in v["verdeling"]:
            per.setdefault(d["naam"], {"verdiend": 0.0, "uitbetaald": 0.0})
            per[d["naam"]]["verdiend"] += d["bedrag"]
    for u in data["uitbetalingen"]:
        per.setdefault(u["persoon"],
                       {"verdiend": 0.0, "uitbetaald": 0.0})
        per[u["persoon"]]["uitbetaald"] += u["bedrag"]
    for naam, r in per.items():
        r["verdiend"] = round(r["verdiend"], 2)
        r["uitbetaald"] = round(r["uitbetaald"], 2)
        r["tegoed"] = round(r["verdiend"] - r["uitbetaald"], 2)
    return per


def uitbetaling(persoon: str, uit_dir: Path) -> dict:
    """Maakt een royalty-overzicht-PDF voor één persoon en boekt zijn
    openstaande saldo als uitbetaald."""
    s = saldi()
    r = s.get(persoon)
    if not r or r["tegoed"] <= 0:
        raise ValueError(f"Geen openstaand tegoed voor {persoon}")
    data = laad()
    regels = []
    for v in data["verkopen"]:
        for d in v["verdeling"]:
            if d["naam"] == persoon:
                regels.append((v["datum"], v["titel"], d["pct"],
                               d["bedrag"]))
    pdf = _maak_royalty_pdf(persoon, regels, r["verdiend"],
                            r["tegoed"], uit_dir)
    u = {"persoon": persoon, "bedrag": r["tegoed"],
         "datum": date.today().isoformat(),
         "pdf": pdf.name}
    data["uitbetalingen"].append(u)
    sla(data)
    return {"pdf": pdf.name, "bedrag": r["tegoed"],
            "regels": len(regels)}


def _maak_royalty_pdf(persoon: str, regels: list, verdiend: float,
                      tegoed: float, uit_dir: Path) -> Path:
    uit = uit_dir / f"royalty_{slug(persoon)}_{date.today():%Y%m%d}.pdf"
    doc = SimpleDocTemplate(
        str(uit), pagesize=(595.27, 841.89),
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title=f"Royalty-overzicht {persoon}", author="G2B")
    s = stijlen()
    el: list = []
    el.append(kop_blok(
        "ROYALTY-OVERZICHT",
        f"G2B Muziekwinkel · voor {persoon} · "
        f"{date.today():%d-%m-%Y}"))
    el.append(Spacer(1, 8 * mm))
    el.append(info_box([
        f"<b>Verdiend totaal:</b> {_euro(verdiend)}",
        f"<b>Nu uitbetaald:</b> {_euro(tegoed)}",
        "Bewaar dit overzicht voor je eigen administratie en "
        "belastingaangifte.",
    ]))
    el.append(Spacer(1, 5 * mm))
    el.append(Paragraph("Verkopen waar jij aandeel in hebt", s["h1"]))
    rijen = [[Paragraph("<b>Datum</b>", s["tabelkop"]),
              Paragraph("<b>Product</b>", s["tabelkop"]),
              Paragraph("<b>Aandeel</b>", s["tabelkop"]),
              Paragraph("<b>Jouw deel</b>", s["tabelkop"])]]
    for datum, titel, pct, bedrag in regels:
        rijen.append([Paragraph(datum, s["body"]),
                      Paragraph(titel, s["body"]),
                      Paragraph(f"{pct:g}%", s["body"]),
                      Paragraph(_euro(bedrag), s["body"])])
    rijen.append([Paragraph("", s["body"]),
                  Paragraph("<b>Totaal</b>", s["body"]),
                  Paragraph("", s["body"]),
                  Paragraph(f"<b>{_euro(tegoed)}</b>", s["body"])])
    t = Table(rijen, colWidths=[25 * mm, 95 * mm, 22 * mm, 28 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GROEN),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("LINEBELOW", (0, 0), (-1, -2), 0.5, LIJN),
        ("LINEABOVE", (0, -1), (-1, -1), 1, GROEN),
        ("ALIGN", (2, 0), (3, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    el.append(t)
    doc.build(el, onFirstPage=footer_canvas("G2B Royalty-overzicht"),
              onLaterPages=footer_canvas("G2B Royalty-overzicht"))
    return uit


__all__ = ["laad", "sla", "verkoop_toevoegen", "verwijder_verkoop",
           "importeer_csv", "saldi", "uitbetaling", "splits_van"]
