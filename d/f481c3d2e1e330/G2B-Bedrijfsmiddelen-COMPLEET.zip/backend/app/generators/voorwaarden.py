"""Algemene Voorwaarden generator — PDF voor op de site/downloads.

Eén knop → actuele AV-PDF met de opgeslagen bedrijfsgegevens
(settings.json / defaults). Zelfde groene huisstijl als de rest.
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

from reportlab.platypus import SimpleDocTemplate

from .factuur import VERKOPER_DEFAULT
from .pdfstyle import (Paragraph, Spacer, footer_canvas, info_box, kop_blok,
                       mm, stijlen)

ARTIKELEN = [
    ("Toepasselijkheid", [
        "Deze voorwaarden gelden voor elk aanbod, elke bestelling en elke "
        "overeenkomst van {BEDRIJFSNAAM} ('de Verkoper'), "
        "onder meer via de website van de Verkoper, betaallinks en "
        "e-mail.",
        "Door te bestellen of te betalen gaat de Koper met deze "
        "voorwaarden akkoord.",
    ]),
    ("Aanbod en prijzen", [
        "Prijzen zijn in euro's en inclusief BTW, tenzij anders vermeld.",
        "Kennelijke vergissingen in prijs of tekst binden de Verkoper "
        "niet; dan wordt een correcte prijs aangeboden.",
    ]),
    ("Betaling", [
        "Betaling gebeurt vooraf via de aangeboden betaalmethoden. "
        "De overeenkomst komt tot stand zodra de betaling is ontvangen.",
    ]),
    ("Levering", [
        "Digitale producten (beats, sounds, packs, apps, e-books) worden "
        "direct na betaling geleverd via download of link.",
        "De Verkoper bevestigt de levering per e-mail wanneer mogelijk.",
    ]),
    ("Licentie en eigendom", [
        "De Koper krijgt een gebruiksrecht zoals beschreven in het "
        "bijbehorende licentie-contract; er wordt geen eigendom "
        "overgedragen.",
        "Alle rechten op de producten — auteursrecht (⅓ componist, "
        "⅓ tekstschrijver, ⅓ uitgever), publishing en master — "
        "blijven volledig (100%) bij de Verkoper.",
        "Doorverkoop, verspreiding of aanbieding van de producten "
        "als zodanig (losse bestanden, packs, bundles) is verboden.",
    ]),
    ("Digitale levering en herroeping", [
        "Bij digitale producten die direct worden geleverd stemt de "
        "Koper uitdrukkelijk in met levering vóór het einde van de "
        "bedenktijd; het herroepingsrecht vervalt daarmee zodra de "
        "levering is gestart (art. 6:230p BW).",
    ]),
    ("Aansprakelijkheid", [
        "De Verkoper is niet aansprakelijk voor indirecte schade; de "
        "aansprakelijkheid is beperkt tot het betaalde bedrag, behalve "
        "bij opzet of grove nalatigheid.",
    ]),
    ("Privacy", [
        "Persoonsgegevens worden alleen gebruikt voor het uitvoeren van "
        "de overeenkomst (betaling, levering, communicatie) en worden "
        "niet aan derden verkocht.",
    ]),
    ("Recht en geschillen", [
        "Op deze voorwaarden en elke overeenkomst is Nederlands recht "
        "van toepassing.",
        "Geschillen worden voorgelegd aan de bevoegde rechter in "
        "Nederland, in de rechtbank van de woonplaats van de Verkoper.",
    ]),
]


def maak_voorwaarden(verkoper: dict | None, uit_dir: Path) -> Path:
    """Bouwt de AV-PDF (vaste bestandsnaam — overschrijft de oude)."""
    v = {**VERKOPER_DEFAULT, **(verkoper or {})}
    vandaag = date.today().strftime("%d-%m-%Y")
    uit = uit_dir / "algemene-voorwaarden_g2b.pdf"
    doc = SimpleDocTemplate(
        str(uit), pagesize=(595.27, 841.89),
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title="Algemene Voorwaarden",
        author=v["bedrijfsnaam"])
    s = stijlen()
    el: list = []

    el.append(kop_blok(
        "ALGEMENE VOORWAARDEN",
        f"{v['bedrijfsnaam']} · versie {vandaag}"))
    el.append(Spacer(1, 8 * mm))

    el.append(info_box([r for r in [
        (f"<b>{v['bedrijfsnaam']}</b> — {v['naam']}"
         if v["naam"] else f"<b>{v['bedrijfsnaam']}</b>"),
        v["adres"],
        f"KvK: {v['kvk']}" if v["kvk"] else "",
        f"BTW-nummer: {v['btw_nr']}" if v["btw_nr"] else "",
        v["email"],
    ] if r]))

    for i, (titel, regels) in enumerate(ARTIKELEN, 1):
        el.append(Paragraph(f"Artikel {i} — {titel}", s["h1"]))
        for j, r in enumerate(regels, 1):
            if r:
                el.append(Paragraph(
                    f"{i}.{j} " + r.replace("{BEDRIJFSNAAM}", v["bedrijfsnaam"]),
                    s["body"]))

    doc.build(
        el,
        onFirstPage=footer_canvas("Algemene Voorwaarden"),
        onLaterPages=footer_canvas("Algemene Voorwaarden"))
    return uit


__all__ = ["maak_voorwaarden"]
