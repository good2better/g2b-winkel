"""G2B Videoboek-Fabriek — boek + voorlees-audio → speelbaar videoboek.

Maakt van een EPUB (of ZIP met afbeeldingen) plus een audiobestand
een zelfstandig videoboek: boekpagina's die meebewegen met de
voorleesstem. Output = een map met index.html-speler + pagina's +
audio, plus een ZIP om te delen of te publiceren (bv. GS Books).

Alles lokaal: epub = zip met xhtml+plaatjes, geen externe diensten.
Regel 1: eigen code, Pillow (PIL), imageio-ffmpeg (beide vrij).
"""
from __future__ import annotations

import base64
import io
import json
import re
import secrets
import shutil
import zipfile
from datetime import date
from pathlib import Path
from xml.sax.saxutils import escape

import imageio_ffmpeg
from PIL import Image

APP_DIR = Path(__file__).resolve().parent.parent
BACKEND_ROOT = APP_DIR.parent
VB_DIR = BACKEND_ROOT / "storage" / "videoboeken"
STATE_FILE = VB_DIR / "videoboeken.json"
EXPORT_DIR = BACKEND_ROOT / "storage" / "exports"

BEELD_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
AUDIO_EXT = {".mp3", ".wav", ".ogg", ".m4a", ".flac", ".aac"}
MAX_BREEDTE = 1200


def _leeg() -> dict:
    return {"videoboeken": []}


def laad() -> dict:
    VB_DIR.mkdir(parents=True, exist_ok=True)
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return _leeg()


def sla(data: dict) -> None:
    VB_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def vind(data: dict, vid: str) -> dict:
    for v in data["videoboeken"]:
        if v["id"] == vid:
            return v
    raise ValueError("Videoboek niet gevonden")


def _attr(tag: str, naam: str) -> str:
    m = re.search(naam + r'\s*=\s*"(.*?)"', tag, re.S)
    return m.group(1) if m else ""


# ------------------------------------------------------------- epub/zip --

def _epub_volgorde(z: zipfile.ZipFile) -> list[str]:
    """Beeldnamen in leesvolgorde: container.xml → OPF → spine →
    elke xhtml levert zijn <img>/<image> in volgorde."""
    names = set(z.namelist())
    opf = ""
    try:
        cont = z.read("META-INF/container.xml").decode("utf-8", "ignore")
        m = re.search(r'full-path\s*=\s*"([^"]+)"', cont)
        if m:
            opf = m.group(1)
    except KeyError:
        pass
    if opf not in names:
        # zoek zelf een .opf
        for n in names:
            if n.endswith(".opf"):
                opf = n
                break
    if not opf:
        return []
    base = opf.rsplit("/", 1)[0] + "/" if "/" in opf else ""
    doc = z.read(opf).decode("utf-8", "ignore")
    manifest = {}
    for tag in re.findall(r"<item\b[^>]*>", doc):
        i, h = _attr(tag, "id"), _attr(tag, "href")
        if i and h:
            manifest[i] = h
    volgorde: list[str] = []
    for tag in re.findall(r"<itemref\b[^>]*>", doc):
        href = manifest.get(_attr(tag, "idref"), "")
        if not href:
            continue
        pad = (base + href).replace("%20", " ")
        if pad not in names:
            pad = href if href in names else ""
        if not pad:
            continue
        html = z.read(pad).decode("utf-8", "ignore")
        sub = pad.rsplit("/", 1)[0] + "/" if "/" in pad else ""
        srcs = re.findall(r"<img\b[^>]*?src\s*=\s*\"([^\"]+)\"", html)
        srcs += re.findall(r"<image\b[^>]*?(?:xlink:href|href)\s*=\s*\"([^\"]+)\"",
                           html)
        for s in srcs:
            s = s.split("#")[0]
            ip = (sub + s).replace("%20", " ") if not s.startswith("/") \
                else s[1:]
            # normaliseer ../
            delen = []
            for d in ip.split("/"):
                if d == "..":
                    if delen:
                        delen.pop()
                elif d not in ("", "."):
                    delen.append(d)
            ip = "/".join(delen)
            if ip in names and ip not in volgorde:
                volgorde.append(ip)
    return volgorde


def _plaatjes_uit(bron: Path, doel: Path) -> int:
    """Schrijft pagina's p00.jpg.. naar doel. Geeft aantal terug."""
    doel.mkdir(parents=True, exist_ok=True)
    ext = bron.suffix.lower()
    if ext == ".zip":
        with zipfile.ZipFile(bron) as z:
            namen = sorted(n for n in z.namelist()
                           if Path(n).suffix.lower() in BEELD_EXT
                           and not n.startswith("__MACOSX")
                           and "/" + Path(n).name not in n[:1])
            namen = [n for n in namen if not Path(n).name.startswith(".")]
            for i, n in enumerate(namen):
                _schrijf_pagina(z.read(n), doel, i)
        return len(namen)
    if ext == ".epub":
        with zipfile.ZipFile(bron) as z:
            volgorde = _epub_volgorde(z)
            if not volgorde:
                volgorde = sorted(n for n in z.namelist()
                                  if Path(n).suffix.lower() in BEELD_EXT)
            i = 0
            for n in volgorde:
                if _schrijf_pagina(z.read(n), doel, i):
                    i += 1
            return i
    raise ValueError("Alleen .epub of .zip met afbeeldingen")


def _schrijf_pagina(data: bytes, doel: Path, i: int) -> bool:
    try:
        im = Image.open(io.BytesIO(data)).convert("RGB")
        im.thumbnail((MAX_BREEDTE, MAX_BREEDTE), Image.LANCZOS)
        im.save(doel / f"p{i:02d}.jpg", quality=82, optimize=True)
        return True
    except Exception:
        return False


def _audio(bron: Path, doel: Path) -> None:
    ext = bron.suffix.lower()
    if ext == ".mp3":
        shutil.copy2(str(bron), str(doel))
        return
    r = __import__("subprocess").run(
        [imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-hide_banner",
         "-loglevel", "error", "-i", str(bron), "-b:a", "160k",
         str(doel)], capture_output=True, timeout=600)
    if not doel.exists() or doel.stat().st_size < 1000:
        raise ValueError("Audio kon niet omgezet worden naar mp3")


# ------------------------------------------------------------- speler ----

SPELER_HTML = """<!doctype html>
<html lang="nl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{titel} — videoboek</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Georgia,'Times New Roman',serif;background:#0d2135;
color:#f5efe0;min-height:100vh;display:flex;align-items:center;
justify-content:center;padding:16px}}
.speler{{width:min(880px,100%);text-align:center}}
h1{{font-size:clamp(1.3rem,4vw,1.9rem);font-weight:600;margin-bottom:4px}}
.sub{{color:#9fb4c4;font-size:.9rem;margin-bottom:16px}}
.scherm{{background:#071522;border-radius:14px;overflow:hidden;
box-shadow:0 10px 40px rgba(0,0,0,.5);position:relative}}
.scherm img{{width:100%;height:min(62vh,560px);object-fit:contain;display:block}}
.play{{position:absolute;inset:0;display:flex;align-items:center;
justify-content:center;background:rgba(7,21,34,.45);border:0;
cursor:pointer;transition:.2s}}
.play:hover{{background:rgba(7,21,34,.25)}}
.play svg{{width:88px;height:88px;filter:drop-shadow(0 4px 12px rgba(0,0,0,.6))}}
.bar{{display:flex;align-items:center;gap:12px;margin-top:14px}}
.bar button{{background:#1b3a55;color:#f5efe0;border:0;border-radius:10px;
width:44px;height:44px;font-size:1.15rem;cursor:pointer}}
.bar button:hover{{background:#25507a}}
.teller{{font-size:.9rem;color:#9fb4c4;min-width:76px}}
.voort{{flex:1;height:7px;background:#1b3a55;border-radius:4px;overflow:hidden}}
.voort i{{display:block;height:100%;width:0;background:#f5a623;border-radius:4px;
transition:width .25s}}
.tip{{margin-top:12px;font-size:.85rem;color:#7c93a8}}
</style></head><body>
<div class="speler">
<h1>📖 {titel}</h1>
<div class="sub">Videoboek — druk op play, de pagina's bladeren zelf mee</div>
<div class="scherm"><img id="img" src="paginas/p00.jpg" alt="">
<button class="play" id="play" onclick="start()"><svg viewBox="0 0 100 100">
<circle cx="50" cy="50" r="46" fill="#f5a623"/>
<path d="M40 32 L72 50 L40 68 Z" fill="#0d2135"/></svg></button></div>
<div class="bar">
<button onclick="stap(-1)" title="Vorige pagina">⏮</button>
<button onclick="stap(1)" title="Volgende pagina">⏭</button>
<span class="teller" id="tel">1 / {n}</span>
<div class="voort"><i id="vrt"></i></div>
</div>
<div class="tip">Tip: blader zelf met ⏮ ⏭ — of laat het verhaal je meenemen.
Gemaakt met G2B Videoboek-Fabriek.</div>
</div>
<audio id="aud" src="audio.mp3" preload="metadata"></audio>
<script>
var N={n},i=0,timer=null;
var img=document.getElementById('img'),aud=document.getElementById('aud'),
tel=document.getElementById('tel'),vrt=document.getElementById('vrt'),
playBtn=document.getElementById('play');
function zet(){{
img.src='paginas/p'+String(i).padStart(2,'0')+'.jpg';
tel.textContent=(i+1)+' / '+N;
vrt.style.width=((i+1)/N*100)+'%';}}
function stap(d){{i=Math.max(0,Math.min(N-1,i+d));zet();}}
function start(){{
playBtn.style.display='none';
aud.play();
timer=setInterval(function(){{
if(aud.duration){{var ni=Math.min(N-1,Math.floor(aud.currentTime/aud.duration*N));
if(ni!==i){{i=ni;zet();}}}}}},300);}}
aud.addEventListener('ended',function(){{clearInterval(timer);}});
aud.addEventListener('pause',function(){{playBtn.style.display='flex';}});
aud.addEventListener('play',function(){{playBtn.style.display='none';}});
document.addEventListener('keydown',function(e){{
if(e.key==='ArrowRight')stap(1);if(e.key==='ArrowLeft')stap(-1);}});
zet();
</script></body></html>
"""


def _schrijf_speler(vdir: Path, titel: str, aantal: int) -> None:
    (vdir / "index.html").write_text(
        SPELER_HTML.replace("{titel}", escape(titel))
        .replace("{n}", str(aantal)), encoding="utf-8")


# ------------------------------------------------------------- publiek ---

def _kies_evenredig(paginas: Path, wil: int) -> int:
    """Beperk het aantal pagina's tot `wil`: kiest plaatjes evenredig
    verdeeld door het boek (eerste én laatste blijven altijd) en
    hernoemt de rest weer netjes p00.jpg.. Geeft nieuw aantal terug."""
    alle = sorted(paginas.glob("p*.jpg"))
    totaal = len(alle)
    if wil <= 0 or totaal <= wil:
        return totaal
    if wil == 1:
        houd = [0]
    else:
        houd = sorted({round(i * (totaal - 1) / (wil - 1))
                       for i in range(wil)})
    gekozen = [alle[i] for i in houd]
    for f in alle:
        if f not in gekozen:
            f.unlink()
    for i, f in enumerate(sorted(paginas.glob("p*.jpg"))):
        nieuw = paginas / f"p{i:02d}.jpg"
        if f.name != nieuw.name:
            f.rename(nieuw)
    return len(gekozen)


def maak(titel: str, boek: Path, audio: Path,
         max_plaatjes: int = 0) -> dict:
    """Bouw een videoboek-pakket. Geeft het record terug.
    max_plaatjes>0 = voor full-bleed boeken: kies dat aantal
    pagina's, evenredig verdeeld door het hele boek."""
    data = laad()
    vid = secrets.token_hex(4)
    vdir = VB_DIR / vid
    paginas = vdir / "paginas"
    aantal = _plaatjes_uit(boek, paginas)
    if aantal < 1:
        shutil.rmtree(vdir, ignore_errors=True)
        raise ValueError("Geen afbeeldingen gevonden in het boek")
    aantal = _kies_evenredig(paginas, max_plaatjes)
    _audio(audio, vdir / "audio.mp3")
    _schrijf_speler(vdir, titel, aantal)
    # cover = eerste pagina
    eerste = paginas / "p00.jpg"
    if eerste.exists():
        shutil.copy2(str(eerste), str(vdir / "cover.jpg"))
    rec = {
        "id": vid,
        "titel": titel,
        "paginas": aantal,
        "gemaakt": date.today().isoformat(),
    }
    data["videoboeken"].append(rec)
    sla(data)
    return rec


def maak_zip(vid: str) -> Path:
    """Zip van het hele pakket in exports/ — staat meteen bij
    BESTANDEN in de app."""
    vdir = VB_DIR / vid
    if not vdir.exists():
        raise ValueError("Videoboek niet gevonden")
    data = laad()
    try:
        titel = vind(data, vid)["titel"]
    except ValueError:
        titel = "videoboek"
    from .winkel import _slug
    slug = _slug(titel)
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    uit = EXPORT_DIR / f"videoboek-{slug}.zip"
    with zipfile.ZipFile(uit, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(vdir.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(vdir))
    return uit


def verwijder(data: dict, vid: str) -> None:
    vind(data, vid)
    shutil.rmtree(VB_DIR / vid, ignore_errors=True)
    data["videoboeken"] = [v for v in data["videoboeken"]
                           if v["id"] != vid]
    sla(data)


# ------------------------------------------------------------- mp4 -------
import subprocess


def _duur(pad: Path) -> float:
    try:
        r = subprocess.run(
            [imageio_ffmpeg.get_ffmpeg_exe(), "-i", str(pad),
             "-hide_banner"], capture_output=True, text=True, timeout=60)
        m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr or "")
        if m:
            return (int(m.group(1)) * 3600 + int(m.group(2)) * 60
                    + float(m.group(3)))
    except Exception:
        pass
    return 0.0


def maak_mp4(vid: str, fps: int = 25) -> Path:
    """Render het videoboek als één mp4: elke pagina wordt een
    Ken Burns-clip (zacht inzoomen), audio eronder, fade aan het eind.
    CPU-ffmpeg, 1280x720 — regel 1 (imageio-ffmpeg, LGPL-binary maar
    vrij te gebruiken; eigen code)."""
    vdir = VB_DIR / vid
    audio = vdir / "audio.mp3"
    paginas = sorted((vdir / "paginas").glob("p*.jpg"))
    if not audio.exists() or not paginas:
        raise ValueError("Videoboek of audio ontbreekt")
    totaal = _duur(audio)
    if totaal <= 0:
        totaal = len(paginas) * 6.0
    per = totaal / len(paginas)
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    tmp = vdir / "_mp4tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    try:
        frames = max(2, int(per * fps))
        for i, p in enumerate(paginas):
            seg = tmp / f"s{i:03d}.mp4"
            # Ken Burns: beeld 4x opschalen, dan langzaam inzoomen
            zoom = "1+0.0008*in"
            r = subprocess.run([
                ff, "-y", "-loop", "1", "-i", str(p),
                "-filter_complex",
                f"scale=2560:-2,zoompan=z='{zoom}':x='iw/2-(iw/zoom/2)':"
                f"y='ih/2-(ih/zoom/2)':d={frames}:s=1280x720:fps={fps},"
                "format=yuv420p",
                "-t", f"{per:.2f}", "-r", str(fps),
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
                str(seg)], capture_output=True, text=True, timeout=600)
            if r.returncode != 0 or not seg.exists():
                raise ValueError("ffmpeg mislukte: " + (r.stderr or "")[-200:])
        # concat + audio + einde-fade
        lst = tmp / "lijst.txt"
        lst.write_text("".join(
            f"file '{s.name}'\n" for s in sorted(tmp.glob("s*.mp4"))))
        uit = EXPORT_DIR / f"videoboek-{vid}.mp4"
        EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        fade_st = max(0.0, totaal - 1.5)
        subprocess.run([
            ff, "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
            "-i", str(audio),
            "-vf", f"fade=t=out:st={fade_st:.2f}:d=1.5",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
            "-c:a", "aac", "-b:a", "160k", "-t", f"{totaal:.2f}",
            "-movflags", "+faststart",
            str(uit)], capture_output=True, text=True, timeout=1800)
        if not uit.exists() or uit.stat().st_size < 10000:
            raise ValueError("mp4-render mislukt")
        return uit
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------- publish ---
def publiceer_site(vid: str) -> dict:
    """1-klik-naar-site: zet het videoboek op GS Books in de
    g2b-winkel GitHub-repo onder gsbooks/vb/<slug>/ en werk het
    vb/index.json-manifest bij (additive tree — niets anders raakt
    weg). Repo/branch/token komen uit de WINKEL-instellingen."""
    from . import winkel
    data = laad()
    rec = vind(data, vid)
    vdir = VB_DIR / vid
    if not vdir.exists():
        raise ValueError("Videoboek-map ontbreekt")
    inst = winkel.laad()["instellingen"]
    repo, branch, token = (inst["repo"].strip(),
                           inst["branch"].strip(),
                           inst["github_token"].strip())
    if not repo or not token:
        raise ValueError("Vul bij WINKEL → Instellingen eerst repo + "
                         "GitHub-token in")
    # bestaand manifest ophalen (mag ontbreken)
    manifest: list[dict] = []
    try:
        cur = winkel._gh(
            "GET", f"/repos/{repo}/contents/gsbooks/vb/index.json"
                   f"?ref={branch}", token)
        manifest = json.loads(
            base64.b64decode(cur["content"]).decode("utf-8"))
    except Exception:
        manifest = []

    slug = rec.get("site_slug")
    if not slug:
        slug = winkel._slug(rec["titel"])
        # twee boeken met dezelfde titel mogen elkaars site-map niet
        # delen — maak de slug uniek als die al in het manifest staat
        basis_slugs = {m.get("slug") for m in manifest}
        n = 2
        while slug in basis_slugs:
            slug = f"{winkel._slug(rec['titel'])}-{n}"
            n += 1
    rec["site_slug"] = slug
    sla(data)
    basis = f"gsbooks/vb/{slug}"

    files: dict[str, Path] = {}
    for f in vdir.rglob("*"):
        if f.is_file():
            files[f"{basis}/{f.relative_to(vdir).as_posix()}"] = f
    manifest = [m for m in manifest if m.get("slug") != slug]
    manifest.append({
        "slug": slug, "titel": rec["titel"],
        "paginas": rec["paginas"],
        "url": f"vb/{slug}/index.html",
        "cover": f"vb/{slug}/cover.jpg",
    })
    import io as _io
    import tempfile
    mtmp = Path(tempfile.mkdtemp()) / "index.json"
    mtmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=1),
                    encoding="utf-8")
    files["gsbooks/vb/index.json"] = mtmp

    ref = winkel._gh("GET",
                     f"/repos/{repo}/git/ref/heads/{branch}", token)
    base_sha = ref["object"]["sha"]
    base_tree = winkel._gh(
        "GET", f"/repos/{repo}/git/commits/{base_sha}", token)["tree"]["sha"]

    blobs = []
    for rel, f in files.items():
        blob = winkel._gh("POST", f"/repos/{repo}/git/blobs", token,
                          json={"content": base64.b64encode(
                              f.read_bytes()).decode(),
                              "encoding": "base64"})
        blobs.append({"path": rel, "mode": "100644", "type": "blob",
                      "sha": blob["sha"]})
    tree = winkel._gh("POST", f"/repos/{repo}/git/trees", token,
                      json={"base_tree": base_tree, "tree": blobs})
    commit = winkel._gh("POST", f"/repos/{repo}/git/commits", token,
                        json={"message": f"videoboek: {rec['titel']}",
                              "tree": tree["sha"], "parents": [base_sha]})
    winkel._gh("PATCH", f"/repos/{repo}/git/refs/heads/{branch}",
               token, json={"sha": commit["sha"]})
    url = (f"https://{repo.split('/')[0]}.github.io/{repo.split('/')[1]}"
           f"/{basis}/index.html")
    rec["site_url"] = url
    rec["paginas_site"] = rec["paginas"]
    sla(data)
    return {"url": url, "commit": commit["sha"][:8],
            "bestanden": len(files)}


def verwijder_van_site(vid: str) -> dict:
    """Haal een gepubliceerd videoboek ook van GS Books af:
    gsbooks/vb/<slug>/ weg uit de tree (sha:null) + uit index.json.
    Roeps vóór de lokale delete zodat site_slug nog bekend is."""
    from . import winkel
    data = laad()
    rec = vind(data, vid)
    slug = rec.get("site_slug") or winkel._slug(rec["titel"])
    inst = winkel.laad()["instellingen"]
    repo, branch, token = (inst["repo"].strip(),
                           inst["branch"].strip(),
                           inst["github_token"].strip())
    if not repo or not token:
        raise ValueError("Vul bij WINKEL → Instellingen eerst repo + "
                         "GitHub-token in")
    basis = f"gsbooks/vb/{slug}"

    ref = winkel._gh("GET",
                     f"/repos/{repo}/git/ref/heads/{branch}", token)
    base_sha = ref["object"]["sha"]
    base_tree = winkel._gh(
        "GET", f"/repos/{repo}/git/commits/{base_sha}", token)["tree"]["sha"]

    # alle bestanden onder de vb-map markeren als verwijderd
    full = winkel._gh(
        "GET", f"/repos/{repo}/git/trees/{base_tree}?recursive=1", token)
    verdwenen = [t for t in full.get("tree", [])
                 if t.get("type") == "blob"
                 and t["path"].startswith(basis + "/")]

    # index.json zonder deze slug — bij een mislukte fetch NOOIT
    # een leeg manifest committen (dat wist alle boeken van de site)
    import tempfile
    try:
        cur = winkel._gh(
            "GET", f"/repos/{repo}/contents/gsbooks/vb/index.json"
                   f"?ref={branch}", token)
        manifest = json.loads(
            base64.b64decode(cur["content"]).decode("utf-8"))
    except Exception:
        raise ValueError("Kon het site-manifest niet lezen — "
                         "niets verwijderd, probeer opnieuw")
    if not verdwenen and not any(m.get("slug") == slug
                                 for m in manifest):
        return {"ok": True, "verwijderd": 0, "slug": slug,
                "noot": "stond niet op de site"}
    manifest = [m for m in manifest if m.get("slug") != slug]
    mtmp = Path(tempfile.mkdtemp()) / "index.json"
    mtmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=1),
                    encoding="utf-8")

    mblob = winkel._gh("POST", f"/repos/{repo}/git/blobs", token,
                       json={"content": base64.b64encode(
                           mtmp.read_bytes()).decode(),
                           "encoding": "base64"})
    entries = [{"path": "gsbooks/vb/index.json", "mode": "100644",
                "type": "blob", "sha": mblob["sha"]}]
    entries += [{"path": t["path"], "mode": "100644", "type": "blob",
                 "sha": None} for t in verdwenen]
    tree = winkel._gh("POST", f"/repos/{repo}/git/trees", token,
                      json={"base_tree": base_tree, "tree": entries})
    commit = winkel._gh("POST", f"/repos/{repo}/git/commits", token,
                        json={"message": f"videoboek verwijderd: {slug}",
                              "tree": tree["sha"], "parents": [base_sha]})
    winkel._gh("PATCH", f"/repos/{repo}/git/refs/heads/{branch}",
               token, json={"sha": commit["sha"]})
    for k in ("site_url", "paginas_site", "site_slug"):
        rec.pop(k, None)
    sla(data)
    return {"ok": True, "verwijderd": len(verdwenen), "slug": slug}


# simpele job-status voor mp4-renders (duurt even: per pagina een clip)
_JOBS: dict[str, str] = {}


def mp4_status(vid: str) -> str:
    return _JOBS.get(vid, "")


def mp4_start(vid: str) -> None:
    """Start de mp4-render in een achtergrond-thread."""
    import threading
    if _JOBS.get(vid) == "busy":
        return
    _JOBS[vid] = "busy"

    def run():
        try:
            pad = maak_mp4(vid)
            _JOBS[vid] = "klaar:" + pad.name
        except Exception as e:
            _JOBS[vid] = "fout:" + str(e)[:200]

    threading.Thread(target=run, daemon=True).start()


# ------------------------------------------------- interactief (CYOA) ---

INTERACTIEF_JS = """// interactieve videoboek-speler — kind kiest het pad (regel 1: eigen code)
const wrap = document.getElementById("scene");
const audio = document.getElementById("stem");
const keuzebox = document.getElementById("keuzes");
const titelEl = document.getElementById("titel");
let huidig = null, plaatTimer = null;

function scene(id) {
  huidig = STORY.scenes[id];
  if (!huidig) return;
  keuzebox.innerHTML = "";
  keuzebox.style.display = "none";
  document.getElementById("einde").style.display = "none";
  wrap.innerHTML = "";
  const tt = document.getElementById("tekst");
  if (huidig.tekst) { tt.textContent = huidig.tekst; tt.style.display = ""; }
  else tt.style.display = "none";
  const paginas = huidig.paginas || [];
  // elke plaat ~4s Ken Burns, zolang de audio duurt
  let i = 0;
  const toon = () => {
    wrap.innerHTML = "";
    const img = document.createElement("img");
    img.src = "scenes/" + id + "/paginas/" + paginas[i % paginas.length];
    img.className = "kb";
    wrap.appendChild(img);
    i++;
  };
  if (paginas.length) toon();
  if (plaatTimer) clearInterval(plaatTimer);
  if (paginas.length > 1) plaatTimer = setInterval(toon, 4000);
  if (huidig.audio) {
    audio.src = huidig.audio;
    audio.play().catch(() => { klaar(); });
    audio.onended = klaar;
  } else {
    // zonder stem: leestijd schaalt mee met de tekstlengte
    const lees = huidig.tekst ? 1800 + huidig.tekst.length * 85 : 0;
    setTimeout(klaar, Math.max(2500, 4000 * Math.min(paginas.length, 2),
                             Math.min(lees, 20000)));
  }
}

function klaar() {
  if (plaatTimer) clearInterval(plaatTimer);
  document.getElementById("tekst").style.display = "none";
  const kz = huidig.keuzes || [];
  if (!kz.length) {
    document.getElementById("eindeTekst").textContent =
      huidig.einde || "Einde — goed gekozen!";
    const tb = document.getElementById("terugNaar");
    if (huidig.terug) {
      tb.style.display = "";
      tb.onclick = () => scene(huidig.terug);
    } else {
      tb.style.display = "none";
    }
    document.getElementById("einde").style.display = "flex";
    return;
  }
  keuzebox.innerHTML = "";
  kz.forEach(k => {
    const b = document.createElement("button");
    b.className = "keuze";
    b.textContent = k.label;
    b.onclick = () => scene(k.doel);
    keuzebox.appendChild(b);
  });
  keuzebox.style.display = "flex";
}

document.getElementById("opnieuw").onclick = () => scene(STORY.start);
// start via knop: browsers eisen een gebruikers-gebaar voor audio-autoplay
document.getElementById("speel").onclick = () => {
  document.getElementById("start").style.display = "none";
  scene(STORY.start);
};
"""

INTERACTIEF_HTML = """<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{titel} — interactief videoboek</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:#0b0d0c;color:#e8ecea;
  font:16px/1.5 'Segoe UI',system-ui,sans-serif;overflow:hidden}
#scene{position:fixed;inset:0}
#scene img.kb{position:absolute;inset:0;width:100%;height:100%;
  object-fit:cover;opacity:0;
  animation:kb 6s ease-in-out forwards,fadein 1s ease forwards}
@keyframes kb{0%{transform:scale(1)}100%{transform:scale(1.12)}}
@keyframes fadein{to{opacity:1}}
#titel{position:fixed;top:14px;left:0;right:0;text-align:center;
  font-weight:800;font-size:clamp(18px,3vw,26px);letter-spacing:1px;
  text-shadow:0 2px 12px #000;z-index:5;pointer-events:none}
#keuzes{position:fixed;bottom:8%;left:0;right:0;display:none;
  flex-wrap:wrap;gap:16px;justify-content:center;z-index:6;padding:0 20px}
#tekst{position:fixed;bottom:20%;left:50%;transform:translateX(-50%);
  max-width:min(760px,86vw);background:#0b0d0cc9;border-radius:14px;
  padding:10px 20px;font-size:clamp(16px,2.4vw,22px);font-weight:700;
  text-align:center;text-shadow:0 1px 4px #000;z-index:5;display:none}
button.keuze{background:#2fbf71;color:#04120a;border:0;border-radius:16px;
  padding:18px 30px;font-size:clamp(17px,2.6vw,24px);font-weight:800;
  cursor:pointer;box-shadow:0 6px 24px #000a;min-width:200px}
button.keuze:hover{filter:brightness(1.12);transform:scale(1.04)}
#einde,#start{position:fixed;inset:0;background:#0b0d0cd9;display:none;z-index:8;
  flex-direction:column;align-items:center;justify-content:center;gap:18px;
  text-align:center;padding:24px}
#einde{overflow-y:auto;justify-content:flex-start;padding-top:15vh}
#einde h1{max-width:22em;line-height:1.35}
#start{display:flex}
#einde h1,#start h1{font-size:clamp(28px,5vw,44px);text-shadow:0 2px 12px #000}
#opnieuw,#speel{background:#2fbf71;color:#04120a;border:0;border-radius:14px;
  padding:16px 32px;font-size:clamp(17px,2.6vw,22px);font-weight:800;cursor:pointer}
#terugNaar{background:#fab005;color:#04120a;border:0;border-radius:14px;
  padding:14px 26px;font-size:clamp(15px,2.2vw,20px);font-weight:800;cursor:pointer}
#terugNaar:hover,#opnieuw:hover,#speel:hover{filter:brightness(1.12);transform:scale(1.04)}
#stem{display:none}
</style>
</head>
<body>
<div id="scene"></div>
<div id="titel">{titel}</div>
<div id="tekst"></div>
<div id="keuzes"></div>
<div id="einde"><h1 id="eindeTekst">Einde — goed gekozen!</h1>
  <button id="terugNaar" style="display:none">↩ Stel nog een vraag</button>
  <button id="opnieuw">🔁 Opnieuw spelen — ander pad</button></div>
<div id="start"><h1>{titel}</h1>
  <p>Jij bepaalt hoe dit verhaal gaat!</p>
  <button id="speel">▶ SPEEL HET VERHAAL</button></div>
<audio id="stem"></audio>
<script>{story}</script>
<script>{js}</script>
</body></html>
"""


def _tts(text: str, uit: Path) -> bool:
    """edge-tts voiceover (MIT); False als offline/mislukt → speler valt
    terug op alleen-beeld-modus."""
    if not text.strip():
        return False
    try:
        import asyncio
        import edge_tts
        import threading
        ok = []

        def _go():
            try:
                asyncio.run(edge_tts.Communicate(
                    text, "nl-NL-FennaNeural").save(str(uit)))
                ok.append(True)
            except Exception:
                ok.append(False)
        # eigen thread: asyncio.run mag niet in een draaiende event loop
        # (FastAPI-endpoint) — zo werkt het overal
        t = threading.Thread(target=_go, daemon=True)
        t.start()
        t.join(timeout=60)
        return ok and ok[0] and uit.exists() and uit.stat().st_size > 1000
    except Exception:
        return False


def maak_interactief(titel: str, scenes: list[dict],
                     start: str | None = None,
                     stem: bool = True) -> dict:
    """Bouw een kies-je-eigen-avontuur videoboek-pakket.
    scenes = [{id, platen:[Path], tekst, keuzes:[{label,doel}]}]
    - elke scene = platen-slideshow + edge-tts-voiceover + keuze-knoppen
    - keuzes wijzen naar scene-id's; scene zonder keuzes = einde
    Pakket: story.json + scenes/<id>/{paginas/,audio.mp3} + index.html."""
    import json as _json
    import re as _re
    # scene-id's worden mappen: alleen veilige tekens (geen ../ e.d.)
    def _sid(x: str) -> str:
        s = _re.sub(r"[^a-zA-Z0-9_-]", "_", str(x)).strip("_")
        if not s:
            raise ValueError("Scene-naam mag niet leeg zijn")
        return s
    data = laad()
    vid = secrets.token_hex(4)
    vdir = VB_DIR / vid
    vdir.mkdir(parents=True)
    story = {"start": _sid(start or scenes[0]["id"]), "scenes": {}}
    ids = {_sid(s["id"]) for s in scenes}
    for s in scenes:
        sid = _sid(s["id"])
        sdir = vdir / "scenes" / sid / "paginas"
        sdir.mkdir(parents=True)
        namen = []
        for i, p in enumerate(s.get("platen", [])):
            uit = sdir / f"p{i:02d}.jpg"
            shutil.copy2(str(p), str(uit))
            namen.append(uit.name)
        mp3rel = None
        if stem:
            mp3 = vdir / "scenes" / sid / "audio.mp3"
            if _tts(s.get("tekst", ""), mp3):
                mp3rel = f"scenes/{sid}/audio.mp3"
        keuzes = [{"label": k["label"], "doel": _sid(k["doel"])}
                  for k in s.get("keuzes", []) if _sid(k["doel"]) in ids]
        terug = (_sid(s["terug"])
                 if s.get("terug") and _sid(s["terug"]) in ids else None)
        story["scenes"][sid] = {
            "paginas": namen, "audio": mp3rel, "keuzes": keuzes,
            "tekst": s.get("tekst", ""),
            "einde": s.get("eindtekst") or s.get("einde") or "",
            "terug": terug}
    (vdir / "index.html").write_text(
        INTERACTIEF_HTML
        .replace("{titel}", escape(titel))
        .replace("{story}", "const STORY = " + _json.dumps(story)
                 .replace("</", "<\\/") + ";")
        .replace("{js}", INTERACTIEF_JS), encoding="utf-8")
    eerste = vdir / "scenes" / story["start"] / "paginas" / "p00.jpg"
    if eerste.exists():
        shutil.copy2(str(eerste), str(vdir / "cover.jpg"))
    rec = {"id": vid, "titel": titel + " (interactief)",
           "paginas": len(scenes), "gemaakt": date.today().isoformat(),
           "interactief": True}
    data["videoboeken"].append(rec)
    sla(data)
    return rec


VERHAAL_VOORBEELD = """# Kies-je-eigen-avontuur verhaal — één SCENE per blok
# platen: nummers van de plaatjes uit je boek (1 = eerste plaatje)
# KEUZE "knoptekst" -> doel-scene  (scene zonder KEUZE = einde)
# EINDTEKST: eigen afsluittext voor een einde-scene (optioneel)
# TERUG: scene-id — einde knoopt terug naar die scene (interview/lus)

SCENE start
platen: 1, 2
tekst: Keesje vindt een spoor in het bos. Welke kant gaat hij op?
KEUZE "🏞️ Naar de rivier" -> rivier
KEUZE "⛰️ De berg op" -> berg

SCENE rivier
platen: 3, 4
tekst: Bij de rivier vindt Keesje de verdwenen eend — veilig thuis gebracht!

SCENE berg
platen: 3, 4
tekst: Op de berg vindt Keesje een adelaar met het eende-ei — ook veilig!
"""


def parse_verhaal(tekst: str, aantal_platen: int) -> list[dict]:
    """Mini-formaat: SCENE <id> / platen: 1,2 / tekst: ... /
    KEUZE "label" -> doel. Plaat-nummers = index in boek (1-based,
    0 = geen plaat). Errors met regelnummers."""
    scenes, cur, fouten = [], None, []
    for nr, regel in enumerate(tekst.splitlines(), 1):
        r = regel.strip()
        if not r or r.startswith("#"):
            continue
        if r.upper().startswith("SCENE "):
            if cur:
                scenes.append(cur)
            cur = {"id": r[6:].strip(), "platen_idx": [],
                   "tekst": "", "keuzes": [], "eindtekst": "",
                   "terug": None}
        elif cur is None:
            fouten.append(f"regel {nr}: buiten een SCENE")
        elif r.lower().startswith("platen:"):
            for deel in r[7:].split(","):
                deel = deel.strip()
                if not deel:
                    continue
                try:
                    idx = int(deel) - 1
                except ValueError:
                    fouten.append(f"regel {nr}: geen plaatnummer '{deel}'")
                    continue
                if 0 <= idx < aantal_platen:
                    cur["platen_idx"].append(idx)
                else:
                    fouten.append(
                        f"regel {nr}: plaat {deel} niet in boek "
                        f"(1-{aantal_platen})")
        elif r.lower().startswith("tekst:"):
            cur["tekst"] = r[6:].strip()
        elif r.upper().startswith("EINDTEKST"):
            cur["eindtekst"] = r.split(":", 1)[-1].strip()
        elif r.upper().startswith("TERUG"):
            doel = r.split(":", 1)[-1].strip()
            if not doel:
                fouten.append(f"regel {nr}: TERUG mist doel-scene")
            cur["terug"] = doel
        elif r.upper().startswith("KEUZE"):
            # KEUZE "label" -> doel   of   KEUZE label -> doel
            rest = r[5:].strip()
            if "->" not in rest:
                fouten.append(f"regel {nr}: KEUZE mist '-> doel'")
                continue
            label, doel = rest.rsplit("->", 1)
            label = label.strip().strip('"').strip("'")
            doel = doel.strip()
            if not label or not doel:
                fouten.append(f"regel {nr}: KEUZE leeg label/doel")
                continue
            cur["keuzes"].append({"label": label, "doel": doel})
        elif cur["tekst"] and not cur["tekst"].endswith((".", "!", "?")):
            cur["tekst"] += " " + r  # doorlopende tekstregel
        elif cur["tekst"]:
            cur["tekst"] += " " + r
        else:
            cur["tekst"] = r
    if cur:
        scenes.append(cur)
    if not scenes:
        raise ValueError("Geen SCENE's gevonden in het verhaal")
    ids = {s["id"] for s in scenes}
    for s in scenes:
        for k in s["keuzes"]:
            if k["doel"] not in ids:
                fouten.append(
                    f"scene '{s['id']}': keuze naar onbekende "
                    f"scene '{k['doel']}'")
        if s.get("terug") and s["terug"] not in ids:
            fouten.append(
                f"scene '{s['id']}': TERUG naar onbekende "
                f"scene '{s['terug']}'")
    # minstens 1 einde nodig, anders loopt elk pad dood op een knop die nergens heen gaat
    if fouten:
        raise ValueError("Verhaal-fouten: " + "; ".join(fouten))
    return scenes


def maak_interactief_van_boek(titel: str, boek: Path,
                              verhaal: str,
                              stem: bool = True) -> dict:
    """Boek + verhaal-txt → interactief videoboek. Haalt de plaatjes uit
    het boek, mapt de platen:-nummers naar echte files."""
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="vb_platen_"))
    try:
        aantal = _plaatjes_uit(boek, tmp)
        if aantal < 1:
            raise ValueError("Geen afbeeldingen gevonden in het boek")
        platen = sorted(tmp.glob("p*.jpg"))
        scenes = parse_verhaal(verhaal, aantal)
        for s in scenes:
            s["platen"] = [platen[i] for i in s["platen_idx"]]
        return maak_interactief(titel, scenes, stem=stem)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
