"""G2B Muziekwinkel — beheer van de eigen open-source muziekwinkel.

Dit module beheert de productcatalogus (audio én andere digitale
producten zoals packs, zip's en e-books) en publiceert de winkel als
statische site naar een GitHub-repo met GitHub Pages.

Werking:
- inbox/   : dropzone — hier komen afgeronde producten terecht
             (handmatig uploaden of geëxporteerd uit andere G2B-apps).
- producten/{id}/ : per product het bronbestand, preview.mp3 en cover.png.
- winkel.json : catalogus + instellingen (repo, token blijft lokaal).
- site/    : de gebouwde statische site die naar GitHub gaat.

Alles lokaal; publiceren gebruikt alleen de GitHub REST API (geen
git-installatie nodig op Windows).
"""
from __future__ import annotations

import base64
import json
import re
import secrets
import shutil
import subprocess
import unicodedata
import zipfile
from datetime import date, datetime
from pathlib import Path

import imageio_ffmpeg
from PIL import Image, ImageDraw, ImageFont

APP_DIR = Path(__file__).resolve().parent.parent
BACKEND_ROOT = APP_DIR.parent               # backend/
REPO_ROOT = BACKEND_ROOT.parent             # repo-root (voor store-template)
WINKEL_DIR = BACKEND_ROOT / "storage" / "winkel"
INBOX_DIR = WINKEL_DIR / "inbox"
# Gedeelde aflevermap voor andere G2B-apps: elke app die hier een
# afgewerkt product in zet, verschijnt automatisch in de winkel-inbox.
GEDEELDE_DIR = Path.home() / "G2B-INBOX"
PRODUCTEN_DIR = WINKEL_DIR / "producten"
SITE_DIR = WINKEL_DIR / "site"
STATE_FILE = WINKEL_DIR / "winkel.json"
TEMPLATE_DIR = REPO_ROOT / "store"

AUDIO_EXT = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aif", ".aiff"}
PREVIEW_SECONDEN = 45
PREVIEW_START_FRACTIE = 0.33

# Licentie-namen zoals ze op bedankt-pagina en knoppen staan
LICENTIE_NAMEN = {
    "mp3": "MP3-lease",
    "wav": "WAV-licentie",
    "exclusief": "Exclusief (buy-out)",
    "download": "Volledige download",
}

# Extra producten die meereizen in de repo (los van de lokale
# winkel.json): store-extra/<map>/product.json + bestand + cover.png.
# Zo blijven door Devin beheerde shop-producten ook staan ná een
# verse publicatie vanuit deze app.
EXTRA_DIR = REPO_ROOT / "store-extra"

GITHUB_API = "https://api.github.com"


# ---------------------------------------------------------------- state

def _leeg() -> dict:
    return {
        "instellingen": {
            "repo": "good2better/g2b-winkel",
            "branch": "main",
            "site_titel": "G2B Muziekwinkel",
            "site_ondertitel": "Beats en meer — direct van de maker",
            "accent": "#2fbf71",
            "github_token": "",
            "betaal_dienst": "ChargeKeep",
            "stats_url": "",
        },
        "producten": [],
    }


def laad() -> dict:
    for d in (INBOX_DIR, PRODUCTEN_DIR, SITE_DIR):
        d.mkdir(parents=True, exist_ok=True)
    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = _leeg()
    else:
        data = _leeg()
    data.setdefault("instellingen", _leeg()["instellingen"])
    for k, v in _leeg()["instellingen"].items():
        data["instellingen"].setdefault(k, v)
    data.setdefault("producten", [])
    return data


def sla(data: dict) -> None:
    WINKEL_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _nieuw_id() -> str:
    return secrets.token_hex(4)


def _nieuwe_sleutels() -> dict:
    """Geheime download-sleutels per licentie. De sleutel bepaalt het
    pad van de download op de winkel-site (d/<sleutel>/); wie de sleutel
    niet kent, kan het bestand niet raden."""
    return {k: secrets.token_hex(8) for k in LICENTIE_NAMEN}


def _ensure_sleutels(p: dict) -> None:
    """Vul ontbrekende download-sleutels aan (oude producten)."""
    s = p.setdefault("sleutels", {})
    for k in LICENTIE_NAMEN:
        if k == "download" and p.get("soort") == "audio":
            continue          # audio gebruikt alleen mp3/wav/exclusief
        s.setdefault(k, secrets.token_hex(8))


def _slug(tekst: str) -> str:
    s = unicodedata.normalize("NFKD", tekst).encode("ascii", "ignore")
    s = re.sub(r"[^a-z0-9]+", "-", s.decode().lower()).strip("-")
    return s[:50] or "product"


def vind_product(data: dict, pid: str) -> dict:
    for p in data["producten"]:
        if p["id"] == pid:
            return p
    raise ValueError("Product niet gevonden")


# ---------------------------------------------------------------- inbox

AUDIO_ECHT = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aif", ".aiff"}


DEEL_UITLEG = """G2B-INBOX — gedeelde aflevermap
===========================================

Zet hier afgewerkte producten neer die je in de Muziekwinkel wilt
verkopen: beats (mp3/wav), packs (zip), e-books (pdf), spellen...

Andere G2B-apps (beatmachine, Sound Lab, PagePlay, ...) schrijven
hun eindproduct automatisch naar DEZE map. Alles wat hier landt,
verschijnt in de app onder 🎵 WINKEL → INBOX — één klik en het
staat in je winkel.

LET OP: bestanden die je in de winkel zet worden uit deze map
VERPLAATST (opgeruimd = verwerkt). Behalve dit uitleg-bestand.
"""


def _deel_uitleg() -> None:
    """Maak de gedeelde aflevermap + uitleg aan als ze er nog niet zijn."""
    try:
        GEDEELDE_DIR.mkdir(parents=True, exist_ok=True)
        uitleg = GEDEELDE_DIR / "DEEL-DEZE-MAP.txt"
        if not uitleg.exists():
            uitleg.write_text(DEEL_UITLEG, encoding="utf-8")
    except Exception:
        pass


def inbox_scan() -> list[dict]:
    """Lijst de bestanden die in de inbox wachten om geïmporteerd te
    worden — uit de eigen dropzone én uit de gedeelde G2B-INBOX-map
    waar andere apps hun afgewerkte producten neerzetten."""
    INBOX_DIR.mkdir(parents=True, exist_ok=True)
    _deel_uitleg()
    out = []
    for f in sorted(INBOX_DIR.iterdir()):
        if f.is_file() and not f.name.startswith("."):
            out.append({
                "bestand": f.name,
                "bron": "inbox",
                "grootte": f.stat().st_size,
                "soort": "audio" if f.suffix.lower() in AUDIO_ECHT
                         else "digitaal",
            })
    try:
        for f in sorted(GEDEELDE_DIR.iterdir()):
            if f.is_file() and not f.name.startswith(".") \
                    and f.name != "DEEL-DEZE-MAP.txt":
                out.append({
                    "bestand": f.name,
                    "bron": "gedeeld",
                    "grootte": f.stat().st_size,
                    "soort": "audio" if f.suffix.lower() in AUDIO_ECHT
                             else "digitaal",
                })
    except Exception:
        pass
    return out


def naar_inbox(bron: Path, naam: str | None = None) -> str:
    """Zet een bestand in de inbox. Geeft de inbox-bestandsnaam."""
    INBOX_DIR.mkdir(parents=True, exist_ok=True)
    naam = naam or bron.name
    doel = INBOX_DIR / Path(naam).name
    if doel.exists():
        stam, ext = doel.stem, doel.suffix
        i = 2
        while (INBOX_DIR / f"{stam}-{i}{ext}").exists():
            i += 1
        doel = INBOX_DIR / f"{stam}-{i}{ext}"
    shutil.copy2(str(bron), str(doel))
    return doel.name


# ---------------------------------------------------------------- media

def _ffmpeg() -> str:
    return imageio_ffmpeg.get_ffmpeg_exe()


def _duur(bron: Path) -> float:
    """Lees de duur in seconden uit de ffmpeg-output."""
    try:
        r = subprocess.run(
            [_ffmpeg(), "-i", str(bron), "-hide_banner"],
            capture_output=True, text=True, timeout=60)
        m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr or "")
        if m:
            return (int(m.group(1)) * 3600 + int(m.group(2)) * 60
                    + float(m.group(3)))
    except Exception:
        pass
    return 0.0


def maak_preview(bron: Path, doel: Path) -> bool:
    """Maak een 45-seconden preview-mp3 (fade in/out, 128k).
    Geeft True als het lukte."""
    duur = _duur(bron)
    start = max(0.0, duur * PREVIEW_START_FRACTIE)
    if duur and duur < PREVIEW_SECONDEN + 5:
        start = 0.0
        lengte = duur
    else:
        lengte = PREVIEW_SECONDEN
    fade_uit = max(0.0, lengte - 2.0)
    try:
        r = subprocess.run([
            _ffmpeg(), "-y", "-hide_banner", "-loglevel", "error",
            "-ss", f"{start:.2f}", "-i", str(bron),
            "-t", f"{lengte:.2f}",
            "-af", f"afade=t=in:d=1,afade=t=out:st={fade_uit:.2f}:d=2",
            "-b:a", "128k", str(doel),
        ], capture_output=True, text=True, timeout=300)
        return doel.exists() and doel.stat().st_size > 1000
    except Exception:
        return False


def _font(grootte: int, vet: bool = True) -> ImageFont.FreeTypeFont:
    fonts_dir = APP_DIR / "fonts"
    naam = "DejaVuSans-Bold.ttf" if vet else "DejaVuSans.ttf"
    pad = fonts_dir / naam
    try:
        return ImageFont.truetype(str(pad), grootte)
    except Exception:
        return ImageFont.load_default()


def maak_full_mp3(bron: Path, doel: Path) -> bool:
    """Volledige track als mp3 192k voor de MP3-lease-download.
    Geeft True als de conversie lukte."""
    try:
        subprocess.run([
            _ffmpeg(), "-y", "-hide_banner", "-loglevel", "error",
            "-i", str(bron), "-b:a", "192k", str(doel),
        ], capture_output=True, text=True, timeout=600)
        return doel.exists() and doel.stat().st_size > 1000
    except Exception:
        return False


def maak_cover(titel: str, doel: Path, soort: str = "audio") -> None:
    """Maakt een G2B-hoeskaart 600x600: donker vlak, groene rand,
    G2B-markering en de titel. Wordt alleen gebruikt als er geen eigen
    hoes is geüpload."""
    W, H = 600, 600
    img = Image.new("RGB", (W, H), (13, 15, 14))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 10], fill=(47, 191, 113))
    d.rectangle([0, H - 10, W, H], fill=(47, 191, 113))
    d.rectangle([24, 24, W - 24, H - 24], outline=(42, 47, 45), width=2)
    d.ellipse([W // 2 - 150, 90, W // 2 + 150, 390],
              outline=(47, 191, 113), width=6)
    d.ellipse([W // 2 - 50, 190, W // 2 + 50, 290], fill=(47, 191, 113))
    if soort == "audio":
        for i, h in enumerate([40, 70, 110, 70, 40]):
            x = W // 2 - 80 + i * 40
            d.rectangle([x, 240 - h // 2 + 40, x + 14, 240 + h // 2 + 40],
                        fill=(230, 236, 234))
    else:
        for i in range(3):
            off = i * 14
            d.rectangle([W // 2 - 70 + off, 190 + off,
                         W // 2 + 30 + off, 250 + off],
                        outline=(230, 236, 234), width=4)
    f_titel = _font(44)
    f_klein = _font(22, vet=False)
    woorden = titel.split()
    regels, regel = [], ""
    for w in woorden:
        proef = (regel + " " + w).strip()
        if d.textlength(proef, font=f_titel) > W - 120 and regel:
            regels.append(regel)
            regel = w
        else:
            regel = proef
    if regel:
        regels.append(regel)
    y = 430
    for r in regels[:3]:
        tw = d.textlength(r, font=f_titel)
        d.text(((W - tw) / 2, y), r, font=f_titel, fill=(232, 236, 234))
        y += 54
    label = "G2B — GOOD2BETTER"
    lw = d.textlength(label, font=f_klein)
    d.text(((W - lw) / 2, H - 60), label, font=f_klein,
           fill=(143, 160, 152))
    img.save(doel, "PNG")


# ---------------------------------------------------------------- producten

def importeer(data: dict, inbox_naam: str, titel: str, soort: str,
              prijs: str = "", beschrijving: str = "",
              bron_map: str = "inbox") -> dict:
    """Verplaatst een inbox-bestand naar een volwaardig product.
    bron_map: 'inbox' (dropzone) of 'gedeeld' (G2B-INBOX-map)."""
    map_dir = GEDEELDE_DIR if bron_map == "gedeeld" else INBOX_DIR
    bron = map_dir / Path(inbox_naam).name
    if not bron.exists():
        raise ValueError(f"Bestand niet gevonden: {inbox_naam}")
    pid = _nieuw_id()
    pdir = PRODUCTEN_DIR / pid
    pdir.mkdir(parents=True, exist_ok=True)
    doel = pdir / bron.name
    shutil.move(str(bron), str(doel))

    if soort == "audio":
        preview = pdir / "preview.mp3"
        heeft_preview = maak_preview(doel, preview)
        duur = _duur(doel)
    else:
        preview = None
        heeft_preview = False
        duur = 0.0

    cover = pdir / "cover.png"
    maak_cover(titel, cover, soort)

    product = {
        "id": pid,
        "titel": titel,
        "soort": soort,
        "beschrijving": beschrijving,
        "prijs": prijs,
        "prijzen": {"mp3": "", "wav": "", "exclusief": ""},
        "herkomst": "eigen",       # eigen | samples | mix
        "groep": "",               # vibe-tag: bv. "rustig", "trap", "soul"
        "bestand": doel.name,
        "preview": "preview.mp3" if heeft_preview else "",
        "cover": "cover.png",
        "cover_eigen": "",
        "links": {"koop": "", "mp3": "", "wav": "", "exclusief": ""},
        "download_url": "",
        "sleutels": _nieuwe_sleutels(),
        "splits": [{"naam": "Ik", "pct": 100}],
        "zichtbaar": True,
        "duur": round(duur, 1),
        "toegevoegd": date.today().isoformat(),
    }
    data["producten"].append(product)
    sla(data)
    return product


def werk_bij(data: dict, pid: str, velden: dict) -> dict:
    p = vind_product(data, pid)
    for k in ("titel", "beschrijving", "prijs", "download_url",
              "soort", "herkomst", "groep"):
        if k in velden:
            p[k] = velden[k]
    p.setdefault("prijzen", {"mp3": "", "wav": "", "exclusief": ""})
    p.setdefault("herkomst", "eigen")
    if "prijzen" in velden:
        p["prijzen"].update({k: v for k, v in velden["prijzen"].items()
                             if k in p["prijzen"]})
    if "links" in velden:
        p["links"].update({k: v for k, v in velden["links"].items()
                           if k in p["links"]})
    if "splits" in velden:
        splits = [{"naam": s["naam"].strip(), "pct": float(s["pct"])}
                  for s in velden["splits"] if s.get("naam")]
        totaal = sum(s["pct"] for s in splits)
        if abs(totaal - 100.0) > 0.01:
            raise ValueError(
                f"Splits moeten samen 100% zijn (nu {totaal:g}%)")
        p["splits"] = splits
    if "zichtbaar" in velden:
        p["zichtbaar"] = bool(velden["zichtbaar"])
    sla(data)
    return p


def zet_cover(data: dict, pid: str, bron: Path) -> dict:
    p = vind_product(data, pid)
    pdir = PRODUCTEN_DIR / pid
    img = Image.open(bron)
    img.thumbnail((600, 600))
    doel = pdir / "cover_eigen.png"
    img.save(doel, "PNG")
    p["cover_eigen"] = "cover_eigen.png"
    sla(data)
    return p


def verwijder(data: dict, pid: str) -> None:
    p = vind_product(data, pid)
    data["producten"] = [x for x in data["producten"] if x["id"] != pid]
    shutil.rmtree(PRODUCTEN_DIR / pid, ignore_errors=True)
    sla(data)


# ---------------------------------------------------------------- site bouwen

def site_url(inst: dict) -> str:
    """Publiek adres van de winkel, afgeleid van de repo-instelling.
    good2better/g2b-winkel → https://good2better.github.io/g2b-winkel/"""
    repo = (inst.get("repo") or "").strip().strip("/")
    if "/" in repo:
        eig, naam = repo.split("/", 1)
        return f"https://{eig}.github.io/{naam}/"
    return ""


def _donkerder(kleur: str, faktor: float = 0.62) -> str:
    """Maak een donkerdere variant van een #rrggbb-kleur (voor --accent2)."""
    try:
        r, g, b = (int(kleur[i:i + 2], 16) for i in (1, 3, 5))
        return "#%02x%02x%02x" % tuple(
            max(0, min(255, round(c * faktor))) for c in (r, g, b))
    except (ValueError, IndexError):
        return "#1d7a48"


def bedankt_links(data: dict, p: dict) -> dict:
    """De bedankt-links per licentie — deze plak je in Stripe bij
    'na betaling doorsturen'. Leeg als er nog geen repo is ingesteld."""
    base = site_url(data["instellingen"])
    if not base:
        return {}
    _ensure_sleutels(p)
    return {k: f"{base}bedankt.html?k={v}"
            for k, v in p["sleutels"].items()}


EXCL_TEKST = """EXCLUSIEF (buy-out)
==================

Deze track is exclusief aan jou verkocht.
De verkoper draagt hiermee de verkooprechten van deze beat over:
jij mag hem gebruiken, uitbrengen en erover rappen zonder dat hij
nog aan anderen wordt verkocht.

Vragen? Via de winkel.
"""


def _bouw_downloads(p: dict, pdir: Path, cover: str) -> None:
    """Schrijf per licentie d/<sleutel>/info.json + het bestand zelf.
    De sleutel staat NIET in products.json — alleen kopers krijgen hem
    via de bedankt-link uit de betaaldienst."""
    bron = pdir / p["bestand"]
    for lic, sleutel in p["sleutels"].items():
        if lic == "download" and p["soort"] == "audio":
            continue
        info = {"titel": p["titel"], "licentie": LICENTIE_NAMEN[lic]}
        if cover:
            info["cover"] = cover     # pad t.o.v. site-root (bedankt.html)
        if p.get("download_url"):
            info["url"] = p["download_url"]      # eigen link (FileJump)
        elif not bron.exists():
            continue                              # niets te leveren
        else:
            ddir = SITE_DIR / "d" / sleutel
            ddir.mkdir(parents=True, exist_ok=True)
            if lic == "mp3" and bron.suffix.lower() != ".mp3" \
                    and p["soort"] == "audio":
                if not maak_full_mp3(bron, ddir / "download.mp3"):
                    continue
                info["bestand"] = "download.mp3"
            elif lic == "exclusief" and p["soort"] == "audio":
                zip_pad = ddir / "exclusief-pakket.zip"
                with zipfile.ZipFile(zip_pad, "w",
                                     zipfile.ZIP_DEFLATED) as z:
                    z.write(bron, bron.name)
                    z.writestr("EXCLUSIEF-licentie.txt", EXCL_TEKST)
                info["bestand"] = "exclusief-pakket.zip"
            else:
                shutil.copy2(str(bron), str(ddir / bron.name))
                info["bestand"] = bron.name
        (SITE_DIR / "d" / sleutel).mkdir(parents=True, exist_ok=True)
        (SITE_DIR / "d" / sleutel / "info.json").write_text(
            json.dumps(info, ensure_ascii=False), encoding="utf-8")


def bouw_site(data: dict) -> Path:
    """Bouwt de complete statische winkel in site/. Geeft de map."""
    if SITE_DIR.exists():
        shutil.rmtree(SITE_DIR)
    SITE_DIR.mkdir(parents=True)
    if not TEMPLATE_DIR.exists():
        raise ValueError("Winkel-template ontbreekt: " + str(TEMPLATE_DIR))
    shutil.copytree(str(TEMPLATE_DIR), str(SITE_DIR),
                    dirs_exist_ok=True)

    inst = data["instellingen"]
    catalogus = []
    (SITE_DIR / "media").mkdir(exist_ok=True)
    (SITE_DIR / "d").mkdir(exist_ok=True)
    veranderd = False
    for p in data["producten"]:
        if not p["zichtbaar"]:
            continue
        _ensure_sleutels(p)
        veranderd = True
        pdir = PRODUCTEN_DIR / p["id"]
        item = {
            "id": p["id"], "titel": p["titel"], "soort": p["soort"],
            "beschrijving": p["beschrijving"], "prijs": p["prijs"],
            "prijzen": p.get("prijzen", {}),
            "links": p["links"], "duur": p.get("duur", 0),
            "groep": p.get("groep", ""),
        }
        cov = "cover_eigen.png" if p.get("cover_eigen") else "cover.png"
        if (pdir / cov).exists():
            doel = f"media/{p['id']}-cover.png"
            shutil.copy2(str(pdir / cov), str(SITE_DIR / doel))
            item["cover"] = doel
        if p.get("preview") and (pdir / "preview.mp3").exists():
            doel = f"media/{p['id']}-preview.mp3"
            shutil.copy2(str(pdir / "preview.mp3"), str(SITE_DIR / doel))
            item["preview"] = doel
        _bouw_downloads(p, pdir, item.get("cover", ""))
        catalogus.append(item)
    if veranderd:
        sla(data)                       # nieuwe sleutels bewaren

    # Extra producten uit de repo (store-extra/<map>/product.json):
    # worden bij élke build opnieuw in de site gezet, onafhankelijk van
    # de lokale winkel.json. Sleutels staan vast in product.json zodat
    # bedankt-links nooit veranderen.
    if EXTRA_DIR.exists():
        for edef in sorted(EXTRA_DIR.glob("*/product.json")):
            pdir = edef.parent
            try:
                xp = json.loads(edef.read_text(encoding="utf-8"))
            except Exception:
                continue
            xp.setdefault("soort", "digitaal")
            xp.setdefault("sleutels", {})
            xp.setdefault("links", {})
            item = {
                "id": xp["id"], "titel": xp["titel"],
                "soort": xp["soort"],
                "beschrijving": xp.get("beschrijving", ""),
                "prijs": xp.get("prijs", ""),
                "prijzen": xp.get("prijzen", {}),
                "links": xp["links"], "duur": 0,
                "groep": xp.get("groep", ""),
            }
            if (pdir / "cover.png").exists():
                doel = f"media/{xp['id']}-cover.png"
                shutil.copy2(str(pdir / "cover.png"),
                             str(SITE_DIR / doel))
                item["cover"] = doel
            _bouw_downloads(xp, pdir, item.get("cover", ""))
            catalogus.append(item)

    accent = inst.get("accent") or "#2fbf71"
    config = {
        "titel": inst["site_titel"],
        "ondertitel": inst["site_ondertitel"],
        "accent": accent,
        "accent2": _donkerder(accent),
        "stats_url": inst.get("stats_url", ""),
        "gebouwd": datetime.now().isoformat(timespec="seconds"),
        "producten": catalogus,
    }
    (SITE_DIR / "products.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=1),
        encoding="utf-8")
    return SITE_DIR


# ---------------------------------------------------------------- publiceren

def _gh(method: str, pad: str, token: str, **kwargs):
    import urllib.request
    import urllib.error
    req = urllib.request.Request(
        GITHUB_API + pad, method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "g2b-bedrijfsmiddelen",
        },
        **({"data": json.dumps(kwargs["json"]).encode(),
            } if "json" in kwargs else {}))
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        body = e.read().decode()[:300]
        if e.code == 404:
            raise ValueError(
                "Repo niet gevonden of token heeft geen toegang. "
                "Controleer repo-naam en token-rechten (Contents: "
                "read/write).")
        if e.code in (401, 403):
            raise ValueError(
                "Token geweigerd — maak een nieuwe token met "
                "Contents read/write op de winkel-repo.")
        raise ValueError(f"GitHub-fout {e.code}: {body}")


def publiceer(data: dict) -> dict:
    """Bouwt de site en pusht alle bestanden naar de GitHub-repo via de
    Git Data API (blobs → tree → commit → ref). Geen git nodig."""
    inst = data["instellingen"]
    repo, branch, token = (inst["repo"].strip(), inst["branch"].strip(),
                           inst["github_token"].strip())
    if not repo or "/" not in repo:
        raise ValueError("Vul eerst de repo in bij Instellingen "
                         "(bv. good2better/g2b-winkel)")
    if not token:
        raise ValueError("GitHub-token ontbreekt — vul die in bij "
                         "Instellingen (werkt alleen voor deze repo)")

    site = bouw_site(data)
    files = [f for f in site.rglob("*") if f.is_file()]

    ref = _gh("GET", f"/repos/{repo}/git/ref/heads/{branch}", token)
    base_sha = ref["object"]["sha"]

    blobs = []
    for f in files:
        rel = f.relative_to(site).as_posix()
        blob = _gh("POST", f"/repos/{repo}/git/blobs", token, json={
            "content": base64.b64encode(f.read_bytes()).decode(),
            "encoding": "base64"})
        blobs.append({"path": rel, "mode": "100644", "type": "blob",
                      "sha": blob["sha"]})

    tree = _gh("POST", f"/repos/{repo}/git/trees", token, json={
        "base_tree": base_sha,   # additief: gsbooks/, animalheroes/,
        "tree": blobs})          # en andere mappen blijven bewaard
    commit = _gh("POST", f"/repos/{repo}/git/commits", token, json={
        "message": f"winkel: {len(catalogus_aan(data))} producten "
                   f"({datetime.now():%d-%m-%Y %H:%M})",
        "tree": tree["sha"],
        "parents": [base_sha]})
    _gh("PATCH", f"/repos/{repo}/git/refs/heads/{branch}", token,
        json={"sha": commit["sha"]})

    return {
        "bestanden": len(files),
        "commit": commit["sha"][:8],
        "url": f"https://{repo.split('/')[0]}.github.io/"
               f"{repo.split('/')[1]}/",
    }


def catalogus_aan(data: dict) -> list:
    return [p for p in data["producten"] if p.get("zichtbaar")]


# ---------------------------------------------------------------- stats --
# Echte luister-tijd ("real views"): de winkelpagina post per product de
# seconden die een bezoeker echt luisterde naar een stats_url-endpoint.
# Jij importeert die data hier (of tikt cijfers handmatig in) en drukt een
# sponsor-rapport af.

STATS_FILE = WINKEL_DIR / "stats.jsonl"


def stats_laad() -> list[dict]:
    if not STATS_FILE.exists():
        return []
    out = []
    for regel in STATS_FILE.read_text(encoding="utf-8").splitlines():
        regel = regel.strip()
        if not regel:
            continue
        try:
            out.append(json.loads(regel))
        except Exception:
            pass
    return out


def stats_toevoegen(data: dict, product_id: str, seconden: float,
                    bron: str = "handmatig") -> dict:
    """Voeg één luisterbeurt toe. product_id mag ook een titel zijn."""
    titel = product_id
    for p in data["producten"]:
        if p["id"] == product_id:
            titel = p["titel"]
            break
    entry = {
        "ts": datetime.now().isoformat(timespec="seconds"),
        "product": titel, "product_id": product_id,
        "seconden": round(float(seconden), 1), "bron": bron,
    }
    WINKEL_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATS_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return entry


def stats_import(data: dict, text: str) -> dict:
    """Importeer stats uit JSONL (één JSON per regel: {product, seconden})
    of CSV (kolommen product/titel + seconden/luistertijd)."""
    toegevoegd, overgeslagen = 0, 0
    for regel in text.splitlines():
        regel = regel.strip()
        if not regel:
            continue
        prod, sec = None, None
        if regel.startswith("{"):
            try:
                r = json.loads(regel)
                prod = r.get("product") or r.get("product_id") or ""
                sec = float(r.get("seconden") or r.get("seconds") or 0)
            except Exception:
                pass
        else:
            delen = re.split(r"[;,\t]", regel)
            for i, deel in enumerate(delen):
                try:
                    sec = float(deel.replace(",", ".").strip())
                except ValueError:
                    if not prod:
                        prod = deel.strip()
        if prod and sec and sec > 0:
            stats_toevoegen(data, prod, sec, bron="import")
            toegevoegd += 1
        else:
            overgeslagen += 1
    return {"toegevoegd": toegevoegd, "overgeslagen": overgeslagen}


def stats_samenvatting(data: dict) -> dict:
    """Aggregeer per product: plays, totale échte luister-seconden,
    gemiddelde, langste — plus totaal."""
    per: dict[str, dict] = {}
    for e in stats_laad():
        k = e.get("product") or "onbekend"
        s = per.setdefault(k, {"plays": 0, "seconden": 0.0,
                               "langste": 0.0})
        sec = float(e.get("seconden") or 0)
        s["plays"] += 1
        s["seconden"] += sec
        s["langste"] = max(s["langste"], sec)
    rijen = []
    for titel, s in sorted(per.items(), key=lambda x: -x[1]["seconden"]):
        rijen.append({
            "titel": titel, "plays": s["plays"],
            "seconden": round(s["seconden"], 1),
            "minuten": round(s["seconden"] / 60, 1),
            "gemiddeld": round(s["seconden"] / max(1, s["plays"]), 1),
            "langste": round(s["langste"], 1),
        })
    totaal_sec = sum(r["seconden"] for r in rijen)
    return {
        "rijen": rijen,
        "totaal_plays": sum(r["plays"] for r in rijen),
        "totaal_seconden": round(totaal_sec, 1),
        "totaal_minuten": round(totaal_sec / 60, 1),
    }


def stats_rapport(data: dict, out_dir: Path) -> Path:
    """Sponsor-rapport als groene G2B-PDF: bewijs van échte luistertijd."""
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate
    from .pdfstyle import (GROEN, LIJN, Paragraph, Spacer, Table,
                           TableStyle, colors, footer_canvas, info_box,
                           kop_blok, mm, stijlen)

    samen = stats_samenvatting(data)
    s = stijlen()
    naam = f"luistercijfers_{date.today():%Y%m%d}.pdf"
    doel = out_dir / naam
    out_dir.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(doel), pagesize=A4,
                            leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=18 * mm, bottomMargin=18 * mm,
                            title="G2B Luistercijfers")
    el = [kop_blok("LUISTERCIJFERS — G2B Muziekwinkel",
                   "Echte luistertijd van échte bezoekers "
                   f"· {date.today():%d %B %Y}"),
          Spacer(1, 8 * mm)]
    el.append(info_box([
        f"<b>{samen['totaal_plays']}</b> plays",
        f"<b>{samen['totaal_minuten']:g} minuten</b> echt geluisterd "
        f"({samen['totaal_seconden']:g} seconden)",
        "Elke seconde is gemeten in de speler zelf — niet geschat."] ))
    el.append(Spacer(1, 6 * mm))
    el.append(Paragraph("Per track", s["h1"]))
    rijen = [[Paragraph("<b>Track</b>", s["tabelkop"]),
              Paragraph("<b>Plays</b>", s["tabelkop"]),
              Paragraph("<b>Echt geluisterd</b>", s["tabelkop"]),
              Paragraph("<b>Gemiddeld/play</b>", s["tabelkop"]),
              Paragraph("<b>Langste</b>", s["tabelkop"])]]
    def _fmt(sec):
        m, s2 = divmod(int(round(sec)), 60)
        return f"{m}:{s2:02d}"
    for r in samen["rijen"]:
        rijen.append([Paragraph(r["titel"], s["body"]),
                      Paragraph(str(r["plays"]), s["body"]),
                      Paragraph(_fmt(r["seconden"]), s["body"]),
                      Paragraph(_fmt(r["gemiddeld"]), s["body"]),
                      Paragraph(_fmt(r["langste"]), s["body"])])
    if len(rijen) == 1:
        rijen.append([Paragraph("Nog geen data — importeer stats of "
                                "koppel het stats-endpoint.", s["body"]),
                      "", "", "", ""])
    t = Table(rijen, colWidths=[64 * mm, 18 * mm, 32 * mm, 30 * mm,
                                26 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GROEN),
        ("GRID", (0, 0), (-1, -1), 0.5, LIJN),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.white, colors.HexColor("#F0F7F2")]),
    ]))
    el.append(t)
    el.append(Spacer(1, 6 * mm))
    el.append(Paragraph(
        "Meetmethode: de winkelspeler telt alleen seconden waarin de "
        "audio écht afspeelde — pauze, mute en wegklikken tellen niet "
        "mee. Vergelijkbaar met de watch-time-pings die YouTube gebruikt, "
        "maar dan voor jouw eigen winkel.", s["klein"]))
    doc.build(el, onFirstPage=footer_canvas("Luistercijfers"),
              onLaterPages=footer_canvas("Luistercijfers"))
    return doel


__all__ = [
    "laad", "sla", "inbox_scan", "naar_inbox", "importeer", "werk_bij",
    "zet_cover", "verwijder", "bouw_site", "publiceer", "vind_product",
    "stats_laad", "stats_toevoegen", "stats_import", "stats_samenvatting",
    "stats_rapport", "site_url", "bedankt_links",
    "WINKEL_DIR", "INBOX_DIR", "GEDEELDE_DIR", "PRODUCTEN_DIR",
    "SITE_DIR", "AUDIO_EXT",
]
