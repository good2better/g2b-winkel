"""Generators: contract, factuur, beschrijving, merk-assets."""
