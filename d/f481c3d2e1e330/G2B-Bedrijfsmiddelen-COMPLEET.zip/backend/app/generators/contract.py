"""Licentie-contract generator — professionele PDF via reportlab.

Groene G2B-huisstijl: kopbalk, partijenblok, rechten, verbod op
doorverkoop-als-zodanig, datum- en handtekeninglijnen.
"""
from __future__ import annotations

import re
from datetime import date
from pathlib import Path

from reportlab.platypus import SimpleDocTemplate

from .pdfstyle import (ACCENT, GROEN, LIJN, Paragraph, Spacer, Table,
                       TableStyle, footer_canvas, handtekening_tabel,
                       info_box, kop_blok, mm, stijlen)

def _verkoper_naam(verkoper: dict | None) -> str:
    v = verkoper or {}
    naam = v.get("bedrijfsnaam") or "de Verkoper"
    persoon = (v.get("naam") or "").strip()
    return f"{naam} ({persoon})" if persoon else naam

LICENTIES = {
    "personal": {
        "naam": "Persoonlijke licentie",
        "rechten": [
            "De Koper mag het Product gebruiken in eigen, niet-commerciële "
            "projecten (persoonlijk gebruik).",
            "De Koper mag het Product aanpassen/bewerken voor dat eigen "
            "gebruik.",
            "De Koper mag het Product NIET gebruiken in werk dat geld "
            "opbrengt (geen streams, verkopen, klantwerk of reclame).",
        ],
    },
    "commercial": {
        "naam": "Commerciële licentie",
        "rechten": [
            "De Koper mag het Product gebruiken in eigen commerciële "
            "eindproducten: releases, streams, klantwerk, video's en "
            "optredens.",
            "De Koper mag het Product aanpassen/bewerken binnen die "
            "eindproducten.",
            "De Koper hoeft geen naamsvermelding te geven (wel gewaardeerd, "
            "niet verplicht).",
        ],
    },
    "beat": {
        "naam": "Beat-licentie (non-exclusief)",
        "rechten": [
            "De Koper mag de Beat gebruiken in eigen nieuwe nummers en "
            "opnames (de 'Nieuwe Song').",
            "De Koper mag de Nieuwe Song uitbrengen, streamen, optreden en "
            "verkopen — onbeperkt aantal streams/downloads.",
            "De Koper mag de Beat binnen de Nieuwe Song bewerken: inkorten, "
            "layern, pitch/tempo aanpassen.",
            "De licentie is non-exclusief: de Verkoper mag dezelfde Beat "
            "ook aan anderen licentiëren.",
        ],
        "extra_verboden": [
            "De Beat registreren bij Content-ID (YouTube o.i.d.) alsof de "
            "Beat zelf van de Koper is; de Koper mag alleen zijn eigen "
            "Nieuwe Song claimen.",
            "De Beat gebruiken als basis voor een eigen beat- of "
            "sample-product (geen 'remix-pack' of doorverkoop-versie).",
        ],
        "eigendom_extra":
            "De Koper is volledig eigenaar van zijn eigen Nieuwe Song "
            "(eigen zang, tekst en master daarvan), maar niet van de "
            "Beat eronder — die blijft 100% van de Verkoper.",
    },
    "exclusief": {
        "naam": "Beat-licentie (exclusief)",
        "rechten": [
            "De Koper mag de Beat gebruiken in eigen nieuwe nummers en "
            "opnames (de 'Nieuwe Song').",
            "De Koper mag de Nieuwe Song uitbrengen, streamen, optreden en "
            "verkopen — onbeperkt aantal streams/downloads.",
            "De Koper mag de Beat binnen de Nieuwe Song bewerken: inkorten, "
            "layern, pitch/tempo aanpassen.",
            "De licentie is EXCLUSIEF: vanaf de datum van dit contract "
            "biedt de Verkoper deze Beat niet meer aan anderen aan en "
            "verleent hij geen nieuwe licenties erop.",
            "Eventuele eerder verleende non-exclusieve licenties op deze "
            "Beat blijven geldig — exclusiviteit geldt alleen voor "
            "nieuwe verkopen.",
        ],
        "extra_verboden": [
            "De Beat registreren bij Content-ID (YouTube o.i.d.) alsof de "
            "Beat zelf van de Koper is; de Koper mag alleen zijn eigen "
            "Nieuwe Song claimen.",
            "De Beat gebruiken als basis voor een eigen beat- of "
            "sample-product (geen 'remix-pack' of doorverkoop-versie).",
            "De exclusiviteit doorverkopen of overdragen — deze licentie "
            "is persoonlijk en geldt alleen voor de Koper.",
        ],
        "eigendom_extra":
            "Exclusief betekent: niemand anders koopt deze Beat meer — "
            "maar de Beat zélf blijft 100% eigendom van de Verkoper. "
            "De Koper is wel volledig eigenaar van zijn eigen Nieuwe "
            "Song (eigen zang, tekst en master daarvan).",
    },
    "buyout": {
        "naam": "Buy-out (volledige overdracht)",
        "rechten": [
            "De Koper krijgt álle exploitatierechten op het Product: "
            "gebruiken, uitbrengen, verkopen, bewerken en in licentie "
            "geven aan anderen — wereldwijd, voor de gekozen duur.",
            "De Verkoper verleent na deze overdracht geen eigen nieuwe "
            "licenties meer op het Product.",
            "De Verkoper mag het Product zelf blijven gebruiken voor "
            "promotie, portfolio en eigen commerciële doeleinden.",
            "De Koper vermeldt 'Produced by {VERKOPER}' waar "
            "redelijkerwijs mogelijk (naamsvermelding).",
        ],
        "extra_verboden": [
            "De naamsvermelding van de Verkoper verwijderen of doen "
            "alsof een ander het Product heeft gemaakt.",
            "De Verkoper aanspreken op gebruik voor eigen promo en "
            "portfolio — dat recht behoudt hij uitdrukkelijk.",
        ],
        "eigendom_vervang":
            "3.3 Buy-out: de exploitatierechten (het financiële deel van "
            "het auteursrecht) gaan voor de gekozen duur volledig over op "
            "de Koper. De Verkoper behoudt alleen zijn <b>naamsvermelding</b> "
            "— een moreel recht dat volgens Nederlands recht nooit "
            "overgedragen kan worden — én zijn eigen gebruiksrecht uit "
            "artikel 1.",
        "eigendom_extra":
            "De Koper is dus economisch eigenaar van het Product voor de "
            "duur van dit contract; de herkomst blijft zichtbaar via de "
            "naamsvermelding.",
    },
}

# Toegestane looptijden voor elk contract (nooit oneindig)
DUREN = ["1 jaar", "3 jaar", "10 jaar", "volle auteursrecht-duur"]


def slug(tekst: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", tekst.lower()).strip("-")
    return s[:40] or "koper"


def maak_contract(koper_naam: str, koper_email: str, product: str,
                  licentie_type: str, uit_dir: Path,
                  vergoeding: float = 0.0, duur: str = "3 jaar",
                  verkoper: dict | None = None) -> Path:
    """Bouwt het contract-PDF en geeft het pad terug."""
    lic = LICENTIES.get(licentie_type)
    if not lic:
        raise ValueError(f"Onbekend licentie-type: {licentie_type}")
    vk_naam = _verkoper_naam(verkoper)
    vk_bedrijf = (verkoper or {}).get("bedrijfsnaam") or "de Verkoper"
    pref = "".join(w[0] for w in vk_bedrijf.upper().split()
                   if w and w[0].isalnum())[:4] or "G2B"
    vandaag = date.today().strftime("%d-%m-%Y")
    nummer = f"{pref}-{date.today():%Y%m%d}-{abs(hash((koper_naam, product))) % 10000:04d}"

    uit = uit_dir / f"contract_{slug(koper_naam)}_{slug(product)}_{nummer}.pdf"
    doc = SimpleDocTemplate(
        str(uit), pagesize=(595.27, 841.89),  # A4
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title=f"Licentie-contract {nummer}",
        author=vk_bedrijf if vk_bedrijf != "de Verkoper" else "G2B")
    s = stijlen()
    el: list = []

    el.append(kop_blok(
        "LICENTIE-CONTRACT",
        f"Licentie-overeenkomst voor een digitaal product · "
        f"contractnummer {nummer} · {vandaag}"))
    el.append(Spacer(1, 8 * mm))

    # --- partijen --------------------------------------------------------
    el.append(Paragraph("Partijen", s["h1"]))
    pt = Table([
        [Paragraph("Verkoper", s["label"]), Paragraph(vk_naam, s["body"])],
        [Paragraph("Koper", s["label"]),
         Paragraph(f"{koper_naam} &lt;{koper_email}&gt;", s["body"])],
    ], colWidths=[30 * mm, 140 * mm])
    pt.setStyle(TableStyle([
        ("LINEBELOW", (0, 0), (-1, -2), 0.5, LIJN),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
    ]))
    el.append(pt)

    # --- product ---------------------------------------------------------
    el.append(Paragraph("Product en licentie", s["h1"]))
    prod_regels = [
        f"<b>Product:</b> {product}",
        f"<b>Licentie:</b> {lic['naam']}",
    ]
    if vergoeding > 0:
        prod_regels.append(
            f"<b>Licentievergoeding:</b> "
            f"{'€ ' + f'{vergoeding:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')}"
            " — eenmalig, geen doorlopende royalty's")
    prod_regels.append(
        f"<b>Geldig vanaf:</b> {vandaag} · duur: {duur} · "
        f"gebied: wereldwijd")
    el.append(info_box(prod_regels))

    # --- artikelen -------------------------------------------------------
    el.append(Paragraph("Artikel 1 — Verleende rechten", s["h1"]))
    for i, r in enumerate(lic["rechten"], 1):
        el.append(Paragraph(
            f"1.{i} " + r.replace("{VERKOPER}", vk_bedrijf), s["body"]))

    el.append(Paragraph("Artikel 2 — Wat niet mag", s["h1"]))
    verboden = [
        "Het Product doorverkopen, weggeven of delen <b>als zodanig</b> "
        "(dus niet als los bestand, pack, bundle of 'gratis download').",
        "Het Product opnieuw aanbieden in een eigen shop, library of "
        "verzameling — ook niet aangepast of omgedoopt.",
        "Doen alsof de Koper het Product zelf heeft gemaakt; het "
        "auteursrecht blijft bij de Verkoper.",
        "De licentie doorgeven aan een ander; de licentie is persoonlijk "
        "en niet overdraagbaar.",
    ] + list(lic.get("extra_verboden", []))
    for i, v in enumerate(verboden, 1):
        el.append(Paragraph(
            f"2.{i} " + v.replace("{VERKOPER}", vk_bedrijf), s["body"]))

    el.append(Paragraph("Artikel 3 — Eigendom en rechtenaandeel", s["h1"]))
    el.append(Paragraph(
        "3.1 Het Product is een origineel werk van de Verkoper (eigen "
        "compositie, gelayerde en bewerkte sounds, eigen mix en master) "
        "en lijkt op geen bestaand werk.", s["body"]))
    el.append(Paragraph(
        "3.2 Volgens de Nederlandse verdeling zijn de muziekrechten in "
        "drieën gesplitst: ⅓ componist, ⅓ tekstschrijver en ⅓ uitgever. "
        "De Verkoper is alle drie — componist, tekstschrijver én eigen "
        "uitgever (publishing) — én eigenaar van de master. Daarmee "
        "bezit de Verkoper <b>100% van alle rechten</b> op het Product.",
        s["body"]))
    eigendom33 = (lic.get("eigendom_vervang") or
                  "3.3 De Koper koopt een gebruiksrecht, geen eigendom "
                  "en geen aandeel: de Koper heeft géén recht op "
                  "auteursrecht, naburige rechten, publishing of "
                  "royalty's op het Product.")
    el.append(Paragraph(
        eigendom33.replace("{VERKOPER}", vk_bedrijf), s["body"]))
    if lic.get("eigendom_extra"):
        el.append(Paragraph(
            "3.4 " + lic["eigendom_extra"].replace("{VERKOPER}", vk_bedrijf),
            s["body"]))

    el.append(Paragraph("Artikel 4 — Levering en garantie", s["h1"]))
    el.append(Paragraph(
        "4.1 Het Product wordt digitaal geleverd. Het wordt geleverd "
        "'zoals het is' (as-is), zonder garantie dat het past bij een "
        "bepaald doel.", s["body"]))
    el.append(Paragraph(
        "4.2 De Verkoper is niet aansprakelijk voor schade door gebruik "
        "van het Product, behalve bij opzet of grove nalatigheid.", s["body"]))

    el.append(Paragraph("Artikel 5 — Recht en geschillen", s["h1"]))
    el.append(Paragraph(
        "5.1 Op deze overeenkomst is Nederlands recht van toepassing, "
        "ongeacht waar een partij zich bevindt.", s["body"]))
    el.append(Paragraph(
        "5.2 Geschillen worden voorgelegd aan de bevoegde rechter in "
        "Nederland, in de rechtbank van de woonplaats van de Verkoper.",
        s["body"]))

    # --- handtekening ----------------------------------------------------
    el.append(Spacer(1, 6 * mm))
    el.append(Paragraph("Ondertekening", s["h1"]))
    el.append(handtekening_tabel(
        f"Verkoper: {vk_naam}", f"Koper: {koper_naam}"))

    el.append(Spacer(1, 6 * mm))
    el.append(info_box([
        "<b>Samengevat:</b> de Koper mag het Product gebruiken zoals de "
        "licentie hierboven zegt — maar het nooit als los bestand "
        f"doorverkopen of delen. Alle rechten (100%) blijven altijd bij "
        f"{vk_bedrijf}.",
    ]))

    doc.build(el, onFirstPage=footer_canvas(f"Licentie-contract {nummer}"),
              onLaterPages=footer_canvas(f"Licentie-contract {nummer}"))
    return uit


__all__ = ["maak_contract", "LICENTIES"]
