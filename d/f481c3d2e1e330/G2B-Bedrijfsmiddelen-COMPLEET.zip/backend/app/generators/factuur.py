"""Simpele factuur-PDF — particuliere verkoop én ZZP/BTW-factuur.

btw_pct = 0 → particuliere verkoop (geen BTW).
btw_pct = 9 of 21 → zakelijke BTW-factuur met bedrijfsgegevens.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from reportlab.platypus import SimpleDocTemplate

from .contract import slug
from .pdfstyle import (GROEN, LIJN, Paragraph, Spacer, Table, TableStyle,
                       colors, footer_canvas, info_box, kop_blok, mm,
                       stijlen)

VERKOPER_DEFAULT = {"bedrijfsnaam": "Jouw Bedrijfsnaam", "naam": "",
                    "kvk": "", "btw_nr": "", "iban": "",
                    "email": "", "adres": ""}


def _prefix(bedrijfsnaam: str) -> str:
    """White-label voorvoegsel uit de bedrijfsnaam ('Test Studio BV' → TSB)."""
    p = "".join(w[0] for w in bedrijfsnaam.upper().split()
               if w and w[0].isalnum())[:4]
    return p or "G2B"


def _volgend_nummer(uit_dir: Path, prefix: str = "G2B") -> str:
    """Doorlopende factuurnummering per jaar (ZZP-verplicht):
    F-TSB-2026-0001, 0002, ... Teller in storage/factuur_teller.json."""
    teller = uit_dir.parent / "factuur_teller.json"
    jaar = str(date.today().year)
    try:
        data = json.loads(teller.read_text("utf-8")) if teller.exists() else {}
    except Exception:
        data = {}
    n = int(data.get(jaar, 0)) + 1
    data[jaar] = n
    teller.write_text(json.dumps(data), "utf-8")
    return f"F-{prefix}-{jaar}-{n:04d}"


def _eur(b: float) -> str:
    """Nederlandse schrijfwijze: € 1.234,56"""
    return "€ " + f"{b:,.2f}".replace(",", "X").replace(
        ".", ",").replace("X", ".")


def maak_factuur(klant_naam: str, bedrag: float, omschrijving: str,
                 uit_dir: Path, klant_email: str = "",
                 datum: str | None = None,
                 betaal_info: str = "",
                 verkoper: dict | None = None,
                 btw_pct: float = 0, incl_btw: bool = False) -> Path:
    """Bouwt de factuur-PDF en geeft het pad terug.

    btw_pct: 0 = particulier (geen BTW), anders 9 of 21.
    incl_btw: is `bedrag` incl. of excl. BTW ingevoerd.
    """
    if bedrag <= 0:
        raise ValueError("Bedrag moet groter zijn dan 0")
    v = {**VERKOPER_DEFAULT, **(verkoper or {})}
    dag = datum or date.today().strftime("%d-%m-%Y")
    nummer = _volgend_nummer(uit_dir, _prefix(v["bedrijfsnaam"]))
    zakelijk = btw_pct > 0

    if zakelijk and incl_btw:
        excl = round(bedrag / (1 + btw_pct / 100), 2)
        btw_bedrag = round(bedrag - excl, 2)
        totaal = bedrag
    elif zakelijk:
        excl = bedrag
        btw_bedrag = round(bedrag * btw_pct / 100, 2)
        totaal = round(bedrag + btw_bedrag, 2)
    else:
        excl = totaal = bedrag
        btw_bedrag = 0.0

    uit = uit_dir / f"factuur_{slug(klant_naam)}_{nummer}.pdf"
    doc = SimpleDocTemplate(
        str(uit), pagesize=(595.27, 841.89),
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title=f"Factuur {nummer}",
        author=v["bedrijfsnaam"] or "G2B")
    s = stijlen()
    el: list = []

    soort = "BTW-factuur" if zakelijk else "Particuliere verkoop"
    el.append(kop_blok(
        "FACTUUR",
        f"{soort} · factuurnummer {nummer} · datum {dag}"))
    el.append(Spacer(1, 8 * mm))

    # --- van / aan --------------------------------------------------------
    van_regels = [v["bedrijfsnaam"], v["naam"], v["adres"]]
    if v["kvk"]:
        van_regels.append(f"KvK: {v['kvk']}")
    if zakelijk and v["btw_nr"]:
        van_regels.append(f"BTW-nummer: {v['btw_nr']}")
    if v["email"]:
        van_regels.append(v["email"])
    aan_regels = [klant_naam] + ([klant_email] if klant_email else [])
    pt = Table([
        [Paragraph("Van", s["label"]), Paragraph("Aan", s["label"])],
        [Paragraph("<br/>".join(van_regels), s["body"]),
         Paragraph("<br/>".join(aan_regels), s["body"])],
    ], colWidths=[85 * mm, 85 * mm])
    pt.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LINEBELOW", (0, 1), (-1, 1), 0.5, LIJN),
    ]))
    el.append(pt)
    el.append(Spacer(1, 4 * mm))

    # --- specificatie ------------------------------------------------------
    el.append(Paragraph("Specificatie", s["h1"]))
    rows = [
        [Paragraph("<b>Omschrijving</b>", s["tabelkop"]),
         Paragraph("<b>Bedrag</b>", s["tabelkop"])],
        [Paragraph(omschrijving, s["body"]),
         Paragraph(_eur(excl), s["body"])],
    ]
    if zakelijk:
        rows.append([Paragraph(f"BTW {btw_pct:g}%", s["body"]),
                     Paragraph(_eur(btw_bedrag), s["body"])])
    rows.append([Paragraph("<b>Totaal te betalen</b>", s["body"]),
                 Paragraph(f"<b>{_eur(totaal)}</b>", s["body"])])
    rt = Table(rows, colWidths=[120 * mm, 50 * mm])
    rt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GROEN),
        ("LINEBELOW", (0, 0), (-1, -2), 0.5, LIJN),
        ("LINEABOVE", (0, -1), (-1, -1), 1, GROEN),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    el.append(rt)
    el.append(Spacer(1, 4 * mm))

    betaal = betaal_info or v["iban"]
    if betaal:
        el.append(info_box([f"<b>Betaalgegevens:</b> {betaal}"]))
        el.append(Spacer(1, 4 * mm))

    if zakelijk:
        el.append(info_box([
            "<b>BTW-factuur.</b> Bewaar deze factuur voor je "
            "belastingaangifte — deze voldoet aan de eisen voor een "
            "factuur tussen bedrijven (met KvK- en BTW-nummer).",
        ]))
    else:
        el.append(info_box([
            "<b>Particuliere verkoop.</b> Dit is een verkoop tussen twee "
            "personen/bedrijven zonder BTW-specificatie: er is geen "
            "BTW-bedrag gespecificeerd op deze factuur.",
            "Bewaar deze factuur samen met je betalingsbewijs als "
            "aankoopbewijs.",
        ]))

    el.append(Spacer(1, 10 * mm))
    el.append(Paragraph(
        f"Vragen over deze factuur? Neem contact op met "
        f"{v['bedrijfsnaam']}.", s["klein"]))

    doc.build(el, onFirstPage=footer_canvas(f"Factuur {nummer}"),
              onLaterPages=footer_canvas(f"Factuur {nummer}"))
    return uit


__all__ = ["maak_factuur"]
