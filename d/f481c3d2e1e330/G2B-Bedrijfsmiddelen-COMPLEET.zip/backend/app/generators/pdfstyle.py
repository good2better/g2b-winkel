"""Gedeelde G2B-huisstijl voor PDF's (reportlab).

Donkergroene koppen, lichtgroene vlakken — dezelfde groene stijl als de
G2B-handleidingen en de Workstation-contracten.
"""
from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.fonts import addMapping
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

FONTS_DIR = Path(__file__).resolve().parent.parent / "fonts"

# G2B huisstijl-kleuren (zelfde palet als de app en de merk-kit)
GROEN = colors.HexColor("#1A5D3A")       # donkergroen (koppen, kaders)
GROEN_LICHT = colors.HexColor("#F0F7F2")  # lichtgroen vlak
ACCENT = colors.HexColor("#2FBF71")       # G2B-accentgroen
LIJN = colors.HexColor("#DDDDDD")
TEKST = colors.HexColor("#1a1a1a")
DIM = colors.HexColor("#666666")

_REGISTERED = False


def registreer_fonts() -> tuple[str, str]:
    """Registreert DejaVu (in repo meegeleverd, Bitstream-licentie, vrij
    voor commercieel gebruik). Geeft (normaal, bold) font-namen terug."""
    global _REGISTERED
    if not _REGISTERED:
        pdfmetrics.registerFont(
            TTFont("G2B", str(FONTS_DIR / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(
            TTFont("G2B-Bold", str(FONTS_DIR / "DejaVuSans-Bold.ttf")))
        addMapping("G2B", 0, 0, "G2B")
        addMapping("G2B", 1, 0, "G2B-Bold")
        _REGISTERED = True
    return "G2B", "G2B-Bold"


def stijlen() -> dict[str, ParagraphStyle]:
    font, bold = registreer_fonts()
    return {
        "titel": ParagraphStyle(
            "titel", fontName=bold, fontSize=22, leading=26,
            textColor=colors.white),
        "subtitel": ParagraphStyle(
            "subtitel", fontName=font, fontSize=10, leading=13,
            textColor=colors.HexColor("#CDE8D8")),
        "h1": ParagraphStyle(
            "h1", fontName=bold, fontSize=13, leading=16,
            textColor=GROEN, spaceBefore=10, spaceAfter=4),
        "body": ParagraphStyle(
            "body", fontName=font, fontSize=10, leading=14,
            textColor=TEKST, spaceAfter=4),
        "klein": ParagraphStyle(
            "klein", fontName=font, fontSize=8.5, leading=11,
            textColor=DIM),
        "tabelkop": ParagraphStyle(
            "tabelkop", fontName=bold, fontSize=10, leading=13,
            textColor=colors.white),
        "label": ParagraphStyle(
            "label", fontName=bold, fontSize=10, leading=13,
            textColor=GROEN),
    }


def kop_blok(titel: str, subtitel: str) -> Table:
    """Groene kopbalk met witte titel + lichte subtitel."""
    s = stijlen()
    t = Table(
        [[Paragraph(titel, s["titel"])],
         [Paragraph(subtitel, s["subtitel"])]],
        colWidths=[170 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), GROEN),
        ("LEFTPADDING", (0, 0), (-1, -1), 14),
        ("RIGHTPADDING", (0, 0), (-1, -1), 14),
        ("TOPPADDING", (0, 0), (0, 0), 12),
        ("BOTTOMPADDING", (0, -1), (0, -1), 12),
        ("TOPPADDING", (0, 1), (0, 1), 0),
    ]))
    return t


def info_box(regels: list[str]) -> Table:
    """Lichtgroen informatieblok met groene linkerrand."""
    s = stijlen()
    data = [[Paragraph(r, s["body"])] for r in regels]
    t = Table(data, colWidths=[170 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), GROEN_LICHT),
        ("LINEBEFORE", (0, 0), (0, -1), 3, GROEN),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def handtekening_tabel(links: str, rechts: str) -> Table:
    """Twee handtekening-lijnen naast elkaar."""
    s = stijlen()
    lijn = "_" * 32
    data = [
        [Paragraph(links, s["label"]), Paragraph(rechts, s["label"])],
        [Paragraph(f"{lijn}<br/>handtekening", s["klein"]),
         Paragraph(f"{lijn}<br/>handtekening", s["klein"])],
        [Paragraph(f"{lijn}<br/>datum + plaats", s["klein"]),
         Paragraph(f"{lijn}<br/>datum + plaats", s["klein"])],
    ]
    t = Table(data, colWidths=[85 * mm, 85 * mm])
    t.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    return t


def footer_canvas(footer_tekst: str):
    """Canvas-functie: grijze gecentreerde footer + paginanummer."""
    font, _ = registreer_fonts()

    def _teken(canvas, doc):
        canvas.saveState()
        canvas.setFont(font, 8)
        canvas.setFillColor(DIM)
        canvas.drawCentredString(
            A4[0] / 2, 10 * mm, f"{footer_tekst} · pagina {doc.page}")
        canvas.restoreState()

    return _teken


__all__ = [
    "A4", "Paragraph", "Spacer", "Table", "TableStyle",
    "colors", "mm", "stijlen", "kop_blok", "info_box",
    "handtekening_tabel", "footer_canvas", "registreer_fonts",
    "GROEN", "GROEN_LICHT", "ACCENT", "LIJN", "TEKST", "DIM",
]
