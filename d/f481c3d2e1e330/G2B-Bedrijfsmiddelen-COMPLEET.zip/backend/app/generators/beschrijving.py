"""Product-beschrijving generator — verkooptekst in het Nederlands.

100% template-gebaseerd (geen AI, geen cloud): vaste bouwstenen die
met de ingevulde velden een lange Gumroad/site-tekst en een korte
versie bouwen. Ook op te slaan als .txt in exports.
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

from .contract import slug

TYPES = {
    "beat": {
        "naam": "beat",
        "voor": "artiesten en producers",
        "claim": "een kant-en-klare basis voor je volgende track",
        "rechten": "royaltyvrij voor je releases (zie licentie)",
    },
    "samplepack": {
        "naam": "samplepack",
        "voor": "producers die sneller willen werken",
        "claim": "klanken die direct in je project passen",
        "rechten": "100% royaltyvrij — gebruik in al je beats",
    },
    "app": {
        "naam": "app",
        "voor": "makers die alles lokaal willen regelen",
        "claim": "een tool die op je eigen PC draait — geen abonnement",
        "rechten": "eenmalige aankoop, voor altijd van jou",
    },
    "ebook": {
        "naam": "e-book",
        "voor": "beginners die het stap voor stap willen leren",
        "claim": "alles uitgelegd in simpel Nederlands",
        "rechten": "digitaal geleverd, meteen lezen",
    },
    "overig": {
        "naam": "digitaal product",
        "voor": "iedereen die serieus aan de slag wil",
        "claim": "gemaakt met aandacht, klaar voor gebruik",
        "rechten": "digitaal geleverd, direct aan de slag",
    },
}


def maak_teksten(product: str, type_: str, eigenschappen: list[str],
                 prijs: str = "", doelgroep: str = "",
                 verkoper: dict | None = None) -> dict:
    """Geeft {"lang": ..., "kort": ...} verkoopteksten terug."""
    merk = (verkoper or {}).get("bedrijfsnaam") or "de maker"
    t = TYPES.get(type_, TYPES["overig"])
    voor = doelgroep.strip() or t["voor"]
    feats = [e.strip() for e in eigenschappen if e.strip()]

    bullets = "\n".join(f"• {f}" for f in feats) if feats else \
        f"• {t['claim']}"

    prijs_regel = f"\n\nPrijs: {prijs}\n" if prijs.strip() else ""

    lang = f"""{product.upper()}

{t['naam'].capitalize()} voor {voor} — {t['claim']}.

WAAROM DIT PRODUCT
Gemaakt door {merk}: een maker die zijn eigen
producten dagelijks gebruikt. Geen loze beloftes — je krijgt precies
wat hieronder staat.

WAT JE KRIJGT
{bullets}

GOED OM TE WETEN
• {t['rechten']}
• Instant download — meteen aan de slag
• Lokaal aanbod: geen abonnement, geen verborgen kosten
• Vragen achteraf? Rechtstreeks contact met de maker.{prijs_regel}
{merk}
"""

    feat_kort = f" met {', '.join(feats[:3])}" if feats else ""
    kort = (
        f"{product} — {t['naam']} voor {voor}{feat_kort}. "
        f"{t['rechten']}. Instant download."
        + (f" Prijs: {prijs}." if prijs.strip() else "")
        + f" {merk}."
    )
    return {"lang": lang, "kort": kort}


def sla_op(product: str, teksten: dict, uit_dir: Path) -> Path:
    uit = uit_dir / f"beschrijving_{slug(product)}_{date.today():%Y%m%d}.txt"
    uit.write_text(
        f"{teksten['lang']}\n{'=' * 60}\nKORTE VERSIE\n{'=' * 60}\n\n"
        f"{teksten['kort']}\n",
        encoding="utf-8")
    return uit


__all__ = ["maak_teksten", "sla_op", "TYPES"]
