"""G2B Kleurboek-Fabriek — gekleurde boekplaten → kleurplaten + kleurboek-PDF.

Maakt van gekleurde illustraties (boekplaten, heldenplaatjes, covers)
automatisch zwart-wit lijntekeningen die kinderen kunnen inkleuren,
en bundelt ze tot een print-klare A4 kleurboek-PDF.

Techniek: "color dodge" — het beeld wordt omgekeerd en geblurd, daarna
vermenigvuldigd met het origineel. Zo blijven alleen de lijnen over,
exact de methode die bekende online kleurplaat-tools gebruiken.
Alles lokaal: Pillow + numpy + reportlab (regel 1: vrij, 100% commercieel).
"""
from __future__ import annotations

import json
import math
import re
import secrets
import subprocess
import tempfile
import unicodedata
from pathlib import Path

import base64

import imageio_ffmpeg

import numpy as np
from PIL import Image, ImageFilter, ImageOps

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

from .pdfstyle import GROEN, TEKST

APP_DIR = Path(__file__).resolve().parent.parent
BACKEND_ROOT = APP_DIR.parent
KB_DIR = BACKEND_ROOT / "storage" / "kleurboek"
PAG_DIR = KB_DIR / "paginas"
EXPORT_DIR = BACKEND_ROOT / "storage" / "exports"

BEELD_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
VIDEO_EXT = {".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v"}
MAX_BREEDTE = 1400  # werkbereedte voor de lijntekening
VIDEO_FRAMES = 8    # aantal filmbeelden per video → kleurplaten


def _slug(s: str) -> str:
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s or "kleurplaat"


def _staat() -> dict:
    f = KB_DIR / "kleurboek.json"
    if f.exists():
        return json.loads(f.read_text("utf-8"))
    return {"paginas": []}


def _sla(staat: dict) -> None:
    KB_DIR.mkdir(parents=True, exist_ok=True)
    (KB_DIR / "kleurboek.json").write_text(
        json.dumps(staat, indent=2, ensure_ascii=False), "utf-8")


def naar_kleurplaat(src: Path, dst: Path, maxim: int = MAX_BREEDTE) -> None:
    """Maak van één plaat een inkbare zwart-wit lijntekening.

    Twee stappen:
    1. color-dodge → zwakke schetslijnen
    2. afwerking → lijnen verstevigen naar strak zwart, papier sneeuwwit:
       echte randen (FIND_EDGES) er donker overheen, zodat dunne en
       belangrijke contouren even sterk worden als de rest.
    """
    img = Image.open(src).convert("L")
    img.thumbnail((maxim, maxim * 3))
    img = ImageOps.autocontrast(img, cutoff=1)

    omgekeerd = ImageOps.invert(img)
    vaag = omgekeerd.filter(ImageFilter.GaussianBlur(12))

    a = np.asarray(img, dtype=np.float32)
    b = np.asarray(vaag, dtype=np.float32)
    # dodge: alleen echte lijnen blijven donker, vlakken worden wit
    res = np.clip(a * 255.0 / np.maximum(255.0 - b, 1.0), 0, 255)
    uit = Image.fromarray(res.astype(np.uint8), "L")
    uit = uit.filter(ImageFilter.MedianFilter(3))          # ruis-vlekjes weg

    # --- afwerking: lijnen verstevigen -------------------------------
    # randen uit het origineel = waar de échte contouren zitten.
    # Drempel gooit zwakke textuur-randen (gras, spikkels) weg; alleen
    # sterke contouren vermenigvuldigen we over de schets (multiply):
    # wit blijft wit, echte lijnen worden strak potlood-zwart.
    randen = img.filter(ImageFilter.FIND_EDGES)
    randen = randen.point(lambda i: 0 if i < 45 else min(255, int(i * 0.9)))

    # TEKST-herkenning: waar veel randen dicht op elkaar staan (letters,
    # kleine details) is de versteviging zachter — letters blijven fijn
    # lijntjes zoals in de schets, tekening-contouren worden juist strak.
    dichtheid = randen.filter(ImageFilter.GaussianBlur(14))
    dichtheid = ImageOps.autocontrast(dichtheid, cutoff=6)
    tekst_masker = dichtheid.point(lambda i: min(255, int(i * 1.4)))
    zachte_rand = randen.point(lambda i: int(i * 0.45))   # tekst: zacht
    sterke_rand = randen                                   # tekening: strak
    randen = Image.composite(zachte_rand, sterke_rand, tekst_masker)

    randen = randen.filter(ImageFilter.GaussianBlur(1.0))  # zachte overgang
    donkere_rand = ImageOps.invert(randen)
    arr = (np.asarray(uit, dtype=np.float32)
           * np.asarray(donkere_rand, dtype=np.float32) / 255.0)
    uit = Image.fromarray(arr.astype(np.uint8), "L")

    # contrast: lichtgrijs → papier-wit, echte lijnen → potlood-zwart
    uit = ImageOps.autocontrast(uit, cutoff=2)
    lut = [min(255, int(i * 255 / 235)) for i in range(256)]
    uit = uit.point(lut)
    uit = uit.point(lambda i: 255 if i > 232 else i)
    dst.parent.mkdir(parents=True, exist_ok=True)
    uit.save(dst, "PNG")


def _video_frames(src: Path, aantal: int = VIDEO_FRAMES) -> list[Path]:
    """Haal `aantal` gelijkmatig verdeelde beelden uit een video (ffmpeg)."""
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    duur_r = subprocess.run(
        [ff, "-hide_banner", "-i", str(src)],
        capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", duur_r.stderr or "")
    duur = 10.0
    if m:
        duur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    tmpdir = Path(tempfile.mkdtemp(prefix="kb_frames_", dir=str(PAG_DIR)))
    frames = []
    for i in range(aantal):
        t = duur * (i + 0.5) / aantal
        out = tmpdir / f"f{i:02d}.png"
        r = subprocess.run(
            [ff, "-y", "-hide_banner", "-ss", f"{t:.2f}", "-i", str(src),
             "-frames:v", "1", "-q:v", "2", str(out)],
            capture_output=True, timeout=120)
        if out.exists() and out.stat().st_size:
            frames.append(out)
    return frames


def voeg_toe(bestanden: list[tuple[str, bytes]], boek: str = "") -> list[dict]:
    """Converteer geüploade plaatjes (én video's) naar kleurplaten."""
    PAG_DIR.mkdir(parents=True, exist_ok=True)
    staat = _staat()
    nieuwe = []

    def bewaar(bron: Path, label: str) -> None:
        pid = secrets.token_hex(3)
        out = PAG_DIR / f"{_slug(label)}-{pid}.png"
        naar_kleurplaat(bron, out)
        # klein kleurvoorbeeld van het origineel (zoals Paw Patrol doet:
        # kind ziet hoe de plaat er in kleur uitziet ter inspiratie)
        try:
            voorb = Image.open(bron).convert("RGB")
            voorb.thumbnail((900, 900))          # kaft nodigt hoge res uit
            voorb.save(PAG_DIR / f"{out.stem}-voorb.jpg", "JPEG", quality=90)
        except Exception:
            pass
        item = {"id": out.stem, "naam": out.name, "bron": label,
                "boek": boek.strip(), "kaft_uit": False}
        staat["paginas"].append(item)
        nieuwe.append(item)

    for naam, data in bestanden:
        ext = Path(naam).suffix.lower()
        tmp = PAG_DIR / f"_bron-{secrets.token_hex(4)}{ext or '.bin'}"
        tmp.write_bytes(data)
        try:
            if ext in VIDEO_EXT:
                # KLEURPLAAT-filter op film: frames → kleurplaten
                for i, fr in enumerate(_video_frames(tmp), 1):
                    bewaar(fr, f"{Path(naam).stem}-frame{i}")
            elif ext in BEELD_EXT:
                bewaar(tmp, Path(naam).stem)
        finally:
            tmp.unlink(missing_ok=True)
    _sla(staat)
    return nieuwe


def lijst_paginas() -> list[dict]:
    return _staat()["paginas"]


def kaft_uit_zetten(pid: str, uit: bool) -> bool:
    """Plaat wél als kleurplaat gebruiken maar NIET op de kaft
    (bijv. auteur/promo-platen: de gebruiker kiest zelf welke weg moet)."""
    staat = _staat()
    for p in staat["paginas"]:
        if p["id"] == pid:
            p["kaft_uit"] = bool(uit)
            _sla(staat)
            return True
    return False


def verwijder_pagina(pid: str) -> bool:
    staat = _staat()
    voor = len(staat["paginas"])
    staat["paginas"] = [p for p in staat["paginas"] if p["id"] != pid]
    _sla(staat)
    (PAG_DIR / f"{pid}.png").unlink(missing_ok=True)
    return len(staat["paginas"]) < voor


# Merk-stijlen voor de kleurboek-omslag: "ah" = Animal Heroes (licht,
# speels — aqua/teal/geel zoals de merksite), "g2b" = donker G2B-groen.
MERKEN = {
    "ah": {
        "bg": (0.878, 0.969, 0.980),       # aqua #E0F7FA
        "balk": (0.298, 0.686, 0.314),      # groen #4CAF50
        "titel": (0.0, 0.302, 0.247),       # teal #004D40
        "sub": (0.129, 0.588, 0.953),       # blauw #2196F3
        "accent": (1.0, 0.596, 0.0),        # oranje #FF9800
        "voet": "© AnimalHeroes.club by Good2better"
                " — Saving Lives Every Day",
    },
    "g2b": {
        "bg": (0.94, 0.98, 0.95),
        "balk": (0.102, 0.365, 0.227),      # GROEN
        "titel": (1, 1, 1),
        "sub": (1, 1, 1),
        "accent": (0.184, 0.749, 0.443),    # accentgroen
        "voet": "© Good2better"
                " — alleen voor eigen gebruik",
    },
}


# Animal Heroes huisstijl-achtergrond (aqua lucht, wolken, groene heuvels,
# oranje pootjes) — het "alles-in-1" merkbeeld op elke AH-kaft.
AH_BG = Path(__file__).resolve().parents[1] / "static" / "ah-achtergrond.png"


def _bg(c, ox: float, oy: float, W: float, H: float,
        stijl: dict, merk: str) -> None:
    """Merk-achtergrond: AH-illustratie als die er is, anders vlak kleur.
    Met stijl['bg_tint'] schuiven lucht/gras mee in boek-tint."""
    if merk == "ah" and AH_BG.exists():
        src = AH_BG
        if "bg_tint" in stijl:
            src = _bg_getint(stijl["bg_tint"])
        c.drawImage(ImageReader(str(src)), ox, oy, W, H)
    else:
        c.setFillColorRGB(*stijl["bg"])
        c.rect(ox, oy, W, H, stroke=0, fill=1)


def _bg_getint(kleur: tuple) -> Path:
    """Boek-tint over de AH-achtergrond: gekleurde film, gecachet per tint
    zodat elke kaft z'n eigen wereld-kleuren krijgt (zelfde teken-stijl)."""
    import colorsys
    r, g, b = kleur
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    tint = PAG_DIR / f"ah-bg-tint-{int(h * 360)}.png"
    if not tint.exists():
        base = Image.open(AH_BG).convert("RGB")
        film = Image.new("RGB", base.size,
                         tuple(round(x * 255) for x in
                               colorsys.hsv_to_rgb(h, 0.55, 0.85)))
        Image.blend(base, film, 0.28).save(tint)
    return tint


_REMBG = None


def _rembg() -> object | None:
    """Laadt de AI-achtergrondverwijderaar (rembg/u2net) als die er is.
    Eén keer laden; de rest van de app merkt er niets van."""
    global _REMBG
    if _REMBG is None:
        try:
            from rembg import remove  # MIT — regel 1 OK
            _REMBG = remove
        except Exception:
            _REMBG = False
    return _REMBG or None


def _boek_tint(helden: list[Path], stijl: dict,
               boeken: int = 1) -> dict:
    """Kaft-thema mee-laten-veranderen met het boek: dominante kleur van de
    beste heldenplaat → titel-balk/glow/achtergrond (zee→zee-tint, bos→bos).
    Bundel (meerdere boeken) = brede merk-tint, geen enkel-boek-tint."""
    import colorsys
    stijl = dict(stijl)
    if helden and boeken <= 1:
        try:
            im = Image.open(helden[0]).convert("RGB").resize((64, 64))
            px = [p for p in im.getdata() if max(p) - min(p) > 25]
            if px:
                r, g, b = (sum(c[i] for c in px) / len(px) for i in range(3))
                h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
                # behoud AH-groen-teal familie maar schuif naar boek-tint
                nh = min(0.50, max(0.22,
                                   (h * 0.6 + 0.33 * 0.4) % 1.0))
                nb = colorsys.hsv_to_rgb(nh, min(0.75, s * 0.9 + 0.35), 0.68)
                stijl["balk"] = tuple(round(x, 3) for x in nb)
                ng = colorsys.hsv_to_rgb(nh, 0.42, 0.90)
                stijl["glow"] = tuple(round(x, 3) for x in ng)
        except Exception:
            pass
    stijl.setdefault("glow", (0.75, 0.90, 0.87))
    return stijl


def _held_score(bron: Path) -> float:
    """Hoe 'helder' is de plaat? Verhouding zichtbare pixels in de uitsnede
    plus kwaliteitscheck: tekst-banners, dunne vormen en volle foto's
    vallen automatisch af (de gebruiker: alleen mooie schone helden gebruiken)."""
    try:
        a = Image.open(_blend_plaat(bron)).getchannel("A")
        tot = a.width * a.height
        if not tot:
            return 0.0
        hist = a.histogram()
        cover = sum(v for i, v in enumerate(hist) if i > 128) / tot
        if cover > 0.80:                 # bijna alles = foto, geen held
            return 0.0
        bbox = a.getbbox()
        if not bbox:
            return 0.0
        bw, bh = bbox[2] - bbox[0], bbox[3] - bbox[1]
        ar = bw / bh if bh else 0.0
        if ar < 0.35 or ar > 2.8:        # lint/banner-vorm (vaak tekst)
            return 0.0
        fill = sum(v for i, v in enumerate(hist) if i > 128) / (bw * bh)
        if fill < 0.15:                  # dunne vorm / tekst-hartje
            return 0.0
        # stijl-check: cartoon-platen (vlakke kleuren) winnen van foto's —
        # zo blijft de kaft teken-stijl consistent met het boek
        try:
            rgb = Image.open(bron).convert("RGB").resize((96, 96))
            kleuren = len(set(rgb.getdata()))
            if kleuren > 6000:           # foto-achtig: halve score
                cover *= 0.5
            # tekst-detectie: plaatjes met veel kleine donkere brokeltjes
            # (letters, logo's, scrolls) zijn GEEN helden en geen scène —
            # zo vallen auteur/promo-platen automatisch af
            grijs = Image.open(bron).convert("L").resize((64, 64))
            px = grijs.load()
            donker = {(x, y) for x in range(64) for y in range(64)
                      if px[x, y] < 110}
            kleintjes = 0
            while donker:
                stapel = [donker.pop()]
                grootte = 0
                while stapel:
                    gx, gy = stapel.pop()
                    grootte += 1
                    for nx, ny in ((gx+1,gy),(gx-1,gy),(gx,gy+1),(gx,gy-1)):
                        if (nx, ny) in donker:
                            donker.discard((nx, ny))
                            stapel.append((nx, ny))
                if grootte < 60:        # klein brokje = letter-vorm
                    kleintjes += 1
            if kleintjes > 25:          # veel kleintjes = tekst-plaat
                cover *= 0.3
        except Exception:
            pass
        return cover
    except Exception:
        return 0.0


def _scene_score(bron: Path) -> float:
    """Hoe 'verhaal-waardig' is de plaat als KAFT-scène (geheel-variant)?
    Rijke kleurrijke scènes winnen; tekst-platen en banners verliezen.
    Anders dan _held_score: een scène mag juist het hele beeld vullen."""
    try:
        im = Image.open(bron).convert("RGB")
        ar = im.width / im.height
        if ar < 0.35 or ar > 2.8:            # banner/lint-vorm
            return 0.0
        # tekst-detectie: veel kleine donkere brokjes = letter-plaat
        grijs = im.convert("L").resize((64, 64))
        px = grijs.load()
        donker = {(x, y) for x in range(64) for y in range(64)
                  if px[x, y] < 110}
        kleintjes = 0
        while donker:
            stapel = [donker.pop()]
            grootte = 0
            while stapel:
                gx, gy = stapel.pop()
                grootte += 1
                for nx, ny in ((gx+1,gy),(gx-1,gy),(gx,gy+1),(gx,gy-1)):
                    if (nx, ny) in donker:
                        donker.discard((nx, ny))
                        stapel.append((nx, ny))
            if grootte < 60:
                kleintjes += 1
        # rijkheid: deel van de plaat dat geen (bijna-)wit is — volle
        # kleurrijke scènes scoren hoog, kale/lege platen laag
        hsv = im.convert("HSV").resize((96, 96))
        data = list(hsv.getdata())
        rijk = sum(1 for _, s, v in data if s > 40 or v < 235) / len(data)
        # tekst-detectie alleen op kale plaatjes: echte tekst staat op
        # (bijna) wit; aquarel-textuur mag veel kleine brokjes hebben
        if rijk < 0.55 and kleintjes > 30:
            return 0.0
        # banner-detectie: brede donkere horizontale banden (naam-linten
        # zoals "G.T.J. SANDVIET") zijn promo-platen, geen verhaal-scènes
        banden = sum(1 for y in range(64)
                     if sum(1 for x in range(64) if px[x, y] < 110) > 40)
        if banden > 6:
            return 0.0
        # ingebrande ondertitel/watermerk-detectie: heldere letter-brokjes
        # in de onderste rand met een DONKERE omring-ring eromheen —
        # echte tekst steekt af (film-frames met AI-gibberish zoals
        # "Werrterfunite to dilunglo" zijn slordig op een kaft).
        # Hogere resolutie-strip nodig: op 64px smelten letters samen.
        s2 = im.convert("L").resize((256, 256))
        px2 = s2.load()
        # letters kunnen licht-op-donker of donker-op-licht zijn, en zitten
        # in de onder- én bovenrand (ondertitels, logo-banners, watermerken)
        stroken = ((200, 256), (0, 34))
        tekst = 0
        for y0, y1 in stroken:
            for licht, donker in ((True, False), (False, True)):
                if licht:
                    mask_set = {(x, y) for x in range(256)
                                for y in range(y0, y1) if px2[x, y] > 200}
                else:
                    mask_set = {(x, y) for x in range(256)
                                for y in range(y0, y1) if px2[x, y] < 65}
                while mask_set:
                    stapel = [mask_set.pop()]
                    comp = []
                    while stapel:
                        gx, gy = stapel.pop()
                        comp.append((gx, gy))
                        for nx, ny in ((gx+1,gy),(gx-1,gy),
                                       (gx,gy+1),(gx,gy-1)):
                            if (nx, ny) in mask_set:
                                mask_set.discard((nx, ny))
                                stapel.append((nx, ny))
                    if not (4 <= len(comp) <= 400):
                        continue
                    comp_set = set(comp)
                    ring_px = 0.0
                    ring_n = 0
                    for gx, gy in comp:
                        for nx, ny in ((gx+2,gy),(gx-2,gy),
                                       (gx,gy+2),(gx,gy-2),
                                       (gx+1,gy),(gx-1,gy),
                                       (gx,gy+1),(gx,gy-1)):
                            if (nx, ny) in comp_set:
                                continue
                            if 0 <= nx < 256 and 0 <= ny < 256:
                                ring_px += px2[nx, ny]
                                ring_n += 1
                    if not ring_n:
                        continue
                    gem = sum(px2[x, y] for x, y in comp) / len(comp)
                    if abs(gem - ring_px / ring_n) > 55:
                        tekst += 1
        if tekst > 20:
            rijk *= 0.4
        return rijk
    except Exception:
        return 0.0


def _beste_held(bron: list[Path]) -> Path | None:
    """Kiest de plaat met de grootste figuur als kaft-held (automatisch)."""
    beste, best = None, 0.15        # drempel: gedempte tekst-platen afkeuren
    for h in bron:
        s = _held_score(h)
        if s > best:
            best, beste = s, h
    return beste


# Cache-versie: bump wanneer een knip/blend-algoritme verandert zodat
# oude gecachte renders nooit meeliften (voorkomt stale -blend/-vaag).
_CV = "v2"


def _blend_plaat(bron: Path) -> Path:
    """Held uit z'n achtergrond knippen (rembg-chroma-key) óf — als die er
    niet is — zachte geveerde rand. Resultaat wordt gecachet."""
    uit = PAG_DIR / f"{bron.stem}-blend-{_CV}.png"
    if uit.exists() and uit.stat().st_mtime > bron.stat().st_mtime:
        return uit
    cut = _rembg()
    if cut:
        try:
            im = Image.open(bron).convert("RGBA")
            geknipt = cut(im)                 # echte uitsnede (alpha)
            # fransrand schoonmaken: half-transparante kleurresten aan de
            # rand wegknippen zodat de contour schoon op elke kaft past
            a = geknipt.getchannel("A").point(
                lambda v: 0 if v < 90 else min(255, int(v * 1.15)))
            geknipt.putalpha(a)
            geknipt.thumbnail((1200, 1200))
            geknipt.save(uit)
            return uit
        except Exception:
            pass
    im = Image.open(bron).convert("RGBA")
    r = max(12, min(im.width, im.height) // 14)
    mask = Image.new("L", im.size, 0)
    from PIL import ImageDraw
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, im.width - 1, im.height - 1], radius=r, fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(max(2, r // 3)))
    im.putalpha(mask)
    im.save(uit)
    return uit


def _poot(c, cx: float, cy: float, r: float, stijl: dict) -> None:
    """Animal Heroes handtekening: pootafdruk-badge in merkkleuren."""
    c.setFillColorRGB(1, 1, 1)
    c.setStrokeColorRGB(*stijl["balk"])
    c.setLineWidth(2)
    c.circle(cx, cy, r, stroke=1, fill=1)
    c.setFillColorRGB(*stijl["accent"])
    c.ellipse(cx - r * 0.34, cy - r * 0.42, cx + r * 0.34, cy + r * 0.10,
              stroke=0, fill=1)
    for dx, dy in ((-0.36, 0.28), (-0.12, 0.42), (0.12, 0.42), (0.36, 0.28)):
        c.circle(cx + dx * r, cy + dy * r, r * 0.13, stroke=0, fill=1)


def _wolk_lijst(c, x, y, w, h):
    """Speelse wolk-lijst: rechthoek-basis + bolletjes-wolk eromheen."""
    c.setFillColorRGB(1, 1, 1)
    c.roundRect(x, y, w, h, 10 * mm, stroke=0, fill=1)
    stappen = 9
    for i in range(stappen):
        fx = x + w * (i / (stappen - 1))
        r = 7 * mm if i % 2 == 0 else 5 * mm
        c.circle(fx, y + h, r, stroke=0, fill=1)        # bovenrand
        c.circle(fx, y, r * 0.8, stroke=0, fill=1)     # onderrand
    for i in range(4):
        fy = y + h * (i / 3)
        c.circle(x, fy, 6 * mm, stroke=0, fill=1)       # links
        c.circle(x + w, fy, 6 * mm, stroke=0, fill=1)    # rechts


def _cover_crop(bron: Path, verhouding: float) -> Path:
    """Center-crop een plaat op de kaft-verhouding (full-bleed laag)."""
    uit = PAG_DIR / f"{bron.stem}-cover-{_CV}-{verhouding:.3f}.png"
    if not uit.exists():
        im = Image.open(bron).convert("RGB")
        tw, th = im.width, im.height
        if tw / th > verhouding:
            nw = int(th * verhouding)
            x = (tw - nw) // 2
            im = im.crop((x, 0, x + nw, th))
        else:
            nh = int(tw / verhouding)
            y = (th - nh) // 2
            im = im.crop((0, y, tw, y + nh))
        im.save(uit)
    return uit


def _poot_zacht(c, x, y, r, kleur):
    """Grote zachte poot-silhouette als merk-stempel in het vlak."""
    k = (min(1, kleur[0] + 0.18), min(1, kleur[1] + 0.18),
         min(1, kleur[2] + 0.18))
    c.setFillColorRGB(*k)
    c.ellipse(x - r * 0.34, y - r * 0.42, x + r * 0.34, y + r * 0.10,
              stroke=0, fill=1)
    for dx, dy in ((-0.36, 0.28), (-0.12, 0.42), (0.12, 0.42),
                   (0.36, 0.28)):
        c.circle(x + dx * r, y + dy * r, r * 0.13, stroke=0, fill=1)


def _sterretje(c, x, y, r, kleur):
    """Klein glitter-sterretje (4 punten) — Disney-Cozy sprinkles."""
    c.setFillColorRGB(*kleur)
    p = c.beginPath()
    p.moveTo(x, y - r)
    for k, ang in enumerate((-135, -45, 45, 135)):
        a = ang * math.pi / 180
        rr = r * 0.32
        px, py = x + rr * math.cos(a + math.pi / 2 * (k % 2)), 0
    # eenvoudige 4-punt-ster via twee lijnen + ruit
    c.line(x - r, y, x + r, y)
    c.line(x, y - r, x, y + r)
    c.circle(x, y, r * 0.28, stroke=0, fill=1)


def _hartje(c, x, y, r, kleur):
    """Klein hartje voor de Cozy-sprinkles."""
    c.setFillColorRGB(*kleur)
    c.circle(x - r * 0.45, y + r * 0.25, r * 0.55, stroke=0, fill=1)
    c.circle(x + r * 0.45, y + r * 0.25, r * 0.55, stroke=0, fill=1)
    p = c.beginPath()
    p.moveTo(x - r * 0.95, y + r * 0.3)
    p.lineTo(x, y - r)
    p.lineTo(x + r * 0.95, y + r * 0.3)
    p.close()
    c.drawPath(p, stroke=0, fill=1)


def _voorkant(c, ox: float, oy: float, W: float, H: float, stijl: dict,
              titel: str, ondertitel: str, boek: str,
              eerste: Path, aantal: int, merk: str,
              variant: str = "cozy", extra: list | None = None,
              pre_bg: bool = False, soort: str = "kleurboek") -> None:
    """Teken de voorkant van de kaft in een regio op (ox, oy).
    pre_bg=True: de wrap-around scène is al getekend over de hele kaft.
    soort 'boek': geen kleurplaat-badge, 'dit boek is van'-regel."""
    cx = ox + W / 2
    # geheel-variant: de boek-scène ZELF is de achtergrond-laag (full-bleed)
    # — één wereld, één plaat, karakters zitten er al in (compositing).
    scene_als_bg = (variant == "geheel" and eerste and eerste.exists())
    if scene_als_bg:
        if not pre_bg:
            # center-crop de plaat op de kaft-verhouding: exact op de regio,
            # loopt NIET over rug/bleed heen (echte full-bleed laag)
            c.drawImage(ImageReader(str(_cover_crop(eerste, W / H))),
                        ox, oy, W, H)
        # voorkant = één heel plaatje tot de bovenrand (de gebruiker: blauwe
        # vlak weg). Alleen een zachte sluier onderaan zodat de
        # merk-teksten + 'dit kleurboek is van' leesbaar blijven.
        c.saveState()
        c.setFillAlpha(0.55)
        c.setFillColorRGB(*stijl["bg"])
        c.rect(ox, oy, W, 46 * mm, stroke=0, fill=1)
        c.restoreState()
    else:
        _bg(c, ox, oy, W, H, stijl, merk)
    c.setFillColorRGB(*stijl["balk"])
    c.roundRect(ox + 14 * mm, oy + H - 50 * mm, W - 28 * mm, 38 * mm, 8 * mm,
                stroke=0, fill=1)
    # chunky titel: wit met accent-omlijning (sticker-look zoals Disney
    # COLOR) — shrink-to-fit zodat lange titels binnen de balk passen
    tt = titel or "G2B Kleurboek"
    fs = 30
    while fs > 12 and c.stringWidth(tt, "Helvetica-Bold", fs) > W - 40 * mm:
        fs -= 1
    c.setFont("Helvetica-Bold", fs)
    c.setFillColorRGB(*stijl["accent"])
    for dx, dy in ((-0.7, 0), (0.7, 0), (0, -0.7), (0, 0.7)):
        c.drawCentredString(cx + dx * mm, oy + H - 33 * mm + dy * mm, tt)
    c.setFillColorRGB(1, 1, 1)
    c.drawCentredString(cx, oy + H - 33 * mm, tt)
    if ondertitel:
        c.setFont("Helvetica", 14)
        c.drawCentredString(cx, oy + H - 42 * mm, ondertitel)
    if merk == "ah":
        _poot(c, ox + 22 * mm, oy + H - 20 * mm, 7 * mm, stijl)
        _poot(c, ox + W - 22 * mm, oy + H - 20 * mm, 7 * mm, stijl)
    # sprinkles rond de held — variant bepaalt welke decoratie
    if variant in ("cozy", "feest"):
        sprinkles = [(0.16, 0.60), (0.85, 0.58), (0.13, 0.38), (0.87, 0.36),
                     (0.24, 0.27), (0.76, 0.26)]
        for i, (fx, fy) in enumerate(sprinkles):
            k = stijl["accent"] if i % 2 == 0 else (1, 1, 1)
            x, y = ox + W * fx, oy + H * fy
            if variant == "feest":
                # feest: hartjes + pootjes (feestelijk kinderboek)
                if i % 2 == 0:
                    _hartje(c, x, y, 2.4 * mm, k)
                else:
                    _poot(c, x, y, 2.2 * mm, stijl)
            elif i % 3 == 2:
                _hartje(c, x, y, 2.4 * mm, k)
            else:
                _sterretje(c, x, y, 2.6 * mm, k)
    if not scene_als_bg and eerste and eerste.exists():
        # nieuw-geheel: held(en) uitgeknipt op een verse AH-scène
        m = 30 * mm
        maxw, maxh = W - 2 * m, H - 108 * mm
        # zachte boek-tint glow als podium voor de scene
        c.setFillColorRGB(*stijl.get("glow", (0.75, 0.90, 0.87)))
        c.ellipse(cx - maxw * 0.48, oy + 52 * mm,
                  cx + maxw * 0.48, oy + 52 * mm + maxh,
                  stroke=0, fill=1)
        # merk-bewerking in het vlak: grote zachte AH-poot als stempel
        _poot_zacht(c, cx, oy + 52 * mm + maxh * 0.5, maxh * 0.34,
                    stijl["balk"])
        # groep-helden: hoofdheld groot midden, 2 vriendjes kleiner eromheen
        groep = [eerste]
        if extra and len(extra) > 0:
            # alleen échte helden (score>0): banners/tekst/foto's vallen af
            groep = [h for h in extra[:4] if _held_score(h) > 0] or [eerste]
        posities = [(0.50, 0.36, 0.92), (0.17, 0.60, 0.42), (0.84, 0.60, 0.40)]
        for i, hb in enumerate(groep[:3]):
            if not hb.exists():
                continue
            im = Image.open(hb)
            fx, fy, schaal = posities[i]
            s = min(maxw * schaal / im.width, maxh * schaal / im.height)
            iw2, ih2 = im.width * s, im.height * s
            c.drawImage(ImageReader(str(_blend_plaat(hb))),
                        ox + W * fx - iw2 / 2,
                        oy + H * fy - ih2 / 2 + 22 * mm,
                        iw2, ih2, mask="auto")
        _poot(c, cx - maxw * 0.44, oy + 66 * mm, 4 * mm, stijl)
        _poot(c, cx + maxw * 0.42, oy + 60 * mm, 4 * mm, stijl)
    if merk == "ah":
        # subtiele merk-voettekst op het heuvel-gebied (geen harde band)
        c.setFillColorRGB(1, 1, 1)
        c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(cx, oy + 7 * mm,
                            "AnimalHeroes.club · by Good2better")
        bx, by, br = ox + W - 26 * mm, oy + H - 58 * mm, 10 * mm
        if aantal:
            c.setFillColorRGB(*stijl["accent"])
            punten = []
            for k in range(16):
                ang = k * 22.5 * math.pi / 180
                rr = br if k % 2 == 0 else br * 0.72
                punten.append((bx + rr * math.cos(ang), by + rr * math.sin(ang)))
            path = c.beginPath()
            path.moveTo(*punten[0])
            for pt in punten[1:]:
                path.lineTo(*pt)
            path.close()
            c.drawPath(path, stroke=0, fill=1)
            c.setFillColorRGB(1, 1, 1)
            c.setFont("Helvetica-Bold", 12)
            c.drawCentredString(bx, by + 0.5 * mm, str(aantal))
            c.setFont("Helvetica-Bold", 5.5)
            c.drawCentredString(bx, by - 4 * mm,
                                "KLEURPLAAT" if aantal == 1 else "KLEURPLATEN")
    if variant == "stripboek":
        # Marvel/stripboek: dubbel sterk kader rond de hele kaft +
        # witte box achter de naamregel (echte stripboek-kaft look)
        c.setLineWidth(3)
        c.setStrokeColorRGB(*stijl["balk"])
        c.rect(ox + 7 * mm, oy + 19 * mm, W - 14 * mm, H - 26 * mm,
               stroke=1, fill=0)
        c.setLineWidth(1.2)
        c.setStrokeColorRGB(*stijl["accent"])
        c.rect(ox + 10 * mm, oy + 22 * mm, W - 20 * mm, H - 32 * mm,
               stroke=1, fill=0)
        c.setFillColorRGB(1, 1, 1)
        c.setStrokeColorRGB(*stijl["balk"])
        c.setLineWidth(1.5)
        c.roundRect(ox + 24 * mm, oy + 33 * mm, W - 48 * mm, 11 * mm,
                    3 * mm, stroke=1, fill=1)
    if soort == "kleurboek":
        # eigenaars-regel: kinderen schrijven hun naam op hun kleurboek
        c.setStrokeColorRGB(*stijl["accent"])
        c.setFillColorRGB(*stijl["titel"])
        c.setFont("Helvetica-Bold", 12)
        c.drawString(ox + 30 * mm, oy + 38 * mm, "Dit kleurboek is van")
        c.setLineWidth(1)
        c.line(ox + 68 * mm, oy + 38 * mm, ox + W - 30 * mm, oy + 38 * mm)
        c.setFont("Helvetica", 11)
        c.drawCentredString(cx, oy + 30 * mm,
                            f"{aantal} kleurplaat{'en' if aantal != 1 else ''}"
                            " om in te kleuren · 3-8 jaar")
    else:
        c.setFillColorRGB(*stijl["titel"])
        c.setFont("Helvetica", 11)
        c.drawCentredString(cx, oy + 30 * mm, "leesleeftijd 3-8 jaar")
    if merk == "ah" and not ondertitel:
        c.setFont("Helvetica-Oblique", 11)
        c.setFillColorRGB(*stijl["accent"])
        c.drawCentredString(cx, oy + H - 42 * mm, "Saving Lives Every Day")
        # AH-DNA: elke kaft belooft wat zijn boeken leren
        c.setFont("Helvetica-Oblique", 9)
        c.drawCentredString(cx, oy + 13 * mm,
                            "Moed · Vriendschap · Avontuur")
    if boek:
        c.setFont("Helvetica-Oblique", 10)
        c.drawCentredString(cx, oy + 23 * mm, f"met plaatjes uit: {boek}")


def _deeltitel(c: canvas.Canvas, w: float, h: float, stijl: dict,
               merk: str, boek: str, platen: list[dict]) -> None:
    """Scheidingspagina per boek in een verzamel-kleurboek (bundel):
    boek-titel + teller + de beste scène van díe serie als
    kleurvoorbeeld — voelt als echte hoofdstukken in één boek."""
    _bg(c, 0, 0, w, h, stijl, merk)
    _poot(c, w / 2, h - 52 * mm, 13 * mm, stijl)
    tt = boek or "Diverse helden"
    fs = 26
    while fs > 12 and c.stringWidth(tt, "Helvetica-Bold", fs) > w - 30 * mm:
        fs -= 1
    c.setFillColorRGB(*stijl["titel"])
    c.setFont("Helvetica-Bold", fs)
    c.drawCentredString(w / 2, h - 80 * mm, tt)
    n = len(platen)
    c.setFillColorRGB(*stijl["sub"])
    c.setFont("Helvetica", 12)
    c.drawCentredString(w / 2, h - 92 * mm,
                        f"{n} kleurpla{'ten' if n != 1 else 'at'} "
                        f"uit dit boek")
    # beste scène van dit boek als kleurvoorbeeld (zoals op de omslag)
    kand = [PAG_DIR / f"{p['id']}-voorb.jpg" for p in platen]
    kand = [k for k in kand if k.exists()]
    beste = max(kand, key=_scene_score) if kand else None
    if beste:
        im = Image.open(beste)
        bw = 112 * mm
        s = min(bw / im.width, (bw * 0.62) / im.height)
        iw, ih = im.width * s, im.height * s
        x, y = (w - iw) / 2, 52 * mm
        c.setFillColorRGB(1, 1, 1)
        c.setStrokeColorRGB(*stijl["sub"])
        c.setLineWidth(1.4)
        c.roundRect(x - 5, y - 5, iw + 10, ih + 10, 6, stroke=1, fill=1)
        c.drawImage(ImageReader(beste), x, y, iw, ih)


def maak_kleurboek_pdf(pagina_ids: list[str], titel: str,
                       ondertitel: str = "", boek: str = "",
                       merk: str = "ah", variant: str = "cozy",
                       seed: int = 0) -> Path:
    """Bundel gekozen kleurplaten als A4 kleurboek-PDF in exports/."""
    staat = _staat()
    alle = {p["id"]: p for p in staat["paginas"]}
    gekozen = [alle[i] for i in pagina_ids if i in alle]
    if not gekozen:
        raise ValueError("geen kleurplaten gekozen")
    # "Boek opnieuw": elke klik roteert de binnenkant — andere plaat
    # opent het boek, andere omslag-scene via de seed hieronder
    if seed:
        k = seed % len(gekozen)
        gekozen = gekozen[k:] + gekozen[:k]
    stijl = MERKEN.get(merk, MERKEN["ah"])

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    dst = EXPORT_DIR / f"Kleurboek-{_slug(titel) or 'g2b'}.pdf"
    c = canvas.Canvas(str(dst), pagesize=A4)
    w, h = A4

    def ah_poot(cx: float, cy: float, r: float) -> None:
        if merk == "ah":
            _poot(c, cx, cy, r, stijl)

    def voettekst():
        c.setFont("Helvetica", 8)
        c.setFillColorRGB(0.45, 0.45, 0.45)
        c.drawCentredString(w / 2, 10 * mm, stijl["voet"])

    def voorbeeld(f: Path, x: float, y: float, box: float) -> None:
        """Klein kleurvoorbeeld van het origineel (Paw Patrol-stijl)."""
        vb = PAG_DIR / f"{f.stem}-voorb.jpg"
        if not vb.exists():
            return
        im = Image.open(vb)
        s = min(box / im.width, box / im.height)
        iw, ih = im.width * s, im.height * s
        # wit kader met zachte rand
        c.setFillColorRGB(1, 1, 1)
        c.setStrokeColorRGB(*stijl["sub"])
        c.setLineWidth(1.2)
        c.roundRect(x - 2, y - 2, iw + 4, ih + 18, 3, stroke=1, fill=1)
        c.drawImage(ImageReader(vb), x, y + 16, iw, ih)
        c.setFont("Helvetica", 6.5)
        c.setFillColorRGB(0.3, 0.3, 0.3)
        c.drawString(x + 2, y + 4, "zo ziet hij er in kleur uit!")

    # ---- omslag (zelfde ontwerp als de print-kaft voorkant) ----
    # kaft_uit: platen die de gebruiker uit de kaft houdt (wel binnenin)
    kaft_gekozen = [p for p in gekozen if not p.get("kaft_uit")] or gekozen
    eerste = PAG_DIR / f"{kaft_gekozen[0]['id']}-voorb.jpg"
    if not eerste.exists():
        eerste = PAG_DIR / f"{kaft_gekozen[0]['id']}.png"
    helden_omslag = [PAG_DIR / f"{p['id']}-voorb.jpg" for p in kaft_gekozen]
    helden_omslag = sorted([h for h in helden_omslag if h.exists()
                            and "auteur" not in h.stem
                            and "author" not in h.stem],
                          key=_held_score, reverse=True)
    stijl = _boek_tint(helden_omslag, stijl,
                       len({p.get('boek', '') for p in gekozen}))
    scoref_o = _scene_score if variant == "geheel" else _held_score
    pool_omslag = sorted([h for h in helden_omslag if scoref_o(h) > 0.15],
                         key=scoref_o, reverse=True)
    if variant == "geheel" and pool_omslag:
        omslag_held = pool_omslag[seed % len(pool_omslag)]
    else:
        omslag_held = _beste_held(helden_omslag) or eerste
    _voorkant(c, 0, 0, w, h, stijl, titel, ondertitel, boek,
              omslag_held, len(gekozen), merk, variant,
              extra=helden_omslag[:3] or None)
    voettekst()
    c.showPage()

    # ---- kleurplaten ----
    # bundel-modus: platen uit meerdere boeken → per boek een
    # scheidingspagina met boektitel + scène-voorbeeld (verzamelboek)
    groepen: list[tuple[str, list[dict]]] = []
    for p in gekozen:
        b = (p.get("boek") or "").strip()
        if groepen and groepen[-1][0] == b:
            groepen[-1][1].append(p)
        else:
            groepen.append((b, [p]))
    bundel = len([b for b, _ in groepen if b]) > 1

    m = 18 * mm
    maxw, maxh = w - 2 * m, h - 2 * m - 14 * mm
    i = 0
    for bnaam, platen in groepen:
        if bundel and bnaam:
            _deeltitel(c, w, h, stijl, merk, bnaam, platen)
            c.showPage()
        for p in platen:
            i += 1
            f = PAG_DIR / f"{p['id']}.png"
            if not f.exists():
                continue
            im = Image.open(f)
            s = min(maxw / im.width, maxh / im.height)
            iw, ih = im.width * s, im.height * s
            c.drawImage(ImageReader(f), (w - iw) / 2,
                        16 * mm + (maxh - ih) / 2, iw, ih)
            # kleurvoorbeeld rechtsonder (klein, met kader + tekst)
            voorbeeld(f, w - m - 26 * mm, 14 * mm, 26 * mm)
            c.setFont("Helvetica", 9)
            c.setFillColorRGB(0.55, 0.55, 0.55)
            c.drawRightString(w - m, h - 12 * mm, f"{i} / {len(gekozen)}")
            ah_poot(m + 4 * mm, h - 11 * mm, 3.5 * mm)   # handtekening
            voettekst()
            c.showPage()

    # ---- slotpagina: kids vinden een afsluiter leuk ----
    _bg(c, 0, 0, w, h, stijl, merk)
    ah_poot(w / 2, h - 60 * mm, 16 * mm)
    c.setFillColorRGB(*stijl["titel"])
    c.setFont("Helvetica-Bold", 24)
    c.drawCentredString(w / 2, h - 95 * mm, "Goed gekleurd!")
    c.setFillColorRGB(*stijl["accent"])
    c.setFont("Helvetica", 13)
    c.drawCentredString(w / 2, h - 108 * mm,
                        "Je bent een echte Animal Hero!")
    c.setFont("Helvetica", 10)
    c.setFillColorRGB(0.35, 0.35, 0.35)
    c.drawCentredString(w / 2, h - 122 * mm,
                        "Meer helden-avonturen op AnimalHeroes.club")
    voettekst()
    c.showPage()
    c.save()
    return dst


# kaft-formaten: (breedte, hoogte) per kaftzijde in mm
_FORMATEN = {
    "a4": (210 * mm, 297 * mm),      # kleurboek (A4-staand per zijde)
    "a5": (148 * mm, 210 * mm),      # gewoon boek / kinderboek
    "6x9": (6 * 25.4 * mm, 9 * 25.4 * mm),   # KDP-inch formaat
}


def maak_kaft_pdf(pagina_ids: list[str], titel: str,
                  ondertitel: str = "", boek: str = "",
                  merk: str = "ah", variant: str = "cozy",
                  seed: int = 0, formaat: str = "a4",
                  pagina_aantal: int | None = None,
                  soort: str = "kleurboek",
                  blurb: str = "") -> tuple[Path, Path | None]:
    """Print-klare omslag (achter + rug + voor) als één PDF + voorkant-PNG.

    Zoals drukkers/KDP het vragen: 3,175mm bleed (afsnijmarge) rondom,
    rugdikte uit het aantal binnenpagina's (0,0635mm per vel wit papier).
    formaat: a4 (kleurboek) | a5 | 6x9 — soort 'kleurboek' of 'boek'.
    """
    staat = _staat()
    alle = {p["id"]: p for p in staat["paginas"]}
    gekozen = [alle[i] for i in pagina_ids if i in alle]
    if not gekozen:
        raise ValueError("geen kleurplaten gekozen")
    stijl = MERKEN.get(merk, MERKEN["ah"])
    BLEED = 3.175 * mm
    aw, ah = _FORMATEN.get(formaat, _FORMATEN["a4"])
    binnen = pagina_aantal or (len(gekozen) + 2)    # + omslag + slotpagina
    rug = max(1.5 * mm, binnen * 0.0635 * mm)
    W = aw * 2 + rug + BLEED * 2
    H = ah + BLEED * 2
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    dst = EXPORT_DIR / f"{'Kaft' if soort == 'kleurboek' else 'Boekkaft'}-{_slug(titel) or 'g2b'}.pdf"
    c = canvas.Canvas(str(dst), pagesize=(W, H))
    c.setFillColorRGB(*stijl["bg"])
    c.rect(0, 0, W, H, stroke=0, fill=1)            # basis (bleed)
    # ---- achterkant (links) ----
    cx = BLEED + aw / 2
    kaft_gekozen = [p for p in gekozen if not p.get("kaft_uit")] or gekozen
    eerste = PAG_DIR / f"{kaft_gekozen[0]['id']}-voorb.jpg"
    # helden/scènes bepalen vóór de achtergrond: geheel-achterkant = een
    # écht boek-plaatje (neppe aqua-achtergrond weg) met een
    # zachte lichte sluier zodat de tekst erop leesbaar blijft
    helden = [PAG_DIR / f"{p['id']}-voorb.jpg" for p in kaft_gekozen]
    helden = [h for h in helden if h.exists()
              and "auteur" not in h.stem and "author" not in h.stem]
    helden.sort(key=_held_score, reverse=True)
    scoref = _scene_score if variant == "geheel" else _held_score
    ranked = [h for h in helden if scoref(h) > 0.15]
    ranked.sort(key=scoref, reverse=True)
    voer_h = (ranked[seed % len(ranked)]
            if variant == "geheel" and ranked else None)
    sc = None
    if variant == "geheel" and ranked:
        sc = next((h for h in ranked if h != voer_h), None)
        if sc is None:
            rest = sorted((h for h in helden if h != voer_h),
                          key=scoref, reverse=True)
            sc = rest[0] if rest else None
        helden = [h for h in ranked if h not in (voer_h, sc)][:5]
    else:
        helden = ranked[3:8]
    if variant == "geheel" and voer_h is not None:
        # één groot plaatje over de HELE kaft: achter + rug + voor zijn
        # hetzelfde beeld (wrap-around zoals echte boekkaften)
        c.drawImage(ImageReader(str(_cover_crop(voer_h, W / H))),
                    0, 0, W, H)
        # lichte sluier over de achterkant zodat de tekst leesbaar blijft
        c.saveState()
        c.setFillAlpha(0.66)
        c.setFillColorRGB(1, 1, 1)
        c.rect(BLEED, BLEED, aw, ah, stroke=0, fill=1)
        c.restoreState()
    else:
        _bg(c, BLEED, BLEED, aw, ah, stijl, merk)    # achterkant-illustratie
    if merk == "ah":
        _poot(c, cx, BLEED + ah - 55 * mm, 14 * mm, stijl)
    c.setFillColorRGB(*stijl["titel"])
    c.setFont("Helvetica-Bold", 20)
    c.drawCentredString(cx, BLEED + ah - 90 * mm,
                        "Over dit kleurboek" if soort == "kleurboek"
                        else "Over dit boek")
    c.setFont("Helvetica", 11)
    c.setFillColorRGB(0.25, 0.25, 0.25)
    if blurb.strip():
        blurb = blurb.strip()               # eigen flaptekst van de gebruiker
    elif soort == "boek":
        blurb = (f"{titel} — een nieuw Animal Heroes avontuur vol moed, "
                 "vriendschap en dierenreddingen. Samen lezen is het "
                 "leukste avontuur. Voor helden van 3-8 jaar.")
    elif merk == "ah":
        blurb = ("Kleur de helden van Animal Heroes in! Elke pagina is een "
                 "echt reddings-avontuur uit onze boeken — met een "
                 "kleurvoorbeeld bij elke plaat. Voor helden van 3-8 jaar.")
    else:
        blurb = ("Kleur de helden in! Elke pagina is een echt helden-avontuur "
                 "uit onze boeken — met een kleurvoorbeeld bij elke plaat. "
                 "Voor kleine en grote helden van 3-8 jaar.")
    woorden, regels, regel = blurb.split(), [], ""
    for wd in woorden:
        if c.stringWidth((regel + " " + wd).strip(), "Helvetica", 11) > aw - 80 * mm:
            regels.append(regel)
            regel = wd
        else:
            regel = (regel + " " + wd).strip()
    regels.append(regel)
    for i, regel in enumerate(regels[:7]):
        c.drawCentredString(cx, BLEED + ah - 102 * mm - i * 5.2 * mm, regel)
    # mini-heldenrij (niet-geheel): kleine karakters uit het boek onderaan
    if helden and variant != "geheel":
        box = 34 * mm if len(helden) > 3 else 40 * mm
        gap = 5 * mm
        totaal = len(helden) * box + (len(helden) - 1) * gap
        hx = cx - totaal / 2
        for i, hb in enumerate(helden):
            im = Image.open(hb)
            s = min(box / im.width, box / im.height)
            iw, ih = im.width * s, im.height * s
            x0 = hx + i * (box + gap)
            c.drawImage(ImageReader(str(_blend_plaat(hb))),
                        x0 + (box - iw) / 2, BLEED + 55 * mm, iw, ih,
                        mask="auto")
    c.setFillColorRGB(*stijl["accent"])
    c.setFont("Helvetica-Oblique", 12)
    c.drawCentredString(cx, BLEED + 30 * mm,
                        "Saving Lives Every Day" if merk == "ah"
                        else "")
    c.setFont("Helvetica", 9)
    c.setFillColorRGB(0.4, 0.4, 0.4)
    c.drawCentredString(cx, BLEED + 22 * mm,
                        "AnimalHeroes.club" if merk == "ah"
                        else "")
    # ---- rug ----
    rx = BLEED + aw
    c.setFillColorRGB(*stijl["balk"])
    c.rect(rx, 0, rug, H, stroke=0, fill=1)
    if rug >= 5 * mm:
        c.saveState()
        c.translate(rx + rug / 2 + 3, BLEED + ah / 2)
        c.rotate(90)
        c.setFillColorRGB(1, 1, 1)
        c.setFont("Helvetica-Bold", min(14, rug / mm * 2.2))
        c.drawCentredString(0, -4, titel or "Kleurboek")
        c.restoreState()
    # ---- voorkant (rechts) ----
    helden_voor = [PAG_DIR / f"{p['id']}-voorb.jpg" for p in kaft_gekozen]
    helden_voor = sorted([h for h in helden_voor if h.exists()
                          and "auteur" not in h.stem
                          and "author" not in h.stem],
                        key=_held_score, reverse=True)
    stijl = _boek_tint(helden_voor, stijl,
                       len({p.get('boek', '') for p in gekozen}))
    if variant == "geheel" and ranked:
        voer = ranked[seed % len(ranked)]      # zelfde rotatie als achter
    else:
        voer = (_beste_held([h for h in helden_voor if h.exists()])
                or (eerste if eerste.exists()
                    else PAG_DIR / f"{gekozen[0]['id']}.png"))
    _voorkant(c, rx + rug, BLEED, aw, ah, stijl, titel, ondertitel, boek,
              voer, len(gekozen) if soort == "kleurboek" else 0, merk,
              variant, extra=helden_voor[:3] or None,
              pre_bg=(variant == "geheel" and voer_h is not None),
              soort=soort)
    c.showPage()
    c.save()
    # ---- voorkant als PNG voor webwinkel/downloads ----
    png = None
    try:
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(str(dst))
        pil = pdf[0].render(scale=2.5).to_pil()
        deel = int((aw + BLEED) / W * pil.width)     # rechter A4-deel + bleed
        png = EXPORT_DIR / f"Kaft-{_slug(titel) or 'g2b'}-voorkant.png"
        pil.crop((pil.width - deel, 0, pil.width, pil.height)).save(png)
    except Exception:
        png = None
    return dst, png


# ---------------------------------------------------------------------------
# ✨ Zelf-maak-stap: AI-plaatjes voor tekst-boeken
# De Kleurboek-Fabriek kan zélf boekplaten tekenen via dezelfde GPU-pod als
# ImageLab (FLUX.1-schnell — Apache-2.0, regel 1 OK). Werkt alleen als de pod
# draait; zonder worker-url meldt de knop netjes dat de GPU uit is.
# Kosten: pod-centen per plaatje; de pod stopt zichzelf (auto-stop) zoals bij
# ImageLab/Workstation — nooit verrassingskosten.
# ---------------------------------------------------------------------------
_GEN_STIJL = (
    ", children's picture book illustration, soft watercolor style, "
    "warm pastel colors, happy and playful mood, courage friendship "
    "adventure, no text, landscape orientation"
)
_GEN_TIMEOUT = 900  # FLUX is snel, maar pod-cold-start kan duren


def _worker_url() -> str:
    import os
    return (os.environ.get("G2B_WORKER_URL")
            or os.environ.get("GAW_WORKER_URL") or "").rstrip("/")


def genereer_plaat(prompt: str, boek: str = "", batch: int = 2) -> list[dict]:
    """Tekst → eigen boekplaatjes (via ImageLab-pod FLUX-schnell).

    Geeft de nieuwe kleurplaat-items terug zodra de worker klaar is.
    Werpt RuntimeError met een NL-melding als de GPU uit is."""
    import io
    import os
    import time
    import urllib.request
    import uuid
    import zipfile

    base = _worker_url()
    if not base:
        raise RuntimeError(
            "GPU uit — start eerst de pod in ImageLab of de Workstation "
            "(deze app gebruikt dezelfde worker), of zet G2B_WORKER_URL")
    prompt = (prompt or "").strip()
    if not prompt:
        raise RuntimeError("schrijf eerst wat de plaat moet laten zien")

    # AH-boekstijl vastgebakken: zelfde warme aquarel-look als zijn boeken
    params = {
        "model": "flux-schnell",
        "prompt": prompt + _GEN_STIJL,
        "width": 1536, "height": 1024,
        "batch": max(1, min(int(batch), 4)),
    }
    boundary = uuid.uuid4().hex
    body = bytearray()
    for k, v in (("params", json.dumps(params)), ("meta", "{}")):
        body.extend(f'--{boundary}\r\nContent-Disposition: form-data; '
                    f'name="{k}"\r\n\r\n{v}\r\n'.encode())
    body.extend(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(
        f"{base}/api/gpu/run?node=txt2img&async=1",
        data=bytes(body),
        headers={"Content-Type":
                 f"multipart/form-data; boundary={boundary}",
                 "User-Agent": "g2b-bedrijfsmiddelen"})  # RunPod-proxy eis
    try:
        resp = urllib.request.urlopen(req, timeout=120)
        job_id = json.loads(resp.read())["job"]
    except Exception as e:
        raise RuntimeError(f"worker niet bereikbaar ({e}) — pod aan?")

    # Poll: pod blijft wakker via zijn eigen auto-stop budget-timer
    deadline = time.time() + _GEN_TIMEOUT
    while True:
        if time.time() > deadline:
            raise RuntimeError("generatie duurde te lang — probeer opnieuw")
        time.sleep(5)
        try:
            st = json.loads(urllib.request.urlopen(
                urllib.request.Request(
                    f"{base}/api/gpu/status?job={job_id}",
                    headers={"User-Agent": "g2b-bedrijfsmiddelen"}),
                timeout=30).read())
        except Exception:
            continue                       # proxy-flap — door pollen
        if st.get("status") == "failed":
            raise RuntimeError(f"generatie faalde: {st.get('error')}")
        if st.get("status") == "done":
            break

    resp = urllib.request.urlopen(
        urllib.request.Request(
            f"{base}/api/gpu/result?job={job_id}",
            headers={"User-Agent": "g2b-bedrijfsmiddelen"}),
        timeout=300)
    data = resp.read()

    # batch = zip met PNG's; enkel bestand = platte PNG
    platen: list[tuple[str, bytes]] = []
    if data[:4] == b"PK\x03\x04":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for nm in sorted(z.namelist()):
                if nm.lower().endswith(".png"):
                    platen.append(
                        (f"ai-{_slug(prompt)[:40]}-{len(platen) + 1}",
                         z.read(nm)))
    else:
        platen.append((f"ai-{_slug(prompt)[:40]}", data))
    if not platen:
        raise RuntimeError("worker gaf geen plaatjes terug")
    return voeg_toe(platen, boek)


def genereer_actief() -> bool:
    """True als een GPU-worker is ingesteld (knop-tonen in de UI)."""
    return bool(_worker_url())


def _wrap_tekst(c: canvas.Canvas, tekst: str, font: str, size: float,
                maxw: float) -> list[str]:
    """Woord-wrap naar regels die binnen maxw punten passen."""
    regels: list[str] = []
    for blok in tekst.split("\n"):
        blok = blok.strip()
        if not blok:
            continue
        regel = ""
        for wd in blok.split():
            kand = (regel + " " + wd).strip()
            if c.stringWidth(kand, font, size) <= maxw:
                regel = kand
            else:
                if regel:
                    regels.append(regel)
                regel = wd
        if regel:
            regels.append(regel)
    return regels


def maak_boek_pdf(pagina_ids: list[str], teksten: list[str], titel: str,
                  ondertitel: str = "", auteur: str = "",
                  merk: str = "ah", formaat: str = "a5") -> tuple[Path, int]:
    """Print-klare boek-binnenkant: titelpagina + © + per pagina een plaat
    met zijn tekstregel eronder + slotpagina. A5 of 6x9-KDP formaat.

    Geeft (pad, pagina_aantal) terug — dat aantal voert exact de
    rugdikte van de bijpassende Boekkaft."""
    staat = _staat()
    alle = {p["id"]: p for p in staat["paginas"]}
    platen = [alle[i] for i in pagina_ids if i in alle]
    stijl = MERKEN.get(merk, MERKEN["ah"])
    aw, ah = _FORMATEN.get(formaat, _FORMATEN["a5"])
    w, h = aw, ah

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    dst = EXPORT_DIR / f"Boek-{_slug(titel) or 'g2b'}-{formaat}.pdf"
    c = canvas.Canvas(str(dst), pagesize=(w, h))
    m = 14 * mm

    def poot(cx, cy, r):
        if merk == "ah":
            _poot(c, cx, cy, r, stijl)

    # ---- titelpagina ----
    _bg(c, 0, 0, w, h, stijl, merk)
    poot(w / 2, h - 30 * mm, 10 * mm)
    tt = titel or "Animal Heroes"
    fs = 20
    while fs > 11 and c.stringWidth(tt, "Helvetica-Bold", fs) > w - 20 * mm:
        fs -= 1
    c.setFillColorRGB(*stijl["titel"])
    c.setFont("Helvetica-Bold", fs)
    c.drawCentredString(w / 2, h - 52 * mm, tt)
    if ondertitel:
        c.setFillColorRGB(*stijl["sub"])
        c.setFont("Helvetica", 11)
        c.drawCentredString(w / 2, h - 62 * mm, ondertitel)
    c.setFillColorRGB(0.35, 0.35, 0.35)
    c.setFont("Helvetica", 10)
    if auteur:
        c.drawCentredString(w / 2, h - 78 * mm, f"door {auteur}")
    c.showPage()

    # ---- copyrightpagina ----
    c.setFillColorRGB(0.4, 0.4, 0.4)
    c.setFont("Helvetica", 8)
    for i, regel in enumerate([
            f"© {auteur or 'de maker'}"
            + (" · AnimalHeroes.club" if merk == "ah" else ""),
            "Alle rechten voorbehouden — dit boek mag niet worden",
            "gekopieerd of doorverkocht zonder toestemming.",
            "",
            "Een Animal Heroes verhaal over moed,",
            "vriendschap en avontuur — voor lezers van 3-8 jaar."]):
        c.drawCentredString(w / 2, 60 * mm - i * 4.5 * mm, regel)
    c.showPage()

    # ---- verhaalpagina's: plaat boven (~62%) + tekst eronder ----
    n = max(len(platen), len(teksten))
    foto_top = h - m
    foto_h = (h - 2 * m) * 0.62
    for i in range(n):
        # zachte merk-achtergrond houdt het boek in één stijl
        _bg(c, 0, 0, w, h, stijl, merk)
        img_bod = foto_top - foto_h          # onderkant van de beeldzone
        if i < len(platen):
            f = PAG_DIR / f"{platen[i]['id']}-voorb.jpg"
            if not f.exists():
                f = PAG_DIR / f"{platen[i]['id']}.png"
            if f.exists():
                im = Image.open(f)
                maxw = w - 2 * m
                s = min(maxw / im.width, foto_h / im.height)
                iw, ih = im.width * s, im.height * s
                x, y = (w - iw) / 2, foto_top - ih
                c.setFillColorRGB(1, 1, 1)
                c.roundRect(x - 4, y - 4, iw + 8, ih + 8, 5,
                            stroke=0, fill=1)
                c.drawImage(ImageReader(f), x, y, iw, ih)
                img_bod = y                  # tekst sluit aan op de plaat
        if i < len(teksten):
            regels = _wrap_tekst(c, teksten[i], "Helvetica", 11,
                                 w - 2 * m - 6 * mm)
            c.setFillColorRGB(0.2, 0.2, 0.2)
            c.setFont("Helvetica", 11)
            ty = img_bod - 11 * mm
            for r_ in regels[:6]:
                c.drawCentredString(w / 2, ty, r_)
                ty -= 5.5 * mm
        # paginanummer onderaan
        c.setFont("Helvetica", 7)
        c.setFillColorRGB(0.6, 0.6, 0.6)
        c.drawCentredString(w / 2, 7 * mm, str(i + 1))
        poot(w - m - 3 * mm, 8 * mm, 2.5 * mm)
        c.showPage()

    # ---- slotpagina ----
    _bg(c, 0, 0, w, h, stijl, merk)
    poot(w / 2, h - 45 * mm, 12 * mm)
    c.setFillColorRGB(*stijl["titel"])
    c.setFont("Helvetica-Bold", 20)
    c.drawCentredString(w / 2, h - 70 * mm, "Einde")
    c.setFillColorRGB(*stijl["sub"])
    c.setFont("Helvetica", 10)
    c.drawCentredString(w / 2, h - 84 * mm,
                        "Meer helden-avonturen op AnimalHeroes.club")
    c.showPage()
    c.save()
    return dst, 2 + n + 1


# -------------------------------------------------- kleurstudio publish ---
def export_kleurstudio_platen(tmpdir: Path) -> list[dict]:
    """Schrijf alle kleurplaten als web-JPG's (<=1200px) in tmpdir/platen/
    en geef het platen.json-manifest terug."""
    uit_dir = Path(tmpdir) / "platen"
    uit_dir.mkdir(parents=True, exist_ok=True)
    manifest = []
    for p in lijst_paginas():
        src = PAG_DIR / p["naam"]
        if not src.exists():
            continue
        img = Image.open(src).convert("RGB")
        img.thumbnail((1200, 1200))
        dst = uit_dir / f"{p['id']}.jpg"
        img.save(dst, "JPEG", quality=85)
        manifest.append({"id": p["id"], "naam": p["bron"],
                         "boek": p.get("boek") or "Animal Heroes",
                         "src": f"platen/{p['id']}.jpg"})
    return manifest


def publiceer_kleurstudio() -> dict:
    """1-klik-naar-site: alle kleurplaten als webversie naar
    gsbooks/kleur/ in de g2b-winkel repo (platen/ + platen.json).
    Repo/branch/token uit WINKEL-instellingen, zelfde mechanisme
    als videoboek-publicatie."""
    from . import winkel
    inst = winkel.laad()["instellingen"]
    repo, branch, token = (inst["repo"].strip(),
                           inst["branch"].strip(),
                           inst["github_token"].strip())
    if not repo or not token:
        raise ValueError("Vul bij WINKEL → Instellingen eerst repo + "
                         "GitHub-token in")
    tmpdir = Path(tempfile.mkdtemp(prefix="kleurstudio-"))
    try:
        manifest = export_kleurstudio_platen(tmpdir)
        if not manifest:
            raise ValueError("Geen kleurplaten om te publiceren")

        files: dict[str, Path] = {}
        for f in (tmpdir / "platen").glob("*.jpg"):
            files[f"gsbooks/kleur/platen/{f.name}"] = f
        mtmp = tmpdir / "platen.json"
        mtmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=1),
                        encoding="utf-8")
        files["gsbooks/kleur/platen.json"] = mtmp

        # platen die eerder gepubliceerd waren maar nu lokaal weg zijn
        # moeten ook van de site af — markeer ze als verwijderd in de tree
        verdwenen: list[str] = []
        try:
            cur = winkel._gh(
                "GET", f"/repos/{repo}/contents/gsbooks/kleur/platen.json"
                       f"?ref={branch}", token)
            oud = json.loads(
                base64.b64decode(cur["content"]).decode("utf-8"))
            nieuw_ids = {p["id"] for p in manifest}
            verdwenen = [p["id"] for p in oud
                         if p.get("id") and p["id"] not in nieuw_ids]
        except Exception:
            verdwenen = []

        ref = winkel._gh("GET",
                         f"/repos/{repo}/git/ref/heads/{branch}", token)
        base_sha = ref["object"]["sha"]
        base_tree = winkel._gh(
            "GET", f"/repos/{repo}/git/commits/{base_sha}",
            token)["tree"]["sha"]
        blobs = []
        for rel, f in files.items():
            blob = winkel._gh("POST", f"/repos/{repo}/git/blobs", token,
                              json={"content": base64.b64encode(
                                  f.read_bytes()).decode(),
                                  "encoding": "base64"})
            blobs.append({"path": rel, "mode": "100644", "type": "blob",
                          "sha": blob["sha"]})
        for vid in verdwenen:
            blobs.append({"path": f"gsbooks/kleur/platen/{vid}.jpg",
                          "mode": "100644", "type": "blob", "sha": None})
        tree = winkel._gh("POST", f"/repos/{repo}/git/trees", token,
                          json={"base_tree": base_tree, "tree": blobs})
        commit = winkel._gh("POST", f"/repos/{repo}/git/commits", token,
                            json={"message": "KleurStudio: alle kleurplaten",
                                  "tree": tree["sha"],
                                  "parents": [base_sha]})
        winkel._gh("PATCH", f"/repos/{repo}/git/refs/heads/{branch}",
                   token, json={"sha": commit["sha"]})
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)
    url = (f"https://{repo.split('/')[0]}.github.io/{repo.split('/')[1]}"
           f"/gsbooks/kleur/")
    return {"ok": True, "platen": len(manifest), "url": url,
            "verwijderd": len(verdwenen)}
