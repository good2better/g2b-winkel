"""Merk-asset generator — G2B merkbestanden via Pillow.

Maakt banner/wordmark/avatar PNG's, een kleurenpalet-kaart en een
MERK-KIT zip met alles erin + een MERK-GIDS.txt uitleg. Volledig lokaal.
"""
from __future__ import annotations

import io
import math
import zipfile
from datetime import date
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

FONTS_DIR = Path(__file__).resolve().parent.parent / "fonts"
FONT_BOLD = FONTS_DIR / "DejaVuSans-Bold.ttf"
FONT_REG = FONTS_DIR / "DejaVuSans.ttf"

# G2B-kleurenpalet (zelfde als app + PDF's)
PALET = [
    ("Nacht", "#0D0F0E", "achtergrond van de app"),
    ("Paneel", "#171A19", "kaartjes en panelen"),
    ("G2B Groen", "#2FBF71", "accent — knoppen, highlights"),
    ("Donkergroen", "#1D7A48", "koppen en kaders"),
    ("Tekst Wit", "#E8ECEA", "hoofdtekst"),
    ("Grijs Groen", "#8FA098", "subtekst / labels"),
]
NACHT = "#0D0F0E"
PANEEL = "#171A19"
GROEN = "#2FBF71"
DONKERGROEN = "#1D7A48"
WIT = "#E8ECEA"
GRIJS = "#8FA098"


def _font(pad: Path, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(pad), size)


def _g2b_tekst(draw: ImageDraw.ImageDraw, xy, groot: str, klein: str,
               font_groot, font_klein, kleur_groot=GROEN,
               kleur_klein=WIT) -> None:
    """Tekent 'G2B' groen + restwoord wit naast elkaar."""
    x, y = xy
    draw.text((x, y), groot, font=font_groot, fill=kleur_groot)
    w = draw.textlength(groot, font=font_groot)
    if klein:
        # kleine letter, verticaal ongeveer uitgelijnd met baseline
        bbox = font_groot.getbbox(groot)
        bb2 = font_klein.getbbox(klein)
        dy = (bbox[3] - bbox[1]) - (bb2[3] - bb2[1])
        draw.text((x + w + font_groot.size * 0.18, y + dy), klein,
                  font=font_klein, fill=kleur_klein)


def maak_banner(uit: Path, tagline: str = "Good2Better") -> Path:
    """1500×500 banner: donkere achtergrond, groene accentbalk, G2B."""
    W, H = 1500, 500
    img = Image.new("RGB", (W, H), NACHT)
    d = ImageDraw.Draw(img)
    # subtiele diagonale groene glow
    for i in range(H):
        a = int(20 * (1 - i / H))
        d.line([(0, i), (W, i)], fill=(13, 15 + a // 6, 14 + a // 10))
    # groene basis-balk onderaan
    d.rectangle([0, H - 16, W, H], fill=GROEN)
    d.rectangle([0, H - 20, W, H - 16], fill=DONKERGROEN)
    # decoratieve cirkels
    d.ellipse([W - 360, -140, W + 80, 300], outline=DONKERGROEN, width=6)
    d.ellipse([W - 300, -90, W + 10, 230], outline=GROEN, width=3)

    f_groot = _font(FONT_BOLD, 190)
    f_klein = _font(FONT_BOLD, 64)
    f_tag = _font(FONT_REG, 42)
    x, y = 120, 130
    _g2b_tekst(d, (x, y), "G2B", "STUDIO", f_groot, f_klein)
    d.text((x + 6, y + 235), tagline, font=f_tag, fill=GRIJS)
    img.save(uit)
    return uit


def maak_wordmark(uit: Path, tagline: str = "Good2Better",
                  woord: str = "STUDIO") -> Path:
    """1000×280 wordmark op transparante achtergrond.

    Het tweede woord schaalt automatisch mee zodat het altijd op het
    canvas past."""
    W, H = 1000, 280
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    f_groot = _font(FONT_BOLD, 150)
    g2b_w = d.textlength("G2B", font=f_groot) + 150 * 0.18
    max_klein = W - 40 - g2b_w
    # kleinste font-size waarbij het tweede woord nog past
    size = 58
    while size > 12:
        f_klein = _font(FONT_BOLD, size)
        if d.textlength(woord, font=f_klein) <= max_klein:
            break
        size -= 2
    f_tag = _font(FONT_REG, 34)
    _g2b_tekst(d, (20, 30), "G2B", woord, f_groot, f_klein)
    if tagline:
        d.text((24, 200), tagline, font=f_tag, fill=(*_hex_rgb(GRIJS), 255))
    img.save(uit)
    return uit


def maak_avatar(uit: Path) -> Path:
    """512×512 vierkant profiel-icoon: groene G2B op nacht."""
    S = 512
    img = Image.new("RGB", (S, S), NACHT)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([24, 24, S - 24, S - 24], radius=64,
                        outline=GROEN, width=10)
    f = _font(FONT_BOLD, 200)
    tekst = "G2B"
    bbox = d.textbbox((0, 0), tekst, font=f)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    d.text(((S - tw) / 2 - bbox[0], (S - th) / 2 - bbox[1] - 20), tekst,
           font=f, fill=GROEN)
    f2 = _font(FONT_REG, 34)
    sub = "Good2Better"
    bb2 = d.textbbox((0, 0), sub, font=f2)
    d.text(((S - (bb2[2] - bb2[0])) / 2, S - 140), sub, font=f2,
           fill=GRIJS)
    img.save(uit)
    return uit


def maak_palet(uit: Path) -> Path:
    """1200×760 kleurenpalet-kaart met alle merkkleuren + hex-codes."""
    W, H = 1200, 760
    img = Image.new("RGB", (W, H), WIT)
    d = ImageDraw.Draw(img)
    f_t = _font(FONT_BOLD, 44)
    f_n = _font(FONT_BOLD, 25)
    f_k = _font(FONT_REG, 24)
    f_s = _font(FONT_REG, 22)
    d.rectangle([0, 0, W, 120], fill="#0D0F0E")
    d.text((50, 34), "G2B KLEURENPALET", font=f_t, fill=GROEN)
    d.text((50 + d.textlength("G2B KLEURENPALET", font=f_t) + 16, 58),
           "huisstijl-kleuren met hex-code", font=f_s, fill=GRIJS)

    kolommen, rijen = 3, 2
    cw, chh = W // kolommen, (H - 140) // rijen
    for i, (naam, hex_, gebruik) in enumerate(PALET):
        col, rij = i % kolommen, i // kolommen
        x0, y0 = col * cw, 140 + rij * chh
        d.rectangle([x0 + 20, y0 + 18, x0 + cw - 20, y0 + chh - 110],
                    fill=hex_, outline="#cccccc")
        d.text((x0 + 34, y0 + chh - 96), f"{naam}  {hex_}", font=f_n,
               fill="#1a1a1a")
        # gebruik opsplitsen in max 2 regels als het niet past
        woorden = gebruik.split()
        regel1 = ""
        while woorden and d.textlength(
                regel1 + " " + woorden[0], font=f_k) <= cw - 68:
            regel1 = (regel1 + " " + woorden.pop(0)).strip()
        d.text((x0 + 34, y0 + chh - 58), regel1, font=f_k,
               fill="#555555")
        if woorden:
            d.text((x0 + 34, y0 + chh - 30), " ".join(woorden),
                   font=f_k, fill="#555555")
    img.save(uit)
    return uit


def maak_post(uit: Path, tagline: str = "Good2Better") -> Path:
    """1080×1080 social-vierkant: G2B groot gecentreerd."""
    S = 1080
    img = Image.new("RGB", (S, S), NACHT)
    d = ImageDraw.Draw(img)
    d.ellipse([S - 420, -160, S + 160, 420], outline=DONKERGROEN, width=10)
    d.ellipse([S - 340, -80, S + 80, 340], outline=GROEN, width=4)
    d.rectangle([0, S - 24, S, S], fill=GROEN)
    f = _font(FONT_BOLD, 300)
    bb = d.textbbox((0, 0), "G2B", font=f)
    d.text(((S - (bb[2] - bb[0])) / 2 - bb[0], 280), "G2B", font=f,
           fill=GROEN)
    f2 = _font(FONT_REG, 52)
    bb2 = d.textbbox((0, 0), tagline, font=f2)
    d.text(((S - (bb2[2] - bb2[0])) / 2, 640), tagline, font=f2,
           fill=WIT)
    img.save(uit)
    return uit


def _hex_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


MERK_GIDS = """G2B MERK-KIT — Good2Better
===============================
Gemaakt: {dag} · 100% lokaal gegenereerd door G2B Bedrijfsmiddelen

BESTANDEN
• g2b_banner_1500x500.png   — banner voor Gumroad/site/social headers
• g2b_wordmark_1000x280.png — logo met transparante achtergrond
• g2b_avatar_512.png        — profiel/icoon vierkant
• g2b_post_1080.png         — social media vierkant
• g2b_kleurenpalet.png      — alle merkkleuren met hex-codes

KLEUREN
{kleuren}

LETTERYPE
• DejaVu Sans (Bold) — gratis lettertype, vrij voor commercieel gebruik
  (Bitstream-licentie). Zit meegeleverd in de app.

GEBRUIK
• G2B Groen (#2FBF71) is je accent: knoppen, highlights, logo.
• Nacht (#0D0F0E) is je achtergrond: donker, studio-gevoel.
• Wit-achtige tekst (#E8ECEA) op donkere vlakken, donkere tekst op lichte.
• Alles in deze kit is door jouw eigen app gemaakt — jij mag het
  overal commercieel gebruiken.
"""


def genereer_alle(uit_dir: Path, tagline: str = "Good2Better") -> dict:
    """Maakt alle merkbestanden + zip. Geeft {files: [...], zip: Path}."""
    uit_dir.mkdir(parents=True, exist_ok=True)
    files = [
        maak_banner(uit_dir / "g2b_banner_1500x500.png", tagline),
        maak_wordmark(uit_dir / "g2b_wordmark_1000x280.png", tagline),
        maak_avatar(uit_dir / "g2b_avatar_512.png"),
        maak_post(uit_dir / "g2b_post_1080.png", tagline),
        maak_palet(uit_dir / "g2b_kleurenpalet.png"),
    ]
    kit = uit_dir / f"g2b_merkkit_{date.today():%Y%m%d}.zip"
    gids = MERK_GIDS.format(
        dag=date.today().strftime("%d-%m-%Y"),
        kleuren="\n".join(
            f"• {naam:12s} {hex_}  — {gebruik}"
            for naam, hex_, gebruik in PALET))
    with zipfile.ZipFile(kit, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, f.name)
        z.writestr("MERK-GIDS.txt", gids)
    return {"files": [f.name for f in files], "zip": kit.name}


__all__ = ["genereer_alle", "PALET"]
