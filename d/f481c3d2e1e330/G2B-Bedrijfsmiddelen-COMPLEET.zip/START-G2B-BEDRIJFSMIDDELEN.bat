@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo   G2B BEDRIJFSMIDDELEN
echo   Contracten - Beschrijvingen - Merk - Factuur
echo   100%% lokaal, geen cloud, geen kosten
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [FOUT] Python niet gevonden.
  echo.
  echo Fix: installeer Python zo:
  echo   1. Open een Opdrachtprompt ^(Windows-toets, typ cmd, Enter^)
  echo   2. Typ: winget install Python.Python.3.12
  echo   3. Sluit dit venster en dubbelklik dit bestand opnieuw.
  echo.
  echo Of download Python 3.12+ via https://www.python.org/downloads/
  echo BELANGRIJK: vink "Add Python to PATH" aan tijdens installatie!
  pause
  exit /b 1
)

if not exist .venv (
  echo [1/3] Python-omgeving maken ^(eenmalig^)...
  python -m venv .venv
)
call .venv\Scripts\activate.bat

echo [2/3] Onderdelen installeren/controleren...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r backend\requirements.txt
if errorlevel 1 (
  echo [FOUT] Installatie mislukt. Check je internetverbinding.
  pause
  exit /b 1
)

if not exist "%USERPROFILE%\Desktop\G2B Bedrijfsmiddelen.lnk" (
  echo [3/3] Bureaublad-icoon maken...
  powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\G2B Bedrijfsmiddelen.lnk'); $s.TargetPath = '%~f0'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0g2b.ico'; $s.Save()" >nul 2>nul
)

echo.
echo   Bedrijfsmiddelen start op http://localhost:8010
echo   Browser opent vanzelf. Dit venster open laten!
echo.
start "" /min cmd /c "timeout /t 3 >nul & start http://localhost:8010"
cd backend
python -m uvicorn app.main:app --host 127.0.0.1 --port 8010
pause
