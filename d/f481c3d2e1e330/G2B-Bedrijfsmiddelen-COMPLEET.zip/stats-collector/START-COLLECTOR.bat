@echo off
echo G2B Luistercijfers-collector starten op poort 8025...
cd /d %~dp0
uvicorn collector:app --host 0.0.0.0 --port 8025
pause
