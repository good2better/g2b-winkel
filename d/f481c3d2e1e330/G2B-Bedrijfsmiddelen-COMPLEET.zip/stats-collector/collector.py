"""G2B Luistercijfers-collector — vangt de echte luistertijd van de winkel.

De winkelpagina stuurt elke 15 seconden (en bij het wegklikken) een kleine
"ping" naar dit endpoint: {"product": "<id>", "seconden": <n>}. De collector
schrijft die weg als stats.jsonl — hetzelfde formaat dat je in de app onder
📊 Luistercijfers kunt importeren.

Draaien (zelfde Python als de app):

    uvicorn collector:app --host 0.0.0.0 --port 8025

Zet daarna in de app bij 🎵 WINKEL → Instellingen → Stats-endpoint:

    http://<adres-van-deze-machine>:8025/ping

Lokaal op je eigen pc meet die alleen jouw eigen luistersessies. Wil je
échte bezoekers meten, dan moet deze collector op een publiek adres draaien
( bijv. een kleine VPS of een gratis worker). Zolang stats_url leeg is,
stuurt de winkel niks — alles werkt gewoon zonder.
"""
import json
import threading
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse

STATS_DIR = Path(__file__).resolve().parent / "stats-data"
STATS_FILE = STATS_DIR / "stats.jsonl"
_lock = threading.Lock()

app = FastAPI(title="G2B Luistercijfers-collector", docs_url=None)
# De winkelpagina draait op een ander domein (GitHub Pages) — CORS open.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST", "OPTIONS", "GET"],
    allow_headers=["*"],
)


@app.post("/ping")
async def ping(request: Request):
    try:
        body = await request.body()
        data = json.loads(body or b"{}")
    except Exception:
        return JSONResponse({"ok": False}, status_code=400)
    product = str(data.get("product") or data.get("product_id") or "")[:200]
    try:
        seconden = float(data.get("seconden") or data.get("seconds") or 0)
    except (TypeError, ValueError):
        seconden = 0.0
    if not product or seconden <= 0:
        return {"ok": True}          # niks te meten, maar geen fout
    regel = {
        "ts": datetime.now().isoformat(timespec="seconds"),
        "product": product,
        "seconden": round(seconden, 1),
        "bron": "winkel-live",
    }
    with _lock:
        STATS_DIR.mkdir(parents=True, exist_ok=True)
        with open(STATS_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(regel, ensure_ascii=False) + "\n")
    return {"ok": True}


@app.get("/stats.jsonl")
def download():
    """Haal de ruwe stats op — dit bestand importeer je in de app."""
    if not STATS_FILE.exists():
        return PlainTextResponse("", media_type="application/x-ndjson")
    return PlainTextResponse(
        STATS_FILE.read_text(encoding="utf-8"),
        media_type="application/x-ndjson")


@app.get("/")
def status():
    aantal = 0
    if STATS_FILE.exists():
        aantal = sum(1 for r in STATS_FILE.read_text(
            encoding="utf-8").splitlines() if r.strip())
    return {"ok": True, "pings": aantal}
