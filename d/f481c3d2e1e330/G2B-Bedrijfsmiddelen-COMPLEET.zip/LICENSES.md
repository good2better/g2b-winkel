# Licenties — G2B Bedrijfsmiddelen

**Regel 1:** alles in deze app is open-source én 100% vrij voor
commercieel gebruik. Geen GPL/AGPL, geen non-commercial clausules,
geen cloud-API's, geen betalingen.

## Directe dependencies (backend/requirements.txt)

| Package | Versie | Licentie | Commercieel? | Waarvoor |
|---|---|---|---|---|
| FastAPI | ≥ 0.115 | **MIT** | ✅ ja | Web-backend + API |
| Uvicorn | ≥ 0.30 | **BSD-3-Clause** | ✅ ja | Lokale webserver |
| ReportLab | ≥ 4.2 | **BSD** | ✅ ja | PDF-generatie (contracten, facturen) |
| Pillow | ≥ 10.4 | **HPND** (MIT-CMU, permissief) | ✅ ja | Afbeeldingen (merk-assets, paletkaart) |
| python-multipart | ≥ 0.0.9 | **Apache-2.0** | ✅ ja | Form/veld-parsing in FastAPI |
| imageio-ffmpeg | ≥ 0.5 | **BSD-2-Clause** | ✅ ja | ffmpeg-binary voor preview-MP3's |
| numpy | ≥ 1.26 | **BSD-3-Clause** | ✅ ja | Beeld-bewerking kleurboek-lijnen |
| pypdfium2 | ≥ 4.30 | **Apache-2.0 / BSD** | ✅ ja | kaft-PDF → voorkant-PNG export |
| rembg (+ onnxruntime) | ≥ 2.0.50 | **MIT** | ✅ ja | chroma-key helden-uitsnede op kleurboek-kaften |
| edge-tts | ≥ 7.0 | **MIT** | ✅ ja | NL-voorleesstem (Fenna) voor interactieve videoboeken |

## Meegeleverde assets

| Bestand | Licentie | Commercieel? |
|---|---|---|
| `backend/app/fonts/DejaVuSans*.ttf` | **Bitstream Vera / DejaVu** (permissief, vrij gebruik incl. commercieel + inbedden) | ✅ ja |
| `store/vendor/wavesurfer.esm.js` (WaveSurfer.js v7) | **BSD-3-Clause** | ✅ ja |

## Over de ffmpeg-binary (belangrijk, eerlijk)

`imageio-ffmpeg` levert een kant-en-klare ffmpeg-binary mee. De
bibliotheek zelf is BSD; de ffmpeg-binary is LGPL/GPL *software*.
Dat is **OK voor regel 1** omdat:

- Wij roepen ffmpeg aan als apart programma (subprocess), niet als
  library — er is geen GPL-"besmetting" van onze code.
- De output (jouw preview-MP3's) is 100% jouw eigendom en vrij
  commercieel te gebruiken.
- ffmpeg zelf is gratis en open-source (ffmpeg.org).

## Wat hier bewust NIET in zit

- **Geen GPL/AGPL in eigen code** — niks dat jouw eigen product "open"
  zou moeten maken.
- **Geen CC-BY-NC of andere non-commercial assets.**
- **Geen cloud-diensten** — geen API-keys, geen data die je pc verlaat.
- **Geen AI-modellen** — de tekstgenerator werkt met eigen templates.
- **Geen betaalde platforms** — de winkel draait op gratis GitHub Pages;
  betalingen via jouw eigen Stripe/ChargeKeep-betaallinks (standaard
  Stripe-fee per verkoop, geen extra commissie).

## Transitieve dependencies (worden door pip meegeïnstalleerd)

| Package | Licentie |
|---|---|
| Starlette (onder FastAPI) | BSD-3-Clause |
| Pydantic + pydantic-core | MIT |
| AnyIO | MIT |
| h11, httptools, watchfiles, websockets, PyYAML (onder Uvicorn) | MIT / Apache-2.0 / BSD |
| typing-extensions, annotated-types | PSF / MIT |

Geverifieerd: oktober 2026.
