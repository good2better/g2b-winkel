# G2B Bedrijfsmiddelen

**Jouw zakelijke gereedschap — één app voor al je G2B-documenten.**
100% lokaal op je eigen PC (Windows 10, gewone CPU). Geen cloud, geen
account, geen abonnement, geen kosten.

## Wat zit erin

| Tabblad | Wat het doet |
|---|---|
| 📜 **CONTRACT** | Licentie-contract als professionele PDF: naam koper + product + licentie-type (persoonlijk/commercieel) → kant-en-klaar contract met handtekeninglijnen. |
| ✍️ **BESCHRIJVING** | Verkooptekst in het Nederlands voor Gumroad/eigen site: lange versie + korte versie, met kopieer-knoppen. Ook opgeslagen als .txt. |
| 🎨 **MERK-ASSETS** | G2B merkbestanden: banner, wordmark, avatar, social-vierkant en kleurenpalet-kaart (PNG's) + **MERK-KIT zip** met uitleg. |
| 🧾 **FACTUUR** | Zakelijke BTW-factuur-PDF (21%/9%/geen keuze, incl/excl). Je bedrijfsgegevens (KvK, BTW-nummer, IBAN) vul je één keer in — staan dan op elke factuur. |
| 📋 **VOORWAARDEN** | Jouw Algemene Voorwaarden als PDF (met je KvK/BTW-gegevens) — voor op je site of mee bij een verkoop. |
| 🎵 **WINKEL** | Je eigen muziekwinkel: sleep een beat/pack in de inbox → preview + hoes erbij → prijs en betaallinks invullen → **Publiceer** zet hem live op GitHub Pages. Werkt voor audio én andere digitale producten (zip, pdf, pack). |
| 💶 **ROYALTIES** | Verkopen invoeren of CSV importeren (Stripe/ChargeKeep) → netto wordt automatisch verdeeld volgens de splits van het product → per persoon een tegoed + royalty-PDF bij uitbetaling. |
| 🎬 **VIDEOBOEK** | Boek + voorlees-stem erin → videoboek eruit: mp4-filmpje (Ken Burns over je platen met je stem eronder), GS Books-speler voor op je site, en verkoopproduct voor je winkel — alles in één klik. |
| 🖍️ **KLEURBOEK** | Kleurboek-Fabriek: boekplaten of video's erin → zwart-wit kleurplaten + print-klaar kleurboek-PDF + drukkers-kaft (achter+rug+voor, met bleed). **4 kaft-stijlen** (Geheel = boek-scène wrap-around als kaft, Cozy, Feest, Stripboek), 🔄 Kaft/Inhoud-opnieuw-knoppen voor steeds een andere compositie, 🖼-knop per plaat om 'm uit de kaft te houden, en **✨ Teken plaat**: beschrijf een plaat en de Fabriek tekent hem zelf via je ImageLab-pod (FLUX). Ook: **📖 Boek-binnenkant** (verhaal+platen → drukklaar A5/6x9 boek-PDF, auto-rugdikte), **📦 Bundel** (meerdere boeken → verzamelkleurboek met hoofdstuk-pagina's) en **🛒 1-klik naar winkel** (kleurboek+kaft+voorkant als verkoopbaar ZIP-pakket). |
| 📁 **BESTANDEN** | Alles wat je maakte, met download-links en verwijder-knop. Ook de **💾 Backup-knop**: één ZIP met je gegevens + nummering + alle bestanden — en 📥 terugzetten op (een nieuwe) pc. |

## Starten (Windows)

1. Dubbelklik **`START-G2B-BEDRIJFSMIDDELEN.bat`**
2. De eerste keer installeert hij zelf alles (Python-omgeving + onderdelen)
3. Je browser opent vanzelf op **http://localhost:8010**
4. Klaar? Sluit het zwarte venster om de app te stoppen.

> Heb je nog geen Python? De starter legt uit hoe je die met één
> commando installeert (`winget install Python.Python.3.12`).

Details staan in **`docs/SNELSTART.txt`**.

## Verwijderen

Dubbelklik **`VERWIJDER-G2B-BEDRIJFSMIDDELEN.bat`** — haalt de app, de
Python-omgeving en het bureaublad-icoon weg. (Let op: ook je exports,
dus kopieer die eerst.)

## De winkel (je eigen Bandcamp-alternatief)

De publieke winkelpagina staat in `store/` (template) en wordt gebouwd
naar `backend/storage/winkel/site/`. Publiceren gaat via de GitHub API
naar je eigen repo `g2b-winkel` met GitHub Pages — jouw bezoekers zien
een echte winkel met golfvorm-speler, licentie-keuze (MP3-lease / WAV /
Exclusief buy-out) en KOOP-knoppen naar jouw betaallinks.

**Eenmalige setup (eenmalig, ~10 min):**
1. Maak een **publieke** GitHub-repo `g2b-winkel`.
2. Maak een GitHub-token met alleen rechten op die repo
   (Settings → Developer settings → Personal access tokens →
   fine-grained → Contents: read/write).
3. Zet GitHub Pages aan op die repo (Settings → Pages → Branch: main).
4. Vul repo + token in op tabblad 🎵 WINKEL → Instellingen opslaan.

Daarna is het dagelijks: bestand in de inbox → in winkel zetten →
publiceer. Insluiten in je Beezer-site kan met een iFrame-component
(dat werkt omdat de winkel op https://….github.io draait).

## Waar staan mijn bestanden?

Alles wat je genereert landt in `backend/storage/exports/` — en is ook
te downloaden via het tabblad 📁 BESTANDEN in de app. De winkel-data
(catalogus, uploads, previews) staat in `backend/storage/winkel/` en
gaat bewust NIET mee in git (je token staat erin).

## Techniek (voor wie het wil weten)

- FastAPI-backend (`backend/app/main.py`), simpele eigen frontend
  (`backend/app/static/`) — één pagina, geen framework.
- PDF's via ReportLab (BSD-licentie), afbeeldingen via Pillow (HPND),
  lettertype: DejaVu Sans (meegeleverd, vrij voor commercieel gebruik).
- Previews via imageio-ffmpeg (BSD, bundelt ffmpeg); speler op de
  winkelsite: WaveSurfer.js v7 (BSD-3-Clause), lokaal meegeleverd —
  geen CDN, geen trackers, geen cookies.
- Poort **8010** (de G2B Workstation gebruikt 8000 — ze kunnen naast
  elkaar draaien).
- Elke dependency + licentie staat in **`LICENSES.md`** (regel 1:
  alles open-source en commercieel vrij).

## ✨ Zelf-teken-modus (Kleurboek-Fabriek)

De Fabriek kan boekplaten zélf tekenen via je ImageLab-GPU-pod
(FLUX.1-schnell — Apache-2.0, regel 1 OK):

1. Start je pod zoals gewoonlijk in **ImageLab** of de **Workstation**
2. Zet de worker-url als omgevingsvariabele vóór het starten van deze app:
   - `set G2B_WORKER_URL=https://<jouw-pod-id>-8001.proxy.runpod.net`
   - (of `GAW_WORKER_URL` — zelfde als ImageLab)
3. De "✨ Teken plaat"-rij verschijnt dan automatisch in de KLEURBOEK-tab.
   Zonder worker-url blijft die rij verborgen — de rest van de app is 100%
   lokaal en gratis zoals altijd.

Kosten: een paar pod-centen per plaatje; de pod stopt zichzelf (auto-stop).
