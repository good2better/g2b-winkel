@echo off
setlocal
echo Dit verwijdert G2B Bedrijfsmiddelen inclusief omgeving en icoon.
echo LET OP: je gegenereerde bestanden in backend\storage\exports gaan
echo ook weg — kopieer ze eerst als je ze wilt bewaren!
set /p ok=Weet je het zeker? (j/n):
if /i not "%ok%"=="j" exit /b 0
del "%USERPROFILE%\Desktop\G2B Bedrijfsmiddelen.lnk" >nul 2>nul
cd /d "%~dp0"
cd ..
rmdir /s /q "%~dp0"
echo Verwijderd.
pause
