/*
 * G2B Poets — UI (NanoVG): donkergroen paneel, één grote POETS-draai
 * + kleine OUTPUT, met een live oscilloscope (echte golfvorm van het
 * uitgaande signaal) en een glow die oplicht bij elke punch.
 * Sleep omhoog/omlaag = draaien; scroll = fijn.
 */

#include "DistrhoUI.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;



class PoetsUI : public UI
{
public:
    PoetsUI()
        : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        std::memset(fValue, 0, sizeof(fValue));
        std::memset(fScope, 0, sizeof(fScope));
        fMin[0] = 0.0f;  fMax[0] = 100.0f;
        fMin[1] = -6.0f; fMax[1] = 6.0f;
        fPunch = 0.0f;
        fScopePos = 0;
        fDrag = -1;
        fLastY = 0.0f;
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if (index < 2) fValue[index] = value;
        repaint();
    }

    void stateChanged(const char* key, const char* value) override
    {
        if (std::strcmp(key, "scope") == 0)
        {
            // "v1;v2;..." → append aan ringbuffer
            const char* p = value;
            while (*p != '\0')
            {
                char* end = nullptr;
                const float v = std::strtof(p, &end);
                if (end == p) break;
                fScope[fScopePos] = v;
                fScopePos = (fScopePos + 1) % kScopeSize;
                p = (*end == ';') ? end + 1 : end;
            }
        }
        else if (std::strcmp(key, "punch") == 0)
        {
            const float v = std::strtof(value, nullptr);
            if (v > fPunch) fPunch = v;
        }
        repaint();
    }

    void uiIdle() override
    {
        // glow dooft langzaam uit — elke idle-tick
        if (fPunch > 0.0f)
        {
            fPunch *= 0.92f;
            if (fPunch < 0.001f) fPunch = 0.0f;
            repaint();
        }
    }

    void onNanoDisplay() override
    {
        const float W = getWidth(), H = getHeight();

        // achtergrond
        beginPath();
        rect(0, 0, W, H);
        fillColor(13, 15, 14);
        fill();

        // titel
        fontSize(20.0f);
        textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
        fillColor(47, 191, 113);
        text(18.0f, 24.0f, "G2B POETS", nullptr);
        fontSize(11.5f);
        fillColor(143, 160, 152);
        text(18.0f, 43.0f, "punch + body + sizzle — één draai", nullptr);

        // ---- oscilloscope (rechtsboven) ----
        const float sx = 170.0f, sy = 12.0f, sw = W - 188.0f, sh = 46.0f;
        beginPath();
        rect(sx, sy, sw, sh);
        fillColor(8, 10, 9);
        fill();
        strokeColor(42, 47, 45);
        strokeWidth(1.0f);
        stroke();

        beginPath();
        const float mid = sy + sh * 0.5f;
        for (int i = 0; i < kScopeSize - 1; ++i)
        {
            const int idx0 = (fScopePos + i) % kScopeSize;
            const int idx1 = (fScopePos + i + 1) % kScopeSize;
            const float x0 = sx + (float)i / (kScopeSize - 1) * sw;
            const float x1 = sx + (float)(i + 1) / (kScopeSize - 1) * sw;
            float y0 = mid - fScope[idx0] * sh * 0.45f;
            float y1 = mid - fScope[idx1] * sh * 0.45f;
            if (y0 < sy + 1) y0 = sy + 1;
            if (y0 > sy + sh - 1) y0 = sy + sh - 1;
            if (y1 < sy + 1) y1 = sy + 1;
            if (y1 > sy + sh - 1) y1 = sy + sh - 1;
            if (i == 0) moveTo(x0, y0); else lineTo(x0, y0);
            lineTo(x1, y1);
        }
        strokeColor(47, 191, 113);
        strokeWidth(1.5f);
        stroke();

        // ---- grote POETS-knop (links-centraal) met punch-glow ----
        const float pcx = 120.0f, pcy = 175.0f, pR = 62.0f;
        const float norm0 = (fValue[0] - fMin[0]) / (fMax[0] - fMin[0]);
        const float ang0 = -2.4f + norm0 * 4.8f;

        // glow: groene waas die oplicht bij punch-transienten
        const float gl = fPunch * 2.2f;
        if (gl > 0.02f)
        {
            const float gg = gl > 1.0f ? 1.0f : gl;
            beginPath();
            circle(pcx, pcy, pR + 14.0f);
            const Paint grad = radialGradient(pcx, pcy, pR * 0.5f, pR + 14.0f,
                                              Color(47, 191, 113, (int)(gg * 90)),
                                              Color(47, 191, 113, 0));
            fillPaint(grad);
            fill();
        }

        beginPath();
        circle(pcx, pcy, pR);
        fillColor(30, 34, 33);
        fill();
        strokeColor(42, 47, 45);
        strokeWidth(2.5f);
        stroke();

        beginPath();
        arc(pcx, pcy, pR - 6.0f, -2.4f - 1.5708f, ang0 - 1.5708f, CW);
        strokeColor(47, 191, 113);
        strokeWidth(5.0f);
        stroke();

        beginPath();
        moveTo(pcx, pcy);
        lineTo(pcx + std::sin(ang0) * (pR - 16.0f),
               pcy - std::cos(ang0) * (pR - 16.0f));
        strokeColor(232, 236, 234);
        strokeWidth(4.0f);
        stroke();

        fontSize(14.0f);
        fillColor(143, 160, 152);
        textAlign(ALIGN_CENTER | ALIGN_TOP);
        text(pcx, pcy + pR + 10.0f, "POETS", nullptr);
        fontSize(16.0f);
        fillColor(232, 236, 234);
        char buf[32];
        std::snprintf(buf, sizeof(buf), "%.0f %%", fValue[0]);
        text(pcx, pcy + pR + 27.0f, buf, nullptr);

        // ---- kleine OUTPUT-knop (rechts) ----
        const float ocx = W - 90.0f, ocy = 175.0f, oR = 36.0f;
        const float norm1 = (fValue[1] - fMin[1]) / (fMax[1] - fMin[1]);
        const float ang1 = -2.4f + norm1 * 4.8f;

        beginPath();
        circle(ocx, ocy, oR);
        fillColor(30, 34, 33);
        fill();
        strokeColor(42, 47, 45);
        strokeWidth(2.0f);
        stroke();

        beginPath();
        arc(ocx, ocy, oR - 5.0f, -2.4f - 1.5708f, ang1 - 1.5708f, CW);
        strokeColor(29, 122, 72);
        strokeWidth(3.5f);
        stroke();

        beginPath();
        moveTo(ocx, ocy);
        lineTo(ocx + std::sin(ang1) * (oR - 10.0f),
               ocy - std::cos(ang1) * (oR - 10.0f));
        strokeColor(232, 236, 234);
        strokeWidth(3.0f);
        stroke();

        fontSize(11.0f);
        fillColor(143, 160, 152);
        text(ocx, ocy + oR + 8.0f, "OUTPUT", nullptr);
        fontSize(12.5f);
        fillColor(232, 236, 234);
        std::snprintf(buf, sizeof(buf), "%.1f dB", fValue[1]);
        text(ocx, ocy + oR + 24.0f, buf, nullptr);

        // hulptekst
        fontSize(10.5f);
        fillColor(90, 100, 94);
        textAlign(ALIGN_CENTER | ALIGN_BOTTOM);
        
        // preset-knoppen
        {
            float bx = W - 18.0f;
            for (int i = kNumPresets - 1; i >= 0; --i)
            {
                const float bw = 62.0f, bh = 17.0f;
                bx -= bw + 5.0f;
                const bool on = (i == fProg);
                beginPath(); roundedRect(bx, 64.0f, bw, bh, 4.0f);
                if (on) { fillColor(29, 122, 72); fill(); }
                strokeColor(42, 47, 45); strokeWidth(1.0f); stroke();
                fontSize(10.0f); textAlign(ALIGN_CENTER | ALIGN_MIDDLE);
                fillColor(on ? Color(232, 236, 234) : Color(143, 160, 152));
                text(bx + bw * 0.5f, 64.0f + bh * 0.5f, kPresetNames[i], nullptr);
            }
        }

        text(W * 0.5f, H - 8.0f,
             "sleep omhoog/omlaag om te draaien — scroll = fijn", nullptr);

        {
            float bx2 = 14.0f;
            beginPath(); roundedRect(bx2, 48.0f, 26.0f, 17.0f, 4.0f);
            fillColor(fLight ? Color(214,220,217) : Color(24,28,27)); fill();
            strokeColor(42,47,45); strokeWidth(1.0f); stroke();
            fontSize(11.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor(fLight ? Color(28,34,31) : Color(232,236,234));
            text(bx2+13.0f, 56.5f, "\xF0\x9F\x8E\xB2", nullptr);
            const float tx = W - 40.0f;
            beginPath(); roundedRect(tx, 34.0f, 26.0f, 17.0f, 4.0f);
            fillColor(fLight ? Color(214,220,217) : Color(24,28,27)); fill();
            strokeColor(42,47,45); strokeWidth(1.0f); stroke();
            fontSize(10.0f);
            text(tx+13.0f, 42.5f, fLight ? "\xF0\x9F\x8C\x99" : "\xE2\x98\x80", nullptr);
        }
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if (ev.button != 1) return false;
        const float W = getWidth();
        const float knobs[2][3] = {{120.0f, 175.0f, 62.0f},
                                   {W - 90.0f, 175.0f, 36.0f}};
        if (ev.press)
        {
            if (ev.pos.getX() >= 14.0f && ev.pos.getX() <= 40.0f &&
                ev.pos.getY() >= 48.0f && ev.pos.getY() <= 65.0f)
            { setParameterValue(2, 1.0f); repaint(); return true; }
            if (ev.pos.getX() >= W-40.0f && ev.pos.getX() <= W-14.0f &&
                ev.pos.getY() >= 34.0f && ev.pos.getY() <= 51.0f)
            { fLight = !fLight; repaint(); return true; }

            // preset-klik?
            {
                float bx = W - 18.0f;
                for (int i = kNumPresets - 1; i >= 0; --i)
                {
                    const float bw = 62.0f, bh = 17.0f;
                    bx -= bw + 5.0f;
                    if (ev.pos.getX() >= bx && ev.pos.getX() <= bx + bw &&
                        ev.pos.getY() >= 64.0f && ev.pos.getY() <= 64.0f + bh)
                    {
                        setParameterValue(3, (float)i);
                        fProg = i;
                        repaint();
                        return true;
                    }
                }
            }

            for (int i = 0; i < 2; ++i)
            {
                const float dx = ev.pos.getX() - knobs[i][0];
                const float dy = ev.pos.getY() - knobs[i][1];
                if (dx*dx + dy*dy <= knobs[i][2]*knobs[i][2] + 100.0f)
                {
                    fDrag = i;
                    fLastY = ev.pos.getY();
                    editParameter(i, true);
                    return true;
                }
            }
        }
        else if (fDrag >= 0)
        {
            editParameter(fDrag, false);
            fDrag = -1;
        }
        return true;
    }

    bool onMotion(const MotionEvent& ev) override
    {
        if (fDrag < 0) return false;
        const float dy = fLastY - ev.pos.getY();
        fLastY = ev.pos.getY();
        const float range = fMax[fDrag] - fMin[fDrag];
        float v = fValue[fDrag] + dy * range / 200.0f;
        if (v < fMin[fDrag]) v = fMin[fDrag];
        if (v > fMax[fDrag]) v = fMax[fDrag];
        fValue[fDrag] = v;
        setParameterValue(fDrag, v);
        repaint();
        return true;
    }

    bool onScroll(const ScrollEvent& ev) override
    {
        const float W = getWidth();
        const float knobs[2][3] = {{120.0f, 175.0f, 62.0f},
                                   {W - 90.0f, 175.0f, 36.0f}};
        for (int i = 0; i < 2; ++i)
        {
            const float dx = ev.pos.getX() - knobs[i][0];
            const float dy = ev.pos.getY() - knobs[i][1];
            if (dx*dx + dy*dy <= knobs[i][2]*knobs[i][2] + 100.0f)
            {
                const float range = fMax[i] - fMin[i];
                float v = fValue[i] + ev.delta.getY() * range / 100.0f;
                if (v < fMin[i]) v = fMin[i];
                if (v > fMax[i]) v = fMax[i];
                fValue[i] = v;
                editParameter(i, true);
                setParameterValue(i, v);
                editParameter(i, false);
                repaint();
                return true;
            }
        }
        return true;
    }

private:
    static const int kScopeSize = 256;
    float fValue[2], fMin[2], fMax[2];
    float fScope[kScopeSize];
    int fScopePos;
    float fPunch;
    int fDrag;
    float fLastY;
    int fProg = -1;
    bool fLight = false;

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PoetsUI)
};

UI* createUI() { return new PoetsUI(); }

END_NAMESPACE_DISTRHO
