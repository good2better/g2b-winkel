/*
 * G2B Poets — "één dikke draai, alles erin".
 * DSP: dezelfde POETS-macro als in G2B Sound Lab —
 *   punch  = transient-versterker (in - langzaam-gemiddelde, 8 ms)
 *   body   = laag-boost via LP 180 Hz
 *   sizzle = air-boost via HP 10 kHz
 *   glue   = zachte tanh-verzadiger
 * Stuurt elke ~45 ms een gedecimeerde golfvorm + punch-meting naar de UI
 * (state "scope" / "punch") zodat je ziet wat hij doet.
 */

#include "DistrhoPlugin.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;
static const float kPresetParams[6][2] = {
    { 45, 0 },
    { 60, 0 },
    { 70, -0.5 },
    { 30, 0 },
    { 50, 0 },
    { 40, 0 },
};


class PoetsPlugin : public Plugin
{
public:
    enum Parameters {
        kPoets = 0,   // POETS % — de dikke draai
        kOut,         // OUTPUT dB
        kPreset,
        kParameterCount
    };

    PoetsPlugin()
        : Plugin(kParameterCount, 0, 0),
          fPoets(35.0f), fOutDb(0.0f),
          fLpPunchL(0), fLpPunchR(0), fLpBodyL(0), fLpBodyR(0),
          fLpAirL(0), fLpAirR(0),
          fAPunch(0), fABody(0), fAAir(0), fOutGain(1.0f),
          fPunchMeter(0.0f), fDecim(0), fScopeN(0)
    {
        recalc();
    }

protected:
    const char* getLabel() const override { return "G2B Poets"; }
    const char* getDescription() const override
    {
        return "Één dikke draai: punch + body + sizzle tegelijk. "
               "Maakt je mix vet, helder en hard — G2B-stijl.";
    }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','P','t'); }

    void initParameter(uint32_t index, Parameter& parameter) override
    {
        parameter.hints = kParameterIsAutomatable;
        switch (index)
        {
        case kPoets:
            parameter.name = "Poets";
            parameter.shortName = "Poets";
            parameter.symbol = "poets";
            parameter.unit = "%";
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 100.0f;
            parameter.ranges.def = 35.0f;
            break;
        case kOut:
            parameter.name = "Output";
            parameter.shortName = "Output";
            parameter.symbol = "out";
            parameter.unit = "dB";
            parameter.ranges.min = -6.0f;
            parameter.ranges.max = 6.0f;
            parameter.ranges.def = 0.0f;
            break;
        case kPreset:
            parameter.name = "Preset";
            parameter.symbol = "preset";
            parameter.unit = "";
            parameter.hints = kParameterIsInteger;
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 5.0f;
            parameter.ranges.def = 0.0f;
            break;
        }
    }

    float getParameterValue(uint32_t index) const override
    {
        switch (index)
        {
        case kPoets: return fPoets;
        case kOut:   return fOutDb;
        case kPreset: return fPreset;
        }
        return 0.0f;
    }

    void setParameterValue(uint32_t index, float value) override
    {
        if (index == kPreset) { fPreset = value; applyPreset((int)value); return; }
        switch (index)
        {
        case kPoets: fPoets = value; break;
        case kOut:   fOutDb = value; break;
        }
        recalc();
    }

    void activate() override
    {
        fLpPunchL = fLpPunchR = fLpBodyL = fLpBodyR = fLpAirL = fLpAirR = 0.0f;
        fPunchMeter = 0.0f;
        fScopeN = 0;
    }

    void run(const float** inputs, float** outputs, uint32_t frames) override
    {
        const float* inL = inputs[0];
        const float* inR = inputs[1];
        float* outL = outputs[0];
        float* outR = outputs[1];

        const float a   = fPoets / 100.0f;
        const float ap  = fAPunch, ab = fABody, ah = fAAir;
        const float g   = fOutGain;
        const float drv = 1.0f + 0.4f * a;
        const float mk  = 1.0f - 0.10f * a;   // makeup na de tanh

        float ppL = fLpPunchL, ppR = fLpPunchR;
        float pbL = fLpBodyL,  pbR = fLpBodyR;
        float phL = fLpAirL,   phR = fLpAirR;
        float meter = fPunchMeter;

        for (uint32_t i = 0; i < frames; ++i)
        {
            // ---- L ----
            float l = inL[i];
            ppL += ap * (l - ppL);              // ~8 ms gemiddelde
            float transL = l - ppL;             // transient-deel
            pbL += ab * (l - pbL);              // sub-band <180 Hz
            phL += ah * (l - phL);              // lp 10 k → hp = l - ph
            float yL = l + transL * 0.9f * a + pbL * 0.45f * a + (l - phL) * 0.55f * a;
            // ---- R ----
            float r = inR[i];
            ppR += ap * (r - ppR);
            float transR = r - ppR;
            pbR += ab * (r - pbR);
            phR += ah * (r - phR);
            float yR = r + transR * 0.9f * a + pbR * 0.45f * a + (r - phR) * 0.55f * a;

            // glue: tanh + lichte makeup
            yL = std::tanh(yL * drv) * mk * g;
            yR = std::tanh(yR * drv) * mk * g;

            outL[i] = yL;
            outR[i] = yR;

            // punch-meter: hoeveel transient-energie loopt er nu
            const float t = std::fabs(transL) + std::fabs(transR);
            meter += (t > meter ? 0.5f : 0.02f) * (t - meter);

            // scope-buffer: gedecimeerd mono-signaal voor de UI
            if (++fDecim >= 3)
            {
                fDecim = 0;
                if (fScopeN < kScopeLen)
                    fScope[fScopeN++] = (yL + yR) * 0.5f;
            }
        }

        fLpPunchL = ppL; fLpPunchR = ppR;
        fLpBodyL = pbL;  fLpBodyR = pbR;
        fLpAirL = phL;   fLpAirR = phR;
        fPunchMeter = meter;

        // stuur scope-data ±10x/seconde naar de UI
        if (fScopeN >= 40)
        {
            char buf[256];
            int pos = 0;
            for (uint32_t s = 0; s < fScopeN && pos < 230; ++s)
                pos += std::snprintf(buf + pos, sizeof(buf) - pos, "%.3f;", fScope[s]);
            buf[pos] = '\0';
            setState("scope", buf);
            char mb[24];
            std::snprintf(mb, sizeof(mb), "%.3f", meter);
            setState("punch", mb);
            fScopeN = 0;
        }
    }

private:
    static const int kScopeLen = 96;
    float fPoets, fOutDb;
    float fLpPunchL, fLpPunchR, fLpBodyL, fLpBodyR, fLpAirL, fLpAirR;
    float fAPunch, fABody, fAAir, fOutGain;
    float fPunchMeter;
    uint32_t fDecim, fScopeN;
    float fScope[kScopeLen];

    float fPreset = 0.0f;

    void applyPreset(int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        const float* p = kPresetParams[i];
        setParameterValue(kPoets, p[0]);
        setParameterValue(kOut, p[1]);
        recalc();
    }

    void recalc()
    {
        const float sr = (float)getSampleRate();
        const float pi = 3.14159265358979f;
        fAPunch  = 1.0f - std::exp(-1.0f / (sr * 0.008f));   // 8 ms gemiddelde
        fABody   = std::exp(-2.0f * pi * 180.0f / sr);       // LP 180 Hz
        fAAir    = std::exp(-2.0f * pi * 10000.0f / sr);     // LP 10 kHz
        fOutGain = std::pow(10.0f, fOutDb / 20.0f);
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PoetsPlugin)
};

Plugin* createPlugin() { return new PoetsPlugin(); }

END_NAMESPACE_DISTRHO
