#include "DistrhoPlugin.hpp"
#include <cstring>
#include <cmath>
#include <cstdint>
#include <algorithm>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[17] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO","TRAP","BOOM","UKG","JERSEY","BOUNCE","SOUL","LOFI","FUNK","REGGAE","DANCE","KAW"};
static const int kNumPresets = 17;
// RUIMTE(0-1), TIJD ms, DEMP Hz, BREEDTE x, PREDELAY ms, OUT dB
static const float kPresetParams[17][6] = {
    {0.30f, 280.f, 6000.f, 1.2f, 12.f, 0.f},   // G2B
    {0.22f, 300.f, 7000.f, 1.1f, 10.f, 0.f},   // DEMBOW
    {0.18f, 220.f, 5500.f, 1.0f, 8.f,  0.f},   // DRILL
    {0.35f, 340.f, 5200.f, 1.3f, 16.f, 0.f},   // RNB
    {0.28f, 250.f, 6500.f, 1.4f, 8.f,  0.f},   // HOUSE
    {0.26f, 270.f, 6200.f, 1.25f,11.f, 0.f},   // AFRO
    {0.20f, 260.f, 5000.f, 1.1f, 10.f, 0.f},   // TRAP
    {0.32f, 320.f, 5500.f, 1.0f, 14.f, 0.f},   // BOOM
    {0.24f, 240.f, 6800.f, 1.5f, 8.f,  0.f},   // UKG
    {0.22f, 200.f, 7000.f, 1.3f, 8.f,  0.f},   // JERSEY
    {0.27f, 260.f, 6300.f, 1.3f, 10.f, 0.f},   // BOUNCE
    {0.38f, 360.f, 4800.f, 1.2f, 18.f, 0.f},   // SOUL
    {0.30f, 300.f, 4500.f, 1.0f, 15.f, 0.f},   // LOFI
    {0.25f, 230.f, 6400.f, 1.4f, 9.f,  0.f},   // FUNK
    {0.34f, 340.f, 5600.f, 1.3f, 16.f, 0.f},   // REGGAE
    {0.26f, 250.f, 6600.f, 1.4f, 8.f,  0.f},   // DANCE
    {0.29f, 290.f, 6000.f, 1.25f, 12.f, 0.f},  // KAWINA

};

class RuimtePlugin : public Plugin {
public:
    enum Params { kRuimte, kTijd, kDemp, kBreedte, kPredelay, kOutput, kDice, kPreset, kNumParams };
    RuimtePlugin() : Plugin(kNumParams, 0, 2) {
        for (int i=0;i<kMaxDel;i++){fBufL[i]=0.f;fBufR[i]=0.f;}
        for (int i=0;i<kMaxPre;i++){fPreL[i]=0.f;fPreR[i]=0.f;}
    }
protected:
    const char* getLabel() const override { return "G2B Ruimte"; }
    const char* getDescription() const override { return "Ruimte: delay+reverb in één — jouw geluid krijgt plek"; }
    const char* getMaker() const override { return "G2B"; }
    const char* getLicense() const override { return "Proprietary"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','R','u'); }

    void initParameter(uint32_t index, Parameter& p) override {
        switch(index){
        case kRuimte:   p.name="RUIMTE";   p.symbol="ruimte";   p.hints=kParameterIsAutomatable; p.ranges.min=0.f; p.ranges.max=1.f; p.ranges.def=0.30f; p.unit="%"; break;
        case kTijd:     p.name="TIJD";     p.symbol="tijd";     p.hints=kParameterIsAutomatable; p.ranges.min=50.f; p.ranges.max=2000.f; p.ranges.def=280.f; p.unit="ms"; break;
        case kDemp:     p.name="DEMP";     p.symbol="demp";     p.hints=kParameterIsAutomatable; p.ranges.min=1000.f; p.ranges.max=12000.f; p.ranges.def=6000.f; p.unit="Hz"; break;
        case kBreedte:  p.name="BREEDTE";  p.symbol="breedte";  p.hints=kParameterIsAutomatable; p.ranges.min=0.5f; p.ranges.max=2.f; p.ranges.def=1.2f; p.unit="x"; break;
        case kPredelay: p.name="PREDELAY"; p.symbol="predelay"; p.hints=kParameterIsAutomatable; p.ranges.min=0.f; p.ranges.max=100.f; p.ranges.def=12.f; p.unit="ms"; break;
        case kOutput:   p.name="OUTPUT";   p.symbol="output";   p.hints=kParameterIsAutomatable; p.ranges.min=-24.f; p.ranges.max=12.f; p.ranges.def=0.f; p.unit="dB"; break;
        case kDice: p.name="DICE"; p.symbol="dice"; p.hints|=kParameterIsInteger|kParameterIsTrigger; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; break;
        case kPreset:   p.name="PRESET";   p.symbol="preset";   p.hints=kParameterIsAutomatable|kParameterIsInteger; p.ranges.min=0.f; p.ranges.max=16.f; p.ranges.def=0.f; break;
        }
    }
    float getParameterValue(uint32_t i) const override {
        switch(i){case kRuimte:return fRuimte;case kTijd:return fTijd;case kDemp:return fDemp;case kBreedte:return fBreedte;case kPredelay:return fPredelay;case kOutput:return fOutput;case kDice: return fDice; case kPreset: return fPreset;} return 0.f;
    }
    void setParameterValue(uint32_t i, float v) override {
        if (i==kPreset){ applyPreset((int)(v+0.5f)); return; }
        switch(i){case kRuimte:fRuimte=v;break;case kTijd:fTijd=v;break;case kDemp:fDemp=v;break;case kBreedte:fBreedte=v;break;case kPredelay:fPredelay=v;break;case kOutput:fOutput=v;break;case kDice: if(v>0.5f)rollDice(); fDice=0.f; break;}
        fDirty=true;
    }
    void initState(uint32_t index, String& name, String& def) override {
        if(index==0){name="scope";def="";}
        else {name="presetnames";def=""; for(int i=0;i<6;i++){def+=kPresetNames[i]; if(i<5)def+=";";}}
    }
    void setState(const char* key, const char* value) override {
        (void)key; (void)value;
    }

    void run(const float** inputs, float** outputs, uint32_t frames) override {
        const float sr = getSampleRate();
        const int delSamps = (int)(fTijd*0.001f*sr) < kMaxDel ? (int)(fTijd*0.001f*sr) : kMaxDel-1;
        const int preSamps = (int)(fPredelay*0.001f*sr) < kMaxPre ? (int)(fPredelay*0.001f*sr) : kMaxPre-1;
        const float fb = fRuimte*0.72f;                 // feedback = ruimte-hoeveelheid
        const float wet = fRuimte;
        const float lpA = 1.f-expf(-2.f*M_PI*fDemp/sr); // demp = lowpass in feedback
        const float outG = powf(10.f, fOutput*0.05f);
        const float wMix = 0.35f;                        // vaste mix fractie v.d. feedloop als "reverb-tail"

        for (uint32_t i=0;i<frames;i++){
            float inL = inputs[0][i], inR = inputs[1][i];
            // predelay
            fPreL[fPreW]=inL; fPreR[fPreW]=inR;
            int preR = (fPreW - preSamps + kMaxPre)%kMaxPre;
            float pL=fPreL[preR], pR=fPreR[preR];
            fPreW=(fPreW+1)%kMaxPre;
            // delay+feedback met demp-filter (2 taps iets verspr = reverb-sfeer)
            int rd1=(fDelW - delSamps + kMaxDel)%kMaxDel;
            int rd2=(fDelW - (delSamps*61/100) + kMaxDel)%kMaxDel;   // tweede tap (0.61×) verdicht de staart
            float dL=fBufL[rd1]+0.5f*fBufL[rd2];
            float dR=fBufR[rd1]+0.5f*fBufR[rd2];
            fLpL += lpA*(dL-fLpL); fLpR += lpA*(dR-fLpR);
            fBufL[fDelW]=pL + fLpL*fb; fBufR[fDelW]=pR + fLpR*fb;
            fDelW=(fDelW+1)%kMaxDel;
            float wetL=dL*wet, wetR=dR*wet;
            // breedte: mid/side op nat deel
            float m=(wetL+wetR)*0.5f, s=(wetL-wetR)*0.5f*fBreedte;
            wetL=m+s; wetR=m-s;
            float oL=(inL*(1.f-wet*wMix) + wetL)*outG;
            float oR=(inR*(1.f-wet*wMix) + wetR)*outG;
            outputs[0][i]=oL; outputs[1][i]=oR;
            if (++fDecim>=3){ fDecim=0; if (fScopeN<kScopeLen) fScope[fScopeN++]=(oL+oR)*0.5f; }
        }
        if (fScopeN>=40){
            char buf[256]; int pos=0;
            for(uint32_t s=0;s<fScopeN && pos<230;++s) pos+=snprintf(buf+pos,sizeof(buf)-pos,"%.3f;",fScope[s]);
            buf[pos]=0; setState("scope",buf); fScopeN=0;
        }
    }
private:
    void rollDice(){
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kRuimte,0.1f+((fRnd>>8)%100)/100.f*0.7f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kTijd,80.f+((fRnd>>8)%100)/100.f*800.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kDemp,2000.f+((fRnd>>8)%100)/100.f*8000.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kBreedte,0.7f+((fRnd>>8)%100)/100.f*1.2f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kPredelay,((fRnd>>8)%100)/100.f*40.f);
    }
    float fDice = 0.f;
    unsigned fRnd = 998877;

    void applyPreset(int i){
        if(i<0)i=0; if(i>5)i=5;
        fPreset=(float)i;
        setParameterValue(kRuimte,kPresetParams[i][0]);
        setParameterValue(kTijd,kPresetParams[i][1]);
        setParameterValue(kDemp,kPresetParams[i][2]);
        setParameterValue(kBreedte,kPresetParams[i][3]);
        setParameterValue(kPredelay,kPresetParams[i][4]);
        setParameterValue(kOutput,kPresetParams[i][5]);
    }
    static const int kMaxDel = 96000*2;   // tot 2s @48k
    static const int kMaxPre = 4800;      // 100ms predelay
    float fRuimte=0.30f, fTijd=280.f, fDemp=6000.f, fBreedte=1.2f, fPredelay=12.f, fOutput=0.f, fPreset=0.f;
    float fBufL[kMaxDel], fBufR[kMaxDel];
    float fPreL[kMaxPre], fPreR[kMaxPre];
    float fLpL=0.f, fLpR=0.f;
    int fDelW=0, fPreW=0;
    static const uint32_t kScopeLen = 40;
    float fScope[40];
    uint32_t fScopeN=0;
    int fDecim=0;
    bool fDirty=true;

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RuimtePlugin)
};

Plugin* createPlugin(){ return new RuimtePlugin(); }
END_NAMESPACE_DISTRHO
