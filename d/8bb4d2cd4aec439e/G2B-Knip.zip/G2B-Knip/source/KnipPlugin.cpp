/*
 * G2B Knip — luider en breder zonder pieken: soft-clipper + plafond +
 * stereo-breedte + mix. Met presets die weten wat ze doen.
 * Stuurt een live golfvorm naar de UI (state "scope").
 */

#include "DistrhoPlugin.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>

START_NAMESPACE_DISTRHO

static const int kNumPrograms = 6;
// CLIP, CEIL(dB), BREEDTE(%), MIX(%), OUTPUT(dB)
static const float kProgramParams[kNumPrograms][5] = {
    { 35.0f, -1.0f, 110.0f, 100.0f, 0.0f },   // G2B — signature: luider, breed, strak
    { 45.0f, -1.5f, 100.0f, 100.0f, 0.0f },   // DEMBOW — hard en in je gezicht
    { 55.0f, -0.8f,  90.0f, 100.0f, 0.0f },   // DRILL — agressief, smaller
    { 30.0f, -2.0f, 125.0f, 100.0f, 0.0f },   // RNB — schoon, extra breed
    { 40.0f, -1.0f, 115.0f, 100.0f, 0.0f },   // HOUSE — punchy width
    { 38.0f, -1.2f, 120.0f, 100.0f, 0.0f },   // AFRO — warm en rond
};
static const char* kProgramNames[kNumPrograms] = {
    "G2B", "DEMBOW", "DRILL", "RNB", "HOUSE", "AFRO"
};

class KnipPlugin : public Plugin
{
public:
    enum Parameters {
        kClip = 0, kCeil, kWidth, kMix, kOutput, kPreset, kParameterCount
    };

    KnipPlugin()
        : Plugin(kParameterCount, kNumPrograms, 0),
          fClip(35.0f), fCeil(-1.0f), fWidth(110.0f), fMix(100.0f), fOut(0.0f),
          fScopeN(0), fDecim(0)
    {
        recalc();
    }

protected:
    const char* getLabel() const override { return "G2B Knip"; }
    const char* getDescription() const override
    {
        return "G2B Knip: soft-clipper + plafond + stereo-breedte — "
               "luider en breder zonder pieken. Met G2B-presets.";
    }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','K','n'); }

    void initParameter(uint32_t index, Parameter& parameter) override
    {
        parameter.hints = kParameterIsAutomatable;
        switch (index)
        {
        case kClip:
            parameter.name = "Clip"; parameter.symbol = "clip"; parameter.unit = "%";
            parameter.ranges = {0.0f, 100.0f, 35.0f}; break;
        case kCeil:
            parameter.name = "Ceiling"; parameter.symbol = "ceil"; parameter.unit = "dB";
            parameter.ranges = {-6.0f, 0.0f, -1.0f}; break;
        case kWidth:
            parameter.name = "Breedte"; parameter.symbol = "width"; parameter.unit = "%";
            parameter.ranges = {0.0f, 200.0f, 110.0f}; break;
        case kMix:
            parameter.name = "Mix"; parameter.symbol = "mix"; parameter.unit = "%";
            parameter.ranges = {0.0f, 100.0f, 100.0f}; break;
        case kOutput:
            parameter.name = "Output"; parameter.symbol = "output"; parameter.unit = "dB";
            parameter.ranges = {-6.0f, 6.0f, 0.0f}; break;
        case kPreset:
            parameter.name = "Preset"; parameter.symbol = "preset"; parameter.unit = "";
            parameter.ranges = {0.0f, 5.0f, 0.0f};
            parameter.hints = kParameterIsInteger;
            break;
        }
    }

    float getParameterValue(uint32_t index) const override
    {
        switch (index)
        {
        case kClip:   return fClip;
        case kCeil:   return fCeil;
        case kWidth:  return fWidth;
        case kMix:    return fMix;
        case kOutput: return fOut;
        case kPreset: return fPreset;
        }
        return 0.0f;
    }

    void setParameterValue(uint32_t index, float value) override
    {
        if (index == kPreset)
        {
            fPreset = value;
            applyPreset((int)value);
            return;
        }
        switch (index)
        {
        case kClip:   fClip = value; break;
        case kCeil:   fCeil = value; break;
        case kWidth:  fWidth = value; break;
        case kMix:    fMix = value; break;
        case kOutput: fOut = value; break;
        }
        recalc();
    }

    void initProgramName(uint32_t index, String& programName) override
    {
        programName = kProgramNames[index];
    }

    void loadProgram(uint32_t index) override
    {
        applyPreset((int)index);
        for (int i = 0; i < kParameterCount; ++i)
            setParameterValue(i, getParameterValue(i));
    }

    void activate() override { fScopeN = 0; }

    void run(const float** inputs, float** outputs, uint32_t frames) override
    {
        const float* inL = inputs[0];
        const float* inR = inputs[1];
        float* outL = outputs[0];
        float* outR = outputs[1];

        const float drive  = fDrive;    // 1..9
        const float ceil   = fCeilLin;  // lineair plafond
        const float w      = fWidthM;   // mid/side width
        const float mix    = fMixN;     // 0..1
        const float gain   = fOutGain;

        for (uint32_t i = 0; i < frames; ++i)
        {
            float l = inL[i], r = inR[i];

            // breedte via mid/side
            const float m = (l + r) * 0.5f;
            const float s = (l - r) * 0.5f * w;
            float wl = m + s, wr = m - s;

            // clip: drive + soft-clip + plafond
            wl = clipAt(wl * drive, ceil);
            wr = clipAt(wr * drive, ceil);

            outL[i] = (l * (1.0f - mix) + wl * mix) * gain;
            outR[i] = (r * (1.0f - mix) + wr * mix) * gain;
        }

        // scope: mono uitgang ~10x/sec naar UI
        for (uint32_t i = 0; i < frames; ++i)
        {
            if (++fDecim >= 3)
            {
                fDecim = 0;
                if (fScopeN < kScopeLen)
                    fScope[fScopeN++] = (outL[i] + outR[i]) * 0.5f;
            }
        }
        if (fScopeN >= 40)
        {
            char buf[256];
            int pos = 0;
            for (uint32_t s = 0; s < fScopeN && pos < 230; ++s)
                pos += std::snprintf(buf + pos, sizeof(buf) - pos, "%.3f;", fScope[s]);
            buf[pos] = '\0';
            setState("scope", buf);
            fScopeN = 0;
        }
    }

private:
    float fClip, fCeil, fWidth, fMix, fOut, fPreset = 0.0f;
    float fDrive, fCeilLin, fWidthM, fMixN, fOutGain;
    static const int kScopeLen = 96;
    float fScope[kScopeLen];
    uint32_t fScopeN, fDecim;

    void applyPreset(int i)
    {
        if (i < 0 || i >= kNumPrograms) return;
        const float* p = kProgramParams[i];
        fClip = p[0]; fCeil = p[1]; fWidth = p[2]; fMix = p[3]; fOut = p[4];
        recalc();
        // knoppen in de UI/host meebewegen
        setParameterValue(kClip, fClip);
        setParameterValue(kCeil, fCeil);
        setParameterValue(kWidth, fWidth);
        setParameterValue(kMix, fMix);
        setParameterValue(kOutput, fOut);
    }

    static inline float clipAt(float x, float ceil)
    {
        // soft-clip rond 'ceil': cubic knee, daarna hard af
        const float a = std::fabs(x);
        if (a <= ceil * 0.9f) return x;
        float y = x / ceil;
        y = std::tanh(y);
        y *= ceil;
        return y;
    }

    void recalc()
    {
        fDrive = 1.0f + (fClip / 100.0f) * 8.0f;
        fCeilLin = std::pow(10.0f, fCeil / 20.0f);
        fWidthM = fWidth / 100.0f;
        fMixN = fMix / 100.0f;
        fOutGain = std::pow(10.0f, fOut / 20.0f);
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(KnipPlugin)
};

Plugin* createPlugin() { return new KnipPlugin(); }

END_NAMESPACE_DISTRHO
