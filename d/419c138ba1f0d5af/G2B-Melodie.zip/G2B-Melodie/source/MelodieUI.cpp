/*
 * G2B Melodie — UI (NanoVG): 7 knoppen + preset-rij + DICE + AUTO + dark/light
 * + melodie-grid (16 stappen, hoogte = noot die echt klinkt).
 */

#include "DistrhoUI.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>

START_NAMESPACE_DISTRHO

static const int kNumPrograms = 6;
static const char* kProgramNames[kNumPrograms] = {
    "G2B", "DEMBOW", "DRILL", "RNB", "HOUSE", "AFRO"
};
static const char* kKeyNames[12] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};

class MelodieUI : public UI
{
public:
    MelodieUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[7]  = {0,0,0,0,0,0,0};
        static const float maxs[7]  = {5,11,1,2,1,0.5f,1};
        static const float defs[7]  = {0,0,0,1,0.35f,0.08f,0.8f};
        static const char* lbl[7]   = {"PATROON","KEY","SCALE","OCTAVE","TIMBRE","SWING","LEVEL"};
        std::memcpy(fMin,mins,sizeof(mins));
        std::memcpy(fMax,maxs,sizeof(maxs));
        std::memcpy(fValue,defs,sizeof(defs));
        std::memcpy(fLabel,lbl,sizeof(lbl));
        std::memset(fScope,0,sizeof(fScope));
        for(int i=0;i<16;i++)fDeg[i]=-1;
        fScopePos=0;fDrag=-1;fLastY=0;fProg=0;fStep=-1;fAuto=0;fLight=false;
    }
protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if(index<7)fValue[index]=value;
        else if(index==8)fAuto=value;
        else if(index==9)fProg=(int)(value+0.5f);
        repaint();
    }
    void stateChanged(const char* key, const char* value) override
    {
        if(std::strcmp(key,"scope")==0){
            const char* p=value;
            while(*p){
                char* end=nullptr;
                const float v=std::strtof(p,&end);
                if(end==p)break;
                fScope[fScopePos]=v;fScopePos=(fScopePos+1)%kScopeSize;
                p=(*end==';')?end+1:end;
            }
            repaint();
        } else if(std::strcmp(key,"step")==0){
            // "s:deg" — deg -1 = rust
            int s=-1,d=-1;
            if(std::sscanf(value,"%d:%d",&s,&d)==2){fStep=s;if(s>=0&&s<16)fDeg[s]=d;}
            else fStep=atoi(value);
            repaint();
        }
    }
    void onNanoDisplay() override
    {
        const float W=getWidth(),H=getHeight();
        // thema
        const Color bg   = fLight?Color(236,240,238):Color(13,15,14);
        const Color cell = fLight?Color(214,220,217):Color(24,28,27);
        const Color cellD= fLight?Color(190,199,194):Color(8,10,9);
        const Color txt  = fLight?Color(28,34,31):Color(232,236,234);
        const Color dim  = fLight?Color(110,124,116):Color(143,160,152);
        const Color dim2 = fLight?Color(140,152,145):Color(90,100,94);
        const Color edge = fLight?Color(196,204,200):Color(42,47,45);
        const Color knob = fLight?Color(224,229,226):Color(30,34,33);

        beginPath();rect(0,0,W,H);fillColor(bg);fill();
        fontSize(20.0f);textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(47,191,113);
        text(18.0f,22.0f,"G2B MELODIE",nullptr);
        fontSize(11.5f);fillColor(dim);
        text(18.0f,41.0f,"melodie-generator · altijd in key · dice = nieuwe hook",nullptr);

        // ☀/🌙 knopje naast titel
        {
            const float tx=W-40.0f,ty=46.0f,tw=26.0f,th=17.0f;
            beginPath();roundedRect(tx,ty,tw,th,4.0f);
            fillColor(cell);fill();strokeColor(edge);strokeWidth(1.0f);stroke();
            fontSize(10.0f);textAlign(ALIGN_CENTER|ALIGN_MIDDLE);fillColor(txt);
            text(tx+tw*0.5f,ty+th*0.5f,fLight?"🌙":"☀",nullptr);
        }

        // presets rechtsboven + DICE + AUTO
        float bx=W-14.0f;
        for(int i=kNumPrograms-1;i>=0;--i){
            const float bw=58.0f,bh=17.0f;
            bx-=bw+4.0f;
            const bool on=(i==fProg);
            beginPath();roundedRect(bx,12.0f,bw,bh,4.0f);
            if(on){fillColor(29,122,72);fill();}
            strokeColor(edge);strokeWidth(1.0f);stroke();
            fontSize(9.5f);textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor(on?Color(232,236,234):dim);
            text(bx+bw*0.5f,12.0f+bh*0.5f,kProgramNames[i],nullptr);
        }
        bx-=4.0f;
        { // AUTO
            const float bw=38.0f;bx-=bw+4.0f;
            beginPath();roundedRect(bx,12.0f,bw,17.0f,4.0f);
            if(fAuto>0.5f){fillColor(47,191,113);fill();}
            else{fillColor(cell);fill();}
            strokeColor(edge);strokeWidth(1.0f);stroke();
            fontSize(9.5f);textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor(fAuto>0.5f?Color(13,15,14):dim);
            text(bx+bw*0.5f,20.5f,"AUTO",nullptr);
        }
        { // DICE
            const float bw=26.0f;bx-=bw+4.0f;
            beginPath();roundedRect(bx,12.0f,bw,17.0f,4.0f);
            fillColor(cell);fill();strokeColor(edge);strokeWidth(1.0f);stroke();
            fontSize(11.0f);textAlign(ALIGN_CENTER|ALIGN_MIDDLE);fillColor(txt);
            text(bx+bw*0.5f,20.5f,"🎲",nullptr);
        }

        // melodie-grid: 16 kolommen, stiphoogte = degree die klonk
        const float gx=18.0f,gy=70.0f,gw=W-36.0f,gh=58.0f;
        beginPath();rect(gx,gy,gw,gh);fillColor(cellD);fill();
        strokeColor(edge);strokeWidth(1.0f);stroke();
        const float cw=gw/16.0f;
        for(int s=0;s<16;s++){
            const float x=gx+s*cw;
            if(s%4==0){ // beat-markering
                beginPath();rect(x,gy,1.0f,gh);fillColor(edge);fill();
            }
            if(fDeg[s]>=0){
                const float hy=gy+gh-6.0f-(fDeg[s]/9.0f)*(gh-12.0f);
                const bool now=(s==fStep);
                beginPath();circle(x+cw*0.5f,hy,now?5.0f:3.5f);
                fillColor(now?Color(232,236,234):Color(47,191,113));fill();
                beginPath();moveTo(x+cw*0.5f,hy);lineTo(x+cw*0.5f,gy+gh-4.0f);
                strokeColor(29,122,72);strokeWidth(1.0f);stroke();
            } else {
                beginPath();rect(x+cw*0.5f-1.5f,gy+gh-5.0f,3.0f,2.0f);
                fillColor(cell);fill();
            }
            if(s==fStep){ // now-kolom
                beginPath();rect(x+1.0f,gy+1.0f,cw-2.0f,gh-2.0f);
                strokeColor(47,191,113);strokeWidth(1.0f);stroke();
            }
        }

        // scope onder grid
        const float sx=18.0f,sy=136.0f,sw=W-36.0f,sh=34.0f;
        beginPath();rect(sx,sy,sw,sh);fillColor(cellD);fill();
        strokeColor(edge);strokeWidth(1.0f);stroke();
        beginPath();
        const float mid=sy+sh*0.5f;
        for(int i=0;i<kScopeSize-1;++i){
            const int i0=(fScopePos+i)%kScopeSize,i1=(fScopePos+i+1)%kScopeSize;
            const float x0=sx+(float)i/(kScopeSize-1)*sw,x1=sx+(float)(i+1)/(kScopeSize-1)*sw;
            float y0=mid-fScope[i0]*sh*0.45f,y1=mid-fScope[i1]*sh*0.45f;
            if(y0<sy+1)y0=sy+1;if(y0>sy+sh-1)y0=sy+sh-1;
            if(y1<sy+1)y1=sy+1;if(y1>sy+sh-1)y1=sy+sh-1;
            if(i==0)moveTo(x0,y0);else lineTo(x0,y0);lineTo(x1,y1);
        }
        strokeColor(47,191,113);strokeWidth(1.5f);stroke();

        // 7 knoppen
        const int n=7;
        const float step=(W-40.0f)/n;
        for(int i=0;i<n;++i){
            const float cx=20.0f+step*(i+0.5f),cy=220.0f,R=24.0f;
            const float norm=(fValue[i]-fMin[i])/(fMax[i]-fMin[i]);
            const float ang=-2.4f+norm*4.8f;
            beginPath();circle(cx,cy,R);fillColor(knob);fill();
            strokeColor(edge);strokeWidth(2.0f);stroke();
            beginPath();arc(cx,cy,R-4.0f,-2.4f-1.5708f,ang-1.5708f,CW);
            strokeColor(47,191,113);strokeWidth(3.0f);stroke();
            beginPath();moveTo(cx,cy);
            lineTo(cx+std::sin(ang)*(R-8.0f),cy-std::cos(ang)*(R-8.0f));
            strokeColor(txt);strokeWidth(3.0f);stroke();
            fontSize(9.5f);fillColor(dim);textAlign(ALIGN_CENTER|ALIGN_TOP);
            text(cx,cy+R+7.0f,fLabel[i],nullptr);
            fontSize(11.0f);fillColor(txt);
            char buf[24];
            if(i==0)std::snprintf(buf,sizeof(buf),"%s",kProgramNames[(int)fValue[0]<0?0:((int)fValue[0]>5?5:(int)fValue[0])]);
            else if(i==1)std::snprintf(buf,sizeof(buf),"%s",kKeyNames[((int)fValue[1]%12+12)%12]);
            else if(i==2)std::snprintf(buf,sizeof(buf),"%s",(int)fValue[2]==0?"minor":"major");
            else if(i==3)std::snprintf(buf,sizeof(buf),"%+d",(int)fValue[3]-1);
            else std::snprintf(buf,sizeof(buf),"%.0f %%",fValue[i]*100.0f);
            text(cx,cy+R+21.0f,buf,nullptr);
        }
        fontSize(10.0f);fillColor(dim2);textAlign(ALIGN_CENTER|ALIGN_BOTTOM);
        text(W*0.5f,H-7.0f,"stip = noot die klinkt · 🎲 = nieuwe hook · AUTO = muteert elke 4 bars",nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if(ev.button!=1)return false;
        const float W=getWidth();
        if(ev.press){
            // thema-knopje
            if(ev.pos.getX()>=W-40.0f&&ev.pos.getX()<=W-14.0f&&ev.pos.getY()>=46.0f&&ev.pos.getY()<=63.0f){
                fLight=!fLight;repaint();return true;
            }
            // presets + dice + auto (zelfde geometrie als draw)
            float bx=W-14.0f;
            for(int i=kNumPrograms-1;i>=0;--i){
                const float bw=58.0f,bh=17.0f;bx-=bw+4.0f;
                if(ev.pos.getX()>=bx&&ev.pos.getX()<=bx+bw&&ev.pos.getY()>=12.0f&&ev.pos.getY()<=12.0f+bh){
                    setParameterValue(9,(float)i);fProg=i;repaint();return true;
                }
            }
            bx-=4.0f;
            {const float bw=38.0f;bx-=bw+4.0f;
             if(ev.pos.getX()>=bx&&ev.pos.getX()<=bx+bw&&ev.pos.getY()>=12.0f&&ev.pos.getY()<=29.0f){
                 fAuto=fAuto>0.5f?0.f:1.f;setParameterValue(8,fAuto);repaint();return true;}}
            {const float bw=26.0f;bx-=bw+4.0f;
             if(ev.pos.getX()>=bx&&ev.pos.getX()<=bx+bw&&ev.pos.getY()>=12.0f&&ev.pos.getY()<=29.0f){
                 setParameterValue(7,1.0f);repaint();return true;}}
        }
        const float step=(W-40.0f)/7;
        if(ev.press){
            for(int i=0;i<7;++i){
                const float cx=20.0f+step*(i+0.5f),cy=220.0f;
                const float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
                if(dx*dx+dy*dy<=24.0f*24.0f+80.0f){fDrag=i;fLastY=ev.pos.getY();editParameter(i,true);return true;}
            }
        } else if(fDrag>=0){editParameter(fDrag,false);fDrag=-1;}
        return true;
    }
    bool onMotion(const MotionEvent& ev) override
    {
        if(fDrag<0)return false;
        const float dy=fLastY-ev.pos.getY();fLastY=ev.pos.getY();
        const float range=fMax[fDrag]-fMin[fDrag];
        float v=fValue[fDrag]+dy*range/200.0f;
        if(v<fMin[fDrag])v=fMin[fDrag];if(v>fMax[fDrag])v=fMax[fDrag];
        // integer params afronden
        if(fDrag<=3)v=std::floor(v+0.5f);
        fValue[fDrag]=v;setParameterValue(fDrag,v);repaint();return true;
    }
    bool onScroll(const ScrollEvent& ev) override
    {
        const float W=getWidth();const float step=(W-40.0f)/7;
        for(int i=0;i<7;++i){
            const float cx=20.0f+step*(i+0.5f),cy=220.0f;
            const float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
            if(dx*dx+dy*dy<=24.0f*24.0f+80.0f){
                const float range=fMax[i]-fMin[i];
                float v=fValue[i]+ev.delta.getY()*range/100.0f;
                if(i<=3)v=std::floor(v+0.5f);
                if(v<fMin[i])v=fMin[i];if(v>fMax[i])v=fMax[i];
                fValue[i]=v;editParameter(i,true);setParameterValue(i,v);editParameter(i,false);
                repaint();return true;
            }
        }
        return true;
    }
private:
    static const int kScopeSize=256;
    float fValue[7],fMin[7],fMax[7];
    const char* fLabel[7];
    float fScope[kScopeSize];int fScopePos;
    int fDeg[16];
    int fDrag;float fLastY;int fProg;int fStep;float fAuto;bool fLight;
    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MelodieUI)
};

UI* createUI(){return new MelodieUI();}
END_NAMESPACE_DISTRHO
