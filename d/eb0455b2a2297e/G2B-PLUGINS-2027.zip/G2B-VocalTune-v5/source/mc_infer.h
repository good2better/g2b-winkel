/* G2B mini-CREPE inference — eigen code, MIT.
   Plain-C++ forward pass, geen externe deps. Input: 1024 floats @22050Hz.
   Output: argmax-bin → f0 (FMIN*2^(bin/60)) + confidence. */
#pragma once
#include "minicrepe_weights.h"
#include <cmath>
#include <cstring>

static inline float mc_relu(float x) { return x > 0.f ? x : 0.f; }

/* conv1d same-pad: in[ic][L] * w[oc][ic][k] stride s pad k/2 → out[oc][Lo] */
template<int IC,int OC,int K,int S>
static void mc_conv(const float* in,int Lin,const float* w,const float* b,float* out)
{
    const int pad=K/2;
    const int Lo=(Lin+2*pad-K)/S+1;   /* torch: floor((L+2p-k)/s)+1 */
    for(int o=0;o<OC;++o){
        const float* wo=w+o*IC*K;
        for(int t=0;t<Lo;++t){
            float acc=b[o];
            const int base=t*S-pad;
            for(int c=0;c<IC;++c){
                const float* x=in+c*Lin; const float* wc=wo+c*K;
                for(int j=0;j<K;++j){
                    const int i=base+j;
                    if(i>=0&&i<Lin) acc+=x[i]*wc[j];
                }
            }
            out[o*Lo+t]=mc_relu(acc);
        }
    }
}
static inline void mc_dense(const float* in,int n,const float* w,const float* b,float* out,int m,bool relu)
{
    for(int j=0;j<m;++j){
        float acc=b[j];const float* wj=w+j*n;
        for(int i=0;i<n;++i)acc+=in[i]*wj[i];
        out[j]=relu?mc_relu(acc):acc;
    }
}
/* input: 1024 @22050 → f0 Hz (0 bij onvoiced), conf via out-param */
static float mc_pitch(const float* x1024,float& conf)
{
    static float l1[32*257],l2[48*65],l3[64*17],l4[96*9],flat[96*5];
    static float h1[256],logits[360],c1[64],c2[1];
    mc_conv<1,32,64,4>(x1024,1024,MC_W0,MC_B0,l1);     /* →257 */
    mc_conv<32,48,32,4>(l1,257,MC_W1,MC_B1,l2);       /* →65 */
    mc_conv<48,64,16,4>(l2,65,MC_W2,MC_B2,l3);        /* →17 */
    mc_conv<64,96,8,2>(l3,17,MC_W3,MC_B3,l4);         /* →9 */
    mc_conv<96,96,8,2>(l4,9,MC_W4,MC_B4,flat);        /* →5 */
    mc_dense(flat,480,MC_H1W,MC_H1B,h1,256,true);
    mc_dense(h1,256,MC_H2W,MC_H2B,logits,360,false);
    mc_dense(flat,480,MC_C1W,MC_C1B,c1,64,true);
    mc_dense(c1,64,MC_C2W,MC_C2B,c2,1,false);
    conf=1.f/(1.f+std::exp(-c2[0]));
    /* softmax-top + parabolische interp over 3 bins → sub-bin precisie */
    int bi=0; for(int i=1;i<360;++i) if(logits[i]>logits[bi]) bi=i;
    float dBin=0.f;
    if(bi>0&&bi<359){
        const float ym=logits[bi-1],y0=logits[bi],yp=logits[bi+1];
        const float den=ym-2.f*y0+yp;
        if(std::fabs(den)>1e-6f)dBin=0.5f*(ym-yp)/den;
    }
    return 32.703f*std::pow(2.f,(bi+dBin)/60.f);  /* 60 bins per octaaf (20 cent) */
}
