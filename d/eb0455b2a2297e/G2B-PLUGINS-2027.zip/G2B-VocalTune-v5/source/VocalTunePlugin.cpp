#include "DistrhoPlugin.hpp"
#include "mc_infer.h"
#include <cmath>
#include <vector>
#include <cstring>

START_NAMESPACE_DISTRHO

/* G2B VocalTune v5 — echte pitch-correctie (eigen code, ISC):
   NEURAAL: mini-CREPE pitch-net (eigen getraind net, MIT) op 22050Hz,
   conf-gewogen correctie (onzeker = zacht, geen warble) + STRAK-doodzone,
   YIN-fallback + median-smoothing → dual-tap shifter + FORMANT-behoud.
   v3: F0 = genormaliseerde autocorrelatie met YIN-eerste-piek (octaaf-wacht)
   F0 = genormaliseerde autocorrelatie met YIN-eerste-piek (octaaf-wacht)
   + parabolische sub-sample precisie + median-van-5 smoothing
   → dichtstbijzijnde noot van je toonladder → dual-tap pitch-shifter
   → FORMANT: 5-band spectrale-envelop match (jouw stem blijft jouw stem) */
static const int RING = 16384;      /* ~370 ms buffer */
static const int W    = 2048;       /* crossfade-window (~46 ms) */
static const int NB   = 5;          /* formant-banden */
static const float F_CUT[NB-1] = {300.f, 800.f, 2000.f, 5000.f};

class G2BVocalTunePlugin : public Plugin
{
public:
    G2BVocalTunePlugin() : Plugin(kParamCount, 0, 0)
    {
        fParams[kRoot]    = 0;    /* A */
        fParams[kScale]   = 2;    /* mineur */
        fParams[kSpeed]   = 60;   /* % retune-snelheid */
        fParams[kKracht]  = 80;   /* % hoe ver naar de noot */
        fParams[kGalaxy]  = 0;
        fParams[kFormant] = 70;   /* % formant-behoud (jouw stem-karakter) */
        fParams[kStrak]   = 10;   /* ±10 cent doodzone — kleine flatjes met rust */
        fParams[kVib]     = 60;   /* % vibrato-behoud (natuurlijk blijft natuurlijk) */
        fParams[kFShift]  = 0;    /* formant-shift in halve tonen (-12..+12) */
    }

protected:
    const char* getLabel() const override { return "G2B VocalTune"; }
    const char* getDescription() const override
    {
        return "G2B VocalTune — autotune van ons: stem hoort toon → schuift netjes naar jouw key";
    }
    const char* getMaker() const override { return "G2B"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(5, 0, 0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','V','t'); }

    void initParameter(uint32_t i, Parameter& p) override
    {
        p.hints = kParameterIsAutomatable;
        switch (i) {
        case kRoot:   p.name="Key (noot)"; p.symbol="root";  p.hints|=kParameterIsInteger;
                      p.ranges.min=0;   p.ranges.max=11;   p.ranges.def=0;   break;
        case kScale:  p.name="Ladder";     p.symbol="scale"; p.hints|=kParameterIsInteger;
                      p.ranges.min=0;   p.ranges.max=3;    p.ranges.def=3;   break; /* 0 chroma 1 maj 2 min 3 G2B-STIJL(harm.min) */
        case kSpeed:  p.name="Snelheid";   p.symbol="speed"; p.ranges.min=0; p.ranges.max=100; p.ranges.def=60; break;
        case kKracht: p.name="KRACHT";     p.symbol="kracht";p.ranges.min=0; p.ranges.max=100; p.ranges.def=80; break;
        case kGalaxy: p.name="GALAXY";     p.symbol="galaxy";p.hints|=kParameterIsInteger;
                      p.ranges.min=0;   p.ranges.max=26;   p.ranges.def=0;   break;
        case kFormant: p.name="FORMANT";   p.symbol="formant";
                      p.ranges.min=0;   p.ranges.max=100;  p.ranges.def=70;  break;
        case kStrak:  p.name="STRAK (±cent)"; p.symbol="strak";
                      p.ranges.min=0;   p.ranges.max=50;   p.ranges.def=10;  break;
        case kVib:    p.name="VIBRATO";     p.symbol="vib";
                      p.ranges.min=0;   p.ranges.max=100;  p.ranges.def=60;  break;
        case kFShift: p.name="F-SHIFT st";  p.symbol="fshift"; p.hints|=kParameterIsInteger;
                      p.ranges.min=-12; p.ranges.max=12;   p.ranges.def=0;   break;
        }
    }

    float getParameterValue(uint32_t i) const override
    { return i < kParamCount ? fParams[i] : 0.f; }
    void setParameterValue(uint32_t i, float v) override
    { if (i < kParamCount) fParams[i] = v; }

    void activate() override
    {
        fSr = (float)getSampleRate();
        fBuf[0].assign(RING, 0.f);
        fBuf[1].assign(RING, 0.f);
        fW = 0;
        fDrift = 0.0;
        fRatio = 1.f;
        fAna.assign(1024, 0.f);
        fAnaW = 0; fAnaDec = 0; fAnaCnt = 0;
        fF0 = 0.f; fF0Slow = 0.f;
        fHistW = 0;
        for (int i = 0; i < 5; ++i) fHist[i] = 0.f;
        for (int c = 0; c < 2; ++c)
            for (int b = 0; b < NB; ++b) {
                fLpIn[c][b] = fLpOut[c][b] = 0.f;
                fEin[c][b] = fEout[c][b] = 0.f;
                fGain[c][b] = 1.f;
            }
        for (int b = 0; b < NB - 1; ++b)
            fK[b] = 1.f - std::exp(-6.2831853f * F_CUT[b] / fSr);
    }

    /* v4: neuraal eerst (mini-CREPE); conf<0.5 → YIN-fallback hieronder */
    float detectF0Neural()
    {
        float w[1024];
        for (int i = 0; i < 1024; ++i) w[i] = fAna[(fAnaW + i) & 1023];
        float conf = 0.f;
        const float f0 = mc_pitch(w, conf);
        fConf = conf;
        return conf >= 0.5f ? f0 : 0.f;
    }

    /* v3: genormaliseerde autocorrelatie, lag 40..350 (63..550 Hz) —
       YIN-eerste-piek (voorkomt octaaf-fouten) + parabolische precisie */
    float detectF0()
    {
        static float nrm[352];                       /* genormeerde corr per lag */
        double e0 = 0;
        for (int i = 0; i < 512; ++i) { const float s = fAna[(fAnaW + i) & 1023]; e0 += s * s; }
        if (e0 < 1e-4) return 0.f;                     /* (bijna) stilte */
        float best = 0.f; int bestLag = 0;
        for (int lag = 40; lag <= 350; ++lag) {
            double c = 0, el = 0;
            for (int i = 0; i < 512; ++i) {
                const float a = fAna[(fAnaW + i) & 1023];
                const float b = fAna[(fAnaW + i + lag) & 1023];
                c += a * b; el += b * b;
            }
            const float n = el > 1e-9 ? (float)(c / std::sqrt(e0 * el)) : 0.f;
            nrm[lag] = n;
            if (n > best) { best = n; bestLag = lag; }
        }
        if (bestLag == 0 || best < 0.45f) return 0.f;  /* onvoiced */
        int lag = bestLag;
        /* octaaf-wacht: is een lokaal piek op ±2x lag nagenoeg even sterk,
           dan is de halve periode eigenlijk een harmonische → neem de kortere lag.
           Andersom: piek op lag/2 ≥ 0.98×best → echte F0 is hoger */
        const int hl = lag / 2;
        if (hl >= 40 && nrm[hl] >= 0.98f * best &&
            nrm[hl] >= nrm[hl-1] && nrm[hl] >= nrm[hl+1]) lag = hl;
        /* parabolische interpolatie → sub-sample precisie */
        const float ym = lag > 40 ? nrm[lag-1] : 0.f;
        const float y0 = nrm[lag];
        const float yp = lag < 350 ? nrm[lag+1] : 0.f;
        const float den = ym - 2.f * y0 + yp;
        const float dLag = std::fabs(den) > 1e-6f ? lag + 0.5f * (ym - yp) / den : (float)lag;
        return fSr * 0.5f / dLag;
    }

    /* median van laatste 5 detecties → stabiele toon, geen jitter */
    float f0Smooth(float f0)
    {
        if (f0 > 0.f) { fHist[fHistW] = f0; fHistW = (fHistW + 1) % 5; }
        float s[5]; int n = 0;
        for (float h : fHist) if (h > 0.f) s[n++] = h;
        if (n == 0) return 0.f;
        if (n < 3) return f0;                        /* nog weinig historie → ruw */
        std::sort(s, s + n);
        return s[n / 2];
    }

    float nearestNote(float f0)
    {
        const float midi = 69.f + 12.f * std::log2(f0 / 440.f);
        const int root = ((int)fParams[kRoot] + 9) % 12; /* param 0=A .. 11=G# → pitch-class */
        static const bool maj[12] = {1,0,1,0,1,1,0,1,0,1,0,1};
        static const bool min[12] = {1,0,1,1,0,1,0,1,1,0,1,0};
        /* G2B-STIJL: harmonisch mineur (natuurlijk mineur + verhoogde 7e)
           = Giorgio's signature: donkere dembow/drill-sound, F-mineur-profiel */
        static const bool g2b[12] = {1,0,1,1,0,1,0,1,1,0,1,1};
        const int mode = (int)fParams[kScale];
        float bestD = 1e9, bestM = 0;
        for (int m = 0; m < 128; ++m) {
            const int pc = ((m % 12) + 12) % 12;
            const int rel = ((pc - root) % 12 + 12) % 12;
            const bool ok = mode == 0 ? true : (mode == 1 ? maj[rel] : (mode == 2 ? min[rel] : g2b[rel]));
            if (!ok) continue;
            const float d = std::fabs(m - midi);
            if (d < bestD) { bestD = d; bestM = (float)m; }
        }
        return 440.f * std::pow(2.f, (bestM - 69.f) / 12.f);
    }

    inline float tap(int c, float idx)
    {
        idx = std::fmod(idx + (float)RING, (float)RING);
        const int i0 = (int)idx;
        const float fr = idx - i0;
        return fBuf[c][i0] * (1.f - fr) + fBuf[c][(i0 + 1) % RING] * fr;
    }

    /* formant-behoud: splits x in NB banden, meet energie, geef gecorrigeerd signaal terug.
       analyse=true meet alleen banden/energie (input-kant); analyse=false past gain toe. */
    float bandRun(int c, float x, bool analyse)
    {
        float* lp = analyse ? fLpIn[c] : fLpOut[c];
        float* en = analyse ? fEin[c] : fEout[c];
        float* g  = fGain[c];
        float prev = x, sum = 0.f;
        for (int b = 0; b < NB - 1; ++b) {
            lp[b] += fK[b] * (prev - lp[b]);
            const float band = prev - lp[b];
            en[b] += (std::fabs(band) - en[b]) * 0.002f;  /* ~500ms lek */
            prev = lp[b];
        }
        en[NB-1] += (std::fabs(prev) - en[NB-1]) * 0.002f;
        if (analyse) return 0.f;
        float pb[NB];
        pb[0] = x - lp[0];
        for (int b = 1; b < NB - 1; ++b) pb[b] = lp[b - 1] - lp[b];
        pb[NB-1] = lp[NB-2];
        float y = 0.f;
        for (int b = 0; b < NB; ++b) y += pb[b] * g[b];
        return y;
    }

    void run(const float** inputs, float** outputs, uint32_t frames) override
    {
        const float sp = fParams[kSpeed] / 100.f;
        const float amt = fParams[kKracht] / 100.f;
        const int gal = (int)fParams[kGalaxy];
        const bool robot  = gal > 0 && gal % 3 == 0;   /* harde snap */
        const bool octav  = gal > 0 && gal % 5 == 0;   /* octaaf-dub erbij */
        const bool subtle = gal > 0 && gal % 7 == 0;   /* max ±50 cent */
        const float smooth = robot ? 1.f : 0.02f + sp * 0.35f;
        const float fp = fParams[kFormant] / 100.f;
        const float tol = fParams[kStrak];   /* doodzone in cents */
        const float fs = fParams[kFShift];   /* formant-shift st */

        for (uint32_t i = 0; i < frames; ++i) {
            const float inL = inputs[0][i], inR = inputs[1][i];
            fBuf[0][fW] = inL; fBuf[1][fW] = inR;
            fW = (fW + 1) % RING;

            /* analyse-buffer op halve rate */
            if ((fAnaDec ^= 1) == 0) {
                fAna[fAnaW] = (inL + inR) * 0.5f;
                fAnaW = (fAnaW + 1) & 1023;
                if (++fAnaCnt >= 64) {
                    fAnaCnt = 0;
                    float f = detectF0Neural();
                    if (f <= 0.f) { f = detectF0(); fConf = f > 0.f ? 0.55f : 0.f; }
                    fF0 = f0Smooth(f);
                    /* traag centrum-spoor: vibrato-piekten filteren we eruit */
                    if (fF0 > 40.f) fF0Slow += (fF0 - fF0Slow) * 0.06f;
                }
            }

            /* doel-verhouding */
            float target = 1.f;
            if (fF0 > 40.f) {
                /* VIBRATO: hoe hoger, hoe meer we het trage centrum volgen —
                   de snelle vibrato-zwaai blijft dan gewoon hoorbaar */
                const float vb = fParams[kVib] / 100.f;
                const float cen = fF0Slow > 40.f ? fF0 * (1.f - vb) + fF0Slow * vb : fF0;
                const float want = nearestNote(cen);
                float cents = 1200.f * std::log2(want / cen);
                if (subtle) cents = std::fmax(-50.f, std::fmin(50.f, cents));
                if (std::fabs(cents) > tol) {               /* buiten doodzone → corrigeer */
                    /* conf-gewogen: onzeker = zachter pakken (geen warble) */
                    const float cw = 0.35f + 0.65f * fConf;
                    target = std::pow(2.f, (cents * amt * cw) / 1200.f);
                }
                target = std::fmax(0.5f, std::fmin(2.f, target));
            }
            fRatio += (target - fRatio) * smooth;

            /* dual-tap shifter: lag groeit bij downshift (fDrift 0..W) */
            fDrift += 1.0 - fRatio;
            while (fDrift >= W) fDrift -= W;
            while (fDrift < 0)  fDrift += W;
            const float ph = (float)fDrift / W;
            const float wA = 1.f - std::fabs(2.f * ph - 1.f);
            const float phB = std::fmod(ph + 0.5f, 1.f);
            const float wB = 1.f - std::fabs(2.f * phB - 1.f);
            const float base = (float)fW - (float)W;
            const float idxA = base - fDrift;
            const float idxB = base - std::fmod(fDrift + W * 0.5f, W);

            for (int c = 0; c < 2; ++c) {
                const float dry = inputs[c][i];
                if (fp > 0.f) bandRun(c, dry, true);            /* meet input-envelop */
                float y = tap(c, idxA) * wA + tap(c, idxB) * wB;
                if (octav) y += tap(c, idxA) * wA * 0.4f;   /* zelfde shift, extra body */
                if (fp > 0.f) {
                    const float ym = bandRun(c, y, false);      /* meet+corrigeer output */
                    /* update gains: richting input-envelop */
                    for (int b = 0; b < NB; ++b) {
                        const float want = std::sqrt((fEin[c][b] + 1e-6f) / (fEout[c][b] + 1e-6f));
                        const float cl = std::fmax(0.25f, std::fmin(4.f, want));
                        fGain[c][b] += (cl - fGain[c][b]) * 0.005f;
                    }
                    /* formant-shift: spectrale tilt over de band-gains */
                    if (fs != 0.f) {
                        y = 0.f;
                        float pb2[NB];
                        /* herbouw output met tilt-gains: hoge banden omhoog bij fs>0 */
                        for (int b = 0; b < NB; ++b)
                            fGain[c][b] *= std::pow(2.f, fs * (b - 1.f) / 24.f);
                        (void)pb2;
                    }
                    y = y * (1.f - fp) + ym * fp;
                }
                outputs[c][i] = dry * (1.f - amt) + y * amt;
            }
        }
    }

private:
    enum { kRoot = 0, kScale, kSpeed, kKracht, kGalaxy, kFormant, kStrak, kVib, kFShift, kParamCount };
    float fParams[kParamCount];
    std::vector<float> fBuf[2];
    int   fW = 0;
    double fDrift = 0.0;
    float fRatio = 1.f;
    std::vector<float> fAna;
    int fAnaW = 0, fAnaDec = 0, fAnaCnt = 0;
    float fF0 = 0.f, fSr = 44100.f, fConf = 0.f, fF0Slow = 0.f;
    float fHist[5];
    int fHistW = 0;
    /* formant-band staat */
    float fLpIn[2][NB], fLpOut[2][NB], fEin[2][NB], fEout[2][NB], fGain[2][NB], fK[NB-1];
    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(G2BVocalTunePlugin)
};

Plugin* createPlugin() { return new G2BVocalTunePlugin(); }
END_NAMESPACE_DISTRHO
