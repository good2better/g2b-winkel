/*
 * G2B VocalTune — UI (NanoVG): 9 draaiknoppen + key/ladder uitlees + skins.
 */

#include "DistrhoUI.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

static const float G2BSK[8][7][3]={
    {{13,15,14},{23,26,25},{232,236,234},{100,110,103},{42,47,45},{47,191,113},{29,122,72}},
    {{14,14,22},{22,22,34},{230,232,255},{110,110,150},{40,40,58},{120,110,255},{70,60,170}},
    {{10,20,22},{16,30,32},{225,245,245},{95,130,130},{30,55,55},{40,200,210},{20,120,130}},
    {{24,14,20},{34,20,28},{250,230,240},{150,105,125},{60,38,50},{255,110,180},{180,60,120}},
    {{228,230,232},{240,242,244},{30,34,38},{105,112,118},{205,210,214},{40,140,100},{20,100,70}},
    {{18,10,10},{28,16,16},{240,225,220},{140,100,95},{55,35,32},{200,80,60},{130,45,35}},
    {{14,14,10},{22,22,16},{245,240,220},{120,115,95},{50,48,35},{230,190,80},{160,125,45}},
    {{12,14,20},{20,24,32},{235,240,250},{105,115,135},{36,44,58},{80,160,255},{45,110,200}}};
static inline Color g2bsk(int sk,int r){if(sk<0)sk=0;if(sk>7)sk=7;const float*c=G2BSK[sk][r];return Color((int)c[0],(int)c[1],(int)c[2]);}

START_NAMESPACE_DISTRHO

static const char* kKeys[12] = {"A","A#","B","C","C#","D","D#","E","F","F#","G","G#"};
static const char* kScales[4] = {"CHROMA","MAJEUR","MINEUR","G2B-STIJL"};

class VocalTuneUI : public UI
{
public:
    VocalTuneUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[9] = {0, 0, 0, 0, 0, 0, 0, 0, -12};
        static const float maxs[9] = {11, 3, 100, 100, 26, 100, 50, 100, 12};
        static const float defs[9] = {0, 3, 60, 80, 0, 70, 10, 60, 0};
        static const char* lbl[9] = {"KEY","LADDER","SNELHEID","KRACHT","GALAXY",
                                     "FORMANT","STRAK","VIBRATO","F-SHIFT"};
        std::memcpy(fMin, mins, sizeof(mins));
        std::memcpy(fMax, maxs, sizeof(maxs));
        std::memcpy(fValue, defs, sizeof(defs));
        std::memcpy(fLabel, lbl, sizeof(lbl));
        fDrag = -1; fLastY = 0.0f; fLight = 0;
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if (index < 9) fValue[index] = value;
        repaint();
    }

    void onNanoDisplay() override
    {
        const float W = getWidth(), H = getHeight();
        beginPath(); rect(0, 0, W, H); fillColor(g2bsk(fLight,0)); fill();

        fontSize(20.0f); textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
        fillColor(47, 191, 113);
        text(18.0f, 22.0f, "G2B VOCALTUNE", nullptr);
        fontSize(11.5f); fillColor(143, 160, 152);
        text(18.0f, 41.0f, "neurale autotune — jouw stem, jouw stijl", nullptr);

        /* key/ladder uitlees */
        {
            char buf[48];
            std::snprintf(buf, sizeof buf, "KEY %s  ·  %s",
                          kKeys[(int)fValue[0] % 12], kScales[(int)fValue[1] % 4]);
            beginPath(); roundedRect(18.0f, 56.0f, 240.0f, 26.0f, 5.0f);
            fillColor(g2bsk(fLight,1)); fill();
            strokeColor(42,47,45); strokeWidth(1.0f); stroke();
            fontSize(13.0f); textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
            fillColor(232, 236, 234);
            text(28.0f, 69.0f, buf, nullptr);
        }
        /* skin knop */
        {
            const float tx = W - 40.0f;
            beginPath(); roundedRect(tx, 34.0f, 26.0f, 17.0f, 4.0f);
            fillColor(g2bsk(fLight,1)); fill();
            strokeColor(42,47,45); strokeWidth(1.0f); stroke();
            fontSize(10.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor(g2bsk(fLight,2));
            text(tx+13.0f, 42.5f, fLight>0 ? "\xF0\x9F\x8C\x99" : "\xE2\x98\x80", nullptr);
        }

        /* 9 knoppen: 5 boven, 4 onder (gecentreerd) */
        for (int i = 0; i < 9; ++i)
        {
            const int rij = i / 5, kol = i % 5;
            const float step = (W - 40.0f) / 5;
            const float cx = 20.0f + step * (kol + 0.5f) + (rij == 1 ? step * 0.5f : 0.0f);
            const float cy = rij == 0 ? 150.0f : 265.0f;
            const float R  = 30.0f;
            const float norm = (fValue[i] - fMin[i]) / (fMax[i] - fMin[i]);
            const float ang = -2.4f + norm * 4.8f;

            beginPath(); circle(cx, cy, R);
            fillColor(30, 34, 33); fill();
            strokeColor(42, 47, 45); strokeWidth(2.0f); stroke();
            beginPath();
            arc(cx, cy, R - 4.0f, -2.4f - 1.5708f, ang - 1.5708f, CW);
            strokeColor(47, 191, 113); strokeWidth(3.0f); stroke();
            beginPath();
            moveTo(cx, cy);
            lineTo(cx + std::sin(ang) * (R - 8.0f),
                   cy - std::cos(ang) * (R - 8.0f));
            strokeColor(232, 236, 234); strokeWidth(3.0f); stroke();

            fontSize(10.5f); fillColor(143, 160, 152);
            textAlign(ALIGN_CENTER | ALIGN_TOP);
            text(cx, cy + R + 8.0f, fLabel[i], nullptr);
            fontSize(11.5f); fillColor(232, 236, 234);
            char buf[24];
            if (i == 0) std::snprintf(buf, sizeof(buf), "%s", kKeys[(int)fValue[i] % 12]);
            else if (i == 1) std::snprintf(buf, sizeof(buf), "%s", kScales[(int)fValue[i] % 4]);
            else if (i == 8) std::snprintf(buf, sizeof(buf), "%+.0f st", fValue[i]);
            else if (i == 6) std::snprintf(buf, sizeof(buf), "±%.0f ct", fValue[i]);
            else if (i == 4) std::snprintf(buf, sizeof(buf), "%d", (int)fValue[i]);
            else std::snprintf(buf, sizeof(buf), "%.0f %%", fValue[i]);
            text(cx, cy + R + 23.0f, buf, nullptr);
        }

        fontSize(10.5f); fillColor(90, 100, 94);
        textAlign(ALIGN_CENTER | ALIGN_BOTTOM);
        text(W * 0.5f, H - 8.0f,
             "STRAK = doodzone ±cents · G2B-STIJL = jouw eigen ladder", nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if (ev.button != 1) return false;
        const float W = getWidth();
        if (ev.press)
        {
            if (ev.pos.getX() >= W-40.0f && ev.pos.getX() <= W-14.0f &&
                ev.pos.getY() >= 34.0f && ev.pos.getY() <= 51.0f)
            { fLight = (fLight+1)%8; repaint(); return true; }
            const float step = (W - 40.0f) / 5;
            for (int i = 0; i < 9; ++i)
            {
                const int rij = i / 5, kol = i % 5;
                const float cx = 20.0f + step * (kol + 0.5f) + (rij == 1 ? step * 0.5f : 0.0f);
                const float cy = rij == 0 ? 150.0f : 265.0f;
                const float dx = ev.pos.getX() - cx;
                const float dy = ev.pos.getY() - cy;
                if (dx*dx + dy*dy <= 30.0f*30.0f + 70.0f)
                {
                    fDrag = i; fLastY = ev.pos.getY();
                    editParameter(i, true);
                    return true;
                }
            }
        }
        else if (fDrag >= 0)
        {
            editParameter(fDrag, false);
            fDrag = -1;
        }
        return true;
    }

    bool onMotion(const MotionEvent& ev) override
    {
        if (fDrag < 0) return false;
        const float dy = fLastY - ev.pos.getY();
        fLastY = ev.pos.getY();
        const float range = fMax[fDrag] - fMin[fDrag];
        float v = fValue[fDrag] + dy * range / 200.0f;
        if (v < fMin[fDrag]) v = fMin[fDrag];
        if (v > fMax[fDrag]) v = fMax[fDrag];
        fValue[fDrag] = v;
        setParameterValue(fDrag, v);
        repaint();
        return true;
    }

    bool onScroll(const ScrollEvent& ev) override
    {
        const float W = getWidth();
        const float step = (W - 40.0f) / 5;
        for (int i = 0; i < 9; ++i)
        {
            const int rij = i / 5, kol = i % 5;
            const float cx = 20.0f + step * (kol + 0.5f) + (rij == 1 ? step * 0.5f : 0.0f);
            const float cy = rij == 0 ? 150.0f : 265.0f;
            const float dx = ev.pos.getX() - cx;
            const float dy = ev.pos.getY() - cy;
            if (dx*dx + dy*dy <= 30.0f*30.0f + 70.0f)
            {
                const float range = fMax[i] - fMin[i];
                float v = fValue[i] + ev.delta.getY() * range / 100.0f;
                if (v < fMin[i]) v = fMin[i];
                if (v > fMax[i]) v = fMax[i];
                fValue[i] = v;
                editParameter(i, true);
                setParameterValue(i, v);
                editParameter(i, false);
                repaint();
                return true;
            }
        }
        return true;
    }

private:
    float fValue[9], fMin[9], fMax[9];
    const char* fLabel[9];
    int fDrag;
    float fLastY;
    int fLight;

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalTuneUI)
};

UI* createUI() { return new VocalTuneUI(); }

END_NAMESPACE_DISTRHO
