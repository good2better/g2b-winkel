#pragma once
struct OSItem{const char*name;int root;int len;const float*data;};
static const OSItem OS_ITEMS[]={
};
static const int OS_COUNT=0;
