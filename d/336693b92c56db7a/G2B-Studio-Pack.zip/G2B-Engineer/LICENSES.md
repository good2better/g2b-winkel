# Licenties — G2B Engineer (Regel 1)

Alles open source en 100% commercieel te gebruiken:

| Pakket | Licentie | Waarvoor |
|---|---|---|
| FastAPI | MIT | web-backend |
| uvicorn | BSD-3 | server |
| numpy / scipy | BSD-3 | DSP-rekenwerk |
| soundfile | BSD-3 | WAV lezen/schrijven |
| librosa | ISC | analyse (spectrum/loudness-input) |
| pyloudnorm | MIT | LUFS-meting (EBU R128) |
| python-reapy | MIT | brug naar REAPER (ReaScript API) |
| python-multipart | Apache-2.0 | uploads |

**REAPER zelf** is closed-source betaald ($60 discounted na de gratis
proef) — dat is een tool die de gebruiker zélf installeert, geen
onderdeel van deze app, dus geen licentie-conflict met Regel 1.
De door Engineer gebruikte plugins in REAPER (ReaEQ, ReaComp,
ReaLimit) zijn ingebouwde Cockos-effecten — gratis bij REAPER.
