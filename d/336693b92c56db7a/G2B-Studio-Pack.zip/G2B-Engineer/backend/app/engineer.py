"""De Engineer — zet het plan om in echte REAPER-acties.

plan()      = meten + uitleg (werkt zonder REAPER; de dry-run die de
              gebruiker eerst ziet)
execute()   = bouwt het project in REAPER: tracks, volumes, pans,
              ReaEQ unmask-dips, master-keten (ReaEQ+ReaComp+ReaLimit),
              en rendert 2-pass zodat de master echt op stijl-LUFS uitkomt.
"""
from __future__ import annotations

import time
from pathlib import Path

from . import analyzer, bridge
from .styles import STYLES, get_style

RENDER_DIR: Path | None = None


def init(render_dir: Path):
    global RENDER_DIR
    RENDER_DIR = render_dir
    render_dir.mkdir(parents=True, exist_ok=True)


def plan(style_key: str = "schoon") -> dict:
    """Meet + leg uit wat de Engineer gaat doen. Geen REAPER nodig."""
    st = get_style(style_key)
    stems = list(analyzer.STEMS.values())
    if len(stems) < 2:
        raise ValueError("Upload eerst minstens 2 stems.")
    gains, lines = analyzer.plan_balance(stems)
    dips, dlines = analyzer.plan_unmask(stems)
    pans, plines = analyzer.plan_pans(stems)
    lines += dlines + plines
    fixes, flines = analyzer.plan_autofix(stems)
    lines += flines
    polish, polines = analyzer.plan_polish(stems)
    lines += polines
    adj, targets = analyzer.plan_reference(stems,
                                           analyzer.REFERENCE, lines)
    if targets.get("lufs"):
        st = dict(st, lufs=targets["lufs"])
    lines.append(
        f"🎚 Master-keten ({st['label']}): highpass {st['hpf']}Hz, "
        f"air +{st['air_db']}dB @ {st['air_freq']}Hz, glue-comp, "
        f"limiter plafond {st['ceiling_db']}dB → doel "
        f"{st['lufs']} LUFS.")
    return {"stems": stems, "gains": gains, "dips": dips, "pans": pans,
            "ref_adj": adj, "targets": targets, "fixes": fixes,
            "polish": polish, "style": st, "lines": lines}


def _apply_master(st: dict, ref_adj: dict, fixes: dict,
                  targets: dict, lines: list[str]):
    """Master-keten op de master-track: ReaEQ → ReaComp → ReaLimit
    → eigen G2B Glans-plugin (breedte>1.5kHz + extra air)."""
    eq = bridge.add_fx(-1, "ReaEQ")
    if eq >= 0:
        ok1 = bridge.eq_band(-1, eq, 1, "highpass", st["hpf"], 0.0)
        ok2 = bridge.eq_band(-1, eq, 2, "highshelf", st["air_freq"],
                             st["air_db"], 0.7)
        b = 3
        for name, a in ref_adj.items():
            lo, hi = analyzer.BAND_RANGE[name]
            freq = (lo * hi) ** 0.5
            bridge.eq_band(-1, eq, b, "band", freq, a["db"], 1.2)
            b += 1
            if b > 6:
                break
        lines.append(f"🎚 ReaEQ op master: highpass {st['hpf']}Hz" +
                     ("" if ok1 else " (handmatig checken)") +
                     f", air +{st['air_db']}dB @{st['air_freq']}Hz" +
                     ("" if ok2 else " (handmatig checken)") +
                     (f", {len(ref_adj)} referentie-bandjes" if ref_adj
                      else "") + ".")
    comp = bridge.add_fx(-1, "ReaComp")
    if comp >= 0:
        bridge.fx_set_param_by_name(-1, comp, "ratio", st["comp_ratio"])
        bridge.fx_set_normalized(-1, comp, "attack", 0.25)
        bridge.fx_set_normalized(-1, comp, "release", 0.45)
        lines.append(f"🧤 ReaComp glue-comp (ratio {st['comp_ratio']}:1).")
    # eigen G2B-plugin: breedte alleen boven de split + extra air
    jsfx = bridge.install_jsfx()
    if jsfx:
        g = bridge.add_fx(-1, "JS:" + jsfx)
        if g >= 0:
            widen = fixes.get("widen")
            refw = targets.get("width", 1.0)
            bridge.jsfx_param(g, 0, fixes.get("air_extra", 0.0))
            bridge.jsfx_param(g, 1, max(widen or 1.0, refw,
                                      st["width"]))
            bridge.jsfx_param(g, 2, 1500.0)
            lines.append("✨ G2B Glans (eigen plugin): breedte alleen "
                         "boven 1.5kHz" +
                         (" + extra air." if fixes.get("air_extra")
                          else "."))
    lim = bridge.add_fx(-1, "ReaLimit")
    if lim >= 0:
        bridge.fx_set_param_by_name(-1, lim, "ceiling",
                                    st["ceiling_db"])
        bridge.fx_set_param_by_name(-1, lim, "brickwall",
                                    st["ceiling_db"])
        lines.append(f"🧱 ReaLimit: plafond {st['ceiling_db']} dB.")
        return lim
    return -1


def execute(style_key: str = "schoon", fresh: bool = True) -> dict:
    """Voer het plan uit in REAPER en render 2-pass naar stijl-LUFS."""
    ok, status = bridge.connected()
    if not ok:
        raise bridge.BrugError(status)
    p = plan(style_key)
    st = p["style"]
    lines = list(p["lines"])
    lines.insert(0, f"🔌 REAPER {status}")

    if fresh:
        bridge.new_project()
        lines.append("📄 Nieuw REAPER-project geopend.")

    bpms = [s["bpm"] for s in p["stems"] if s.get("bpm", 0) > 40]
    if bpms:
        bpm = sorted(bpms)[len(bpms) // 2]
        try:
            bridge.set_tempo(bpm)
            lines.append(f"⏱ Projecttempo gezet op {bpm:.0f} BPM.")
        except Exception:
            pass

    stem_track: dict[str, int] = {}
    for s in p["stems"]:
        g = p["gains"].get(s["id"], 0.0)
        if s.get("peak_db", -99) > -0.3:
            g -= 3.0  # geclipte stem extra terugtrekken
        pan = p["pans"].get(s["id"], 0.0)
        idx = bridge.import_stem(s["path"], s["name"], g, pan)
        stem_track[s["id"]] = idx

    # unmask-dips als échte ReaEQ op de verliezers
    per_stem: dict[str, list[dict]] = {}
    for d in p["dips"]:
        per_stem.setdefault(d["stem"], []).append(d)
    for sid, ds in per_stem.items():
        idx = stem_track[sid]
        eq = bridge.add_fx(idx, "ReaEQ")
        if eq < 0:
            continue
        for i, d in enumerate(ds[:4], start=1):
            freq = (d["lo"] * d["hi"]) ** 0.5
            bridge.eq_band(idx, eq, i, "band", freq, -2.5, 1.3)

    # rol-poets als échte ReaEQ: highpass op de vloer + nudges
    for sid, pol in p["polish"].items():
        idx = stem_track[sid]
        eq = bridge.add_fx(idx, "ReaEQ")
        if eq < 0:
            continue
        b = 1
        if pol["hpf"] > 30:
            bridge.eq_band(idx, eq, b, "highpass", pol["hpf"], 0.0)
            b += 1
        for band, db in pol["nudges"][:2]:
            lo, hi = analyzer.BAND_RANGE[band]
            freq = (lo * hi) ** 0.5
            bridge.eq_band(idx, eq, b, "band", freq, db, 1.1)
            b += 1
            if b > 4:
                break

    lim = _apply_master(st, p["ref_adj"], p["fixes"],
                        p["targets"], lines)
    return _render_2pass(st, lim, lines, "G2B-master")


def _render_2pass(st: dict, lim: int, lines: list[str],
                  name: str = "G2B-master", max_passes: int = 3) -> dict:
    """SMAAK-LOOP: render → meet → limiter bijsturen → opnieuw,
    tot het doel binnen ±0.5 LUFS zit (max max_passes rondes)."""
    out = ""
    a = {"lufs": -99.0, "peak_db": 0.0}
    for p in range(1, max_passes + 1):
        pat = name if p == max_passes else f"{name}_pass{p}"
        out = bridge.render_to(str(RENDER_DIR), pat)
        a = analyzer.analyze_file(out)
        need = st["lufs"] - a["lufs"]
        if abs(need) <= 0.5:
            lines.append(f"🎯 Pass {p}: {a['lufs']} LUFS — op smaak "
                         f"(doel {st['lufs']}).")
            break
        lines.append(f"📊 Pass {p}: {a['lufs']} LUFS gemeten "
                     f"(doel {st['lufs']}) — bijsturen {need:+.1f} dB.")
        if lim >= 0:
            bridge.fx_set_param_by_name(-1, lim, "gain", need)
            bridge.fx_set_param_by_name(-1, lim, "threshold",
                                        st["ceiling_db"] - max(need, 0))
    lines.append(f"✅ Klaar: {Path(out).name} — {a['lufs']} LUFS, "
                 f"piek {a['peak_db']} dB, stijl {st['label']}.")
    if bridge.save_project_template():
        lines.append("💾 Project ook opgeslagen als REAPER-template — "
                     "in REAPER: File → Project templates → G2B-Engineer.")
    return {"out": out, "lufs": a["lufs"], "peak": a["peak_db"],
            "lines": lines}


def _apply_stem_eq(stem_track: dict, p: dict):
    """Unmask-dips + rol-poets als échte ReaEQ-bandjes per stem."""
    per_stem: dict[str, list[dict]] = {}
    for d in p["dips"]:
        per_stem.setdefault(d["stem"], []).append(d)
    for sid, ds in per_stem.items():
        idx = stem_track[sid]
        eq = bridge.add_fx(idx, "ReaEQ")
        if eq < 0:
            continue
        for i, d in enumerate(ds[:4], start=1):
            freq = (d["lo"] * d["hi"]) ** 0.5
            bridge.eq_band(idx, eq, i, "band", freq, -2.5, 1.3)
    for sid, pol in p["polish"].items():
        idx = stem_track[sid]
        eq = bridge.add_fx(idx, "ReaEQ")
        if eq < 0:
            continue
        b = 1
        if pol["hpf"] > 30:
            bridge.eq_band(idx, eq, b, "highpass", pol["hpf"], 0.0)
            b += 1
        for band, db in pol["nudges"][:2]:
            lo, hi = analyzer.BAND_RANGE[band]
            freq = (lo * hi) ** 0.5
            bridge.eq_band(idx, eq, b, "band", freq, db, 1.1)
            b += 1
            if b > 4:
                break


def execute_arrange(style_key: str = "schoon") -> dict:
    """🏗 BOUW TRACK: arrangement (intro→buildup→drop→outro) + mix +
    master in één gang, in REAPER."""
    ok, status = bridge.connected()
    if not ok:
        raise bridge.BrugError(status)
    p = plan(style_key)
    st = p["style"]
    lines = list(p["lines"])
    lines.insert(0, f"🔌 REAPER {status}")

    bpms = [s["bpm"] for s in p["stems"] if s.get("bpm", 0) > 40]
    bpm = sorted(bpms)[len(bpms) // 2] if bpms else 120.0
    arr, alines = analyzer.plan_arrangement(p["stems"], bpm)
    lines = lines[:1] + alines + lines[1:]

    bridge.new_project()
    lines.append("📄 Nieuw REAPER-project geopend.")
    try:
        bridge.set_tempo(bpm)
        lines.append(f"⏱ Projecttempo gezet op {bpm:.0f} BPM.")
    except Exception:
        pass

    # één track per stem, items gepland op de tijdlijn
    stem_track: dict[str, int] = {}
    for s in p["stems"]:
        idx = bridge.new_track()
        g = p["gains"].get(s["id"], 0.0)
        if s.get("peak_db", -99) > -0.3:
            g -= 3.0
        bridge.set_track_props(idx, s["name"], g,
                               p["pans"].get(s["id"], 0.0))
        stem_track[s["id"]] = idx
    placed = 0
    for item in arr["schedule"]:
        bridge.place_media(stem_track[item["stem"]],
                           next(s["path"] for s in p["stems"]
                                if s["id"] == item["stem"]),
                           item["start"])
        placed += 1
    lines.append(f"🏗 {placed} items gepland op de tijdlijn "
                 "(intro → drop → outro).")

    _apply_stem_eq(stem_track, p)
    lim = _apply_master(st, p["ref_adj"], p["fixes"],
                        p["targets"], lines)
    return _render_2pass(st, lim, lines, "G2B-track")
