"""Brug naar REAPER — via python-reapy (MIT), praat met ReaScript.

Draait REAPER niet of is de brug niet ingesteld → connect() geeft een
duidelijke NL-fout met wat de gebruiker moet doen. Alle andere calls
gooien BrugError met uitleg; de app blijft altijd bruikbaar voor
meten + plan (die werken ook zonder REAPER).
"""
from __future__ import annotations

import time
from pathlib import Path


class BrugError(Exception):
    """Fout bij het praten met REAPER — boodschap is in gewoon NL."""


def _rpr():
    try:
        import reapy
        return reapy.reascript_api
    except Exception as e:  # niet geinstalleerd / niet gekoppeld
        raise BrugError(
            "REAPER-brug niet bereikbaar. Start REAPER en controleer "
            "dat de installatie is gelukt (START-ENGINEER.bat doet "
            "reapy.configure_reaper()). Technisch: " + str(e))


def connect() -> tuple[bool, str]:
    """Registreer de brug éénmalig in REAPER. Werkt het beste als
    REAPER dicht is; daarna openen = verbonden."""
    try:
        import reapy
        # False = niet zoeken naar een draaiend REAPER-proces —
        # gewoon de standaard resource-map gebruiken (werkt áltijd,
        # óók als REAPER dicht of open is)
        reapy.config.configure_reaper(detect_portable_install=False)
        ini = Path.home() / "AppData/Roaming/REAPER/reaper.ini"
        ok = ini.exists() and "2307" in ini.read_text(
            encoding="utf-8", errors="ignore")
        if not ok:
            return False, ("koppelen lukte niet — reaper.ini heeft de "
                           "web-poort niet. Gebruik CHECK BRUG voor "
                           "details.")
        if _reaper_running():
            return True, ("brug gekoppeld — REAPER is open: sluit REAPER "
                          "helemaal en open weer, dan ververs deze "
                          "pagina")
        return True, ("brug gekoppeld — open REAPER en ververs "
                      "deze pagina")
    except Exception as e:
        return False, str(e)


def _reaper_running() -> bool:
    """Is er een reaper.exe-proces? (Windows tasklist; elders False)"""
    try:
        import subprocess
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq reaper.exe"],
            capture_output=True, text=True, timeout=5).stdout.lower()
        return "reaper.exe" in out
    except Exception:
        return False


def _reaper_exe() -> str | None:
    """Zoek reaper.exe op bekende plekken (normale install)."""
    import glob
    kandidaten = [
        r"C:\Program Files\REAPER (x64)\reaper.exe",
        r"C:\Program Files\REAPER\reaper.exe",
        r"C:\Program Files (x86)\REAPER\reaper.exe",
    ]
    kandidaten += glob.glob(
        str(Path.home() / "**/reaper.exe"), recursive=False)
    for k in kandidaten:
        if k and Path(k).exists():
            return k
    # fallback: zoek in PATH
    try:
        import shutil
        w = shutil.which("reaper") or shutil.which("reaper.exe")
        if w:
            return w
    except Exception:
        pass
    return None


def _repair_reascript_registration() -> bool:
    """Maakt de ReaScript-registratie in reaper-kb.ini actueel.

    Na verplaatsen/verwijderen van de app-map wijzen oude
    'activate_reapy_server'-regels naar weggegooide .venv's →
    REAPER kan de brug-server dan nooit starten. Hier verwijderen
    we alle oude regels en zetten we één regel naar het huidige
    reapy-script + bijpassende extstate.
    """
    import reapy
    import random
    import string

    resdir = Path.home() / "AppData/Roaming/REAPER"
    resdir.mkdir(parents=True, exist_ok=True)
    kb = resdir / "reaper-kb.ini"
    ext = resdir / "reaper-extstate.ini"
    site_pkgs = Path(reapy.__file__).parent.parent.resolve()
    scripts_dir = resdir / "Scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)

    # Eigen activate-script met expliciete site-packages + fout-log —
    # crasht hij, dan schrijft hij de échte error naar g2b_brug_status.txt
    status_file = resdir / "g2b_brug_status.txt"
    status_file.unlink(missing_ok=True)  # oude fout weg
    own_script = scripts_dir / "g2b_activate.py"
    own_script.write_text(
        "import sys, traceback, pathlib\n"
        "sys.path.insert(0, {!r})\n"
        "_res = pathlib.Path.home() / 'AppData/Roaming/REAPER/"
        "g2b_brug_status.txt'\n"
        "try:\n"
        "    import reapy\n"
        "    from reapy.tools.network import Server\n"
        "    SERVER = Server(2306)\n"
        "    reapy.set_ext_state('reapy', 'server_port', 2306)\n"
        "    _res.write_text('server draait', encoding='utf-8')\n"
        "    def loop():\n"
        "        try:\n"
        "            SERVER.accept()\n"
        "        except Exception:\n"
        "            pass\n"          # afgebroken test-verbinding negeren
        "        try:\n"
        "            reqs = SERVER.get_requests()\n"
        "            res = SERVER.process_requests(reqs)\n"
        "            SERVER.send_results(res)\n"
        "        except Exception:\n"
        "            pass\n"          # lopende request nooit laten vallen
        "        reapy.defer(loop)\n"
        "    loop()\n"
        "    reapy.at_exit(reapy.delete_ext_state, 'reapy',"
        " 'server_port')\n"
        "except Exception:\n"
        "    _res.write_text('FOUT:\\n' + traceback.format_exc(),"
        " encoding='utf-8')\n"
        "    raise\n".format(str(site_pkgs).replace("\\", "/")),
        encoding="utf-8")
    script = own_script

    code = "RS" + "".join(random.choice(string.ascii_letters + string.digits)
                          for _ in range(40))
    # 1) reaper-kb.ini: oude SCR-regels weg, verse regel erbij
    lines = kb.read_text(encoding="utf-8", errors="ignore").splitlines() \
        if kb.exists() else []
    lines = [l for l in lines
             if "activate_reapy_server" not in l.lower()
             and "g2b_activate" not in l.lower()]
    lines.append(
        'SCR 4 0 {} "Custom: g2b_activate.py" {}'.format(
            code, str(script).replace("/", "\\")))
    kb.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # 2) reaper-extstate.ini: [reapy] activate_reapy_server="_RS<code>"
    try:
        import configparser
        cfg = configparser.ConfigParser()
        if ext.exists():
            cfg.read(ext, encoding="utf-8")
        if not cfg.has_section("reapy"):
            cfg.add_section("reapy")
        cfg.set("reapy", "activate_reapy_server", '"_{}"'.format(code))
        with open(ext, "w", encoding="utf-8") as f:
            cfg.write(f)
    except Exception:
        return False

    # 3) Scripts/__startup.lua — start de brug-server automatisch bij
    # elke REAPER-start, ZONDER de trage web-interface (poort 2307).
    try:
        scripts = resdir / "Scripts"
        scripts.mkdir(parents=True, exist_ok=True)
        lua = (
            "-- G2B Engineer: start de reapy-brug automatisch\n"
            "local target = \"_{}\"\n"
            "local t0 = reaper.time_precise()\n"
            "local function try()\n"
            "  local cmd = reaper.NamedCommandLookup(target)\n"
            "  if cmd ~= 0 then reaper.Main_OnCommand(cmd, 0); "
            "return end\n"
            "  if reaper.time_precise() - t0 < 90 then "
            "reaper.defer(try) end\n"
            "end\n"
            "reaper.defer(try)\n"
        ).format(code)
        (scripts / "__startup.lua").write_text(lua, encoding="utf-8")
    except Exception:
        return False
    return True


def fix_bridge() -> tuple[bool, list[str]]:
    """Volautomatisch: sluit REAPER, koppel brug, start REAPER,
    wacht en test de verbinding. Geeft NL-stappen terug."""
    import subprocess
    log: list[str] = []

    # 1) REAPER sluiten (overschrijft anders de ini bij afsluiten)
    if _reaper_running():
        log.append("REAPER was open — ik sluit hem")
        try:
            subprocess.run(["taskkill", "/IM", "reaper.exe", "/F"],
                           capture_output=True, timeout=10)
            time.sleep(1.5)
        except Exception as e:
            log.append(f"sluiten mislukte: {e}")
    else:
        log.append("REAPER was al dicht")

    # 2) brug registreren (werkt nu altijd, zonder proces-detectie)
    try:
        import reapy
        reapy.config.configure_reaper(detect_portable_install=False)
        log.append("brug geregistreerd in reaper.ini")
    except Exception as e:
        log.append(f"registreren mislukte: {e}")
        return False, log

    # 2b) ReaScript-pad repareren (verwijderde .venv's = kapotte regels)
    if _repair_reascript_registration():
        log.append("script-registratie ververst naar deze install")
    else:
        log.append("script-registratie verversen mislukte")

    # 3) REAPER weer openen — ini wordt nu pas geladen
    exe = _reaper_exe()
    if not exe:
        log.append("reaper.exe niet gevonden — open REAPER zelf even")
        return False, log
    try:
        subprocess.Popen([exe], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
        log.append("REAPER gestart — als er een venster "
                   "'Still Evaluating' verschijnt: klik die knop "
                   "aan (dat is de gratis proefversie)")
    except Exception as e:
        log.append(f"openen mislukte: {e} — open REAPER zelf")
        return False, log

    # 4) wachten tot de brug echt leeft (dist-api op poort 2306)
    log.append("wachten op verbinding...")
    for _ in range(48):  # ~60 sec — eval-venster kan even duren
        ok, _msg = connected()
        if ok:
            log.append("VERBONDEN — de brug werkt")
            return True, log
        time.sleep(1.25)
    log.append("nog geen verbinding — staat het venster "
               "'Still Evaluating' nog open? Klik die knop, "
               "daarna F5 in deze app")
    return False, log


def diagnose() -> list[str]:
    """Checkt elke schakel van de brug; geeft NL-regels terug."""
    import reapy
    lines: list[str] = []
    lines.append("REAPER draait nu" if _reaper_running()
                 else "REAPER draait nu NIET")
    # 1) is reaper.ini geschreven? (resource-map + csurf-webinterface)
    ini = None
    for cand in (Path.home() / "AppData/Roaming/REAPER/reaper.ini",
                 Path.home() / "AppData/Roaming/REAPER/reaper.ini"):
        if cand.exists():
            ini = cand
            break
    if ini is None:
        lines.append("reaper.ini niet gevonden — is REAPER ooit "
                     "opgestart?")
        return lines
    txt = ini.read_text(encoding="utf-8", errors="ignore").lower()
    if "csurf_" in txt and "2307" in txt:
        lines.append("OK: web-poort 2307 staat in reaper.ini")
    else:
        lines.append("MISSEND: web-poort niet in reaper.ini — "
                     "brug nog niet gekoppeld (of REAPER heeft de "
                     "instellingen overschreven toen hij sloot)")
    if "pythonlibdll64" in txt:
        lines.append("OK: python voor ReaScripts staat in reaper.ini")
    else:
        lines.append("MISSEND: python-regel niet in reaper.ini")
    # 2) leeft de web-interface al? (alleen als REAPER open + ini geladen)
    web_up = False
    try:
        from urllib.request import urlopen
        urlopen("http://localhost:2307", timeout=1)
        lines.append("OK: REAPER-web-interface leeft (poort 2307)")
        web_up = True
    except Exception:
        if _reaper_running():
            lines.append("REAPER is open maar poort 2307 doet niets — "
                         "de ini-wijziging was er nog niet toen REAPER "
                         "startte: sluit REAPER, klik KOPPEL, open "
                         "REAPER weer")
        else:
            lines.append("poort 2307 nog niet bereikbaar (normaal als "
                         "REAPER dicht is)")
    if not web_up:
        return lines

    # 3) leeft de brug-server al? (poort 2306 — onafhankelijk van web)
    try:
        import socket
        s = socket.create_connection(("localhost", 2306), timeout=1)
        s.close()
        lines.append("OK: brug-server leeft op poort 2306")
        if _manual_client():
            lines.append("OK: directe verbinding gemaakt — alles werkt")
            return lines
    except Exception:
        lines.append("brug-server (2306) nog niet aan — de brug-start "
                     "in REAPER is nog niet gelopen")
    startup = (Path.home() / "AppData/Roaming/REAPER/Scripts"
               / "__startup.lua")
    if startup.exists():
        lines.append("OK: auto-start-script staat in REAPER")
    else:
        lines.append("MISSEND: auto-start-script — klik FIX BRUG AUTO")
    # echte fout uit REAPER lezen als de server crashte
    st = Path.home() / "AppData/Roaming/REAPER/g2b_brug_status.txt"
    if st.exists():
        inhoud = st.read_text(encoding="utf-8", errors="ignore").strip()
        if inhoud and "draait" not in inhoud:
            lines.append("FOUT uit REAPER-python:")
            lines.append(inhoud[-800:])
    return lines


def _drop_client() -> None:
    """Gooi de gecachte reapy-client weg — na een REAPER-herstart is
    die dood (lege reply → JSONDecodeError) en moet hij opnieuw."""
    try:
        from reapy.tools.network import machines
        for k in list(getattr(machines, "CLIENTS", {})):
            machines.CLIENTS.pop(k, None)
        machines.CLIENT = None
    except Exception:
        pass


def _manual_client() -> bool:
    """Verbind reapy direct met de brug-server op poort 2306 —
    zonder de web-interface (die bij sommige pc's time-out geeft)."""
    import importlib
    import reapy
    import socket
    try:
        s = socket.create_connection(("localhost", 2306), timeout=1)
        s.close()
    except Exception:
        return False
    _drop_client()
    try:
        from reapy.tools.network import client, machines
        cl = client.Client(2306, "localhost")
        machines.CLIENTS["localhost"] = cl
        machines.CLIENTS[None] = cl
        machines.CLIENT = cl
        importlib.reload(reapy.reascript_api)
        return hasattr(reapy.reascript_api, "EnumProjects")
    except Exception:
        return False


def _probe_project() -> str | None:
    """Projectnaam als de brug echt antwoordt, anders None."""
    import reapy
    pr = reapy.Project()
    return pr.name or "(naamloos project)"


def connected() -> tuple[bool, str]:
    """True als we REAPER kunnen bereiken + korte status voor de UI."""
    for _ in range(2):
        try:
            name = _probe_project()
            return True, f"verbonden — project: {name}"
        except Exception:
            # dode/lege verbinding → verse socket op 2306 proberen
            if not _manual_client():
                break
    return False, ("REAPER draait (nog) niet — open REAPER "
                   "en ververs deze pagina")


def new_project():
    """Leeg het huidige project — zelfde effect als 'File: New' maar
    zónder de 'Save unsaved project?'-dialoog die elke run blokkeerde."""
    r = _rpr()
    # tracks achterstevoren wissen (neemt items mee), geen popups
    for i in range(int(r.CountTracks(0)) - 1, -1, -1):
        r.DeleteTrack(r.GetTrack(0, i))
    r.SetEditCurPos(0.0, False, False)
    time.sleep(0.2)


def _project():
    import reapy
    return reapy.Project()


def count_tracks() -> int:
    r = _rpr()
    return int(r.CountTracks(0))


def set_tempo(bpm: float):
    """Zet het REAPER-projecttempo (werkt niet als REAPER het blokkeert)."""
    r = _rpr()
    r.SetCurrentBPM(0, float(bpm), False)


def import_stem(path: str, name: str, volume_db: float = 0.0,
                pan: float = 0.0) -> int:
    """Importeer een WAV als nieuwe track. Geeft het track-index."""
    r = _rpr()
    before = count_tracks()
    # cursor naar 0, mode 1 = nieuw spoor aanmaken
    r.SetEditCurPos(0.0, False, False)
    r.InsertMedia(str(Path(path)), 1)
    time.sleep(0.15)
    after = count_tracks()
    idx = after - 1  # de nieuwste track onderaan
    if after <= before:
        raise BrugError(f"Kon {name} niet in REAPER laden.")
    tr = r.GetTrack(0, idx)
    r.GetSetMediaTrackInfo_String(tr, "P_NAME", name, True)
    vol = 10 ** (volume_db / 20.0)
    r.SetMediaTrackInfo_Value(tr, "D_VOL", vol)
    r.SetMediaTrackInfo_Value(tr, "D_PAN", pan)
    return idx


def set_track_volume(idx: int, db: float):
    r = _rpr()
    tr = r.GetTrack(0, idx)
    r.SetMediaTrackInfo_Value(tr, "D_VOL", 10 ** (db / 20.0))


def set_track_pan(idx: int, pan: float):
    r = _rpr()
    tr = r.GetTrack(0, idx)
    r.SetMediaTrackInfo_Value(tr, "D_PAN", pan)


def _get_track(idx: int):
    r = _rpr()
    return r.GetTrack(0, idx) if idx >= 0 else r.GetMasterTrack(0)


def add_fx(track_idx: int, fx_name: str) -> int:
    """Voeg FX toe op track (-1 = master). Geeft fx-index of -1."""
    r = _rpr()
    tr = _get_track(track_idx)
    fx = r.TrackFX_AddByName(tr, fx_name, False, -1)
    return int(fx)


def fx_param_index(track_idx: int, fx_idx: int, needle: str) -> int | None:
    """Vind parameter-index op deel van de naam (case-insensitive)."""
    r = _rpr()
    tr = _get_track(track_idx)
    n = int(r.TrackFX_GetNumParams(tr, fx_idx))
    needle = needle.lower()
    best = None
    for i in range(n):
        # paramnaam staat op index 4 van de tuple (reapy-conventie)
        name = str(r.TrackFX_GetParamName(tr, fx_idx, i, "", 2048)[4])
        if needle in name.lower():
            best = i  # laatste match wint (bv. post-gain vangt we)
    return best


def fx_set_param_by_name(track_idx: int, fx_idx: int, needle: str,
                         value: float) -> bool:
    r = _rpr()
    tr = _get_track(track_idx)
    i = fx_param_index(track_idx, fx_idx, needle)
    if i is None:
        return False
    # veel FX-params zijn genormaliseerd 0..1; EQ/limiet gebruiken
    # echte eenheden → probeer direct, val terug op genormaliseerd
    r.TrackFX_SetParam(tr, fx_idx, i, value)
    return True


def fx_set_normalized(track_idx: int, fx_idx: int, needle: str,
                      norm: float) -> bool:
    """Zet een parameter als 0..1 fractie van zijn eigen bereik."""
    r = _rpr()
    tr = _get_track(track_idx)
    i = fx_param_index(track_idx, fx_idx, needle)
    if i is None:
        return False
    res = r.TrackFX_GetParam(tr, fx_idx, i, 0.0, 0.0)
    lo, hi = res[-2:]  # min,max = laatste twee elementen
    r.TrackFX_SetParam(tr, fx_idx, i, lo + norm * (hi - lo))
    return True


def eq_band(track_idx: int, fx_idx: int, band_nr: int, btype: str,
            freq: float, gain_db: float, q: float = 1.0) -> bool:
    """Zet een ReaEQ-band. Bandparams heten bv. 'Band 1 Gain (dB)'.
    btype: 'lowshelf','highshelf','band','highpass','lowpass',
           'notch' — mapped op ReaEQ's type-dropdown."""
    tr = _get_track(track_idx)
    r = _rpr()
    n = int(r.TrackFX_GetNumParams(tr, fx_idx))
    base = f"band {band_nr}"
    found = {}
    types = {"lowshelf": 0, "band": 3, "highshelf": 1, "highpass": 7,
             "lowpass": 8, "notch": 5}  # ReaEQ dropdown-volgorde (ongeveer)
    for i in range(n):
        nm = str(r.TrackFX_GetParamName(tr, fx_idx, i, "", 2048)[4]).lower()
        if base in nm:
            for key in ("freq", "gain", "q", "type", "enable"):
                if key in nm:
                    found[key] = i
    if "freq" not in found or "gain" not in found:
        return False
    if "enable" in found:
        r.TrackFX_SetParam(tr, fx_idx, found["enable"], 1.0)
    if "type" in found and btype in types:
        r.TrackFX_SetParam(tr, fx_idx, found["type"],
                           float(types[btype]))
    if "q" in found:
        r.TrackFX_SetParam(tr, fx_idx, found["q"], q)
    r.TrackFX_SetParam(tr, fx_idx, found["freq"], freq)
    r.TrackFX_SetParam(tr, fx_idx, found["gain"], gain_db)
    return True


def new_track() -> int:
    """Nieuwe lege track achteraan; geeft zijn index."""
    r = _rpr()
    r.Main_OnCommand(40001, 0)  # Track: Insert new track
    return int(r.CountTracks(0)) - 1


def set_track_props(idx: int, name: str | None = None,
                    gain_db: float | None = None,
                    pan: float | None = None):
    """Naam/volume(dB)/pan(-1..1) van een track zetten."""
    r = _rpr()
    tr = r.GetTrack(0, idx)
    if name is not None:
        r.GetSetMediaTrackInfo_String(tr, "P_NAME", name, True)
    if gain_db is not None:
        r.SetMediaTrackInfo_Value(tr, "D_VOL", 10 ** (gain_db / 20.0))
    if pan is not None:
        r.SetMediaTrackInfo_Value(tr, "D_PAN", float(pan))


def place_media(track_idx: int, path: str, pos_sec: float):
    """Plaats een audiofile als item op track_idx op pos_sec."""
    r = _rpr()
    tr = r.GetTrack(0, track_idx)
    r.SetOnlyTrackSelected(tr)
    r.SetEditCurPos(0, float(pos_sec), False, False)
    r.InsertMedia(str(path), 0)  # 0 = voeg toe op geselecteerde track


def insert_midi_track(path: str, name: str = "ChordLab",
                      instrument: str = "") -> int:
    """Nieuwe track + .mid als MIDI-item erin (+ optioneel VSTi erop).
    ChordLab-brug: akkoorden komen zo rechtstreeks in je project.
    Geeft de track-index terug."""
    r = _rpr()
    idx = new_track()
    set_track_props(idx, name)
    tr = _get_track(idx)
    r.SetOnlyTrackSelected(tr)
    r.SetEditCurPos(0, 0.0, False, False)
    # InsertMedia opent een .mid als echt MIDI-item (noten bewerkbaar).
    r.InsertMedia(str(path), 0)
    if instrument:
        add_fx(idx, instrument)
    return idx


def install_jsfx() -> str:
    """Kopieer de eigen G2B-JSFX-plugin naar REAPER's Effects-map.
    JSFX = REAPER's gratis ingebouwde plugin-taal — 100% eigen code,
    Regel 1 OK. Geeft de naam terug om mee te laden, of '' bij falen."""
    try:
        r = _rpr()
        src = Path(__file__).parent / "jsfx" / "g2b_glans"
        eff = Path(r.GetResourcePath()) / "Effects" / "g2b"
        eff.mkdir(parents=True, exist_ok=True)
        tgt = eff / "g2b_glans"
        if (not tgt.exists()) or tgt.read_text() != src.read_text():
            tgt.write_text(src.read_text(encoding="utf-8"),
                           encoding="utf-8")
        return "g2b/g2b_glans"
    except Exception:
        return ""


def jsfx_param(fx_idx: int, slider_nr: int, value: float):
    """Zet een JSFX-slider (track -1 = master). Waarde = echte slider."""
    tr = _get_track(-1)
    r = _rpr()
    r.TrackFX_SetParam(tr, fx_idx, int(slider_nr), float(value))


def _unlink_zacht(path: Path, tries: int = 15, pause: float = 0.4) -> None:
    """Verwijderen met geduld — Windows/REAPER houdt WAV's soms even vast
    (WinError 32). Als het echt niet kan, gewoon verder: overschrijven
    lukt bij de render zelf meestal alsnog."""
    if not path.exists():
        return
    for _ in range(tries):
        try:
            path.unlink()
            return
        except PermissionError:
            time.sleep(pause)
        except FileNotFoundError:
            return


def render_to(out_dir: str, pattern: str, timeout: int = 120) -> str:
    """Render het project met huidige render-instellingen."""
    r = _rpr()
    r.GetSetProjectInfo_String(0, "RENDER_FILE", str(out_dir), True)
    r.GetSetProjectInfo_String(0, "RENDER_PATTERN", pattern, True)
    r.GetSetProjectInfo(0, "RENDER_BOUNDSFLAG", 1, True)   # hele project
    r.GetSetProjectInfo(0, "RENDER_CHANNELS", 2, True)     # stereo
    out = Path(out_dir) / f"{pattern}.wav"
    _unlink_zacht(out)
    # 42230 = Render met laatste instellingen + venster automatisch
    # sluiten — REAPER 7; zo klikt de gebruiker nergens op.
    # (oudere REAPER: terugvallen op 41824, die het venster opent)
    try:
        r.Main_OnCommand(42230, 0)
    except Exception:
        r.Main_OnCommand(41824, 0)
    t0 = time.time()
    while time.time() - t0 < timeout:
        if out.exists() and out.stat().st_size > 1000:
            time.sleep(0.5)
            return str(out)
        time.sleep(0.5)
    raise BrugError("Render duurde te lang — check REAPER-venster.")


def save_project_template(name: str = "G2B-Engineer") -> str | None:
    """Sla het huidige REAPER-project op als template
    (File → Project templates). Best-effort — mag nooit falen."""
    try:
        r = _rpr()
        resdir = Path(r.GetResourcePath())
        tdir = resdir / "ProjectTemplates"
        tdir.mkdir(parents=True, exist_ok=True)
        dest = tdir / f"{name}.RPP"
        r.Main_SaveProjectEx(0, str(dest), 0)
        return str(dest)
    except Exception:
        return None
