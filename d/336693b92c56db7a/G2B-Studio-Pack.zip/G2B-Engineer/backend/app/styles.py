"""Stijl-presets voor de master — jouw genres als doel.

Elke stijl definieert een doel (LUFS, lucht/glans, breedte, sub-behoud)
dat de Engineer nastreeft op de master-keten. Waardes zijn bewust
conservatief: liever subtiel goed dan hard mis.
"""

STYLES = {
    "schoon": {
        "label": "Schoon & Glans (G2B-handtekening)",
        "desc": "Zijn default: strak schoon + air. Werkt voor alles.",
        "lufs": -9.0,          # modern loud, streaming-proof
        "hpf": 25,             # master highpass (rumble eruit)
        "air_freq": 9500, "air_db": 2.5,
        "width": 1.15,         # subtiele extra breedte bovenin
        "comp_ratio": 2.0,     # ReaComp glue
        "ceiling_db": -1.0,
    },
    "drill": {
        "label": "Drill",
        "desc": "Sub zwaar en strak; 808 voorop; donker met scherpe rand.",
        "lufs": -8.0,
        "hpf": 20,             # sub zo diep mogelijk behouden
        "air_freq": 9000, "air_db": 2.0,
        "width": 1.05,         # laag mono, boven subtiel
        "comp_ratio": 2.5,
        "ceiling_db": -1.0,
    },
    "amapiano": {
        "label": "Amapiano / Kwayana",
        "desc": "Log drum voorop, warm en breed, veel lucht.",
        "lufs": -9.0,
        "hpf": 28,
        "air_freq": 10000, "air_db": 3.0,
        "width": 1.25,
        "comp_ratio": 2.0,
        "ceiling_db": -1.0,
    },
    "rnb": {
        "label": "R&B",
        "desc": "Warm en rond, zachte transiënten, ruimtelijk.",
        "lufs": -10.0,
        "hpf": 25,
        "air_freq": 9000, "air_db": 2.0,
        "width": 1.25,
        "comp_ratio": 1.5,
        "ceiling_db": -1.0,
    },
    "dancehall": {
        "label": "Dancehall / Bubbling",
        "desc": "Percussie voorop, veel beweging links-rechts.",
        "lufs": -9.0,
        "hpf": 25,
        "air_freq": 9500, "air_db": 2.5,
        "width": 1.20,
        "comp_ratio": 2.0,
        "ceiling_db": -1.0,
    },
}

# ---------------------------------------------------------------- eigen presets
# De gebruiker kan zijn eigen stijl opslaan (bv. "Giorgio Glans"); die
# landen in storage/presets.json en doen overal mee zoals ingebouwde stijlen.
import json
from pathlib import Path

_PRESET_FILE = Path(__file__).resolve().parents[1] / "storage" / "presets.json"
_TUNEABLE = ("lufs", "hpf", "air_freq", "air_db", "width",
             "comp_ratio", "ceiling_db")


def _load_user():
    try:
        return json.loads(_PRESET_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_user(data: dict):
    try:
        _PRESET_FILE.parent.mkdir(parents=True, exist_ok=True)
        _PRESET_FILE.write_text(json.dumps(data, indent=1),
                                encoding="utf-8")
    except OSError:
        pass


def all_styles() -> dict:
    """Ingebouwde + eigen presets samen (eigen krijgen id 'eigen:<naam>')."""
    out = dict(STYLES)
    for name, params in _load_user().items():
        key = f"eigen:{name}"
        st = dict(STYLES["schoon"])
        st.update({k: params[k] for k in _TUNEABLE if k in params})
        st["label"] = f"{name} (eigen preset)"
        st["desc"] = "Jouw eigen opgeslagen stijl."
        out[key] = st
    return out


def get_style(key: str) -> dict:
    return all_styles().get(key, STYLES["schoon"])


def save_preset(name: str, params: dict) -> dict:
    name = name.strip()[:32]
    if not name:
        return {"error": "Geef een naam mee."}
    data = _load_user()
    data[name] = {k: params[k] for k in _TUNEABLE if k in params}
    _save_user(data)
    return {"ok": True, "key": f"eigen:{name}"}


def delete_preset(name: str) -> dict:
    data = _load_user()
    if name in data:
        del data[name]
        _save_user(data)
        return {"ok": True}
    return {"error": "Preset niet gevonden."}
