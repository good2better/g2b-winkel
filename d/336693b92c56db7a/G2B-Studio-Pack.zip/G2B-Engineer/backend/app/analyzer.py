"""Hersenen van G2B Engineer — meten & beslissen, geen AI.

Meet stems en referentietracks (loudness, piek, bandenergie, rol) en
vertaalt dat naar een concreet plan in gewoon Nederlands. De brug
(bridge.py) voert het plan uit in REAPER. Alles lokaal, Regel 1.
"""
from __future__ import annotations

import shutil
import uuid
from pathlib import Path

import librosa
import numpy as np
import pyloudnorm as pyln
import soundfile as sf

SR = 44100
STEMS_DIR: Path | None = None

# (lo, hi, naam) — zelfde banden als Sound Lab
BANDS = [(0, 60, "sub"), (60, 120, "laag"), (120, 250, "laagmid"),
         (250, 500, "mid"), (500, 2000, "highmid"), (2000, 6000, "hoog"),
         (6000, 12000, "air")]

# rol → (NL-label, gain-offset t.o.v. anker in dB)
ROLES = {
    "kick": ("kick", 0.0), "bas": ("bas / 808", -1.0),
    "snare": ("snare / clap", -2.0), "vocal": ("vocal", -2.5),
    "melodie": ("melodie / keys", -3.0), "perc": ("percussie", -5.0),
    "hihat": ("hihat", -6.0), "fx": ("fx / riser", -9.0),
    "overig": ("overig", -4.0),
}
ROLE_PRIORITY = {
    "low": ["kick", "bas", "snare", "melodie", "vocal", "perc", "hihat",
            "fx", "overig"],
    "mid": ["vocal", "snare", "melodie", "kick", "bas", "perc", "hihat",
            "fx", "overig"],
    "high": ["melodie", "vocal", "hihat", "perc", "snare", "fx",
             "overig", "bas", "kick"],
}
BAND_GROUP = {"sub": "low", "laag": "low", "laagmid": "mid",
              "mid": "mid", "highmid": "mid", "hoog": "high",
              "air": "high"}
BAND_RANGE = {name: (a, b) for a, b, name in BANDS}

_NAME_HINTS = [("kick", "kick"), ("808", "bas"), ("sub", "bas"),
               ("bass", "bas"), ("bas", "bas"), ("snare", "snare"),
               ("clap", "snare"), ("hihat", "hihat"), ("hat", "hihat"),
               ("hh", "hihat"), ("perc", "perc"), ("shaker", "perc"),
               ("tom", "perc"), ("vocal", "vocal"), ("vox", "vocal"),
               ("lead", "vocal"), ("fx", "fx"), ("riser", "fx"),
               ("impact", "fx"), ("sweep", "fx"), ("pad", "melodie"),
               ("keys", "melodie"), ("piano", "melodie"),
               ("synth", "melodie"), ("pluck", "melodie"),
               ("guitar", "melodie"), ("melo", "melodie"),
               ("chord", "melodie"), ("loop", "melodie")]

STEMS: dict[str, dict] = {}
REFERENCE: dict | None = None


STATE_FILE = "state.json"


def init(stems_dir: Path):
    global STEMS_DIR
    STEMS_DIR = stems_dir
    stems_dir.mkdir(parents=True, exist_ok=True)
    load_state()


def save_state():
    """Stems + referentie overleven een herstart van de app."""
    import json
    if not STEMS_DIR:
        return
    data = {"stems": [{"path": s["path"], "name": s["name"]}
                      for s in STEMS.values()],
            "reference": ({"path": REFERENCE["path"],
                           "name": REFERENCE["name"]}
                          if REFERENCE else None)}
    (STEMS_DIR / STATE_FILE).write_text(json.dumps(data))


def load_state():
    global REFERENCE
    import json
    f = STEMS_DIR / STATE_FILE
    if not f.exists():
        return
    try:
        data = json.loads(f.read_text())
    except Exception:
        return
    for st in data.get("stems", []):
        p = Path(st["path"])
        if not p.exists():
            continue
        sid = uuid.uuid4().hex[:8]
        info = analyze_file(p)
        info["role"] = _guess_role(st["name"], info["bands"])
        info["role_nl"] = ROLES[info["role"]][0]
        STEMS[sid] = {"id": sid, "name": st["name"], "path": str(p),
                      **info}
    ref = data.get("reference")
    if ref and Path(ref["path"]).exists():
        REFERENCE = {"name": ref["name"], "path": ref["path"],
                     **analyze_file(ref["path"])}


def _load(path: str | Path, sr: int = SR):
    try:
        y, orig = sf.read(str(path), always_2d=True)
    except Exception:
        # mp3 e.d. → via librosa (audioread/ffmpeg op zijn pc)
        ym, orig = librosa.load(str(path), sr=sr, mono=False)
        y = np.atleast_2d(ym).T if ym.ndim > 1 else ym[:, None].repeat(2, 1)
        return y.astype(np.float32), sr
    y = y.astype(np.float32)
    if orig != sr:
        y = np.stack([librosa.resample(y[:, c], orig_sr=orig, target_sr=sr)
                      for c in range(y.shape[1])], axis=1)
    return y, sr


def _spectral(mono: np.ndarray, sr: int) -> dict[str, float]:
    spec = np.abs(librosa.stft(mono, n_fft=4096, hop_length=2048)) ** 2
    freqs = librosa.fft_frequencies(sr=sr, n_fft=4096)
    power = spec.mean(axis=1)
    tot = power.sum() or 1e-12
    return {name: float(power[(freqs >= a) & (freqs < b)].sum() / tot)
            for a, b, name in BANDS}


def _guess_role(name: str, bands: dict[str, float]) -> str:
    low = name.lower().replace("-", "_").replace(" ", "_")
    for hint, role in _NAME_HINTS:
        if hint in low:
            return role
    if bands["sub"] + bands["laag"] > 0.5:
        return "bas"
    if bands["hoog"] + bands["air"] > 0.25:
        return "hihat"
    if bands["laagmid"] + bands["mid"] > 0.4:
        return "melodie"
    return "overig"


def analyze_file(path: str | Path) -> dict:
    path = Path(path)
    y, sr = _load(path)
    stereo = y if y.shape[1] >= 2 else np.repeat(y, 2, axis=1)
    mono = stereo.mean(axis=1)
    meter = pyln.Meter(sr)
    try:
        lufs = float(meter.integrated_loudness(stereo))
    except ValueError:
        lufs = -70.0
    peak_db = float(20 * np.log10(max(np.abs(stereo).max(), 1e-9)))
    bands = _spectral(mono[: sr * 90], sr)
    role = _guess_role(path.name, bands)
    bpm = 0.0
    try:
        bpm = float(librosa.beat.tempo(y=mono[: sr * 60], sr=sr)[0])
    except Exception:
        pass
    corr = (float(np.corrcoef(stereo[:, 0], stereo[:, 1])[0, 1])
            if stereo.shape[1] >= 2 and len(stereo) > 1000 else 1.0)
    clips = int((np.abs(stereo) >= 0.999).sum())

    def _f(x: float, fb: float) -> float:
        # stilte/kapotte meting → -inf/NaN; dat kan niet in JSON →
        # altijd een echt getal teruggeven
        return float(x) if np.isfinite(x) else fb

    bands = {k: _f(v, 0.0) for k, v in bands.items()}
    return {"lufs": round(_f(lufs, -70.0), 1),
            "peak_db": round(_f(peak_db, -70.0), 1),
            "dur": round(_f(len(mono) / sr, 0.0), 1), "role": role,
            "role_nl": ROLES[role][0], "bands": bands,
            "bpm": round(_f(bpm, 0.0), 1), "corr": round(_f(corr, 1.0), 3),
            "clips": clips, "air_share": round(bands.get("air", 0.0), 4)}


def add_stem(src_path: Path, name: str | None = None) -> dict:
    stem_id = uuid.uuid4().hex[:8]
    nice = name or src_path.name
    STEMS_DIR.mkdir(parents=True, exist_ok=True)
    dest = STEMS_DIR / f"{stem_id}_{Path(nice).name}"
    shutil.copyfile(src_path, dest)
    info = analyze_file(dest)
    # rol-gok op de ECHTE naam, niet op de temp-/id-naam
    info["role"] = _guess_role(nice, info["bands"])
    info["role_nl"] = ROLES[info["role"]][0]
    stem = {"id": stem_id, "name": Path(nice).name, "path": str(dest),
            "locked": False, **info}
    STEMS[stem_id] = stem
    save_state()
    return stem


def remove_stem(stem_id: str):
    st = STEMS.pop(stem_id, None)
    if st:
        Path(st["path"]).unlink(missing_ok=True)
    save_state()


def clear_stems():
    for sid in list(STEMS):
        remove_stem(sid)


def toggle_lock(stem_id: str) -> dict:
    """🔒 Stem vastzetten/vrijgeven — gelockte stems worden niet aangeraakt
    (geen volume/EQ/pan); ze spelen gewoon mee zoals ze zijn."""
    st = STEMS.get(stem_id)
    if not st:
        return {"error": "stem niet gevonden"}
    st["locked"] = not st.get("locked", False)
    save_state()
    return {"id": stem_id, "locked": st["locked"], "name": st["name"]}


def set_reference(src_path: Path, name: str | None = None) -> dict:
    global REFERENCE
    nice = Path(name or src_path.name).name
    dest = STEMS_DIR / f"ref_{nice}"
    shutil.copyfile(src_path, dest)
    a = analyze_file(dest)
    REFERENCE = {"name": nice, "path": str(dest), **a}
    save_state()
    return REFERENCE


def clear_reference():
    global REFERENCE
    REFERENCE = None
    save_state()


def plan_balance(stems: list[dict]) -> tuple[dict[str, float], list[str]]:
    """Gain-voorstel per stem (dB) + uitlegregels."""
    lines: list[str] = []
    if not stems:
        return {}, lines
    for s in stems:
        if s.get("peak_db", -99) > -0.3:
            lines.append(f"🚨 {s['name']} piekt op {s['peak_db']} dB — "
                         "mogelijk geclipt; Engineer trekt hem iets "
                         "terug in de mix.")
    bpms = [s["bpm"] for s in stems if s.get("bpm", 0) > 40]
    if bpms:
        bpm = sorted(bpms)[len(bpms) // 2]
        lines.append(f"⏱ Projecttempo ≈ {bpm:.0f} BPM "
                     "(meest voorkomende in je stems).")
    anchors = [s for s in stems if s["role"] == "kick"]
    anchor = anchors[0] if anchors else max(stems, key=lambda s: s["lufs"])
    if anchors:
        lines.append(f"🥁 {anchor['name']} is het anker "
                     f"({anchor['lufs']:.1f} LUFS).")
    else:
        lines.append(f"🥁 Geen kick gevonden — {anchor['name']} "
                     f"(luidste, {anchor['lufs']:.1f} LUFS) is het anker.")
    gains: dict[str, float] = {}
    for s in stems:
        if s["lufs"] < -60:
            gains[s["id"]] = 0.0
            lines.append(f"⚠ {s['name']} lijkt (bijna) leeg — niet "
                         "aangeraakt.")
            continue
        if s.get("locked"):
            gains[s["id"]] = 0.0
            lines.append(f"🔒 {s['name']} vastgezet — speelt mee zoals "
                         "hij is.")
            continue
        offset = ROLES[s["role"]][1] if s["id"] != anchor["id"] else 0.0
        want = anchor["lufs"] + offset
        g = max(-12.0, min(12.0, want - s["lufs"]))
        gains[s["id"]] = round(g, 1)
        verb = "omhoog" if g > 0.2 else ("omlaag" if g < -0.2 else "≈ goed")
        lines.append(
            f"{s['role_nl']}: {s['name']} {verb} {g:+.1f} dB → "
            f"{s['lufs'] + g:.1f} LUFS")
    return gains, lines


def plan_unmask(stems: list[dict]) -> tuple[list[dict], list[str]]:
    """Band-conflicten → EQ-dips voor de verliezer (niet-destructief in
    REAPER als ReaEQ-band i.p.v. gebakken in de WAV)."""
    dips: list[dict] = []
    lines: list[str] = []
    for a, b, band in BANDS:
        fighters = [s for s in stems if s["bands"][band] >= 0.05]
        if len(fighters) < 2:
            continue
        prio = ROLE_PRIORITY[BAND_GROUP[band]]
        fighters.sort(key=lambda s: prio.index(s["role"]))
        winner, *losers = fighters
        for loser in losers:
            if loser.get("locked"):
                continue  # 🔒 gelockte stem krijgt geen EQ-dip
            if loser["bands"][band] < winner["bands"][band] * 0.4:
                continue
            dips.append({"stem": loser["id"], "band": band,
                         "lo": a, "hi": b})
            lines.append(
                f"⚔ {winner['name']} ↔ {loser['name']} vechten om "
                f"{band} ({a}-{b}Hz) — {winner['name']} wint; zachte "
                f"EQ-dip in {loser['name']}.")
    return dips, lines


def plan_pans(stems: list[dict]) -> tuple[dict[str, float], list[str]]:
    """Subtiele pans voor breedte — bas/laag blijft in het midden."""
    pans: dict[str, float] = {}
    lines: list[str] = []
    alt = 1
    for s in stems:
        if s.get("locked"):
            continue  # 🔒 vastgezette stem wordt niet verplaatst
        if s["role"] in ("perc", "hihat", "fx", "melodie"):
            pans[s["id"]] = round(0.15 * alt, 2)
            alt = -alt
    if pans:
        lines.append("↔ Melodie/perc/hihat/fx krijgen subtiele "
                     "links-rechts spreiding (laag blijft centraal).")
    return pans, lines


def plan_autofix(stems: list[dict]) -> tuple[dict, list[str]]:
    """Beat-Check-kennis als reparateur: vind en fix standaard-issues.
    - geclipte samples → extra terugtrekken
    - (bijna) mono overal → breedte alleen in de hoge banden
    - geen air (>6kHz) → extra air-boost op de master
    """
    fixes: dict = {"widen": None, "air_extra": 0.0, "clipped": []}
    lines: list[str] = []
    if not stems:
        return fixes, lines
    clipped = [s["name"] for s in stems if s.get("clips", 0) > 0]
    if clipped:
        fixes["clipped"] = clipped
        lines.append("🔧 AUTO-FIX: " + ", ".join(clipped) +
                     " bevat geclipte samples → trekt hij extra terug "
                     "voordat ze de mix in gaan.")
    monos = [s for s in stems if s.get("corr", 1.0) > 0.9]
    if len(monos) == len(stems):
        fixes["widen"] = 1.35
        lines.append("🔧 AUTO-FIX: ál je stems zijn (bijna) mono → "
                     "breedte komt er ALLEEN boven ~1.5kHz bij "
                     "(sub/mid blijft gecentreerd en krachtig).")
    air = sum(s.get("air_share", 0.0) for s in stems) / len(stems)
    if air < 0.01:
        fixes["air_extra"] = 1.5
        lines.append("🔧 AUTO-FIX: vrijwel geen air (>6kHz) in je stems "
                     "→ +1.5dB extra air op de master voor glans.")
    return fixes, lines


# Highpass-vloer per rol: modder onder deze frequentie gaat eruit
# (kick/808 mogen hun sub houden; alles daarboven hoort schoon te zijn).
ROLE_FLOOR = {"kick": 20.0, "bas": 25.0, "snare": 60.0, "vocal": 80.0,
              "melodie": 80.0, "perc": 60.0, "hihat": 150.0, "fx": 100.0,
              "overig": 60.0}

# Hoe zo'n instrument in een hit klinkt: energie-verdeling over banden.
# Zachte nudges (max ±2dB, max 2 banden) — geen harde herschrijving.
ROLE_PROFILE = {
    "kick":    {"sub": .35, "laag": .30, "laagmid": .15, "mid": .05,
                "highmid": .05, "hoog": .05, "air": .05},
    "bas":     {"sub": .55, "laag": .30, "laagmid": .10, "mid": .03,
                "highmid": .015, "hoog": .003, "air": .002},
    "snare":   {"sub": .01, "laag": .10, "laagmid": .15, "mid": .25,
                "highmid": .25, "hoog": .15, "air": .09},
    "vocal":   {"sub": .0, "laag": .02, "laagmid": .08, "mid": .15,
                "highmid": .35, "hoog": .25, "air": .15},
    "melodie": {"sub": .02, "laag": .10, "laagmid": .18, "mid": .25,
                "highmid": .25, "hoog": .13, "air": .07},
    "perc":    {"sub": .0, "laag": .05, "laagmid": .15, "mid": .25,
                "highmid": .30, "hoog": .18, "air": .07},
    "hihat":   {"sub": .0, "laag": .0, "laagmid": .02, "mid": .05,
                "highmid": .18, "hoog": .40, "air": .35},
    "fx":      {"sub": .02, "laag": .08, "laagmid": .15, "mid": .20,
                "highmid": .25, "hoog": .18, "air": .12},
    "overig":  {"sub": .05, "laag": .15, "laagmid": .20, "mid": .22,
                "highmid": .20, "hoog": .12, "air": .06},
}


def plan_polish(stems: list[dict]) -> tuple[dict, list[str]]:
    """Per-stem rol-poets: highpass op de rol-vloer + max 2 zachte
    band-nudges (±2dB) richting hoe zo'n instrument in een hit klinkt.
    Geeft {stem_id: {hpf, nudges:[(band,db)]}} + uitlegregels."""
    polish: dict = {}
    lines: list[str] = []
    for s in stems:
        if s.get("locked"):
            continue  # 🔒 vastgezette stem wordt niet gepoetst
        role = s["role"]
        hpf = ROLE_FLOOR.get(role, 60.0)
        prof = ROLE_PROFILE.get(role, ROLE_PROFILE["overig"])
        diffs = []
        for _, _, band in BANDS:
            target = max(prof[band], 1e-6)
            have = max(s["bands"][band], 1e-6)
            db = 10 * np.log10(target / have)
            diffs.append((band, float(np.clip(db, -2.0, 2.0))))
        diffs.sort(key=lambda x: -abs(x[1]))
        nudges = [(b, round(d, 1)) for b, d in diffs[:2] if abs(d) >= 0.75]
        polish[s["id"]] = {"hpf": hpf, "nudges": nudges}
        bits = [f"highpass {hpf:.0f}Hz"] if hpf >= 60 else []
        bits += [f"{b} {d:+.1f}dB" for b, d in nudges]
        if bits:
            lines.append(f"🧼 Poets {s['name']} ({s['role_nl']}): " +
                         ", ".join(bits) +
                         " — modder eruit, karakter erin.")
    if lines:
        lines.insert(0, "🧼 ROL-POETS: elke stem krijgt een highpass op "
                        "zijn eigen vloer + kleine nudges naar hoe zo'n "
                        "instrument in een hit klinkt.")
    return polish, lines


def plan_arrangement(stems: list[dict], bpm: float) -> tuple[dict, list[str]]:
    """Leg stems in een lied-arrangement: intro → buildup → drop → outro.
    Rollen bepalen wie waar speelt; maten op het projecttempo."""
    if bpm <= 0:
        bpm = 120.0
    bar = 240.0 / bpm  # seconden per maat (4/4)
    sections = [  # (naam, start_maat, lengte_maten, welke rollen)
        ("intro",   0,  8, {"melodie", "vocal", "fx", "overig"}),
        ("buildup", 8,  8, {"melodie", "vocal", "fx", "overig",
                            "perc", "hihat"}),
        ("drop",    16, 16, {"kick", "bas", "snare", "vocal", "melodie",
                             "perc", "hihat", "fx", "overig"}),
        ("outro",   32, 8, {"melodie", "vocal", "fx", "overig"}),
    ]
    # niemand in intro? dan komt alles in de drop en wordt intro 'buildup'
    sched: list[dict] = []
    for s in stems:
        sdur = max(s.get("dur", 8.0), 0.25)
        for name, start, ln, roles in sections:
            if s["role"] not in roles:
                continue
            sec_start, sec_end = start * bar, (start + ln) * bar
            # loop: kortere stem vult de hele sectie (eigen lengte als stap)
            pos = sec_start
            while pos < sec_end - 0.05:
                sched.append({"stem": s["id"], "name": s["name"],
                              "section": name, "start": pos,
                              "dur": min(sdur, sec_end - pos)})
                pos += sdur
    lines = [f"🏗 ARRANGEMENT op {bpm:.0f} BPM "
             f"(maat = {bar:.1f}s): intro 8m → buildup 8m → "
             "drop 16m → outro 8m."]
    for name, start, ln, _ in sections:
        who = list(dict.fromkeys(s_["name"] for s_ in sched
                                 if s_["section"] == name))
        if who:
            lines.append(f"🏗 {name} ({ln} maten): " + ", ".join(who))
    return {"bpm": bpm, "bar": bar, "schedule": sched}, lines


def plan_reference(stems: list[dict], ref: dict | None,
                   lines: list[str]) -> tuple[dict, dict]:
    """Vergelijk bands van de stems-som met de referentie → per-band
    correctievoorstel in dB (clamped ±4) + doel-luidheid/-breedte.
    Geeft (adj, targets); ({}, {}) als geen ref."""
    if not ref:
        return {}, {}
    # som de bands over stems (gewogen op lufs-energie)
    tot: dict[str, float] = {}
    wsum = 0.0
    for s in stems:
        w = 10 ** (s["lufs"] / 20.0)
        wsum += w
        for _, _, name in BANDS:
            tot[name] = tot.get(name, 0.0) + s["bands"][name] * w
    if wsum <= 0:
        return {}
    ours = {n: (tot[n] / wsum) for _, _, n in BANDS}
    theirs = ref["bands"]
    adj: dict[str, dict[str, float]] = {}
    for _, _, name in BANDS:
        o = max(ours[name], 1e-6)
        t = max(theirs[name], 1e-6)
        db = float(max(-4.0, min(4.0, 10 * np.log10(t / o))))
        if abs(db) >= 0.75:
            adj[name] = {"db": round(db, 1)}
    for name, a in adj.items():
        lo, hi = BAND_RANGE[name]
        lines.append(
            f"🎯 Referentie {ref['name']}: jouw mix heeft in {name} "
            f"({lo}-{hi}Hz) {a['db']:+.1f} dB nodig om op zijn stijl "
            "te lijken.")
    targets: dict[str, float] = {}
    # referentie bepaalt ook luidte- en breedte-doel
    if ref.get("lufs", -70) > -40:
        targets["lufs"] = round(max(-14.0, min(-7.0, ref["lufs"])), 1)
        lines.append(f"🎯 Referentie-loudness {ref['lufs']} LUFS → "
                     f"doel wordt {targets['lufs']} LUFS "
                     "(i.p.v. de stijl-standaard).")
    if 0.4 < ref.get("corr", 1.0) < 0.9:
        targets["width"] = round(1.0 + (1.0 - ref["corr"]) * 0.6, 2)
        lines.append(f"🎯 Referentie is breed (corr {ref['corr']}) → "
                     f"breedte-doel x{targets['width']}.")
    return adj, targets


def suggest_style(stems: list[dict], ref: dict | None = None
                  ) -> tuple[str, list[str]]:
    """Kies zélf de beste stijl op basis van de stems —
    meet BPM + energieverdeling en legt in NL uit waarom."""
    lines: list[str] = []
    if not stems:
        return "schoon", ["geen stems — standaard Schoon & Glans."]

    bpms = sorted(s["bpm"] for s in stems if 60 < s.get("bpm", 0) < 260)
    bpm = bpms[len(bpms) // 2] if bpms else 0.0

    # gewogen band-energie over alle stems
    tot: dict[str, float] = {}
    wsum = 0.0
    for s in stems:
        w = 10 ** (s["lufs"] / 20.0)
        wsum += w
        for _, _, n in BANDS:
            tot[n] = tot.get(n, 0.0) + s["bands"].get(n, 0.0) * w
    if wsum <= 0:
        return "schoon", ["stems te stil om te meten — Schoon & Glans."]
    bnd = {n: tot[n] / wsum for _, _, n in BANDS}
    low = bnd["sub"] + bnd["laag"]
    dark = bnd["air"] < 0.03          # weinig top → donker
    bright = bnd["air"] > 0.12        # veel lucht → helder
    punchy = (bnd["highmid"] + bnd["hoog"]) > 0.35  # percussief

    scores = {"schoon": 1.0, "drill": 0.0, "amapiano": 0.0,
              "rnb": 0.0, "dancehall": 0.0}
    why: dict[str, list[str]] = {k: [] for k in scores}

    if 135 <= bpm <= 165:
        scores["drill"] += 2; why["drill"].append(f"tempo {bpm:.0f} BPM is drill-gebied")
    if low > 0.40:
        scores["drill"] += 1.5; why["drill"].append("sub/laag domineert (808 voorop)")
        scores["schoon"] += 0.3
    if dark and low > 0.30:
        scores["drill"] += 1; why["drill"].append("donkere mix + zware sub")
    if 100 <= bpm <= 125:
        scores["amapiano"] += 1.8; why["amapiano"].append(f"tempo {bpm:.0f} BPM is amapiano-gebied")
        scores["dancehall"] += 1.0; why["dancehall"].append(f"tempo {bpm:.0f} BPM past bij dancehall")
    if bnd["laagmid"] + bnd["mid"] > 0.30:
        scores["amapiano"] += 1; why["amapiano"].append("warme midden (log-drum feel)")
        scores["rnb"] += 0.8; why["rnb"].append("warme midden")
    if punchy:
        scores["dancehall"] += 1.6; why["dancehall"].append("percussie/ritme drijft de mix")
    if bpm < 95:
        scores["rnb"] += 1.6; why["rnb"].append(f"rustig tempo {bpm:.0f} BPM")
    if bright:
        scores["schoon"] += 1.2; why["schoon"].append("veel lucht — glans past hier")
        scores["amapiano"] += 0.4
    if ref:
        scores["schoon"] += 0.5; why["schoon"].append("referentie op maat nastreven")

    best = max(scores, key=lambda k: scores[k])
    lines.append(f"🎯 Ik meet: BPM ≈ {bpm:.0f}, sub+laag "
                 f"{low * 100:.0f}%, air {bnd['air'] * 100:.0f}% "
                 f"{'(donker)' if dark else '(licht)'}.")
    if not why[best]:
        why[best].append("geen uitgesproken genre-signaal — veiligste keuze")
    lines.append(f"🎯 Gekozen: {best} — " + "; ".join(why[best]) + ".")
    return best, lines
