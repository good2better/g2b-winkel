"""G2B Engineer — FastAPI backend, poort 8300."""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import analyzer, bridge, engineer, localmix
from . import styles as styles_mod

BASE = Path(__file__).resolve().parent.parent
STORAGE = BASE / "storage"
STEMS_DIR = STORAGE / "stems"
RENDER_DIR = STORAGE / "render"

analyzer.init(STEMS_DIR)
engineer.init(RENDER_DIR)
localmix.init(RENDER_DIR)

app = FastAPI(title="G2B Engineer")


@app.exception_handler(Exception)
async def _server_fout(request: Request, exc: Exception):
    # Elke fout terug als Nederlands bericht — nooit een kale 500/crash.
    return JSONResponse(status_code=500, content={"error": str(exc)})


@app.get("/api/status")
def status():
    ok, msg = bridge.connected()
    return {
        "ok": True,
        "reaper": ok,
        "reaper_msg": msg,
        "stems": list(analyzer.STEMS.values()),
        "reference": analyzer.REFERENCE,
        "styles": [{"key": k, "label": v["label"], "desc": v["desc"]}
                   for k, v in styles_mod.all_styles().items()],
    }


@app.post("/api/bridge/connect")
def bridge_connect():
    ok, msg = bridge.connect()
    return {"ok": ok, "msg": msg}


@app.post("/api/bridge/fix")
def bridge_fix():
    try:
        ok, log = bridge.fix_bridge()
        return {"ok": ok, "lines": log}
    except Exception as e:
        return {"ok": False, "lines": ["fix fout: " + str(e)]}


@app.get("/api/bridge/diagnose")
def bridge_diagnose():
    try:
        return {"lines": bridge.diagnose()}
    except Exception as e:
        return {"lines": ["diagnose fout: " + str(e)]}


def _tmp_weg(p: Path) -> None:
    """Tijdbestand wissen — op Windows kan een audio-handle het nog
    even vasthouden (WinError 32); dan gewoon laten staan."""
    try:
        p.unlink(missing_ok=True)
    except PermissionError:
        pass


@app.post("/api/stems")
async def add_stem(file: UploadFile = File(...)):
    tmp = Path(tempfile.mkstemp(suffix=Path(file.filename).suffix)[1])
    tmp.write_bytes(await file.read())
    stem = analyzer.add_stem(tmp, file.filename)
    _tmp_weg(tmp)
    return stem


@app.delete("/api/stems/{stem_id}")
def del_stem(stem_id: str):
    analyzer.remove_stem(stem_id)
    return {"ok": True}


@app.post("/api/stems/{stem_id}/lock")
def lock_stem(stem_id: str):
    return analyzer.toggle_lock(stem_id)


@app.post("/api/stems/clear")
def clear():
    analyzer.clear_stems()
    return {"ok": True}


@app.post("/api/reference")
async def set_ref(file: UploadFile = File(...)):
    tmp = Path(tempfile.mkstemp(suffix=Path(file.filename).suffix)[1])
    tmp.write_bytes(await file.read())
    ref = analyzer.set_reference(tmp, file.filename)
    _tmp_weg(tmp)
    return ref


@app.delete("/api/reference")
def del_ref():
    analyzer.clear_reference()
    return {"ok": True}


class PlanReq(BaseModel):
    style: str = "schoon"


@app.post("/api/plan")
def make_plan(r: PlanReq):
    return engineer.plan(r.style)


@app.get("/api/style/auto")
def style_auto():
    key, lines = analyzer.suggest_style(list(analyzer.STEMS.values()),
                                        analyzer.REFERENCE)
    return {"key": key, "lines": lines}


@app.get("/api/presets")
def presets_list():
    return {"presets": [{"key": k, "label": v["label"]}
                        for k, v in styles_mod.all_styles().items()
                        if k.startswith("eigen:")]}


class PresetReq(BaseModel):
    name: str
    params: dict = {}
    base: str = ""


@app.post("/api/presets")
def preset_save(r: PresetReq):
    params = dict(r.params)
    if r.base and not params:
        # sla de huidige stijl op onder eigen naam
        params = styles_mod.get_style(r.base)
    return styles_mod.save_preset(r.name, params)


@app.delete("/api/presets/{name}")
def preset_del(name: str):
    return styles_mod.delete_preset(name)


@app.post("/api/auto_run")
def auto_run():
    """🚀 DOE ALLES: meet stems → kiest zelf de stijl → mixt+master.
    REAPER als de brug aan staat, anders volledig lokaal."""
    stems = list(analyzer.STEMS.values())
    if len(stems) < 2:
        return {"error": "Zet eerst minstens 2 stems in kaart ① "
                         "(of gebruik 🔗 uit Sound Lab halen)."}
    key, lines = analyzer.suggest_style(stems, analyzer.REFERENCE)
    ok, _ = bridge.connected()
    if ok:
        res = engineer.execute(key)
        lines.append("🖥 Gemixt + gemasterd ín REAPER.")
    else:
        res = localmix.execute_local(key)
        lines.append("💻 Gemixt + gemasterd lokaal (REAPER niet "
                     "verbonden).")
    return {"style": key, "out": res.get("out"),
            "lufs": res.get("lufs"), "peak": res.get("peak"),
            "lines": lines + res.get("lines", [])}


@app.post("/api/run")
def run(r: PlanReq):
    return engineer.execute(r.style)


@app.post("/api/run_local")
def run_local(r: PlanReq):
    return localmix.execute_local(r.style)


@app.post("/api/run_arrange")
def run_arrange(r: PlanReq):
    return engineer.execute_arrange(r.style)


@app.post("/api/run_arrange_local")
def run_arrange_local(r: PlanReq):
    return localmix.execute_arrange_local(r.style)


AUDIO_EXT = {".wav", ".mp3", ".aiff", ".aif", ".flac"}


def _soundlab_dir() -> Path | None:
    """Vind de exports-map van G2B Sound Lab: env-override, anders
    zoeken naast deze app (werkt ook als ze los uitgepakt staan)."""
    env = os.environ.get("G2B_SOUNDLAB_EXPORTS")
    if env and Path(env).is_dir():
        return Path(env)
    hits: list[Path] = []
    for up in (BASE.parent, BASE.parent.parent, BASE.parent.parent.parent):
        for pat in ("*/backend/storage/exports", "*/storage/exports"):
            hits += sorted(p for p in up.glob(pat) if p.is_dir())
    for h in hits:  # liefst een map met 'soundlab' in de naam
        if "soundlab" in str(h).lower():
            return h
    return hits[0] if hits else None


@app.get("/api/soundlab")
def soundlab_preview():
    d = _soundlab_dir()
    if not d:
        return {"found": False, "files": [], "dir": None}
    have = {s["name"] for s in analyzer.STEMS.values()}
    files = [p.name for p in sorted(d.iterdir())
             if p.suffix.lower() in AUDIO_EXT]
    return {"found": True, "dir": str(d), "files": files,
            "nieuw": [f for f in files if f not in have]}


@app.post("/api/soundlab/import")
def soundlab_import():
    d = _soundlab_dir()
    if not d:
        return {"ok": False,
                "error": "Geen Sound Lab-exports gevonden. Zet je "
                         "G2B-SoundLab-map naast G2B-Engineer, of zet "
                         "de omgevingsvariabele G2B_SOUNDLAB_EXPORTS."}
    have = {s["name"] for s in analyzer.STEMS.values()}
    imported = []
    for p in sorted(d.iterdir()):
        if p.suffix.lower() not in AUDIO_EXT or p.name in have:
            continue
        analyzer.add_stem(p, p.name)
        imported.append(p.name)
    return {"ok": True, "imported": imported}


MIDI_DIR = STORAGE / "midi"
MIDI_DIR.mkdir(parents=True, exist_ok=True)


@app.post("/api/midi")
async def midi_upload(file: UploadFile = File(...)):
    """Drop een ChordLab-.mid — wordt bewaard voor → REAPER."""
    name = Path(file.filename).name
    if not name.lower().endswith(".mid"):
        return {"error": "alleen .mid-bestanden"}
    tmp = Path(tempfile.mkstemp(suffix=".mid")[1])
    tmp.write_bytes(await file.read())
    shutil.copy(tmp, MIDI_DIR / name)
    _tmp_weg(tmp)
    return {"ok": True, "name": name}


@app.get("/api/midi")
def midi_list():
    files = sorted(p.name for p in MIDI_DIR.glob("*.mid"))
    return {"files": files}


class MidiTrackReq(BaseModel):
    file: str
    name: str = "ChordLab"
    instrument: str = ""


@app.post("/api/midi_track")
def midi_track(r: MidiTrackReq):
    """Zet een .mid als MIDI-spoor in REAPER + instrument erop."""
    p = MIDI_DIR / Path(r.file).name
    if not p.exists():
        return {"error": f"{r.file} niet gevonden — upload hem eerst."}
    ok, msg = bridge.connected()
    if not ok:
        return {"error": "REAPER niet verbonden — klik eerst 🔧 FIX BRUG "
                         f"AUTO ({msg})."}
    try:
        idx = bridge.insert_midi_track(str(p), r.name or "ChordLab",
                                       r.instrument.strip())
        inst = f" + instrument '{r.instrument}'" if r.instrument.strip() \
            else " (geen instrument — kies er zelf een in REAPER)"
        return {"ok": True, "track": idx,
                "lines": [f"🎹 '{r.file}' ligt als MIDI-spoor "
                          f"'{r.name}' in REAPER{inst}."]}
    except Exception as e:
        return {"error": str(e)}


@app.get("/api/download/{name}")
def download(name: str):
    p = RENDER_DIR / name
    if not p.exists():
        return {"error": "niet gevonden"}
    return FileResponse(p, filename=name)


app.mount("/", StaticFiles(directory=BASE / "static", html=True),
          name="static")
