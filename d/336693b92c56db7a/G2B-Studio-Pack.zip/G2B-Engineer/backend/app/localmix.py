"""Lokale render — werkt ook zonder REAPER.

Zelfde hersenen (analyzer-plan), zelfde uitkomst, maar de DSP gebeurt
hier in numpy i.p.v. als echte knoppen in REAPER. Voordeel van REAPER-
pad: non-destructief. Dit pad: werkt áltijd, ook als REAPER niet
gekoppeld is — en produceert dezelfde mix+master als WAV.
"""
from __future__ import annotations

from pathlib import Path

import librosa
import numpy as np
import pyloudnorm as pyln
import soundfile as sf
from scipy import signal

from . import analyzer
from .styles import STYLES

RENDER_DIR: Path | None = None


def init(render_dir: Path):
    global RENDER_DIR
    RENDER_DIR = render_dir
    render_dir.mkdir(parents=True, exist_ok=True)


def _load(path: str, sr: int):
    return analyzer._load(path, sr)


def _eq_dip(y, sr, lo, hi, depth=0.55):
    lo = max(lo, 25.0); hi = min(hi, sr / 2 - 500)
    if hi <= lo:
        return y
    sos = signal.butter(2, [lo, hi], btype="bandpass", fs=sr,
                        output="sos")
    region = signal.sosfilt(sos, y, axis=0).astype(np.float32)
    return (y - region * depth).astype(np.float32)


def _eq_boost(y, sr, freq, gain_db, q=1.0):
    """Zachte piek-boost via bandpass-add."""
    b = freq / max(2 * q, 0.5)
    lo, hi = max(freq - b, 30.0), min(freq + b, sr / 2 - 500)
    if hi <= lo:
        return y
    sos = signal.butter(2, [lo, hi], btype="bandpass", fs=sr,
                        output="sos")
    region = signal.sosfilt(sos, y, axis=0).astype(np.float32)
    return (y + region * (10 ** (gain_db / 20) - 1)).astype(np.float32)


def _highpass(y, sr, f0):
    sos = signal.butter(2, f0, btype="highpass", fs=sr, output="sos")
    return signal.sosfilt(sos, y, axis=0).astype(np.float32)


def _air_shelf(y, sr, gain_db, f0):
    sos = signal.butter(2, f0, btype="highpass", fs=sr, output="sos")
    top = signal.sosfilt(sos, y, axis=0).astype(np.float32)
    return (y + top * (10 ** (gain_db / 20) - 1)).astype(np.float32)


def _width(y, factor):
    if y.shape[1] < 2:
        return y
    mid = (y[:, 0] + y[:, 1]) * 0.5
    side = (y[:, 0] - y[:, 1]) * 0.5 * factor
    return np.stack([mid + side, mid - side], axis=1).astype(np.float32)


def _widen_high(y, sr, f0=1500.0, factor=1.35):
    """Breedte alleen boven f0 — sub/mid blijft mono en krachtig."""
    if y.shape[1] < 2:
        return y
    mid = (y[:, 0] + y[:, 1]) * 0.5
    side = (y[:, 0] - y[:, 1]) * 0.5
    sos = signal.butter(2, f0, btype="highpass", fs=sr, output="sos")
    side_hi = signal.sosfilt(sos, side).astype(np.float32)
    side = (side - side_hi) + side_hi * factor
    return np.stack([mid + side, mid - side], axis=1).astype(np.float32)


def _soft_limit(y):
    return np.tanh(y * 1.1).astype(np.float32)


def _glue_comp(y, sr, ratio):
    """Heel simpele RMS-glue: verzacht pieken boven -12dB met 'ratio'."""
    mono = np.abs(y).max(axis=1)
    w = max(int(sr * 0.02), 16)  # ~20ms
    env = np.convolve(mono, np.ones(w) / w, mode="same")
    th = 10 ** (-12 / 20)
    over = np.maximum(env - th, 0.0)
    g = 1.0 / (1.0 + over / th * (ratio - 1) * 3.0)
    return (y * g[:, None]).astype(np.float32)


def _prep_stem(s: dict, p: dict, sr: int):
    """Eén stem bewerken: rol-poets, unmask-dips, gain, pan."""
    y, _ = _load(s["path"], sr)
    if y.shape[1] < 2:
        y = np.repeat(y, 2, axis=1)
    pol = p["polish"].get(s["id"], {})
    if pol.get("hpf", 0) > 30:
        y = _highpass(y, sr, pol["hpf"])
    for band, db in pol.get("nudges", [])[:2]:
        lo, hi = analyzer.BAND_RANGE[band]
        freq = (lo * hi) ** 0.5
        if db > 0:
            y = _eq_boost(y, sr, freq, db, 1.1)
        else:
            y = _eq_dip(y, sr, lo, hi, min(0.35, abs(db) / 6))
    for d in [d for d in p["dips"] if d["stem"] == s["id"]]:
        y = _eq_dip(y, sr, d["lo"], d["hi"])
    g = p["gains"].get(s["id"], 0.0)
    if s.get("peak_db", -99) > -0.3:
        g -= 3.0
    y = y * (10 ** (g / 20.0))
    pan = p["pans"].get(s["id"], 0.0)
    if pan:  # constant-power pan
        ang = (pan + 1) * np.pi / 4
        y[:, 0] *= np.cos(ang) * np.sqrt(2)
        y[:, 1] *= np.sin(ang) * np.sqrt(2)
    return y


def _master_chain(mix, st: dict, p: dict, sr: int):
    """Master-keten (spiegel van de REAPER-keten)."""
    mix = _highpass(mix, sr, st["hpf"])
    for name_b, a in p["ref_adj"].items():
        lo, hi = analyzer.BAND_RANGE[name_b]
        freq = (lo * hi) ** 0.5
        if a["db"] > 0:
            mix = _eq_boost(mix, sr, freq, a["db"], 1.2)
        else:
            mix = _eq_dip(mix, sr, lo, hi,
                          min(0.7, abs(a["db"]) / 20))
    mix = _glue_comp(mix, sr, st["comp_ratio"])
    widen = p["fixes"].get("widen")
    refw = p.get("targets", {}).get("width")
    if widen or refw:
        mix = _widen_high(mix, sr, 1500.0,
                          max(widen or 1.0, refw or 1.0, st["width"]))
    elif st["width"] != 1.0:
        mix = _width(mix, st["width"])
    return _air_shelf(mix, sr, st["air_db"] + p["fixes"].get("air_extra",
                                                            0.0),
                      st["air_freq"])


def _finalize(mix, st: dict, lines: list[str], name: str, sr: int):
    """LUFS-doel → limiter → pass-2 → schrijf + meet → resultaat."""
    meter = pyln.Meter(sr)
    lufs_in = float(meter.integrated_loudness(mix))
    mix *= 10 ** ((st["lufs"] - lufs_in) / 20)
    ceiling = 10 ** (st["ceiling_db"] / 20)
    if float(np.abs(mix).max()) > ceiling:
        mix = _soft_limit(mix)
        p2 = float(np.abs(mix).max())
        if p2 > ceiling:
            mix *= ceiling / p2
    lufs2 = float(meter.integrated_loudness(mix))
    resid = st["lufs"] - lufs2
    if resid > 0.3:
        mix *= 10 ** (resid / 20)
        if float(np.abs(mix).max()) > ceiling:
            mix *= ceiling / float(np.abs(mix).max())
        lines.append(f"🔧 Pass 2: limiter drukte {abs(resid):.1f} dB — "
                     f"bijgestuurd naar doel {st['lufs']} LUFS.")
    out = RENDER_DIR / f"{name}.wav"
    sf.write(str(out), np.clip(mix, -1, 1), sr, subtype="PCM_16")
    a2 = analyzer.analyze_file(out)
    lines.append(f"✅ Klaar: {out.name} — {a2['lufs']} LUFS, "
                 f"piek {a2['peak_db']} dB, stijl {st['label']}.")
    return {"out": str(out), "lufs": a2["lufs"], "peak": a2["peak_db"],
            "lines": lines}


def execute_local(style_key: str, name: str = "G2B-master") -> dict:
    from . import engineer
    p = engineer.plan(style_key)
    st = p["style"]  # incl. referentie-LUFS-override
    lines = ["💻 LOKALE RENDER (geen REAPER — zelfde hersenen, "
             "DSP in de app i.p.v. echte knoppen)"] + list(p["lines"])
    sr = analyzer.SR
    rendered = [_prep_stem(s, p, sr) for s in p["stems"]]
    n = max(len(y) for y in rendered)
    mix = np.zeros((n, 2), dtype=np.float32)
    for y in rendered:
        if len(y) < n:
            y = np.vstack([y, np.zeros((n - len(y), y.shape[1]),
                                     dtype=np.float32)])
        mix += y
    mix = _master_chain(mix, st, p, sr)
    return _finalize(mix, st, lines, name, sr)


def execute_arrange_local(style_key: str,
                          name: str = "G2B-track") -> dict:
    """🏗 BOUW TRACK lokaal: arrangement op de tijdlijn + mix + master."""
    from . import engineer
    p = engineer.plan(style_key)
    st = p["style"]
    bpms = [s["bpm"] for s in p["stems"] if s.get("bpm", 0) > 40]
    bpm = sorted(bpms)[len(bpms) // 2] if bpms else 120.0
    arr, alines = analyzer.plan_arrangement(p["stems"], bpm)
    lines = ["💻 LOKALE TRACK (geen REAPER — arrangement + mix + "
             "master in de app)"] + alines + list(p["lines"])
    sr = analyzer.SR
    total = max((it["start"] + it["dur"] for it in arr["schedule"]),
                default=10.0)
    n = int(total * sr) + sr
    mix = np.zeros((n, 2), dtype=np.float32)
    for it in arr["schedule"]:
        s = next(s for s in p["stems"] if s["id"] == it["stem"])
        y = _prep_stem(s, p, sr)
        maxn = int(it["dur"] * sr)
        if len(y) > maxn:  # inkorten naar sectie-lengte
            y = y[:maxn]
        off = int(it["start"] * sr)
        end = min(off + len(y), n)
        mix[off:end] += y[: end - off]
    mix = _master_chain(mix, st, p, sr)
    return _finalize(mix, st, lines, name, sr)
