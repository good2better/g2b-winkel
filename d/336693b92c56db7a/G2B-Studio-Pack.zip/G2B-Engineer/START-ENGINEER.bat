@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
echo ============================================
echo   G2B ENGINEER - jouw eigen mix/master-studio
echo   bestuurt REAPER automatisch
echo ============================================
echo.

rem --- Echte Python vinden (py-launcher is de normale weg) ---
set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY (
  python -c "import sys" >nul 2>nul && set "PY=python"
)
if not defined PY (
  python3 -c "import sys" >nul 2>nul && set "PY=python3"
)

rem --- Geen Python? Dan zelf installeren via winget ---
if not defined PY (
  echo Python ontbreekt - ik installeer het nu zelf ^(eenmalig^)...
  winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo.
    echo [FOUT] Automatische installatie lukte niet.
    echo Doe het handmatig: https://www.python.org/downloads/
    echo BELANGRIJK: vink "Add Python to PATH" aan!
    pause
    exit /b 1
  )
  rem PATH voor dít venster verversen
  for /f "tokens=2,*" %%a in ('reg query "HKCU\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "PATH=%%b"
  set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
  py -3 --version >nul 2>nul && set "PY=py -3"
  if not defined PY (python -c "import sys" >nul 2>nul && set "PY=python")
  if not defined PY (
    echo [FOUT] Python staat erop maar deze sessie ziet hem niet.
    echo Sluit dit venster en dubbelklik START-ENGINEER.bat nog een keer.
    pause
    exit /b 1
  )
)

if not exist .venv (
  echo [1/4] Python-omgeving maken ^(eenmalig^)...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo [FOUT] Kon de omgeving niet maken.
    pause
    exit /b 1
  )
)
call .venv\Scripts\activate.bat

echo [2/4] Onderdelen installeren/controleren...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r backend\requirements.txt
if errorlevel 1 (
  echo [FOUT] Installatie mislukt. Check je internetverbinding.
  pause
  exit /b 1
)

echo [3/4] REAPER-brug koppelen...
tasklist /FI "IMAGENAME eq reaper.exe" 2>nul | find /I "reaper.exe" >nul
if not errorlevel 1 (
  echo   ^!^!^! REAPER is nu OPEN — sluit REAPER eerst en start dit
  echo   bestand opnieuw, anders kan de brug niet koppelen ^!^!^!
  goto afterbridge
)
python -c "import reapy; reapy.config.configure_reaper(detect_portable_install=False)" >nul 2>nul
if errorlevel 1 (
  echo   ^(brug nog niet gekoppeld — gebruik in de app de knop KOPPEL BRUG^)
) else (
  echo   brug gekoppeld — open daarna REAPER en de app vindt hem
)
:afterbridge

if not exist "%USERPROFILE%\Desktop\G2B Engineer.lnk" (
  echo [4/4] Bureaublad-icoon maken...
  powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\G2B Engineer.lnk'); $s.TargetPath = '%~f0'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0g2b.ico'; $s.Save()" >nul 2>nul
)

echo.
echo   Engineer start op http://localhost:8300
echo   Browser opent vanzelf. Dit venster open laten!
echo.
start "" /min cmd /c "timeout /t 3 >nul & start http://localhost:8300"
cd backend
python -m uvicorn app.main:app --host 127.0.0.1 --port 8300
pause
