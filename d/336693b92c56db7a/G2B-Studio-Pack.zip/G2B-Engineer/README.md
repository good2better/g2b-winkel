# G2B Engineer

Jouw eigen mix/master-engineer — een lokale app die **REAPER** aanstuurt.
Upload stems (+ optioneel een referentie-hit), kies een stijl, en de
Engineer balanceert, EQ't, mastered en rendert — automatisch, in gewoon
Nederlands uitgelegd.

## Starten (Windows)
1. Installeer **REAPER** (gratis proef 60 dagen: https://www.reaper.fm).
2. Open REAPER (eenmalig, voor de eerste koppeling).
3. Dubbelklik **START-ENGINEER.bat** → browser opent op
   http://localhost:8300
4. Herstart REAPER één keer na de eerste start (brug-koppeling).
5. Daarna: stems erin → stijl → **BEREKEN PLAN** →
   **🎚 ZET IN REAPER + RENDER**.

## Hoe het werkt
- **Meten**: elke stem wordt gemeten (loudness, piek, frequentie-bands)
  en krijgt een rol (kick, bas, melodie...).
- **Plan**: de Engineer legt in gewone woorden uit wat hij gaat doen —
  volumes, EQ-dips waar stems vechten, pans voor breedte, en de
  master-keten (highpass, air, glue-comp, limiter).
- **Uitvoeren**: hij bouwt het REAPER-project via python-reapy,
  zet ReaEQ/ReaComp/ReaLimit op de master en rendert 2× — de tweede
  keer met de limiter bijgestuurd op de gemeten loudness.
- Alles non-destructief: jij kunt elke knop in REAPER daarna nog
  bijsturen.

## Stijlen
Schoon & Glans (G2B-standaard) · Drill · Amapiano/Kwayana · R&B ·
Dancehall/Bubbling — elk met eigen loudness-doel en karakter.

100% lokaal, geen AI, geen cloud. Jouw muziek blijft van jou.
