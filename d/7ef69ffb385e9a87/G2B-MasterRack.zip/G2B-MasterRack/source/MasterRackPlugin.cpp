#include "DistrhoPlugin.hpp"
#include <cstring>
#include <cmath>
#include <cstdint>
#include <algorithm>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
// SUB,POETS,KNIP,GLANS,RUIMTE,OUT(dB) — 0..1 behalve OUT
static const float kPresetParams[6][6] = {
    {0.55f,0.35f,0.40f,0.30f,0.30f, 0.f},  // G2B
    {0.60f,0.40f,0.45f,0.25f,0.22f, 0.f},  // DEMBOW
    {0.65f,0.45f,0.55f,0.15f,0.18f, 0.f},  // DRILL
    {0.45f,0.30f,0.30f,0.40f,0.35f, 0.f},  // RNB
    {0.50f,0.38f,0.42f,0.35f,0.28f, 0.f},  // HOUSE
    {0.55f,0.36f,0.40f,0.30f,0.26f, 0.f},  // AFRO
};

class MasterRackPlugin : public Plugin {
public:
    enum Params { kSub, kPoets, kKnip, kGlans, kRuimte, kOutput, kListen, kDice, kPreset, kNumParams };
    MasterRackPlugin() : Plugin(kNumParams, 0, 2) {
        memset(fBufL,0,sizeof(fBufL)); memset(fBufR,0,sizeof(fBufR));
        memset(fPreL,0,sizeof(fPreL)); memset(fPreR,0,sizeof(fPreR));
    }
protected:
    const char* getLabel() const override { return "G2B MasterRack"; }
    const char* getDescription() const override { return "Alles in één: sub+vet+luid+air+ruimte — de complete G2B-keten"; }
    const char* getMaker() const override { return "G2B"; }
    const char* getLicense() const override { return "Proprietary"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','M','r'); }

    void initParameter(uint32_t i, Parameter& p) override {
        p.hints=kParameterIsAutomatable;
        switch(i){
        case kSub:    p.name="SUB";     p.symbol="sub";     p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.55f;p.unit="%";break;
        case kPoets:  p.name="POETS";   p.symbol="poets";   p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.35f;p.unit="%";break;
        case kKnip:   p.name="KNIP";    p.symbol="knip";    p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.40f;p.unit="%";break;
        case kGlans:  p.name="GLANS";   p.symbol="glans";   p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.30f;p.unit="%";break;
        case kRuimte: p.name="RUIMTE";  p.symbol="ruimte";  p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.30f;p.unit="%";break;
        case kOutput: p.name="OUTPUT";  p.symbol="output";  p.ranges.min=-24.f;p.ranges.max=12.f;p.ranges.def=0.f;p.unit="dB";break;
        case kListen: p.name="LUISTER"; p.symbol="listen";  p.hints|=kParameterIsInteger|kParameterIsTrigger;p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.f;break;
        case kDice:   p.name="DICE";    p.symbol="dice";    p.hints|=kParameterIsInteger|kParameterIsTrigger;p.ranges.min=0.f;p.ranges.max=1.f;p.ranges.def=0.f;break;
        case kPreset: p.name="PRESET";  p.symbol="preset";  p.hints|=kParameterIsInteger; p.ranges.min=0.f;p.ranges.max=5.f;p.ranges.def=0.f;break;
        }
    }
    float getParameterValue(uint32_t i) const override {
        switch(i){case kSub:return fSub;case kPoets:return fPoets;case kKnip:return fKnip;case kGlans:return fGlans;case kRuimte:return fRuimte;case kOutput:return fOut;case kListen:return fListen;case kDice:return fDice;case kPreset:return fPreset;}return 0.f;
    }
    void setParameterValue(uint32_t i, float v) override {
        if(i==kPreset){applyPreset((int)(v+0.5f));return;}
        switch(i){case kSub:fSub=v;break;case kPoets:fPoets=v;break;case kKnip:fKnip=v;break;case kGlans:fGlans=v;break;case kRuimte:fRuimte=v;break;case kOutput:fOut=v;break;case kListen:
            fListen=v;
            if(v>0.9f){fListenN=(uint32_t)(2.f*getSampleRate());fAccRms=fAccLow=fAccAir=0;fPeak=0;}
            fListen=0.f;break;
            case kDice:fDice=v;if(v>0.5f)rollDice();fDice=0.f;break;}
    }
    void initState(uint32_t index, String& name, String& def) override {
        if(index==0){name="scope";def="";}
        else{name="presetnames";def="";for(int i=0;i<6;i++){def+=kPresetNames[i];if(i<5)def+=";";}}
    }
    void setState(const char* k, const char* v) override {(void)k;(void)v;}

    void run(const float** inputs, float** outputs, uint32_t frames) override {
        const float sr=getSampleRate();
        const float srInv=1.f/sr;
        // ---- voorberekeningen per module ----
        // SUB: lowpass-meting onder ~120Hz + tame-gain (0 = uit)
        const float subLpA=1.f-expf(-2.f*M_PI*140.f*srInv);
        // POETS: body-lift (laag-shelf ~200Hz), punch-volg-transient, sizzle-air ~10k
        const float bodyA=1.f-expf(-2.f*M_PI*200.f*srInv);
        const float airA =1.f-expf(-2.f*M_PI*9500.f*srInv);
        // KNIP: drive + plafond −1dB
        const float drive=1.f+fKnip*6.f, ceil=0.89f;
        // GLANS: air-boost dB = glans*6, breedte-factor op hoog
        const float airDb=fGlans*6.f, airGain=powf(10.f,airDb*0.05f);
        const float wGain=fGlans*0.6f;             // breedte op hoog
        // RUIMTE: delay+reverb (zelfde als Ruimte-plugin, vaste smaak)
        const int delSamps=(int)(0.27f*sr); const int preS=(int)(0.012f*sr);
        const float fb=fRuimte*0.72f, wet=fRuimte, wMix=0.35f;
        const float dmpA=1.f-expf(-2.f*M_PI*6000.f*srInv);
        const float outG=powf(10.f,fOut*0.05f);

        for(uint32_t i=0;i<frames;i++){
            float L=inputs[0][i], R=inputs[1][i];

            // LUISTER-analyse op input (lp250 + hp4k + rms)
            if(fListenN>0){
                fALpL+=(1.f-expf(-2.f*M_PI*250.f*srInv))*(L-fALpL);
                fAHpL+=(1.f-expf(-2.f*M_PI*4000.f*srInv))*(L-fAHpL);
                fAccRms+=fabsf(L);
                fAccLow+=fabsf(fALpL);
                fAccAir+=fabsf(L-fAHpL);
                float ax=fabsf(L);if(ax>fPeak)fPeak=ax;
                if(--fListenN==0) listenApply();
            }

            // 1) SUBTAMER: meet sub-energie, verzwak (damping)
            fSubLpL+=subLpA*(L-fSubLpL); fSubLpR+=subLpA*(R-fSubLpR);
            const float tame=1.f-fSub*0.5f;
            L-=fSubLpL*fSub*0.5f; R-=fSubLpR*fSub*0.5f;   // sub wordt rustiger
            // mono onder 120Hz: sub-deel naar midden
            float sM=(fSubLpL+fSubLpR)*0.5f;
            float sL=fSubLpL*tame+sM*fSub, sR=fSubLpR*tame+sM*fSub;
            L=L+fSubLpL-sL; R=R+fSubLpR-sR;

            // 2) POETS: punch(volg transient)+body(laag)+sizzle(air)
            float envL=fabsf(L), envR=fabsf(R);
            fEnvL+=0.01f*(envL-fEnvL); fEnvR+=0.01f*(envR-fEnvR);
            float trL=envL-fEnvL, trR=envR-fEnvR;          // transient-verschil
            fBodyL+=bodyA*(L-fBodyL); fBodyR+=bodyA*(R-fBodyR);
            fAirL+=airA*(L-fAirL);   fAirR+=airA*(R-fAirR);
            float pL=L + trL*fPoets*1.5f + fBodyL*fPoets*0.4f + (L-fAirL)*fPoets*0.25f;
            float pR=R + trR*fPoets*1.5f + fBodyR*fPoets*0.4f + (R-fAirR)*fPoets*0.25f;
            L=pL; R=pR;

            // tussen-begrenzer: vangt pieken na elke stage (altijd goed)
            L=tanhf(L);R=tanhf(R);

            // 3) KNIP: tanh-clipper met plafond
            L=clipAt(L*drive,ceil); R=clipAt(R*drive,ceil);

            // 4) GLANS: air-boost op hoog + breedte op hoog
            fGairL+=airA*(L-fGairL); fGairR+=airA*(R-fGairR);
            float hiL=L-fGairL, hiR=R-fGairR;
            L=fGairL+hiL*airGain; R=fGairR+hiR*airGain;
            float hiM=(hiL+hiR)*0.5f, hiS=(hiL-hiR)*0.5f*(1.f+wGain);
            hiL=hiM+hiS; hiR=hiM-hiS;
            L+=hiL*(airGain-1.f)*0.0f; // breedte loopt via hiS hierboven al

            L=tanhf(L);R=tanhf(R);   // stage-veiligheid 2

            // 5) RUIMTE: delay+reverb-chain (vaste smaak uit de Ruimte-plugin)
            fPreL[fPreW]=L; fPreR[fPreW]=R;
            int prI=(fPreW-preS+kMaxPre)%kMaxPre;
            float pPL=fPreL[prI], pPR=fPreR[prI]; fPreW=(fPreW+1)%kMaxPre;
            int r1=(fDelW-delSamps+kMaxDel)%kMaxDel, r2=(fDelW-delSamps*61/100+kMaxDel)%kMaxDel;
            float dL=fBufL[r1]+0.5f*fBufL[r2], dR=fBufR[r1]+0.5f*fBufR[r2];
            fDLpL+=dmpA*(dL-fDLpL); fDLpR+=dmpA*(dR-fDLpR);
            fBufL[fDelW]=pPL+fDLpL*fb; fBufR[fDelW]=pPR+fDLpR*fb; fDelW=(fDelW+1)%kMaxDel;
            float mW=(dL+dR)*0.5f, sW=(dL-dR)*0.5f*1.3f;
            L=(L*(1.f-wet*wMix)+(mW+sW)*wet)*outG;
            R=(R*(1.f-wet*wMix)+(mW-sW)*wet)*outG;

            outputs[0][i]=L; outputs[1][i]=R;
            if(++fDecim>=3){fDecim=0;if(fScopeN<40)fScope[fScopeN++]=(L+R)*0.5f;}
        }
        if(fScopeN>=40){
            char buf[256];int pos=0;
            for(uint32_t s=0;s<fScopeN&&pos<230;++s)pos+=snprintf(buf+pos,sizeof(buf)-pos,"%.3f;",fScope[s]);
            buf[pos]=0;setState("scope",buf);fScopeN=0;
        }
    }
private:
    void listenApply(){
        // stijl-doelen: hoeveel laag/air mag de stijl hebben {lowShare, airShare}
        static const float kTgt[6][2]={
            {0.35f,0.12f}, // G2B
            {0.45f,0.09f}, // DEMBOW (dikke sub hoort)
            {0.42f,0.10f}, // DRILL
            {0.32f,0.14f}, // RNB
            {0.38f,0.12f}, // HOUSE
            {0.37f,0.12f}  // AFRO
        };
        int pi=(int)(fPreset+0.5f);if(pi<0)pi=0;if(pi>5)pi=5;
        float tot=fAccRms+1e-9f;
        float lowShare=fAccLow/tot, airShare=fAccAir/tot, rms=fAccRms/(2.f*getSampleRate());
        float dSub=(lowShare-kTgt[pi][0])*2.5f, dGla=(kTgt[pi][1]-airShare)*5.f, dKni=(0.12f-rms)*3.f;
        float amax=fmaxf(fabsf(dSub),fmaxf(fabsf(dGla),fabsf(dKni)));
        if(amax<0.15f){
            setParameterValue(kListen,0.5f); // AL GOED
        }else{
            setParameterValue(kSub,  fminf(0.8f,fmaxf(0.2f,0.5f+dSub)));
            setParameterValue(kGlans,fminf(0.8f,fmaxf(0.2f,0.5f+dGla)));
            setParameterValue(kKnip, fminf(0.7f,fmaxf(0.15f,0.4f+dKni)));
            setParameterValue(kPoets,0.35f);
            setParameterValue(kRuimte,0.20f);
            setParameterValue(kListen,0.35f);
        }
        if(fPeak>0.9f){ setParameterValue(kOutput,-3.f); setParameterValue(kListen,0.75f); }
        fPeak=0.f;
    }
    void rollDice(){
        for(int p=kSub;p<=kRuimte;p++){
            fRnd=fRnd*1664525u+1013904223u;
            setParameterValue(p,((fRnd>>8)%100)/100.f);
        }
    }
    float fListen=0.f,fDice=0.f;
    uint32_t fListenN=0; float fAccRms=0,fAccLow=0,fAccAir=0,fALpL=0,fAHpL=0,fPeak=0;
    unsigned fRnd=777777;
    static inline float clipAt(float x,float c){
        const float th=c*0.9f;
        if(x>th) return c*tanhf((x-th)/(c-th))*1.f+th;   // zachte knie boven 90%
        if(x<-th) return -c*tanhf((-x-th)/(c-th))*1.f-th;
        return x;
    }
    void applyPreset(int i){
        if(i<0)i=0;if(i>5)i=5;fPreset=(float)i;
        setParameterValue(kSub,kPresetParams[i][0]);
        setParameterValue(kPoets,kPresetParams[i][1]);
        setParameterValue(kKnip,kPresetParams[i][2]);
        setParameterValue(kGlans,kPresetParams[i][3]);
        setParameterValue(kRuimte,kPresetParams[i][4]);
        setParameterValue(kOutput,kPresetParams[i][5]);
    }
    float fSub=0.55f,fPoets=0.35f,fKnip=0.40f,fGlans=0.30f,fRuimte=0.30f,fOut=0.f,fPreset=0.f;
    float fSubLpL=0,fSubLpR=0,fEnvL=0,fEnvR=0,fBodyL=0,fBodyR=0,fAirL=0,fAirR=0,fGairL=0,fGairR=0;
    static const int kMaxDel=96000*2, kMaxPre=4800;
    float fBufL[kMaxDel],fBufR[kMaxDel],fPreL[kMaxPre],fPreR[kMaxPre];
    float fDLpL=0,fDLpR=0;int fDelW=0,fPreW=0;
    float fScope[40];uint32_t fScopeN=0;int fDecim=0;
    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MasterRackPlugin)
};
Plugin* createPlugin(){return new MasterRackPlugin();}
END_NAMESPACE_DISTRHO
