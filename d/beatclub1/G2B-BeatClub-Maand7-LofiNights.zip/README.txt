G2B BEAT-CLUB — MAAND 7: LOFI NIGHTS
====================================
16 club-exclusives: lofi kicks/snares, vinyl-knits, rhodes-akkoord,
zachte bassen, rain/pluck/texturen + complete 76bpm-loop.
Past naadloos bij de "Rainy Sunday" sync-track — maak je eigen lo-fi.

© G2B — alleen voor Beat-Club leden, exclusieve rechten inbegrepen.
