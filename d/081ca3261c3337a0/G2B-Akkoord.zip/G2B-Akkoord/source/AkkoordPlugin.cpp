#include "DistrhoPlugin.hpp"
#include <cstring>
#include <cmath>
#include <cstdint>
#include <algorithm>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
// VOICING(0-5 = kwaliteit), TIMBRE(0 pluck→1 pad), OCTAVE(-2..2), DECAY(0.1-4s), LEVEL(0-1), —
static const float kPresetParams[6][5] = {
    {1.f, 0.35f, 0.f, 1.6f, 0.8f},   // G2B    — min9 warm
    {4.f, 0.15f, 0.f, 0.5f, 0.85f},  // DEMBOW — korte minor stab
    {2.f, 0.30f, -1.f,1.2f, 0.8f},   // DRILL  — donkere minor triad, oktaaf lager
    {0.f, 0.60f, 0.f, 2.2f, 0.8f},   // RNB    — maj7 pad
    {3.f, 0.20f, 0.f, 0.9f, 0.85f},  // HOUSE  — maj stab
    {5.f, 0.30f, 0.f, 1.1f, 0.82f},  // AFRO   — sus2/7 groove
};

// voicing-sets (halve tonen t.o.v. root), max 5 noten
static const int kVoicings[6][5] = {
    {0,4,7,11,-999},      // maj7
    {0,3,7,10,14},        // min9
    {0,3,7,-999,-999},    // minor triad
    {0,4,7,-999,-999},    // maj stab
    {0,3,10,-999,-999},   // min7 stab
    {0,7,10,14,-999},     // sus/7 afro
};

struct ChordVoice {
    bool active=false; float freq=0,phase=0,amp=0,vel=0; int age=0; float lp=0; int delay=0;
};

static const int kScales[2][7] = {
    {0,2,3,5,7,8,10},   // minor
    {0,2,4,5,7,9,11},   // major
};

class AkkoordPlugin : public Plugin {
public:
    enum Params { kVoicing,kTimbre,kOctave,kDecay,kLevel,kKey,kScale,kStrum,kHuman,kDice,kAuto,kPreset,kNumParams };
    AkkoordPlugin() : Plugin(kNumParams, 0, 2) {}
protected:
    const char* getLabel() const override { return "G2B Akkoord"; }
    const char* getDescription() const override { return "Eén toets = een heel akkoord in jouw stijl"; }
    const char* getMaker() const override { return "G2B"; }
    const char* getLicense() const override { return "Proprietary"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','A','k'); }

    void initParameter(uint32_t i, Parameter& p) override {
        p.hints=kParameterIsAutomatable;
        switch(i){
        case kVoicing:p.name="VOICING";p.symbol="voicing";p.hints|=kParameterIsInteger;p.ranges.min=0;p.ranges.max=5;p.ranges.def=1;break;
        case kTimbre: p.name="TIMBRE"; p.symbol="timbre"; p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.35f;p.unit="";break;
        case kOctave: p.name="OCTAVE"; p.symbol="octave"; p.hints|=kParameterIsInteger;p.ranges.min=-2;p.ranges.max=2;p.ranges.def=0;break;
        case kDecay:  p.name="DECAY";  p.symbol="decay";  p.ranges.min=0.1f;p.ranges.max=4.f;p.ranges.def=1.6f;p.unit="s";break;
        case kLevel:  p.name="LEVEL";  p.symbol="level";  p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.8f;p.unit="%";break;
        case kKey:    p.name="KEY";    p.symbol="key";    p.hints|=kParameterIsInteger;p.ranges.min=0;p.ranges.max=11;p.ranges.def=0;break;
        case kScale:  p.name="SCALE";  p.symbol="scale";  p.hints|=kParameterIsInteger;p.ranges.min=0;p.ranges.max=1;p.ranges.def=0;break;
        case kStrum:  p.name="STRUM";  p.symbol="strum";  p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.f;p.unit="%";break;
        case kHuman:  p.name="HUMANIZE";p.symbol="human"; p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.3f;p.unit="%";break;
        case kPreset: p.name="PRESET"; p.symbol="preset"; p.hints|=kParameterIsInteger;p.ranges.min=0;p.ranges.max=5;p.ranges.def=0;break;
        }
    }
    float getParameterValue(uint32_t i) const override {
        switch(i){case kVoicing:return fVoicing;case kTimbre:return fTimbre;case kOctave:return fOctave;case kDecay:return fDecay;case kLevel:return fLevel;case kKey:return fKey;case kScale:return fScale;case kStrum:return fStrum;case kHuman:return fHuman;case kDice:return fDice;case kAuto:return fAuto;case kPreset:return fPreset;}return 0.f;
    }
    void setParameterValue(uint32_t i, float v) override {
        if(i==kPreset){applyPreset((int)(v+0.5f));return;}
        switch(i){case kVoicing:fVoicing=v;break;case kTimbre:fTimbre=v;break;case kOctave:fOctave=v;break;case kDecay:fDecay=v;break;case kLevel:fLevel=v;break;case kKey:fKey=v;break;case kScale:fScale=v;break;case kStrum:fStrum=v;break;case kHuman:fHuman=v;break;case kDice:fDice=v;if(v>0.5f)rollDice();fDice=0.f;break;case kAuto:fAuto=v;break;}
    }
    void initState(uint32_t index, String& name, String& def) override {
        if(index==0){name="scope";def="";}
        else{name="presetnames";def="";for(int i=0;i<6;i++){def+=kPresetNames[i];if(i<5)def+=";";}}
    }
    void setState(const char* k, const char* v) override {(void)k;(void)v;}

    void run(const float** in, float** out, uint32_t frames, const MidiEvent* midi, uint32_t midiCount) override {
        const float sr=getSampleRate();
        // MIDI events eerst
        for(uint32_t m=0;m<midiCount;m++){
            const MidiEvent& ev=midi[m];
            if(ev.size<4) continue;
            const uint8_t st=ev.data[0]&0xF0;
            if(st==0x90 && ev.data[2]>0){          // noteOn
                const int root=snap(ev.data[1]); const float vel=ev.data[2]/127.f;
                const int* voic=kVoicings[(int)fVoicing<0?0:((int)fVoicing>5?5:(int)fVoicing)];
                float strumMax=fStrum*0.030f*sr;   // tot 30ms per extra noot
                if(fAuto>0.5f){ fRnd=(fRnd*1664525u+1013904223u); strumMax*=(0.7f+(fRnd%1000)/1000.f*0.8f); }
                for(int n=0;n<5;n++){
                    if(voic[n]<=-999) break;
                    const float f=440.f*powf(2.f,((snap(root+voic[n])+(int)fOctave*12)-69)/12.f);
                    const float hv=1.f+fHuman*0.35f*((fRnd=(fRnd*1664525u+1013904223u))%1000/1000.f*2.f-1.f);
                    for(auto& v:fV){ if(!v.active){ v.active=true;v.freq=f;v.phase=0;v.amp=0;v.vel=vel*hv;v.age=0;v.lp=0;v.delay=(int)(strumMax*n); break; } }
                }
            }
        }
        const float decRate=expf(-1.f/(fDecay*sr));
        const float cutHz=600.f+fTimbre*6000.f;
        const float lpA=1.f-expf(-2.f*M_PI*cutHz/sr);
        for(uint32_t i=0;i<frames;i++){
            float o=0.f;
            for(auto& v:fV){
                if(!v.active) continue;
                if(v.delay>0){ v.delay--; continue; }
                if(v.amp<0.001f) v.amp=v.vel;   // start na strum-delay
                // osc: sine + driehoek-blend (pluck↔pad), via timbre
                float ph=v.phase*2.f*M_PI;
                float s=sinf(ph)*(1.f-fTimbre*0.5f)+ (2.f*fabsf(2.f*(v.phase-floorf(v.phase))-1.f)-1.f)*fTimbre*0.35f;
                v.lp+=lpA*(s-v.lp);
                o+=v.lp*v.amp;
                v.phase+=v.freq/sr; if(v.phase>1.f)v.phase-=1.f;
                v.amp*=decRate; v.age++;
                if(v.amp<0.0003f)v.active=false;
            }
            o=tanhf(o*1.4f)*fLevel;
            out[0][i]=o; out[1][i]=o;
            if(++fDecim>=3){fDecim=0;if(fScopeN<40)fScope[fScopeN++]=o;}
        }
        if(fScopeN>=40){
            char buf[256];int pos=0;
            for(uint32_t s=0;s<fScopeN&&pos<230;++s)pos+=snprintf(buf+pos,sizeof(buf)-pos,"%.3f;",fScope[s]);
            buf[pos]=0;setState("scope",buf);fScopeN=0;
        }
    }
private:
    int snap(int midi) const {
        // quantize naar KEY+SCALE — elke toets klinkt in key
        int key=(int)fKey, sc=(int)fScale<0?0:((int)fScale>1?1:(int)fScale);
        int pc=((midi-key)%12+12)%12;
        int best=kScales[sc][0],bd=99;
        for(int i=0;i<7;i++){int d=abs(pc-kScales[sc][i]);if(d<bd){bd=d;best=kScales[sc][i];}}
        return midi-pc+best;
    }
    void rollDice(){
        fRnd=fRnd*1664525u+1013904223u;
        setParameterValue(kVoicing,(float)((fRnd>>8)%6));
        fRnd=fRnd*1664525u+1013904223u;
        setParameterValue(kTimbre,((fRnd>>8)%100)/100.f);
        fRnd=fRnd*1664525u+1013904223u;
        setParameterValue(kStrum,((fRnd>>8)%40)/100.f);
        fRnd=fRnd*1664525u+1013904223u;
        setParameterValue(kHuman,((fRnd>>8)%60)/100.f);
    }
    void applyPreset(int i){
        if(i<0)i=0;if(i>5)i=5;fPreset=(float)i;
        setParameterValue(kVoicing,kPresetParams[i][0]);
        setParameterValue(kTimbre,kPresetParams[i][1]);
        setParameterValue(kOctave,kPresetParams[i][2]);
        setParameterValue(kDecay,kPresetParams[i][3]);
        setParameterValue(kLevel,kPresetParams[i][4]);
    }
    float fVoicing=1.f,fTimbre=0.35f,fOctave=0.f,fDecay=1.6f,fLevel=0.8f,fKey=0.f,fScale=0.f,fStrum=0.f,fHuman=0.3f,fPreset=0.f,fDice=0.f,fAuto=0.f;
    ChordVoice fV[24];
    unsigned fRnd=54321;
    float fScope[40];uint32_t fScopeN=0;int fDecim=0;
    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AkkoordPlugin)
};
Plugin* createPlugin(){return new AkkoordPlugin();}
END_NAMESPACE_DISTRHO
