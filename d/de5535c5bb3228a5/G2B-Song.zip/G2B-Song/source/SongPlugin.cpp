// G2B Song — all-in-one beat engine: drums + bas + akkoorden + melodie
// één scherm, tempo-sync, key-locked, engine-bewaking vanaf nul
#include "DistrhoPlugin.hpp"
#include <cmath>
#include <cstring>

START_NAMESPACE_DISTRHO

static const char kScaleM[7]={0,2,3,5,7,8,10};
static const char kScaleJ[7]={0,2,4,5,7,9,11};
// stijl-patternsets: {kick, snare, hat} 16 steps
static const char kPat[5][3][17]={
    {"x...x...x...x...","....x.......x...","x.x.x.x.x.x.x.x."}, // DEMBOW
    {"x.....x..x......","....x.......x...","x.xxx..x.xx.x.x."}, // DRILL
    {"x.....x...x.....","....x.......x...","x..x..x..x..x..x"}, // RNB
    {"x...x...x...x...","....x.......x...","..x...x...x...x."}, // HOUSE
    {"x..x....x..x....","....x.......x...","x.x..x.x.x.x..x."}  // AFRO
};
// baslijn per stijl (scale-degree, -1=rust), 8 steps per 2 bars → gekoppeld aan 16-step grid x2
static const char kBasPat[5][8]={
    {0,-1,0,-1,3,-1,0,-1},  // DEMBOW
    {0,-1,-1,5,-1,0,-1,-1}, // DRILL
    {0,-1,-1,-1,5,-1,-1,-1},// RNB
    {0,0,-1,-1,0,-1,5,-1},  // HOUSE
    {0,-1,3,-1,0,-1,5,-1}   // AFRO
};
// akkoord-voicing min9 {root, min3, min7, 9} relatieven op tonic
static const char kChr[4]={0,3,10,14};

class SongPlugin : public Plugin
{
public:
    SongPlugin() : Plugin(11, 0, 0) {}

protected:
    const char* getLabel() const override { return "G2B Song"; }
    const char* getDescription() const override { return "All-in-one beat engine"; }
    const char* getMaker() const override { return "G2B"; }
    const char* getLicense() const override { return "MIT"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','S','o'); }

    void initState(uint32_t, String&, String&) override {}
    void setState(const char*, const char*) override {}

    enum { kStijl, kKey, kScale, kDrums, kBas, kChord, kMel, kDice, kAuto, kLight, kPreset };

    void initParameter(uint32_t i, Parameter& p) override {
        p.hints = kParameterIsAutomable;
        switch(i){
        case kStijl: p.name="STYLE"; p.symbol="style"; p.ranges.min=0; p.ranges.max=4; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kKey:   p.name="KEY";   p.symbol="key";   p.ranges.min=0; p.ranges.max=11; p.ranges.def=9; p.hints|=kParameterIsInteger; break;
        case kScale: p.name="SCALE"; p.symbol="scale"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kDrums: p.name="DRUMS"; p.symbol="drums"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.8f; break;
        case kBas:   p.name="BAS";   p.symbol="bas";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.7f; break;
        case kChord: p.name="CHORD"; p.symbol="chord"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.6f; break;
        case kMel:   p.name="MEL";   p.symbol="mel";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.6f; break;
        case kDice:  p.name="DICE";  p.symbol="dice";  p.ranges.min=0; p.ranges.max=1; p.hints|=kParameterIsTrigger; break;
        case kAuto:  p.name="AUTO";  p.symbol="auto";  p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kLight: p.name="LIGHT"; p.symbol="light"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kPreset:p.name="PRESET";p.symbol="preset";p.ranges.min=0; p.ranges.max=4; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        }
    }

    float getParameterValue(uint32_t i) const override {
        switch(i){case kStijl:return fStijl;case kKey:return fKey;case kScale:return fScale;
                  case kDrums:return fDrums;case kBas:return fBas;case kChord:return fChord;
                  case kMel:return fMel;case kDice:return fDice;case kAuto:return fAuto;
                  case kLight:return fLight;case kPreset:return fPreset;}return 0.f;
    }

    void setParameterValue(uint32_t i, float v) override {
        switch(i){
        case kStijl:fStijl=v;break; case kKey:fKey=v;break; case kScale:fScale=v;break;
        case kDrums:fDrums=v;break; case kBas:fBas=v;break; case kChord:fChord=v;break;
        case kMel:fMel=v;break;
        case kDice:if(v>0.5f)rollDice();fDice=0;break;
        case kAuto:fAuto=v;break; case kLight:fLight=v;break;
        case kPreset:if(v!=fPreset)applyPreset((int)v);fPreset=v;break;
        }
    }

    void run(const float** in, float** out, uint32_t frames, const MidiEvent*, uint32_t) override {
        const float sr=getSampleRate();
        double bpm=100.0;
        const TimePosition& tp=getTimePosition();
        if(tp.playing && tp.bbt.valid && tp.bbt.beatsPerMinute>1.0) bpm=tp.bbt.beatsPerMinute;
        const double stepLen=60.0/bpm/4.0;
        const int st=clampi(fStijl,0,4);
        for(uint32_t i=0;i<frames;i++){
            fPhase+=1.0/sr;
            if(fPhase>=stepLen){
                fPhase=0; fStep++;
                int s=(int)fStep%16;
                if(fAuto>0.5f && s==0 && (fStep%64)==0) rollDice();
                // drums
                if(kPat[st][0][s]!='.'){kick();}
                if(kPat[st][1][s]!='.'){snare();}
                if(kPat[st][2][s]!='.'){hat();}
                // bas op even steps
                int b8=(s/2)%8;
                if(s%2==0 && kBasPat[st][b8]>=0){bass(deg2midi(kBasPat[st][b8]));}
                // chord elke maat 1 + melodie op beat-starts
                if(s==0)chord();
                if(s%4==0)melody();
                char sb[8];std::snprintf(sb,sizeof(sb),"%d",s);setState("step",sb);
            }
            float o=0.f;
            o+=drumRender();
            o+=basRender(sr);
            o+=chordRender(sr);
            o+=melRender(sr);
            o=tanhf(o*1.4f)*0.8f;           // engine-tamer: nooit kapot
            out[0][i]=o; out[1][i]=o;
        }
    }

private:
    static int clampi(float v,int a,int b){int x=(int)(v+0.5f);return x<a?a:(x>b?b:x);}
    float frand(uint32_t& s){s=s*1664525u+1013904223u;return (s>>9)*(1.f/8388608.f);}

    int deg2midi(int deg){
        const char* sc=fScale>0.5f?kScaleJ:kScaleM;
        int d=deg%7; if(d<0)d+=7;
        return 36+(int)fKey+sc[d]+12*(deg/7);
    }

    // ---- voices ----
    struct DV{bool on;int type;float t,f0,f1,dec,amp;DV():on(false),type(0),t(0),f0(0),f1(0),dec(.1f),amp(.5f){}};
    DV dv_[3];
    void dv(int i,int ty,float f0,float f1,float dec,float amp){
        DV&v=dv_[i];v.on=true;v.type=ty;v.t=0;v.f0=f0;v.f1=f1;v.dec=dec;v.amp=amp;}
    void kick(){dv(0,0,150.f,48.f,.28f,.9f);}
    void snare(){dv(1,1,190.f,170.f,.16f,.5f);}
    void hat(){dv(2,2,0.f,0.f,.05f,.3f);}
    float drumRender(){
        float o=0;
        for(auto&v:dv_){if(!v.on)continue;v.t+=1.f/getSampleRate();
            float e=expf(-v.t/v.dec*5.f),s=0;
            if(v.type==0){float f=v.f1+(v.f0-v.f1)*expf(-v.t*30.f);s=sinf(2*M_PI*f*v.t)*e;}
            else if(v.type==1){s=(frand(fNs)*2-1)*e*0.7f+sinf(2*M_PI*v.f0*v.t)*e*0.4f;}
            else{s=(frand(fNs)*2-1)*e*0.8f;}
            o+=s*v.amp; if(e<0.001)v.on=false;}
        return o*fDrums;
    }

    struct BV{bool on;float t,f,amp;BV():on(false),t(0),f(55),amp(.6f){}};
    BV bv_;
    void bass(int m){bv_.on=true;bv_.t=0;bv_.f=440*powf(2,(m-69)/12.f);}
    float basRender(float sr){
        if(!bv_.on)return 0;
        bv_.t+=1.f/sr;
        float e=expf(-bv_.t*3.2f);
        float s=tanhf(sinf(2*M_PI*bv_.f*bv_.t)*(1.f+0.4f))*e;
        if(e<0.002)bv_.on=false;
        return s*fBas*0.5f;
    }

    struct CV{bool on;float t;float f[4];CV():on(false),t(0){f[0]=f[1]=f[2]=f[3]=0;}};
    CV cv_;
    void chord(){
        cv_.on=true;cv_.t=0;
        for(int j=0;j<4;j++)cv_.f[j]=440*powf(2,(deg2midi(kChr[j])+12-69)/12.f);
    }
    float chordRender(float sr){
        if(!cv_.on)return 0;
        cv_.t+=1.f/sr;
        float e=expf(-cv_.t*0.9f);
        float s=0;for(int j=0;j<4;j++)s+=sinf(2*M_PI*cv_.f[j]*cv_.t)*0.22f+sinf(2*M_PI*cv_.f[j]*2*cv_.t)*e*0.06f;
        if(e<0.004)cv_.on=false;
        return s*fChord;
    }

    struct MV{bool on;float t,f,amp;MV():on(false),t(0),f(440),amp(.5f){}};
    MV mv_;int fMelDeg=0;
    void melody(){
        // random-walk in scale: -1..+2 graden
        int mv=(int)(frand(fRs)*4)-1;
        fMelDeg+=mv; if(fMelDeg<0)fMelDeg+=7; if(fMelDeg>10)fMelDeg-=7;
        int oct=(fMelDeg/7)*12; int d=fMelDeg%7;
        const char* sc=fScale>0.5f?kScaleJ:kScaleM;
        mv_.f=440*powf(2,((int)fKey+sc[d]+oct+12-69)/12.f);
        mv_.on=true;mv_.t=0;
    }
    float melRender(float sr){
        if(!mv_.on)return 0;
        mv_.t+=1.f/sr;
        float e=expf(-mv_.t*2.4f);
        float s=(sinf(2*M_PI*mv_.f*mv_.t)+0.3f*sinf(2*M_PI*mv_.f*2*mv_.t)*e)*e;
        if(e<0.003)mv_.on=false;
        return s*fMel*0.5f;
    }

    void rollDice(){
        for(int b=0;b<6;b++)frand(fRs);
        int st=(int)(frand(fRs)*5); setParameterValue(kStijl,st);
        setParameterValue(kDrums,0.6f+frand(fRs)*0.4f);
        setParameterValue(kBas,0.5f+frand(fRs)*0.5f);
        setParameterValue(kChord,0.4f+frand(fRs)*0.6f);
        setParameterValue(kMel,0.4f+frand(fRs)*0.6f);
        fMelDeg=(int)(frand(fRs)*7);
    }
    void applyPreset(int i){
        i=clampi(i,0,4);
        setParameterValue(kStijl,i);
        setParameterValue(kDrums,0.8f); setParameterValue(kBas,0.7f);
        setParameterValue(kChord,0.6f); setParameterValue(kMel,0.6f);
    }

    float fStijl=0,fKey=9,fScale=0,fDrums=.8f,fBas=.7f,fChord=.6f,fMel=.6f;
    float fDice=0,fAuto=0,fLight=0,fPreset=0;
    double fPhase=1.0; uint64_t fStep=0;
    uint32_t fNs=1234,fRs=777;
};

Plugin* createPlugin(){ return new SongPlugin(); }
END_NAMESPACE_DISTRHO
