// G2B Song UI — all-in-one beat engine scherm
#include "DistrhoUI.hpp"
#include <cstring>
#include <cstdio>
#include <cmath>

START_NAMESPACE_DISTRHO

class SongUI : public UI
{
public:
    SongUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[7] = {0,0,0,0,0,0,0};
        static const float maxs[7] = {4,11,1,1,1,1,1};
        static const float defs[7] = {0,9,0,0.8f,0.7f,0.6f,0.6f};
        static const char* lbl[7]  = {"STYLE","KEY","SCALE","DRUMS","BAS","CHORD","MEL"};
        std::memcpy(fMin, mins, sizeof(mins));
        std::memcpy(fMax, maxs, sizeof(maxs));
        std::memcpy(fValue, defs, sizeof(defs));
        std::memcpy(fLabel, lbl, sizeof(lbl));
        std::memset(fScope, 0, sizeof(fScope));
        fScopePos=0; fDrag=-1; fLastY=0; fStep=-1; fAuto=0; fLight=0; fPreset=0;
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if(index<7) fValue[index]=value;
        else if(index==8) fAuto=value;
        else if(index==9) fLight=value;
        else if(index==10) fPreset=value;
        repaint();
    }
    void stateChanged(const char* key, const char* value) override
    {
        if(std::strcmp(key,"step")==0) fStep=std::atoi(value);
        repaint();
    }
    void uiIdle() override { repaint(); }

    void onNanoDisplay() override
    {
        const float W=getWidth(), H=getHeight();
        const float bg[3] = {fLight?228.f:13.f, fLight?232.f:15.f, fLight?230.f:14.f};
        const float pn[3] = {fLight?214.f:23.f, fLight?220.f:26.f, fLight?217.f:25.f};
        const float tx[3] = {fLight?28.f:232.f, fLight?34.f:236.f, fLight?31.f:234.f};
        const float gy[3] = {fLight?96.f:143.f, fLight?108.f:160.f, fLight?101.f:152.f};
        const float ed[3]={42,47,45};
        const float GR[3]={47,191,113}, DG[3]={29,122,72};
        beginPath(); rect(0,0,W,H); fillColor(bg[0],bg[1],bg[2]); fill();

        fontSize(20.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(GR[0],GR[1],GR[2]);
        text(18,22,"G2B SONG",nullptr);
        fontSize(9.0f); fillColor(gy[0],gy[1],gy[2]);
        text(18,41,"all-in-one beat engine — in key, op tempo",nullptr);

        // preset-rij (stijlen)
        static const char* names[5]={"G2B","DEMBOW","DRILL","RNB","HOUSE"};
        float bx=W-14.f;
        for(int i=4;i>=0;i--){
            float bw=58.f; bx-=bw+4;
            beginPath(); roundedRect(bx,12,bx?bw:bw,17,4);
            if((int)fPreset==i) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
            fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.0f); stroke();
            fontSize(9.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor((int)fPreset==i?tx[0]:gy[0],(int)fPreset==i?tx[1]:gy[1],(int)fPreset==i?tx[2]:gy[2]);
            text(bx+bw/2,20.5f,names[i],nullptr);
        }
        // dice + auto + light control-bar
        beginPath(); roundedRect(14,48,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(11.f); fillColor(tx[0],tx[1],tx[2]);
        text(27,56.5f,"\xF0\x9F\x8E\xB2",nullptr);
        beginPath(); roundedRect(44,48,42,17,4);
        if(fAuto>0.5f) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
        fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(8.5f); fillColor(fAuto>0.5f?tx[0]:gy[0],fAuto>0.5f?tx[1]:gy[1],fAuto>0.5f?tx[2]:gy[2]);
        text(65,56.5f,"AUTO",nullptr);
        float tlx=W-40.f;
        beginPath(); roundedRect(tlx,34,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(10.f); fillColor(tx[0],tx[1],tx[2]);
        text(tlx+13,42.5f,fLight?"\xF0\x9F\x8C\x99":"\xE2\x98\x80",nullptr);

        // part-activiteit: 4 rijen DRUM/BAS/CHORD/MEL met step-indicator
        static const char* parts[4]={"DRUMS","BAS","CHORD","MEL"};
        static const unsigned char pc[4][3]={{47,191,113},{242,155,42},{66,135,245},{235,205,60}};
        for(int r=0;r<4;r++){
            float y=74.f+r*16.f;
            fontSize(8.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
            fillColor(pc[r][0],pc[r][1],pc[r][2]);
            text(18,y+4,parts[r],nullptr);
            for(int s=0;s<16;s++){
                beginPath(); rect(74.f+s*(W-96.f)/16.f,y+1.f,(W-96.f)/16.f-3.f,7.f);
                fillColor(s==fStep%16?pc[r][0]:ed[0],s==fStep%16?pc[r][1]:ed[1],s==fStep%16?pc[r][2]:ed[2]);
                fill();
            }
        }

        // knobs
        for(int i=0;i<7;i++){
            float cx=20+(W-40)/7.f*(i+0.5f), cy=175, R=24;
            float norm=(fValue[i]-fMin[i])/(fMax[i]-fMin[i]); if(norm<0)norm=0; if(norm>1)norm=1;
            float ang=-2.4f+norm*4.8f;
            beginPath(); arc(cx,cy,R,0,6.2832f,CW); fillColor(pn[0],pn[1],pn[2]); fill();
            strokeColor(ed[0],ed[1],ed[2]); strokeWidth(2.f); stroke();
            beginPath(); arc(cx,cy,R-4.f,-2.4f-1.5708f,ang-1.5708f,CW);
            strokeColor(GR[0],GR[1],GR[2]); strokeWidth(3.f); stroke();
            beginPath(); moveTo(cx,cy); lineTo(cx+sinf(ang)*(R-8),cy-cosf(ang)*(R-8));
            strokeColor(tx[0],tx[1],tx[2]); strokeWidth(3.f); stroke();
            fontSize(9.5f); textAlign(ALIGN_CENTER|ALIGN_TOP);
            fillColor(gy[0],gy[1],gy[2]); text(cx,cy+R+8,fLabel[i],nullptr);
            static const char* stn[5]={"G2B","DEMBOW","DRILL","RNB","HOUSE"};
            static const char* kn[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
            char buf[16];
            if(i==0) std::snprintf(buf,16,"%s",stn[(int)fValue[0]]);
            else if(i==1) std::snprintf(buf,16,"%s",kn[(int)fValue[1]]);
            else if(i==2) std::snprintf(buf,16,"%s",fValue[2]>0.5f?"major":"minor");
            else std::snprintf(buf,16,"%.0f%%",fValue[i]*100.f);
            fillColor(tx[0],tx[1],tx[2]); text(cx,cy+R+21,buf,nullptr);
        }
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if(ev.press&&ev.button==1){
            const float W=getWidth();
            // presets
            float bx=W-14.f;
            for(int i=4;i>=0;i--){float bw=58.f;bx-=bw+4;
                if(ev.pos.getX()>=bx&&ev.pos.getX()<=bx+bw&&ev.pos.getY()>=12&&ev.pos.getY()<=29){
                    setParameterValue(10,(float)i);fPreset=i;repaint();return true;}}
            if(ev.pos.getX()>=14&&ev.pos.getX()<=40&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                setParameterValue(7,1.f);return true;}
            if(ev.pos.getX()>=44&&ev.pos.getX()<=86&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                fAuto=fAuto>0.5f?0.f:1.f;setParameterValue(8,fAuto);repaint();return true;}
            if(ev.pos.getX()>=W-40&&ev.pos.getX()<=W-14&&ev.pos.getY()>=34&&ev.pos.getY()<=51){
                fLight=fLight>0.5f?0.f:1.f;setParameterValue(9,fLight);repaint();return true;}
            for(int i=0;i<7;i++){
                float cx=20+(W-40)/7.f*(i+0.5f),cy=175,R=24;
                float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
                if(dx*dx+dy*dy<(R+8)*(R+8)){fDrag=i;fLastY=ev.pos.getY();return true;}
            }
        }
        if(fDrag>=0&&ev.press==false){fDrag=-1;repaint();return true;}
        return false;
    }
    bool onMotion(const MotionEvent& ev) override
    {
        if(fDrag<0)return false;
        float dy=fLastY-ev.pos.getY(); fLastY=ev.pos.getY();
        float range=fMax[fDrag]-fMin[fDrag];
        float v=fValue[fDrag]+dy*range/200.f;
        if(v<fMin[fDrag])v=fMin[fDrag];if(v>fMax[fDrag])v=fMax[fDrag];
        fValue[fDrag]=v; setParameterValue(fDrag,v); repaint(); return true;
    }

private:
    float fValue[7],fMin[7],fMax[7];
    const char* fLabel[7];
    float fScope[128]; int fScopePos;
    int fDrag; float fLastY;
    int fStep; float fAuto,fLight,fPreset;
};

UI* createUI(){ return new SongUI(); }
END_NAMESPACE_DISTRHO
