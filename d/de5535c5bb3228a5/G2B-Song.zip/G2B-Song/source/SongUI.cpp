// G2B Song UI — all-in-one beat engine scherm
#include "DistrhoUI.hpp"
#include <cstring>
#include <cstdio>
#include <cmath>

START_NAMESPACE_DISTRHO

class SongUI : public UI
{
public:
    SongUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[7] = {0,0,0,0,0,0,0};
        static const float maxs[7] = {4,11,1,1,1,1,1};
        static const float defs[7] = {0,9,0,0.8f,0.7f,0.6f,0.6f};
        static const char* lbl[7]  = {"STYLE","KEY","SCALE","DRUMS","BAS","CHORD","MEL"};
        std::memcpy(fMin, mins, sizeof(mins));
        std::memcpy(fMax, maxs, sizeof(maxs));
        std::memcpy(fValue, defs, sizeof(defs));
        std::memcpy(fLabel, lbl, sizeof(lbl));
        std::memset(fScope, 0, sizeof(fScope));
        fScopePos=0; fDrag=-1; fLastY=0; fStep=-1; fAuto=0; fLight=0; fPreset=0;
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if(index<7) fValue[index]=value;
        else if(index==8) fAuto=value;
        else if(index==9) fLight=value;
        else if(index==10) fPreset=value;
        repaint();
    }
    void stateChanged(const char* key, const char* value) override
    {
        if(std::strcmp(key,"step")==0) fStep=std::atoi(value);
        repaint();
    }
    void uiIdle() override { repaint(); }

    void onNanoDisplay() override
    {
        const float W=getWidth(), H=getHeight();
        static const float SK[8][7][3]={
            {{13,15,14},{23,26,25},{232,236,234},{100,110,103},{42,47,45},{47,191,113},{29,122,72}},
            {{14,14,22},{22,22,34},{230,232,255},{110,110,150},{40,40,58},{120,110,255},{70,60,170}},
            {{10,20,22},{16,30,32},{225,245,245},{95,130,130},{30,55,55},{40,200,210},{20,120,130}},
            {{24,14,20},{34,20,28},{250,230,240},{150,105,125},{60,38,50},{255,110,180},{180,60,120}},
            {{228,230,232},{240,242,244},{30,34,38},{105,112,118},{205,210,214},{40,140,100},{20,100,70}},
            {{18,10,10},{28,16,16},{240,225,220},{140,100,95},{55,35,32},{200,80,60},{130,45,35}},
            {{14,14,10},{22,22,16},{245,240,220},{120,115,95},{50,48,35},{230,190,80},{160,125,45}},
            {{12,14,20},{20,24,32},{235,240,250},{105,115,135},{36,44,58},{80,160,255},{45,110,200}}};
        static const char* SKN[8]={"MELIOR","SPECTRUM","LAGOON","CANDY","GHOST","MAROON","GOLD","STUDIO"};
        const int sk=(int)fLight<0?0:((int)fLight>7?7:(int)fLight);
        const float *bg=SK[sk][0],*pn=SK[sk][1],*tx=SK[sk][2],*gy=SK[sk][3],*ed=SK[sk][4],*GR=SK[sk][5],*DG=SK[sk][6];

        beginPath(); rect(0,0,W,H); fillColor(bg[0],bg[1],bg[2]); fill();

        fontSize(20.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(GR[0],GR[1],GR[2]);
        text(18,22,"G2B SONG",nullptr);
        fontSize(9.0f); fillColor(gy[0],gy[1],gy[2]);
        text(18,41,"all-in-one beat engine — in key, op tempo",nullptr);

        // preset-rij (stijlen)
        static const char* names[5]={"G2B","DEMBOW","DRILL","RNB","HOUSE"};
        float bx=W-14.f;
        for(int i=4;i>=0;i--){
            float bw=58.f; bx-=bw+4;
            beginPath(); roundedRect(bx,12,bx?bw:bw,17,4);
            if((int)fPreset==i) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
            fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.0f); stroke();
            fontSize(9.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor((int)fPreset==i?tx[0]:gy[0],(int)fPreset==i?tx[1]:gy[1],(int)fPreset==i?tx[2]:gy[2]);
            text(bx+bw/2,20.5f,names[i],nullptr);
        }
        // dice + auto + light control-bar
        beginPath(); roundedRect(14,48,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(11.f); fillColor(tx[0],tx[1],tx[2]);
        text(27,56.5f,"\xF0\x9F\x8E\xB2",nullptr);
        beginPath(); roundedRect(44,48,42,17,4);
        if(fAuto>0.5f) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
        fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(8.5f); fillColor(fAuto>0.5f?tx[0]:gy[0],fAuto>0.5f?tx[1]:gy[1],fAuto>0.5f?tx[2]:gy[2]);
        text(65,56.5f,"AUTO",nullptr);
        float tlx=W-40.f;
        beginPath(); roundedRect(tlx,34,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(10.f); fillColor(tx[0],tx[1],tx[2]);
        text(tlx+13,42.5f,fLight>0.5f?"\xF0\x9F\x8C\x99":"\xE2\x98\x80",nullptr);
        fontSize(7.5f); fillColor(gy[0],gy[1],gy[2]); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
        text(tlx+13,60.5f,SKN[sk],nullptr);

        // part-activiteit: 4 rijen DRUM/BAS/CHORD/MEL met step-indicator
        static const char* parts[4]={"DRUMS","BAS","CHORD","MEL"};
        static const unsigned char pc[4][3]={{47,191,113},{242,155,42},{66,135,245},{235,205,60}};
        for(int r=0;r<4;r++){
            float y=74.f+r*16.f;
            fontSize(8.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
            fillColor(pc[r][0],pc[r][1],pc[r][2]);
            text(18,y+4,parts[r],nullptr);
            for(int s=0;s<16;s++){
                beginPath(); rect(74.f+s*(W-96.f)/16.f,y+1.f,(W-96.f)/16.f-3.f,7.f);
                fillColor(s==fStep%16?pc[r][0]:ed[0],s==fStep%16?pc[r][1]:ed[1],s==fStep%16?pc[r][2]:ed[2]);
                fill();
            }
        }

        // knobs
        for(int i=0;i<7;i++){
            float cx=20+(W-40)/7.f*(i+0.5f), cy=175, R=24;
            float norm=(fValue[i]-fMin[i])/(fMax[i]-fMin[i]); if(norm<0)norm=0; if(norm>1)norm=1;
            float ang=-2.4f+norm*4.8f;
            beginPath(); arc(cx,cy,R,0,6.2832f,CW); fillColor(pn[0],pn[1],pn[2]); fill();
            strokeColor(ed[0],ed[1],ed[2]); strokeWidth(2.f); stroke();
            beginPath(); arc(cx,cy,R-4.f,-2.4f-1.5708f,ang-1.5708f,CW);
            strokeColor(GR[0],GR[1],GR[2]); strokeWidth(3.f); stroke();
            beginPath(); moveTo(cx,cy); lineTo(cx+sinf(ang)*(R-8),cy-cosf(ang)*(R-8));
            strokeColor(tx[0],tx[1],tx[2]); strokeWidth(3.f); stroke();
            fontSize(9.5f); textAlign(ALIGN_CENTER|ALIGN_TOP);
            fillColor(gy[0],gy[1],gy[2]); text(cx,cy+R+8,fLabel[i],nullptr);
            static const char* stn[5]={"G2B","DEMBOW","DRILL","RNB","HOUSE"};
            static const char* kn[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
            char buf[16];
            if(i==0) std::snprintf(buf,16,"%s",stn[(int)fValue[0]]);
            else if(i==1) std::snprintf(buf,16,"%s",kn[(int)fValue[1]]);
            else if(i==2) std::snprintf(buf,16,"%s",fValue[2]>0.5f?"major":"minor");
            else std::snprintf(buf,16,"%.0f%%",fValue[i]*100.f);
            fillColor(tx[0],tx[1],tx[2]); text(cx,cy+R+21,buf,nullptr);
        }
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if(ev.press&&ev.button==1){
            const float W=getWidth();
            // presets
            float bx=W-14.f;
            for(int i=4;i>=0;i--){float bw=58.f;bx-=bw+4;
                if(ev.pos.getX()>=bx&&ev.pos.getX()<=bx+bw&&ev.pos.getY()>=12&&ev.pos.getY()<=29){
                    setParameterValue(10,(float)i);fPreset=i;repaint();return true;}}
            if(ev.pos.getX()>=14&&ev.pos.getX()<=40&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                setParameterValue(7,1.f);return true;}
            if(ev.pos.getX()>=44&&ev.pos.getX()<=86&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                fAuto=fAuto>0.5f?0.f:1.f;setParameterValue(8,fAuto);repaint();return true;}
            if(ev.pos.getX()>=W-40&&ev.pos.getX()<=W-14&&ev.pos.getY()>=34&&ev.pos.getY()<=51){
                fLight=((int)fLight+1)%8;setParameterValue(9,fLight);repaint();return true;}
            for(int i=0;i<7;i++){
                float cx=20+(W-40)/7.f*(i+0.5f),cy=175,R=24;
                float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
                if(dx*dx+dy*dy<(R+8)*(R+8)){fDrag=i;fLastY=ev.pos.getY();return true;}
            }
        }
        if(fDrag>=0&&ev.press==false){fDrag=-1;repaint();return true;}
        return false;
    }
    bool onMotion(const MotionEvent& ev) override
    {
        if(fDrag<0)return false;
        float dy=fLastY-ev.pos.getY(); fLastY=ev.pos.getY();
        float range=fMax[fDrag]-fMin[fDrag];
        float v=fValue[fDrag]+dy*range/200.f;
        if(v<fMin[fDrag])v=fMin[fDrag];if(v>fMax[fDrag])v=fMax[fDrag];
        fValue[fDrag]=v; setParameterValue(fDrag,v); repaint(); return true;
    }

private:
    float fValue[7],fMin[7],fMax[7];
    const char* fLabel[7];
    float fScope[128]; int fScopePos;
    int fDrag; float fLastY;
    int fStep; float fAuto,fLight,fPreset;
};

UI* createUI(){ return new SongUI(); }
END_NAMESPACE_DISTRHO
