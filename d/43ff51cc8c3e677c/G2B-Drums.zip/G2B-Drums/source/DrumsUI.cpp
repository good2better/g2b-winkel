/*
 * G2B Drums — UI (NanoVG): 4 knoppen + preset-rij + 16-staps LED-grid + scope.
 */

#include "DistrhoUI.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>

START_NAMESPACE_DISTRHO

static const int kNumPrograms = 6;
static const char* kProgramNames[kNumPrograms] = {
    "G2B", "DEMBOW", "DRILL", "RNB", "HOUSE", "AFRO"
};
// patroon-LED's per rij (K/S/H/P) — zelfde patronen als DSP
static const char* kPatternRows[4] = {
    "K...K...K..K...","....S.......S...","H.H.H.H.H.H.H.H.","............P..."
};

class DrumsUI : public UI
{
public:
    DrumsUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[4]  = {0,0,0,0};
        static const float maxs[4]  = {1,1,0.5f,1};
        static const float defs[4]  = {0,0.5f,0.10f,0.85f};
        static const char* lbl[4]   = {"PATROON","DRIVE","SWING","LEVEL"};
        std::memcpy(fMin,mins,sizeof(mins));
        std::memcpy(fMax,maxs,sizeof(maxs));
        std::memcpy(fValue,defs,sizeof(defs));
        std::memcpy(fLabel,lbl,sizeof(lbl));
        std::memset(fScope,0,sizeof(fScope));
        fScopePos=0;fDrag=-1;fLastY=0;fProg=-1;fStep=-1;
    }
protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if(index<4)fValue[index]=value;
        repaint();
    }
    void stateChanged(const char* key, const char* value) override
    {
        if(std::strcmp(key,"scope")==0){
            const char* p=value;
            while(*p){
                char* end=nullptr;
                const float v=std::strtof(p,&end);
                if(end==p)break;
                fScope[fScopePos]=v;fScopePos=(fScopePos+1)%kScopeSize;
                p=(*end==';')?end+1:end;
            }
            repaint();
        } else if(std::strcmp(key,"step")==0){
            fStep=atoi(value);repaint();
        }
    }
    void onNanoDisplay() override
    {
        const float W=getWidth(),H=getHeight();
        beginPath();rect(0,0,W,H);fillColor(13,15,14);fill();
        fontSize(20.0f);textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(47,191,113);
        text(18.0f,22.0f,"G2B DRUMS",nullptr);
        fontSize(11.5f);fillColor(143,160,152);
        text(18.0f,41.0f,"drum-machine: jouw stijl-patroon, gesyncd met je DAW",nullptr);

        // presets rechtsboven
        float bx=W-14.0f;
        for(int i=kNumPrograms-1;i>=0;--i){
            const float bw=62.0f,bh=17.0f;
            bx-=bw+5.0f;
            const bool on=(i==fProg);
            beginPath();roundedRect(bx,12.0f,bw,bh,4.0f);
            if(on){fillColor(29,122,72);fill();}
            strokeColor(42,47,45);strokeWidth(1.0f);stroke();
            fontSize(10.0f);textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor(on?Color(232,236,234):Color(143,160,152));
            text(bx+bw*0.5f,12.0f+bh*0.5f,kProgramNames[i],nullptr);
        }

        // 16-staps LED-grid (4 rijen: K S H P)
        const float gx=18.0f, gy=56.0f, gw=W-36.0f;
        const char rowN[4]={'K','S','H','P'};
        for(int r=0;r<4;r++){
            for(int s=0;s<16;s++){
                const float cw=gw/16.0f;
                const float x=gx+s*cw, y=gy+r*16.0f;
                const bool hit=(kPatternRows[r][s]!='.');
                const bool now=(s==fStep);
                beginPath();rect(x+1.5f,y+1.5f,cw-3.0f,12.0f);
                if(hit) fillColor(now?Color(232,236,234):Color(47,191,113));
                else    fillColor(now?Color(29,122,72):Color(24,28,27));
                fill();
            }
            fontSize(9.0f);fillColor(90,100,94);textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
            text(gx-2.0f,gy+r*16.0f+7.0f,&rowN[r],nullptr); // rij-letter links (valt deels buiten grid, ok)
        }

        // scope onder grid
        const float sx=18.0f,sy=132.0f,sw=W-36.0f,sh=36.0f;
        beginPath();rect(sx,sy,sw,sh);fillColor(8,10,9);fill();
        strokeColor(42,47,45);strokeWidth(1.0f);stroke();
        beginPath();
        const float mid=sy+sh*0.5f;
        for(int i=0;i<kScopeSize-1;++i){
            const int i0=(fScopePos+i)%kScopeSize,i1=(fScopePos+i+1)%kScopeSize;
            const float x0=sx+(float)i/(kScopeSize-1)*sw,x1=sx+(float)(i+1)/(kScopeSize-1)*sw;
            float y0=mid-fScope[i0]*sh*0.45f,y1=mid-fScope[i1]*sh*0.45f;
            if(y0<sy+1)y0=sy+1;if(y0>sy+sh-1)y0=sy+sh-1;
            if(y1<sy+1)y1=sy+1;if(y1>sy+sh-1)y1=sy+sh-1;
            if(i==0)moveTo(x0,y0);else lineTo(x0,y0);lineTo(x1,y1);
        }
        strokeColor(47,191,113);strokeWidth(1.5f);stroke();

        // 4 knoppen
        const int n=4;
        const float step=(W-40.0f)/n;
        for(int i=0;i<n;++i){
            const float cx=20.0f+step*(i+0.5f),cy=222.0f,R=34.0f;
            const float norm=(fValue[i]-fMin[i])/(fMax[i]-fMin[i]);
            const float ang=-2.4f+norm*4.8f;
            beginPath();circle(cx,cy,R);fillColor(30,34,33);fill();
            strokeColor(42,47,45);strokeWidth(2.0f);stroke();
            beginPath();arc(cx,cy,R-4.0f,-2.4f-1.5708f,ang-1.5708f,CW);
            strokeColor(47,191,113);strokeWidth(3.0f);stroke();
            beginPath();moveTo(cx,cy);
            lineTo(cx+std::sin(ang)*(R-8.0f),cy-std::cos(ang)*(R-8.0f));
            strokeColor(232,236,234);strokeWidth(3.0f);stroke();
            fontSize(10.5f);fillColor(143,160,152);textAlign(ALIGN_CENTER|ALIGN_TOP);
            text(cx,cy+R+8.0f,fLabel[i],nullptr);
            fontSize(12.0f);fillColor(232,236,234);
            char buf[24];
            if(i==0)std::snprintf(buf,sizeof(buf),"%s",kProgramNames[(int)fValue[0]<0?0:((int)fValue[0]>5?5:(int)fValue[0])]);
            else std::snprintf(buf,sizeof(buf),"%.0f %%",fValue[i]*100.0f);
            text(cx,cy+R+23.0f,buf,nullptr);
        }
        fontSize(10.5f);fillColor(90,100,94);textAlign(ALIGN_CENTER|ALIGN_BOTTOM);
        text(W*0.5f,H-8.0f,"groen = stap die klinkt · wit = nu · speelt zodra je DAW loopt",nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if(ev.button!=1)return false;
        const float W=getWidth();
        if(ev.press){
            float bx=W-14.0f;
            for(int i=kNumPrograms-1;i>=0;--i){
                const float bw=62.0f,bh=17.0f;bx-=bw+5.0f;
                if(ev.pos.getX()>=bx&&ev.pos.getX()<=bx+bw&&ev.pos.getY()>=12.0f&&ev.pos.getY()<=12.0f+bh){
                    setParameterValue(4,(float)i);fProg=i;repaint();return true;
                }
            }
        }
        const float step=(W-40.0f)/4;
        if(ev.press){
            for(int i=0;i<4;++i){
                const float cx=20.0f+step*(i+0.5f),cy=222.0f;
                const float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
                if(dx*dx+dy*dy<=34.0f*34.0f+80.0f){fDrag=i;fLastY=ev.pos.getY();editParameter(i,true);return true;}
            }
        } else if(fDrag>=0){editParameter(fDrag,false);fDrag=-1;}
        return true;
    }
    bool onMotion(const MotionEvent& ev) override
    {
        if(fDrag<0)return false;
        const float dy=fLastY-ev.pos.getY();fLastY=ev.pos.getY();
        const float range=fMax[fDrag]-fMin[fDrag];
        float v=fValue[fDrag]+dy*range/200.0f;
        if(v<fMin[fDrag])v=fMin[fDrag];if(v>fMax[fDrag])v=fMax[fDrag];
        fValue[fDrag]=v;setParameterValue(fDrag,v);repaint();return true;
    }
    bool onScroll(const ScrollEvent& ev) override
    {
        const float W=getWidth();const float step=(W-40.0f)/4;
        for(int i=0;i<4;++i){
            const float cx=20.0f+step*(i+0.5f),cy=222.0f;
            const float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
            if(dx*dx+dy*dy<=34.0f*34.0f+80.0f){
                const float range=fMax[i]-fMin[i];
                float v=fValue[i]+ev.delta.getY()*range/100.0f;
                if(v<fMin[i])v=fMin[i];if(v>fMax[i])v=fMax[i];
                fValue[i]=v;editParameter(i,true);setParameterValue(i,v);editParameter(i,false);
                repaint();return true;
            }
        }
        return true;
    }
private:
    static const int kScopeSize=256;
    float fValue[4],fMin[4],fMax[4];
    const char* fLabel[4];
    float fScope[kScopeSize];int fScopePos;
    int fDrag;float fLastY;int fProg;int fStep;
    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DrumsUI)
};
UI* createUI(){return new DrumsUI();}
END_NAMESPACE_DISTRHO
