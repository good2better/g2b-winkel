/*
 * G2B SampleX — laad je eigen one-shot/loop, maak er je eigen instrument van.
 * Sample komt binnen via state "sample" (base64 WAV) — blijft in je project.
 * 8 stemmen: pitch st, LP-filter, drive, pitch-drop, start-punt, level.
 */

#include "DistrhoPlugin.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>

START_NAMESPACE_DISTRHO

static const int kNumPresets = 6;
static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
// PITCH, FILTER, DRIVE, DROP, START, LEVEL
static const float kPresetParams[6][6] = {
    {  0, 8000, 30, 40, 0, 85 },
    { -2, 6000, 45, 55, 0, 85 },
    { -5, 4000, 55, 60, 0, 80 },
    { +2, 10000, 20, 25, 0, 85 },
    {  0, 7000, 40, 45, 0, 85 },
    { -3, 5500, 35, 50, 0, 80 },
};

static const int kMaxVoices = 8;

struct SVoice
{
    bool active = false;
    uint8_t note = 0;
    float pos = 0.0f;
    float amp = 0.0f;
    float vel = 0.0f;
    float age = 0.0f;
    float lp = 0.0f;
};

// ---- base64 ----
static int b64v(char c)
{
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

class SampleXPlugin : public Plugin
{
public:
    enum Parameters {
        kPitch = 0, kFilter, kDrive, kDrop, kStart, kLevel, kDice, kPreset, kParameterCount
    };

    SampleXPlugin()
        : Plugin(kParameterCount, 0, 0),
          fPitch(0.0f), fFilter(8000.0f), fDrive(30.0f), fDrop(40.0f),
          fStart(0.0f), fLevel(85.0f), fPreset(0.0f),
          fScopeN(0), fDecim(0)
    {
        recalc();
    }

protected:
    const char* getLabel() const override { return "G2B SampleX"; }
    const char* getDescription() const override
    {
        return "Laad je eigen one-shot/loop en maak er je eigen instrument van — "
               "pitch, filter, drive, pitch-drop, start-punt. G2B SampleX.";
    }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','S','x'); }

    void initParameter(uint32_t index, Parameter& parameter) override
    {
        parameter.hints = kParameterIsAutomatable;
        switch (index)
        {
        case kPitch:
            parameter.name = "Pitch"; parameter.symbol = "pitch"; parameter.unit = "st";
            parameter.ranges = {-12.0f, 12.0f, 0.0f}; break;
        case kFilter:
            parameter.name = "Filter"; parameter.symbol = "filter"; parameter.unit = "Hz";
            parameter.ranges = {500.0f, 15000.0f, 8000.0f}; break;
        case kDrive:
            parameter.name = "Drive"; parameter.symbol = "drive"; parameter.unit = "%";
            parameter.ranges = {0.0f, 100.0f, 30.0f}; break;
        case kDrop:
            parameter.name = "Drop"; parameter.symbol = "drop"; parameter.unit = "%";
            parameter.ranges = {0.0f, 100.0f, 40.0f}; break;
        case kStart:
            parameter.name = "Start"; parameter.symbol = "start"; parameter.unit = "%";
            parameter.ranges = {0.0f, 90.0f, 0.0f}; break;
        case kLevel:
            parameter.name = "Level"; parameter.symbol = "level"; parameter.unit = "%";
            parameter.ranges = {0.0f, 100.0f, 85.0f}; break;
        case kDice: parameter.name="Dice"; parameter.symbol="dice"; parameter.hints=kParameterIsInteger|kParameterIsTrigger; parameter.ranges={0.0f,1.0f,0.0f}; break;
        case kPreset:
            parameter.name = "Preset"; parameter.symbol = "preset"; parameter.unit = "";
            parameter.hints = kParameterIsInteger;
            parameter.ranges = {0.0f, 5.0f, 0.0f}; break;
        }
    }

    float getParameterValue(uint32_t index) const override
    {
        switch (index)
        {
        case kPitch:  return fPitch;
        case kFilter: return fFilter;
        case kDrive:  return fDrive;
        case kDrop:   return fDrop;
        case kStart:  return fStart;
        case kLevel:  return fLevel;
        case kDice: return fDice; case kPreset: return fPreset;
        }
        return 0.0f;
    }

    void setParameterValue(uint32_t index, float value) override
    {
        if (index == kPreset)
        {
            fPreset = value;
            applyPreset((int)value);
            return;
        }
        switch (index)
        {
        case kPitch:  fPitch = value; break;
        case kFilter: fFilter = value; break;
        case kDrive:  fDrive = value; break;
        case kDrop:   fDrop = value; break;
        case kStart:  fStart = value; break;
        case kLevel:  fLevel = value; break;case kDice: if(value>0.5f)rollDice(); fDice=0.f; break;
        }
        recalc();
    }

    void initState(uint32_t, String&, String&) override {}

    void setState(const char* key, const char* value) override
    {
        if (std::strcmp(key, "sample") == 0)
            loadSampleB64(value);
    }

    void activate() override
    {
        for (int v = 0; v < kMaxVoices; ++v) fVoice[v] = SVoice();
        fScopeN = 0;
    }

    void run(const float**, float** outputs, uint32_t frames,
             const MidiEvent* midi, uint32_t midiCount) override
    {
        float* outL = outputs[0];
        float* outR = outputs[1];
        std::memset(outL, 0, frames * sizeof(float));
        std::memset(outR, 0, frames * sizeof(float));

        const float sr = (float)getSampleRate();
        const float lpA   = 1.0f - std::exp(-2.0f * 3.14159f * fFilter / sr);
        const float drive = 1.0f + (fDrive / 100.0f) * 3.0f;
        const float dropAmt = fDrop / 100.0f * 0.9f;
        const float level = fLevelGain;
        const float startF = (fStart / 100.0f) * (float)fSamp.size();
        const bool hasSamp = fSamp.size() > 64;

        uint32_t curFrame = 0;
        for (uint32_t e = 0; e <= midiCount; ++e)
        {
            const uint32_t until = (e < midiCount) ? midi[e].frame : frames;
            for (; curFrame < until; ++curFrame)
            {
                float s = 0.0f;
                if (hasSamp)
                {
                    for (int vi = 0; vi < kMaxVoices; ++vi)
                    {
                        SVoice& v = fVoice[vi];
                        if (!v.active) continue;
                        const float drop = 1.0f + dropAmt * std::exp(-v.age * 9.0f / sr);
                        const float rate = vRate(v.note) * drop;
                        const int n = (int)fSamp.size();
                        const int i0 = (int)v.pos;
                        if (i0 >= n - 1) { v.active = false; continue; }
                        const float frac = v.pos - i0;
                        float x = fSamp[i0] * (1.0f - frac) + fSamp[i0 + 1] * frac;
                        v.pos += rate;
                        v.lp += lpA * (x - v.lp);
                        x = std::tanh(v.lp * drive);
                        s += x * v.amp * v.vel;
                        v.age += 1.0f;
                        v.amp *= 0.99995f;
                    }
                }
                const float y = s * level;
                outL[curFrame] = y;
                outR[curFrame] = y;
                if (++fDecim >= 3)
                {
                    fDecim = 0;
                    if (fScopeN < kScopeLen) fScope[fScopeN++] = y;
                }
            }
            if (e < midiCount)
            {
                const MidiEvent& ev = midi[e];
                const uint8_t* data = ev.data;
                const uint8_t status = data[0] & 0xF0;
                if (status == 0x90 && data[2] > 0)
                {
                    SVoice* v = nullptr;
                    for (int i = 0; i < kMaxVoices; ++i)
                        if (!fVoice[i].active) { v = &fVoice[i]; break; }
                    if (!v) v = &fVoice[0];
                    v->active = true;
                    v->note = data[1];
                    v->pos = startF;
                    v->amp = 1.0f;
                    v->vel = data[2] / 127.0f;
                    v->age = 0.0f;
                    v->lp = 0.0f;
                }
                else if (status == 0x80 || (status == 0x90 && data[2] == 0))
                {
                    for (int i = 0; i < kMaxVoices; ++i)
                        if (fVoice[i].active && fVoice[i].note == data[1])
                            fVoice[i].amp *= 0.3f;
                }
            }
        }

        if (fScopeN >= 40)
        {
            char buf[256];
            int pos = 0;
            for (uint32_t s = 0; s < fScopeN && pos < 230; ++s)
                pos += std::snprintf(buf + pos, sizeof(buf) - pos, "%.3f;", fScope[s]);
            buf[pos] = '\0';
            setState("scope", buf);
            fScopeN = 0;
        }
    }

private:
    void rollDice(){
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kPitch,-12.f+((fRnd>>8)%100)/100.f*24.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kFilter,500.f+((fRnd>>8)%100)/100.f*12000.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kDrive,((fRnd>>8)%100)/100.f*70.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kDrop,((fRnd>>8)%100)/100.f*90.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kStart,((fRnd>>8)%100)/100.f*70.f);
    }
    float fDice = 0.f;
    unsigned fRnd = 998877;

    float fPitch, fFilter, fDrive, fDrop, fStart, fLevel, fPreset;
    float fLevelGain;
    std::vector<float> fSamp;
    SVoice fVoice[kMaxVoices];
    static const int kScopeLen = 96;
    float fScope[kScopeLen];
    uint32_t fScopeN, fDecim;

    float vRate(uint8_t note) const
    {
        // basistoon = C4 (60): sample klinkt als de bron bij C4
        return std::pow(2.0f, ((float)note - 60.0f + fPitch) / 12.0f);
    }

    void applyPreset(int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        const float* p = kPresetParams[i];
        setParameterValue(kPitch, p[0]);
        setParameterValue(kFilter, p[1]);
        setParameterValue(kDrive, p[2]);
        setParameterValue(kDrop, p[3]);
        setParameterValue(kStart, p[4]);
        setParameterValue(kLevel, p[5]);
        recalc();
    }

    void recalc()
    {
        fLevelGain = (fLevel / 100.0f) * 0.95f;
    }

    void loadSampleB64(const char* b64)
    {
        // decode base64 -> bytes
        std::vector<unsigned char> bytes;
        const size_t len = std::strlen(b64);
        bytes.reserve(len * 3 / 4);
        int acc = 0, nbits = 0;
        for (size_t i = 0; i < len; ++i)
        {
            const int v = b64v(b64[i]);
            if (v < 0) continue;
            acc = (acc << 6) | v;
            nbits += 6;
            if (nbits >= 8)
            {
                nbits -= 8;
                bytes.push_back((unsigned char)((acc >> nbits) & 0xFF));
            }
        }
        // parse WAV: RIFF ... fmt ... data (PCM16)
        fSamp.clear();
        if (bytes.size() < 44 || std::memcmp(bytes.data(), "RIFF", 4) != 0)
            return;
        int ch = 1, bits = 16, dataOff = -1; size_t dataLen = 0;
        for (size_t p = 12; p + 8 <= bytes.size();)
        {
            const uint32_t sz = bytes[p+4] | (bytes[p+5]<<8) | (bytes[p+6]<<16) | ((uint32_t)bytes[p+7]<<24);
            if (std::memcmp(bytes.data()+p, "fmt ", 4) == 0 && sz >= 16)
            {
                ch = bytes[p+10] | (bytes[p+11]<<8);
                bits = bytes[p+22] | (bytes[p+23]<<8);
            }
            if (std::memcmp(bytes.data()+p, "data", 4) == 0)
            { dataOff = (int)p + 8; dataLen = sz; break; }
            p += 8 + sz + (sz & 1);
        }
        if (dataOff < 0 || bits != 16) return;
        const int frames = (int)dataLen / (2 * ch);
        fSamp.resize(frames);
        const short* raw = (const short*)(bytes.data() + dataOff);
        for (int i = 0; i < frames; ++i)
        {
            float s = 0.0f;
            for (int c = 0; c < ch; ++c) s += raw[i * ch + c] / 32768.0f;
            fSamp[i] = s / ch;
        }
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SampleXPlugin)
};

Plugin* createPlugin() { return new SampleXPlugin(); }

END_NAMESPACE_DISTRHO
