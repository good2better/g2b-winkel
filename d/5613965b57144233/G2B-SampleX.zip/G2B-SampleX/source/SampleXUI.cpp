/*
 * G2B SampleX — UI (NanoVG): LAAD SAMPLE knop + preset-rij + scope +
 * 7 draaiknoppen (PITCH/FILTER/DRIVE/DROP/START/LEVEL + preset-knoppen).
 */

#include "DistrhoUI.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;

static void b64enc(const std::vector<unsigned char>& in, std::string& out)
{
    static const char* T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    size_t i = 0;
    out.clear();
    while (i + 2 < in.size())
    {
        const unsigned v = (in[i] << 16) | (in[i+1] << 8) | in[i+2];
        out += T[(v >> 18) & 63]; out += T[(v >> 12) & 63];
        out += T[(v >> 6) & 63];  out += T[v & 63];
        i += 3;
    }
    if (i < in.size())
    {
        unsigned v = in[i] << 16;
        const bool two = (i + 1 < in.size());
        if (two) v |= in[i+1] << 8;
        out += T[(v >> 18) & 63]; out += T[(v >> 12) & 63];
        out += two ? T[(v >> 6) & 63] : '=';
        out += '=';
    }
}

class SampleXUI : public UI
{
public:
    SampleXUI()
        : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[6]  = {-12, 500, 0, 0, 0, 0};
        static const float maxs[6]  = { 12, 15000, 100, 100, 90, 100};
        static const float defs[6]  = {  0, 8000, 30, 40, 0, 85};
        static const char* lbl[6]   = {"PITCH","FILTER","DRIVE","DROP","START","LEVEL"};
        std::memcpy(fMin, mins, sizeof(mins));
        std::memcpy(fMax, maxs, sizeof(maxs));
        std::memcpy(fValue, defs, sizeof(defs));
        std::memcpy(fLabel, lbl, sizeof(lbl));
        std::memset(fScope, 0, sizeof(fScope));
        fScopePos = 0; fDrag = -1; fLastY = 0.0f; fProg = 0;
        fName = "geen sample geladen — klik LAAD SAMPLE";
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if (index < 6) fValue[index] = value;
        repaint();
    }

    void stateChanged(const char* key, const char* value) override
    {
        if (std::strcmp(key, "scope") == 0)
        {
            const char* p = value;
            while (*p != '\0')
            {
                char* end = nullptr;
                const float v = std::strtof(p, &end);
                if (end == p) break;
                fScope[fScopePos] = v;
                fScopePos = (fScopePos + 1) % kScopeSize;
                p = (*end == ';') ? end + 1 : end;
            }
            repaint();
        }
    }

    void uiFileBrowserSelected(const char* filename) override
    {
        std::ifstream in(filename, std::ios::binary);
        if (!in) { fName = "kon bestand niet openen"; repaint(); return; }
        std::vector<unsigned char> buf((std::istreambuf_iterator<char>(in)),
                                       std::istreambuf_iterator<char>());
        // hard cap ~4MB wav → ~5.4MB base64
        if (buf.size() > 4 * 1024 * 1024) buf.resize(4 * 1024 * 1024);
        std::string b64;
        b64enc(buf, b64);
        setState("sample", b64.c_str());
        const char* base = std::strrchr(filename, '/');
        if (!base) base = std::strrchr(filename, '\\');
        fName = base ? base + 1 : filename;
        if (fName.size() > 44) fName = fName.substr(0, 41) + "...";
        repaint();
    }

    void onNanoDisplay() override
    {
        const float W = getWidth(), H = getHeight();
        beginPath(); rect(0, 0, W, H); fillColor(13, 15, 14); fill();

        fontSize(20.0f); textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
        fillColor(47, 191, 113);
        text(18.0f, 22.0f, "G2B SAMPLEX", nullptr);
        fontSize(11.5f); fillColor(143, 160, 152);
        text(18.0f, 41.0f, "jouw one-shot/loop → jouw eigen instrument", nullptr);

        // LAAD SAMPLE knop
        const bool hover = false;
        beginPath(); roundedRect(18.0f, 56.0f, 150.0f, 24.0f, 5.0f);
        fillColor(hover ? Color(47, 191, 113) : Color(29, 122, 72)); fill();
        strokeColor(42, 47, 45); strokeWidth(1.0f); stroke();
        fontSize(11.5f); textAlign(ALIGN_CENTER | ALIGN_MIDDLE);
        fillColor(232, 236, 234);
        text(18.0f + 75.0f, 56.0f + 12.0f, "LAAD SAMPLE", nullptr);

        fontSize(10.0f); textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
        fillColor(143, 160, 152);
        text(178.0f, 68.0f, fName.c_str(), nullptr);

        // preset-knoppen rechtsboven
        float bx = W - 14.0f;
        for (int i = kNumPresets - 1; i >= 0; --i)
        {
            const float bw = 62.0f, bh = 17.0f;
            bx -= bw + 5.0f;
            const bool on = (i == fProg);
            beginPath(); roundedRect(bx, 12.0f, bw, bh, 4.0f);
            if (on) { fillColor(29, 122, 72); fill(); }
            strokeColor(42, 47, 45); strokeWidth(1.0f); stroke();
            fontSize(10.0f); textAlign(ALIGN_CENTER | ALIGN_MIDDLE);
            fillColor(on ? Color(232, 236, 234) : Color(143, 160, 152));
            text(bx + bw * 0.5f, 12.0f + bh * 0.5f, kPresetNames[i], nullptr);
        }

        // scope (onder de knoppenbalk)
        const float sx = 18.0f, sy = 90.0f, sw = W - 36.0f, sh = 42.0f;
        beginPath(); rect(sx, sy, sw, sh);
        fillColor(8, 10, 9); fill();
        strokeColor(42, 47, 45); strokeWidth(1.0f); stroke();
        beginPath();
        const float mid = sy + sh * 0.5f;
        for (int i = 0; i < kScopeSize - 1; ++i)
        {
            const int i0 = (fScopePos + i) % kScopeSize;
            const int i1 = (fScopePos + i + 1) % kScopeSize;
            const float x0 = sx + (float)i / (kScopeSize - 1) * sw;
            const float x1 = sx + (float)(i + 1) / (kScopeSize - 1) * sw;
            float y0 = mid - fScope[i0] * sh * 0.45f;
            float y1 = mid - fScope[i1] * sh * 0.45f;
            if (y0 < sy + 1) y0 = sy + 1; if (y0 > sy + sh - 1) y0 = sy + sh - 1;
            if (y1 < sy + 1) y1 = sy + 1; if (y1 > sy + sh - 1) y1 = sy + sh - 1;
            if (i == 0) moveTo(x0, y0); else lineTo(x0, y0);
            lineTo(x1, y1);
        }
        strokeColor(47, 191, 113); strokeWidth(1.5f); stroke();

        // 6 knoppen
        const int n = 6;
        const float step = (W - 40.0f) / n;
        for (int i = 0; i < n; ++i)
        {
            const float cx = 20.0f + step * (i + 0.5f);
            const float cy = 200.0f;
            const float R  = 30.0f;
            const float norm = (fValue[i] - fMin[i]) / (fMax[i] - fMin[i]);
            const float ang = -2.4f + norm * 4.8f;

            beginPath(); circle(cx, cy, R);
            fillColor(30, 34, 33); fill();
            strokeColor(42, 47, 45); strokeWidth(2.0f); stroke();
            beginPath();
            arc(cx, cy, R - 4.0f, -2.4f - 1.5708f, ang - 1.5708f, CW);
            strokeColor(47, 191, 113); strokeWidth(3.0f); stroke();
            beginPath();
            moveTo(cx, cy);
            lineTo(cx + std::sin(ang) * (R - 8.0f),
                   cy - std::cos(ang) * (R - 8.0f));
            strokeColor(232, 236, 234); strokeWidth(3.0f); stroke();

            fontSize(10.5f); fillColor(143, 160, 152);
            textAlign(ALIGN_CENTER | ALIGN_TOP);
            text(cx, cy + R + 8.0f, fLabel[i], nullptr);
            fontSize(11.5f); fillColor(232, 236, 234);
            char buf[24];
            if (i == 0)
                std::snprintf(buf, sizeof(buf), "%+.0f st", fValue[i]);
            else if (i == 1)
                std::snprintf(buf, sizeof(buf), "%.0f Hz", fValue[i]);
            else
                std::snprintf(buf, sizeof(buf), "%.0f %%", fValue[i]);
            text(cx, cy + R + 23.0f, buf, nullptr);
        }

        fontSize(10.5f); fillColor(90, 100, 94);
        textAlign(ALIGN_CENTER | ALIGN_BOTTOM);
        text(W * 0.5f, H - 8.0f,
             "LAAD SAMPLE = jouw one-shot/loop erin — speel met MIDI/piano-roll", nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if (ev.button != 1) return false;
        const float W = getWidth();
        if (ev.press)
        {
            // LAAD SAMPLE knop
            if (ev.pos.getX() >= 18.0f && ev.pos.getX() <= 168.0f &&
                ev.pos.getY() >= 56.0f && ev.pos.getY() <= 80.0f)
            {
                openFileBrowser();
                return true;
            }
            // preset-klik
            float bx = W - 14.0f;
            for (int i = kNumPresets - 1; i >= 0; --i)
            {
                const float bw = 62.0f, bh = 17.0f;
                bx -= bw + 5.0f;
                if (ev.pos.getX() >= bx && ev.pos.getX() <= bx + bw &&
                    ev.pos.getY() >= 12.0f && ev.pos.getY() <= 12.0f + bh)
                {
                    setParameterValue(6, (float)i);
                    fProg = i;
                    repaint();
                    return true;
                }
            }
            // knoppen
            const float step = (W - 40.0f) / 6;
            for (int i = 0; i < 6; ++i)
            {
                const float cx = 20.0f + step * (i + 0.5f);
                const float cy = 200.0f;
                const float dx = ev.pos.getX() - cx;
                const float dy = ev.pos.getY() - cy;
                if (dx*dx + dy*dy <= 30.0f*30.0f + 70.0f)
                {
                    fDrag = i; fLastY = ev.pos.getY();
                    editParameter(i, true);
                    return true;
                }
            }
        }
        else if (fDrag >= 0)
        {
            editParameter(fDrag, false);
            fDrag = -1;
        }
        return true;
    }

    bool onMotion(const MotionEvent& ev) override
    {
        if (fDrag < 0) return false;
        const float dy = fLastY - ev.pos.getY();
        fLastY = ev.pos.getY();
        const float range = fMax[fDrag] - fMin[fDrag];
        float v = fValue[fDrag] + dy * range / 200.0f;
        if (v < fMin[fDrag]) v = fMin[fDrag];
        if (v > fMax[fDrag]) v = fMax[fDrag];
        fValue[fDrag] = v;
        setParameterValue(fDrag, v);
        repaint();
        return true;
    }

    bool onScroll(const ScrollEvent& ev) override
    {
        const float W = getWidth();
        const float step = (W - 40.0f) / 6;
        for (int i = 0; i < 6; ++i)
        {
            const float cx = 20.0f + step * (i + 0.5f);
            const float cy = 200.0f;
            const float dx = ev.pos.getX() - cx;
            const float dy = ev.pos.getY() - cy;
            if (dx*dx + dy*dy <= 30.0f*30.0f + 70.0f)
            {
                const float range = fMax[i] - fMin[i];
                float v = fValue[i] + ev.delta.getY() * range / 100.0f;
                if (v < fMin[i]) v = fMin[i];
                if (v > fMax[i]) v = fMax[i];
                fValue[i] = v;
                editParameter(i, true);
                setParameterValue(i, v);
                editParameter(i, false);
                repaint();
                return true;
            }
        }
        return true;
    }

private:
    static const int kScopeSize = 256;
    float fValue[6], fMin[6], fMax[6];
    const char* fLabel[6];
    float fScope[kScopeSize];
    int fScopePos;
    int fDrag;
    float fLastY;
    int fProg;
    std::string fName;

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SampleXUI)
};

UI* createUI() { return new SampleXUI(); }

END_NAMESPACE_DISTRHO
