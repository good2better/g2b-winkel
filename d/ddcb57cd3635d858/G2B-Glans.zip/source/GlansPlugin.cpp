/*
 * G2B Glans — air + stereo width above a split frequency.
 * DSP: one-pole high-shelf "air" on the mid path + side-widening only
 * above the split point (sub/bass stays mono and powerful).
 * Same math as the JSFX g2b_glans used by G2B Engineer.
 */

#include "DistrhoPlugin.hpp"

START_NAMESPACE_DISTRHO

class GlansPlugin : public Plugin
{
public:
    enum Parameters {
        kAir = 0,      // AIR dB
        kWidth,        // BREEDTE x
        kSplit,        // breedte vanaf Hz
        kAirFreq,      // air vanaf Hz
        kOut,          // output dB
        kParameterCount
    };

    GlansPlugin()
        : Plugin(kParameterCount, 0, 0),
          fAirDb(2.5f), fWidth(1.15f), fSplit(1500.0f),
          fAirFreq(9500.0f), fOutDb(0.0f),
          fLpA{0.0f,0.0f}, fLpB{0.0f,0.0f}, fLpS(0.0f),
          fAlphaAir(0.0f), fAlphaSplit(0.0f), fAirK(0.0f), fOutGain(1.0f)
    {
        recalc();
    }

protected:
    const char* getLabel() const override { return "G2B Glans"; }
    const char* getDescription() const override
    {
        return "Glans aan je mix: air-boost en stereo-breedte ALLEEN boven "
               "een splitpunt — sub en midden blijven strak en gecentreerd.";
    }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','G','l'); }

    void initParameter(uint32_t index, Parameter& parameter) override
    {
        parameter.hints = kParameterIsAutomatable;
        switch (index)
        {
        case kAir:
            parameter.name = "Air";
            parameter.shortName = "Air";
            parameter.symbol = "air";
            parameter.unit = "dB";
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 10.0f;
            parameter.ranges.def = 2.5f;
            break;
        case kWidth:
            parameter.name = "Breedte";
            parameter.shortName = "Breedte";
            parameter.symbol = "width";
            parameter.unit = "x";
            parameter.ranges.min = 0.5f;
            parameter.ranges.max = 2.0f;
            parameter.ranges.def = 1.15f;
            break;
        case kSplit:
            parameter.name = "Breedte vanaf";
            parameter.shortName = "Vanaf";
            parameter.symbol = "split";
            parameter.unit = "Hz";
            parameter.ranges.min = 400.0f;
            parameter.ranges.max = 4000.0f;
            parameter.ranges.def = 1500.0f;
            break;
        case kAirFreq:
            parameter.name = "Air vanaf";
            parameter.shortName = "Air vanaf";
            parameter.symbol = "airfreq";
            parameter.unit = "Hz";
            parameter.ranges.min = 6000.0f;
            parameter.ranges.max = 14000.0f;
            parameter.ranges.def = 9500.0f;
            break;
        case kOut:
            parameter.name = "Output";
            parameter.shortName = "Output";
            parameter.symbol = "out";
            parameter.unit = "dB";
            parameter.ranges.min = -6.0f;
            parameter.ranges.max = 6.0f;
            parameter.ranges.def = 0.0f;
            break;
        }
    }

    float getParameterValue(uint32_t index) const override
    {
        switch (index)
        {
        case kAir:     return fAirDb;
        case kWidth:   return fWidth;
        case kSplit:   return fSplit;
        case kAirFreq: return fAirFreq;
        case kOut:     return fOutDb;
        }
        return 0.0f;
    }

    void setParameterValue(uint32_t index, float value) override
    {
        switch (index)
        {
        case kAir:     fAirDb = value; break;
        case kWidth:   fWidth = value; break;
        case kSplit:   fSplit = value; break;
        case kAirFreq: fAirFreq = value; break;
        case kOut:     fOutDb = value; break;
        }
        recalc();
    }

    void activate() override
    {
        fLpA[0] = fLpA[1] = fLpB[0] = fLpB[1] = fLpS = 0.0f;
    }

    void run(const float** inputs, float** outputs, uint32_t frames) override
    {
        const float* inL = inputs[0];
        const float* inR = inputs[1];
        float* outL = outputs[0];
        float* outR = outputs[1];

        const float aAir = fAlphaAir;
        const float aHp  = fAlphaSplit;
        const float airK = fAirK;
        const float w    = fWidth;
        const float g    = fOutGain;

        float lpa0 = fLpA[0], lpa1 = fLpA[1];
        float lpb0 = fLpB[0], lpb1 = fLpB[1];
        float lps  = fLpS;

        for (uint32_t i = 0; i < frames; ++i)
        {
            float l = inL[i], r = inR[i];

            // air-shelf: een-pools hoogdoorlaat op elk kanaal
            lpa0 += aAir * (l - lpa0);
            lpa1 += aAir * (r - lpa1);
            l += (l - lpa0) * airK;
            r += (r - lpa1) * airK;

            // mid/side — breedte alleen boven de split
            const float mid  = (l + r) * 0.5f;
            const float side = (l - r) * 0.5f;
            lps += aHp * (side - lps);
            const float sideHi = side - lps;
            const float side2 = (side - sideHi) + sideHi * w;

            outL[i] = (mid + side2) * g;
            outR[i] = (mid - side2) * g;
        }

        fLpA[0] = lpa0; fLpA[1] = lpa1;
        fLpB[0] = lpb0; fLpB[1] = lpb1;
        fLpS = lps;
    }

private:
    float fAirDb, fWidth, fSplit, fAirFreq, fOutDb;
    float fLpA[2], fLpB[2], fLpS;
    float fAlphaAir, fAlphaSplit, fAirK, fOutGain;

    void recalc()
    {
        const float sr = (float)getSampleRate();
        const float pi = 3.14159265358979f;
        fAirK      = std::pow(10.0f, fAirDb / 20.0f) - 1.0f;
        fAlphaAir  = std::exp(-2.0f * pi * fAirFreq / sr);
        fAlphaSplit= std::exp(-2.0f * pi * fSplit / sr);
        fOutGain   = std::pow(10.0f, fOutDb / 20.0f);
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(GlansPlugin)
};

Plugin* createPlugin() { return new GlansPlugin(); }

END_NAMESPACE_DISTRHO
