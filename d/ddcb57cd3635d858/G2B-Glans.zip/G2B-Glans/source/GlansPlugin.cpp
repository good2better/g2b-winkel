/*
 * G2B Glans — air + stereo width above a split frequency.
 * DSP: one-pole high-shelf "air" on the mid path + side-widening only
 * above the split point (sub/bass stays mono and powerful).
 * Same math as the JSFX g2b_glans used by G2B Engineer.
 */

#include "DistrhoPlugin.hpp"

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;
static const float kPresetParams[6][5] = {
    { 5, 1.3, 400, 9000, 0 },
    { 6, 1.15, 600, 8500, 0 },
    { 4, 1, 800, 8000, 0 },
    { 6.5, 1.5, 400, 10000, 0 },
    { 5.5, 1.25, 500, 9500, 0 },
    { 5, 1.4, 400, 9000, 0 },
};


class GlansPlugin : public Plugin
{
public:
    enum Parameters {
        kAir = 0,      // AIR dB
        kWidth,        // BREEDTE x
        kSplit,        // breedte vanaf Hz
        kAirFreq,      // air vanaf Hz
        kOut,          // output dB
        kDice, kPreset,
        kParameterCount
    };

    GlansPlugin()
        : Plugin(kParameterCount, 0, 0),
          fAirDb(2.5f), fWidth(1.15f), fSplit(1500.0f),
          fAirFreq(9500.0f), fOutDb(0.0f),
          fLpA{0.0f,0.0f}, fLpB{0.0f,0.0f}, fLpS(0.0f),
          fAlphaAir(0.0f), fAlphaSplit(0.0f), fAirK(0.0f), fOutGain(1.0f)
    {
        recalc();
    }

protected:
    const char* getLabel() const override { return "G2B Glans"; }
    const char* getDescription() const override
    {
        return "Glans aan je mix: air-boost en stereo-breedte ALLEEN boven "
               "een splitpunt — sub en midden blijven strak en gecentreerd.";
    }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','G','l'); }

    void initParameter(uint32_t index, Parameter& parameter) override
    {
        parameter.hints = kParameterIsAutomatable;
        switch (index)
        {
        case kAir:
            parameter.name = "Air";
            parameter.shortName = "Air";
            parameter.symbol = "air";
            parameter.unit = "dB";
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 10.0f;
            parameter.ranges.def = 2.5f;
            break;
        case kWidth:
            parameter.name = "Breedte";
            parameter.shortName = "Breedte";
            parameter.symbol = "width";
            parameter.unit = "x";
            parameter.ranges.min = 0.5f;
            parameter.ranges.max = 2.0f;
            parameter.ranges.def = 1.15f;
            break;
        case kSplit:
            parameter.name = "Breedte vanaf";
            parameter.shortName = "Vanaf";
            parameter.symbol = "split";
            parameter.unit = "Hz";
            parameter.ranges.min = 400.0f;
            parameter.ranges.max = 4000.0f;
            parameter.ranges.def = 1500.0f;
            break;
        case kAirFreq:
            parameter.name = "Air vanaf";
            parameter.shortName = "Air vanaf";
            parameter.symbol = "airfreq";
            parameter.unit = "Hz";
            parameter.ranges.min = 6000.0f;
            parameter.ranges.max = 14000.0f;
            parameter.ranges.def = 9500.0f;
            break;
        case kOut:
            parameter.name = "Output";
            parameter.shortName = "Output";
            parameter.symbol = "out";
            parameter.unit = "dB";
            parameter.ranges.min = -6.0f;
            parameter.ranges.max = 6.0f;
            parameter.ranges.def = 0.0f;
            break;
        case kDice: parameter.name="Dice"; parameter.symbol="dice"; parameter.hints=kParameterIsInteger|kParameterIsTrigger; parameter.ranges={0.0f,1.0f,0.0f}; break;
        case kPreset:
            parameter.name = "Preset";
            parameter.symbol = "preset";
            parameter.unit = "";
            parameter.hints = kParameterIsInteger;
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 5.0f;
            parameter.ranges.def = 0.0f;
            break;
        }
    }

    float getParameterValue(uint32_t index) const override
    {
        switch (index)
        {
        case kAir:     return fAirDb;
        case kWidth:   return fWidth;
        case kSplit:   return fSplit;
        case kAirFreq: return fAirFreq;
        case kOut:     return fOutDb;
        case kDice: return fDice; case kPreset: return fPreset;
        }
        return 0.0f;
    }

    void setParameterValue(uint32_t index, float value) override
    {
        if (index == kPreset) { fPreset = value; applyPreset((int)value); return; }
        switch (index)
        {
        case kAir:     fAirDb = value; break;
        case kWidth:   fWidth = value; break;
        case kSplit:   fSplit = value; break;
        case kAirFreq: fAirFreq = value; break;
        case kOut:     fOutDb = value; break;case kDice: if(value>0.5f)rollDice(); fDice=0.f; break;
        }
        recalc();
    }

    void activate() override
    {
        fLpA[0] = fLpA[1] = fLpB[0] = fLpB[1] = fLpS = 0.0f;
    }

    void run(const float** inputs, float** outputs, uint32_t frames) override
    {
        const float* inL = inputs[0];
        const float* inR = inputs[1];
        float* outL = outputs[0];
        float* outR = outputs[1];

        const float aAir = fAlphaAir;
        const float aHp  = fAlphaSplit;
        const float airK = fAirK;
        const float w    = fWidth;
        const float g    = fOutGain;

        float lpa0 = fLpA[0], lpa1 = fLpA[1];
        float lpb0 = fLpB[0], lpb1 = fLpB[1];
        float lps  = fLpS;

        for (uint32_t i = 0; i < frames; ++i)
        {
            float l = inL[i], r = inR[i];

            // air-shelf: een-pools hoogdoorlaat op elk kanaal
            lpa0 += aAir * (l - lpa0);
            lpa1 += aAir * (r - lpa1);
            l += (l - lpa0) * airK;
            r += (r - lpa1) * airK;

            // mid/side — breedte alleen boven de split
            const float mid  = (l + r) * 0.5f;
            const float side = (l - r) * 0.5f;
            lps += aHp * (side - lps);
            const float sideHi = side - lps;
            const float side2 = (side - sideHi) + sideHi * w;

            outL[i] = (mid + side2) * g;
            outR[i] = (mid - side2) * g;
        }

        fLpA[0] = lpa0; fLpA[1] = lpa1;
        fLpB[0] = lpb0; fLpB[1] = lpb1;
        fLpS = lps;
    }

private:
    void rollDice(){
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kAir,((fRnd>>8)%100)/100.f*8.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kWidth,0.8f+((fRnd>>8)%100)/100.f*1.0f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kSplit,800.f+((fRnd>>8)%100)/100.f*2400.f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kAirFreq,7000.f+((fRnd>>8)%100)/100.f*6000.f);
    }
    float fDice = 0.f;
    unsigned fRnd = 998877;

    float fAirDb, fWidth, fSplit, fAirFreq, fOutDb;
    float fLpA[2], fLpB[2], fLpS;
    float fAlphaAir, fAlphaSplit, fAirK, fOutGain;

    float fPreset = 0.0f;

    void applyPreset(int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        const float* p = kPresetParams[i];
        setParameterValue(kAir, p[0]);
        setParameterValue(kWidth, p[1]);
        setParameterValue(kSplit, p[2]);
        setParameterValue(kAirFreq, p[3]);
        setParameterValue(kOut, p[4]);
        recalc();
    }

    void recalc()
    {
        const float sr = (float)getSampleRate();
        const float pi = 3.14159265358979f;
        fAirK      = std::pow(10.0f, fAirDb / 20.0f) - 1.0f;
        fAlphaAir  = std::exp(-2.0f * pi * fAirFreq / sr);
        fAlphaSplit= std::exp(-2.0f * pi * fSplit / sr);
        fOutGain   = std::pow(10.0f, fOutDb / 20.0f);
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(GlansPlugin)
};

Plugin* createPlugin() { return new GlansPlugin(); }

END_NAMESPACE_DISTRHO
