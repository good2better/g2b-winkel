/*
 * G2B Glans — UI (NanoVG): donkergroen paneel, 5 draaiknoppen.
 * Verticaal slepen past de waarde aan; scrollwiel fijnafstellen.
 */

#include "DistrhoUI.hpp"

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;



class GlansUI : public UI
{
public:
    GlansUI()
        : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        std::memset(fValue, 0, sizeof(fValue));
        std::memset(fMin,   0, sizeof(fMin));
        std::memset(fMax,   0, sizeof(fMax));
        fDrag = -1;
        fLastY = 0.0f;

        // gespiegelde ranges (dezelfde als in de plugin)
        fMin[0]=0.0f;    fMax[0]=10.0f;
        fMin[1]=0.5f;    fMax[1]=2.0f;
        fMin[2]=400.0f;  fMax[2]=4000.0f;
        fMin[3]=6000.0f; fMax[3]=14000.0f;
        fMin[4]=-6.0f;   fMax[4]=6.0f;
        fLabel[0]="AIR";      fUnit[0]="dB";
        fLabel[1]="BREEDTE";  fUnit[1]="x";
        fLabel[2]="VANAF";    fUnit[2]="Hz";
        fLabel[3]="AIR VANAF";fUnit[3]="Hz";
        fLabel[4]="OUTPUT";   fUnit[4]="dB";
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        fValue[index] = value;
        repaint();
    }

    void onNanoDisplay() override
    {
        const float W = getWidth(), H = getHeight();

        // achtergrond — G2B donker
        beginPath();
        rect(0, 0, W, H);
        fillColor(13, 15, 14);
        fill();

        // titelbalk
        fontSize(20.0f);
        textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
        fillColor(47, 191, 113);
        text(18.0f, 26.0f, "G2B GLANS", nullptr);
        fontSize(12.0f);
        fillColor(143, 160, 152);
        text(18.0f, 46.0f, "air + breedte boven de split — G2B Engineer", nullptr);

        const int n = 5;
        const float step = (W - 40.0f) / n;
        for (int i = 0; i < n; ++i)
        {
            const float cx = 40.0f + step * (i + 0.5f);
            const float cy = 120.0f;
            const float R  = 34.0f;
            const float norm = (fValue[i] - fMin[i]) / (fMax[i] - fMin[i]);
            const float ang = -2.4f + norm * 4.8f;  // van ~-137° tot +137°

            // achterrand
            beginPath();
            circle(cx, cy, R);
            fillColor(30, 34, 33);
            fill();
            strokeColor(42, 47, 45);
            strokeWidth(2.0f);
            stroke();

            // waarde-boog (groen)
            beginPath();
            arc(cx, cy, R - 4.0f, -2.4f - 1.5708f, ang - 1.5708f, CW);
            strokeColor(47, 191, 113);
            strokeWidth(3.0f);
            stroke();

            // pointer
            beginPath();
            moveTo(cx, cy);
            lineTo(cx + std::sin(ang) * (R - 9.0f),
                   cy - std::cos(ang) * (R - 9.0f));
            strokeColor(232, 236, 234);
            strokeWidth(3.0f);
            stroke();

            // label + waarde
            fontSize(11.0f);
            fillColor(143, 160, 152);
            textAlign(ALIGN_CENTER | ALIGN_TOP);
            text(cx, cy + R + 8.0f, fLabel[i], nullptr);

            fontSize(12.5f);
            fillColor(232, 236, 234);
            char buf[32];
            if (fMax[i] > 1000.0f)
                snprintf(buf, sizeof(buf), "%.0f %s", fValue[i], fUnit[i]);
            else if (fMax[i] <= 2.5f)
                snprintf(buf, sizeof(buf), "%.2f %s", fValue[i], fUnit[i]);
            else
                snprintf(buf, sizeof(buf), "%.1f %s", fValue[i], fUnit[i]);
            text(cx, cy + R + 24.0f, buf, nullptr);
        }

        // voettekst
        fontSize(10.5f);
        fillColor(90, 100, 94);
        textAlign(ALIGN_CENTER | ALIGN_BOTTOM);
        
        // preset-knoppen
        {
            float bx = W - 14.0f;
            for (int i = kNumPresets - 1; i >= 0; --i)
            {
                const float bw = 62.0f, bh = 17.0f;
                bx -= bw + 5.0f;
                const bool on = (i == fProg);
                beginPath(); roundedRect(bx, 62.0f, bw, bh, 4.0f);
                if (on) { fillColor(29, 122, 72); fill(); }
                strokeColor(42, 47, 45); strokeWidth(1.0f); stroke();
                fontSize(10.0f); textAlign(ALIGN_CENTER | ALIGN_MIDDLE);
                fillColor(on ? Color(232, 236, 234) : Color(143, 160, 152));
                text(bx + bw * 0.5f, 62.0f + bh * 0.5f, kPresetNames[i], nullptr);
            }
        }

        text(W * 0.5f, H - 10.0f,
             "sleep omhoog/omlaag om te draaien — scroll = fijn", nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if (ev.button != 1) return false;
        const float W = getWidth();
        const float step = (W - 40.0f) / 5;
        if (ev.press)
        {
            // preset-klik?
            {
                float bx = W - 14.0f;
                for (int i = kNumPresets - 1; i >= 0; --i)
                {
                    const float bw = 62.0f, bh = 17.0f;
                    bx -= bw + 5.0f;
                    if (ev.pos.getX() >= bx && ev.pos.getX() <= bx + bw &&
                        ev.pos.getY() >= 62.0f && ev.pos.getY() <= 62.0f + bh)
                    {
                        setParameterValue(5, (float)i);
                        fProg = i;
                        repaint();
                        return true;
                    }
                }
            }

            for (int i = 0; i < 5; ++i)
            {
                const float cx = 40.0f + step * (i + 0.5f);
                const float cy = 120.0f;
                const float dx = ev.pos.getX() - cx;
                const float dy = ev.pos.getY() - cy;
                if (dx*dx + dy*dy <= 34.0f * 34.0f + 64.0f)
                {
                    fDrag = i;
                    fLastY = ev.pos.getY();
                    editParameter(i, true);
                    return true;
                }
            }
        }
        else if (fDrag >= 0)
        {
            editParameter(fDrag, false);
            fDrag = -1;
        }
        return true;
    }

    bool onMotion(const MotionEvent& ev) override
    {
        if (fDrag < 0) return false;
        const float dy = fLastY - ev.pos.getY();
        fLastY = ev.pos.getY();
        const float range = fMax[fDrag] - fMin[fDrag];
        float v = fValue[fDrag] + dy * range / 200.0f;
        if (v < fMin[fDrag]) v = fMin[fDrag];
        if (v > fMax[fDrag]) v = fMax[fDrag];
        fValue[fDrag] = v;
        setParameterValue(fDrag, v);
        repaint();
        return true;
    }

    bool onScroll(const ScrollEvent& ev) override
    {
        const float W = getWidth();
        const float step = (W - 40.0f) / 5;
        for (int i = 0; i < 5; ++i)
        {
            const float cx = 40.0f + step * (i + 0.5f);
            const float cy = 120.0f;
            const float dx = ev.pos.getX() - cx;
            const float dy = ev.pos.getY() - cy;
            if (dx*dx + dy*dy <= 34.0f * 34.0f + 64.0f)
            {
                const float range = fMax[i] - fMin[i];
                float v = fValue[i] + ev.delta.getY() * range / 100.0f;
                if (v < fMin[i]) v = fMin[i];
                if (v > fMax[i]) v = fMax[i];
                fValue[i] = v;
                editParameter(i, true);
                setParameterValue(i, v);
                editParameter(i, false);
                repaint();
                return true;
            }
        }
        return true;
    }

private:
    float fValue[5], fMin[5], fMax[5];
    const char* fLabel[5];
    const char* fUnit[5];
    int fDrag;
    float fLastY;
    int fProg = -1;

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(GlansUI)
};

UI* createUI() { return new GlansUI(); }

END_NAMESPACE_DISTRHO
