// G2B Donder Glider UI — all-in-one beat-machine scherm
// vaste G2B-balk: presets + dice + auto + dark/light
// 4 live-rijen (DRUMS/808/CHORD/MEL) + pitch-slide visual + 10 knobs (2 rijen)
#include "DistrhoUI.hpp"
#include <cstring>
#include <cstdio>
#include <cmath>

START_NAMESPACE_DISTRHO

class GliderUI : public UI
{
public:
    GliderUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[10] = {0,0,0,0,0,0,0,0,0,0};
        static const float maxs[10] = {16,11,1,1,1,1,1,1,1,1};
        static const float defs[10] = {1,9,0,0.8f,0.7f,0.35f,0.55f,0.35f,0.6f,0.6f};
        static const char* lbl[10]  = {"STYLE","KEY","SCALE","DRUMS","808","GLIDE","DROP","SUB","CHORD","MEL"};
        std::memcpy(fMin, mins, sizeof(mins));
        std::memcpy(fMax, maxs, sizeof(maxs));
        std::memcpy(fValue, defs, sizeof(defs));
        std::memcpy(fLabel, lbl, sizeof(lbl));
        fDrag=-1; fLastY=0; fStep=-1; fAuto=0; fLight=0; fPreset=0;
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if(index<10) fValue[index]=value;
        else if(index==11) fAuto=value;
        else if(index==12) fLight=value;
        else if(index==13) fPreset=value;
        repaint();
    }
    void stateChanged(const char* key, const char* value) override
    {
        if(std::strcmp(key,"step")==0) fStep=std::atoi(value);
        repaint();
    }
    void uiIdle() override { repaint(); }

    void onNanoDisplay() override
    {
        const float W=getWidth(), H=getHeight();
        const float bg[3] = {fLight?228.f:13.f, fLight?232.f:15.f, fLight?230.f:14.f};
        const float pn[3] = {fLight?214.f:23.f, fLight?220.f:26.f, fLight?217.f:25.f};
        const float tx[3] = {fLight?28.f:232.f, fLight?34.f:236.f, fLight?31.f:234.f};
        const float gy[3] = {fLight?96.f:100.f, fLight?108.f:110.f, fLight?101.f:103.f};
        const float ed[3]={42,47,45};
        const float GR[3]={47,191,113}, DG[3]={29,122,72};
        beginPath(); rect(0,0,W,H); fillColor(bg[0],bg[1],bg[2]); fill();

        fontSize(20.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(GR[0],GR[1],GR[2]);
        text(18,22,"G2B DONDER GLIDER",nullptr);
        fontSize(9.0f); fillColor(gy[0],gy[1],gy[2]);
        text(18,41,"all-in-one beat-machine — jouw 808 glijdt echt · MIDI",nullptr);

        // 16 presets: 2 rijen van 8, rechts
        static const char* names[17]={"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO","TRAP","BOOM","UKG","JERSEY","BOUNCE","SOUL","LOFI","FUNK","REGGAE","DANCE","KAW"};
        for(int i=0;i<17;i++){
            int prow=i/8, pcol=i%8;
            float bw=44.f, px=W-14.f-((prow<2?8:1)-pcol)*(bw+4.f), py=12.f+prow*20.f;
            beginPath(); roundedRect(px,py,bw,17,4);
            if((int)fPreset==i) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
            fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.0f); stroke();
            fontSize(8.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor((int)fPreset==i?tx[0]:gy[0],(int)fPreset==i?tx[1]:gy[1],(int)fPreset==i?tx[2]:gy[2]);
            text(px+bw/2,py+8.5f,names[i],nullptr);
        }
        // dice + auto + light
        beginPath(); roundedRect(14,48,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(11.f); fillColor(tx[0],tx[1],tx[2]); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
        text(27,56.5f,"\xF0\x9F\x8E\xB2",nullptr);
        beginPath(); roundedRect(44,48,42,17,4);
        if(fAuto>0.5f) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
        fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(8.5f); fillColor(fAuto>0.5f?tx[0]:gy[0],fAuto>0.5f?tx[1]:gy[1],fAuto>0.5f?tx[2]:gy[2]);
        text(65,56.5f,"AUTO",nullptr);
        float tlx=W-40.f;
        beginPath(); roundedRect(tlx,34,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(10.f); fillColor(tx[0],tx[1],tx[2]);
        text(tlx+13,42.5f,fLight?"\xF0\x9F\x8C\x99":"\xE2\x98\x80",nullptr);

        // part-activiteit: 4 rijen DRUMS/808/CHORD/MEL
        static const char* parts[4]={"DRUMS","808","CHORD","MEL"};
        static const unsigned char pc[4][3]={{47,191,113},{242,155,42},{66,135,245},{235,205,60}};
        for(int r=0;r<4;r++){
            float y=74.f+r*15.f;
            fontSize(8.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
            fillColor(pc[r][0],pc[r][1],pc[r][2]);
            text(18,y+4,parts[r],nullptr);
            for(int s=0;s<16;s++){
                beginPath(); rect(74.f+s*(W-96.f)/16.f,y+1.f,(W-96.f)/16.f-3.f,7.f);
                fillColor(s==fStep%16?pc[r][0]:ed[0],s==fStep%16?pc[r][1]:ed[1],s==fStep%16?pc[r][2]:ed[2]);
                fill();
            }
        }

        // pitch-slide visual (808-gebied)
        float gy0=142.f, gy1=196.f;
        beginPath(); rect(14,gy0,W-28,gy1-gy0); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(7.5f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(gy[0],gy[1],gy[2]); text(18,gy0+8,"808 slide",nullptr);
        float gs=0.02f+fValue[5]*0.38f; // zelfde glide-tijd als DSP
        beginPath();
        float x0=70.f,x1=W-20.f,yy=gy1-8.f,yTop=gy0+10.f;
        moveTo(x0,yy);
        for(float x=x0;x<x1;x+=4.f){
            float k=1.f-expf(-(x-x0)/(gs*(x1-x0)*3.f));
            lineTo(x,yy-(yy-yTop)*k);
        }
        strokeColor(GR[0],GR[1],GR[2]); strokeWidth(2.5f); stroke();

        // 10 knobs in 2 rijen van 5
        for(int i=0;i<10;i++){
            int row=i/5, col=i%5;
            float cx=40+(W-80)/5.f*(col+0.5f), cy=252+row*95.f, R=24;
            float norm=(fValue[i]-fMin[i])/(fMax[i]-fMin[i]); if(norm<0)norm=0; if(norm>1)norm=1;
            float ang=-2.4f+norm*4.8f;
            beginPath(); arc(cx,cy,R,0,6.2832f,CW); fillColor(pn[0],pn[1],pn[2]); fill();
            strokeColor(ed[0],ed[1],ed[2]); strokeWidth(2.f); stroke();
            beginPath(); arc(cx,cy,R-4.f,-2.4f-1.5708f,ang-1.5708f,CW);
            strokeColor(i==5?242.f:GR[0],i==5?155.f:GR[1],i==5?42.f:GR[2]); strokeWidth(3.f); stroke();
            beginPath(); moveTo(cx,cy); lineTo(cx+sinf(ang)*(R-8),cy-cosf(ang)*(R-8));
            strokeColor(tx[0],tx[1],tx[2]); strokeWidth(3.f); stroke();
            fontSize(9.5f); textAlign(ALIGN_CENTER|ALIGN_TOP);
            fillColor(i==5?242.f:gy[0],i==5?155.f:gy[1],i==5?42.f:gy[2]); text(cx,cy+R+8,fLabel[i],nullptr);
            static const char* stn[17]={"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO","TRAP","BOOM","UKG","JERSEY","BOUNCE","SOUL","LOFI","FUNK","REGGAE","DANCE","KAW"};
            static const char* kn[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
            char buf[16];
            if(i==0) std::snprintf(buf,16,"%s",stn[(int)fValue[0]<0?0:((int)fValue[0]>16?16:(int)fValue[0])]);
            else if(i==1) std::snprintf(buf,16,"%s",kn[(int)fValue[1]]);
            else if(i==2) std::snprintf(buf,16,"%s",fValue[2]>0.5f?"major":"minor");
            else std::snprintf(buf,16,"%.0f%%",fValue[i]*100.f);
            fillColor(tx[0],tx[1],tx[2]); text(cx,cy+R+21,buf,nullptr);
        }
        // onderregel
        fontSize(8.5f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
        fillColor(gy[0],gy[1],gy[2]);
        text(W/2,H-10,"MIDI-keyboard = 808 live spelen · legato = glijdt · DICE = nieuwe beat",nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if(ev.press&&ev.button==1){
            const float W=getWidth();
            for(int i=0;i<17;i++){
                int prow=i/8, pcol=i%8; float bw=44.f;
                float px=W-14.f-(8-pcol)*(bw+4.f), py=12.f+prow*20.f;
                if(ev.pos.getX()>=px&&ev.pos.getX()<=px+bw&&ev.pos.getY()>=py&&ev.pos.getY()<=py+17){
                    setParameterValue(13,(float)i);fPreset=i;repaint();return true;}}
            if(ev.pos.getX()>=14&&ev.pos.getX()<=40&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                setParameterValue(10,1.f);return true;}
            if(ev.pos.getX()>=44&&ev.pos.getX()<=86&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                fAuto=fAuto>0.5f?0.f:1.f;setParameterValue(11,fAuto);repaint();return true;}
            if(ev.pos.getX()>=W-40&&ev.pos.getX()<=W-14&&ev.pos.getY()>=34&&ev.pos.getY()<=51){
                fLight=fLight>0.5f?0.f:1.f;setParameterValue(12,fLight);repaint();return true;}
            for(int i=0;i<10;i++){
                int row=i/5, col=i%5;
                float cx=40+(W-80)/5.f*(col+0.5f),cy=252+row*95.f,R=24;
                float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
                if(dx*dx+dy*dy<(R+8)*(R+8)){fDrag=i;fLastY=ev.pos.getY();return true;}
            }
        }
        if(fDrag>=0&&ev.press==false){fDrag=-1;repaint();return true;}
        return false;
    }
    bool onMotion(const MotionEvent& ev) override
    {
        if(fDrag<0)return false;
        float dy=fLastY-ev.pos.getY(); fLastY=ev.pos.getY();
        float range=fMax[fDrag]-fMin[fDrag];
        float v=fValue[fDrag]+dy*range/200.f;
        if(v<fMin[fDrag])v=fMin[fDrag];if(v>fMax[fDrag])v=fMax[fDrag];
        fValue[fDrag]=v; setParameterValue(fDrag,v); repaint(); return true;
    }

private:
    float fValue[10],fMin[10],fMax[10];
    const char* fLabel[10];
    int fDrag; float fLastY;
    int fStep; float fAuto,fLight,fPreset;
};

UI* createUI(){ return new GliderUI(); }
END_NAMESPACE_DISTRHO
