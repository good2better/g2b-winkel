// G2B Donder Glider UI — all-in-one beat-machine scherm
// vaste G2B-balk: presets + dice + auto + dark/light
// 4 live-rijen (DRUMS/808/CHORD/MEL) + pitch-slide visual + 10 knobs (2 rijen)
#include "DistrhoUI.hpp"
#include <cstring>
#include <cstdio>
#include <cmath>

START_NAMESPACE_DISTRHO

class GliderUI : public UI
{
public:
    GliderUI() : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        static const float mins[14] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        static const float maxs[14] = {26,11,1,1,1,1,1,1,1,1,26,1,2,2};
        static const float defs[14] = {1,9,0,0.8f,0.7f,0.35f,0.55f,0.35f,0.6f,0.6f,9,0.7f,1.f,1.f};
        static const char* lbl[14]  = {"STYLE","KEY","SCALE","DRUMS","808","GLIDE","DROP","SUB","CHORD","MEL","GALAXY","DENS","SWING","HUMAN"};
        std::memcpy(fMin, mins, sizeof(mins));
        std::memcpy(fMax, maxs, sizeof(maxs));
        std::memcpy(fValue, defs, sizeof(defs));
        std::memcpy(fLabel, lbl, sizeof(lbl));
        static const int pids[14] = {0,1,2,3,4,7,8,9,5,6,10,17,18,19};
        std::memcpy(fParamId, pids, sizeof(pids));
        fDrag=-1; fLastY=0; fStep=-1; fAuto=0; fLight=0; fPreset=0;
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        for(int i=0;i<14;i++) if(index==fParamId[i]){fValue[i]=value;break;}
        else if(index==12) fAuto=value;
        else if(index==13) fLight=value;
        else if(index==14) fPreset=value;
        repaint();
    }
    void stateChanged(const char* key, const char* value) override
    {
        if(std::strcmp(key,"step")==0) fStep=std::atoi(value);
        else if(std::strcmp(key,"midifile")==0){ std::snprintf(fMidMsg,sizeof(fMidMsg),"%s",value); fMidT=400; }
        repaint();
    }
    void uiIdle() override { repaint(); }

    void onNanoDisplay() override
    {
        const float W=getWidth(), H=getHeight();
        static const int SK[8][7][3]={
            {{13,15,14},{23,26,25},{232,236,234},{100,110,103},{42,47,45},{47,191,113},{29,122,72}},
            {{14,14,22},{22,22,34},{230,232,255},{110,110,150},{40,40,58},{120,110,255},{70,60,170}},
            {{10,20,22},{16,30,32},{225,245,245},{95,130,130},{30,55,55},{40,200,210},{20,120,130}},
            {{24,14,20},{34,20,28},{250,230,240},{150,105,125},{60,38,50},{255,110,180},{180,60,120}},
            {{228,230,232},{240,242,244},{30,34,38},{105,112,118},{205,210,214},{40,140,100},{20,100,70}},
            {{18,10,10},{28,16,16},{240,225,220},{140,100,95},{55,35,32},{200,80,60},{130,45,35}},
            {{14,14,10},{22,22,16},{245,240,220},{120,115,95},{50,48,35},{230,190,80},{160,125,45}},
            {{12,14,20},{20,24,32},{235,240,250},{105,115,135},{36,44,58},{80,160,255},{45,110,200}}};
        static const char* SKN[8]={"MELIOR","SPECTRUM","LAGOON","CANDY","GHOST","MAROON","GOLD","STUDIO"};
        const int sk=(int)fLight<0?0:((int)fLight>7?7:(int)fLight);
        const int *bg=SK[sk][0],*pn=SK[sk][1],*tx=SK[sk][2],*gy=SK[sk][3],*ed=SK[sk][4],*GR=SK[sk][5],*DG=SK[sk][6];
        beginPath(); rect(0,0,W,H); fillColor(bg[0],bg[1],bg[2]); fill();

        fontSize(20.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(GR[0],GR[1],GR[2]);
        text(18,22,"G2B DONDER GLIDER",nullptr);
        fontSize(9.0f); fillColor(gy[0],gy[1],gy[2]);
        text(18,41,"all-in-one beat-machine — jouw 808 glijdt echt · MIDI",nullptr);

        // 16 presets: 2 rijen van 8, rechts
        static const char* names[27]={"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO","TRAP","BOOM","UKG","JERSEY","BOUNCE","SOUL","LOFI","FUNK","REGGAE","DANCE","KAW","DNB","GRIME","AFROT","LATIN","ZOUK","BUBBLE","EDM","POP","FUNKY","SURIN"};
        for(int i=0;i<27;i++){
            int prow=i/8, pcol=i%8;
            float bw=44.f, px=W-48.f-((prow<3?8:3)-pcol)*(bw+4.f), py=12.f+prow*20.f;
            beginPath(); roundedRect(px,py,bw,17,4);
            if((int)fPreset==i) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
            fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.0f); stroke();
            fontSize(8.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor((int)fPreset==i?tx[0]:gy[0],(int)fPreset==i?tx[1]:gy[1],(int)fPreset==i?tx[2]:gy[2]);
            text(px+bw/2,py+8.5f,names[i],nullptr);
        }
        // dice + auto + light
        beginPath(); roundedRect(14,48,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(11.f); fillColor(tx[0],tx[1],tx[2]); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
        text(27,56.5f,"\xF0\x9F\x8E\xB2",nullptr);
        beginPath(); roundedRect(44,48,42,17,4);
        if(fAuto>0.5f) fillColor(DG[0],DG[1],DG[2]); else fillColor(pn[0],pn[1],pn[2]);
        fill(); strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(8.5f); fillColor(fAuto>0.5f?tx[0]:gy[0],fAuto>0.5f?tx[1]:gy[1],fAuto>0.5f?tx[2]:gy[2]);
        text(65,56.5f,"AUTO",nullptr);
        // EXPORT .MID knop — schrijft het patroon als midi-bestand naar Muziek\\G2B
        beginPath(); roundedRect(90,48,42,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(8.0f); fillColor(tx[0],tx[1],tx[2]);
        text(111,56.5f,"\xE2\x86\x93MID",nullptr);

        float tlx=W-40.f;
        beginPath(); roundedRect(tlx,34,26,17,4); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(10.f); fillColor(tx[0],tx[1],tx[2]);
        text(tlx+13,42.5f,fLight>0.5f?"\xF0\x9F\x8C\x99":"\xE2\x98\x80",nullptr);
        fontSize(7.5f); fillColor(gy[0],gy[1],gy[2]); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
        text(tlx+13,60.5f,SKN[sk],nullptr);

        // part-activiteit: 4 rijen DRUMS/808/CHORD/MEL
        static const char* parts[4]={"DRUMS","808","CHORD","MEL"};
        static const unsigned char pc[4][3]={{47,191,113},{242,155,42},{66,135,245},{235,205,60}};
        for(int r=0;r<4;r++){
            float y=74.f+r*15.f;
            fontSize(8.0f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
            fillColor(pc[r][0],pc[r][1],pc[r][2]);
            text(18,y+4,parts[r],nullptr);
            for(int s=0;s<16;s++){
                beginPath(); rect(74.f+s*(W-96.f)/16.f,y+1.f,(W-96.f)/16.f-3.f,7.f);
                fillColor(s==fStep%16?pc[r][0]:ed[0],s==fStep%16?pc[r][1]:ed[1],s==fStep%16?pc[r][2]:ed[2]);
                fill();
            }
        }

        // pitch-slide visual (808-gebied)
        float gy0=142.f, gy1=196.f;
        beginPath(); rect(14,gy0,W-28,gy1-gy0); fillColor(pn[0],pn[1],pn[2]); fill();
        strokeColor(ed[0],ed[1],ed[2]); strokeWidth(1.f); stroke();
        fontSize(7.5f); textAlign(ALIGN_LEFT|ALIGN_MIDDLE);
        fillColor(gy[0],gy[1],gy[2]); text(18,gy0+8,"808 slide",nullptr);
        if(fMidT>0){ textAlign(ALIGN_RIGHT|ALIGN_TOP); fillColor(GR[0],GR[1],GR[2]);
                     text(W-20,gy0+3,fMidMsg,nullptr); fMidT--; }
        float gs=0.02f+fValue[5]*0.38f; // zelfde glide-tijd als DSP
        beginPath();
        float x0=70.f,x1=W-20.f,yy=gy1-8.f,yTop=gy0+10.f;
        moveTo(x0,yy);
        for(float x=x0;x<x1;x+=4.f){
            float k=1.f-expf(-(x-x0)/(gs*(x1-x0)*3.f));
            lineTo(x,yy-(yy-yTop)*k);
        }
        strokeColor(GR[0],GR[1],GR[2]); strokeWidth(2.5f); stroke();

        // 10 knobs in 2 rijen van 5
        for(int i=0;i<14;i++){
            int row=i/7, col=i%7;
            float cx=40+(W-80)/7.f*(col+0.5f), cy=252+row*95.f, R=24;
            float norm=(fValue[i]-fMin[i])/(fMax[i]-fMin[i]); if(norm<0)norm=0; if(norm>1)norm=1;
            float ang=-2.4f+norm*4.8f;
            beginPath(); arc(cx,cy,R,0,6.2832f,CW); fillColor(pn[0],pn[1],pn[2]); fill();
            strokeColor(ed[0],ed[1],ed[2]); strokeWidth(2.f); stroke();
            beginPath(); arc(cx,cy,R-4.f,-2.4f-1.5708f,ang-1.5708f,CW);
            strokeColor(i==5?242.f:GR[0],i==5?155.f:GR[1],i==5?42.f:GR[2]); strokeWidth(3.f); stroke();
            beginPath(); moveTo(cx,cy); lineTo(cx+sinf(ang)*(R-8),cy-cosf(ang)*(R-8));
            strokeColor(tx[0],tx[1],tx[2]); strokeWidth(3.f); stroke();
            fontSize(9.5f); textAlign(ALIGN_CENTER|ALIGN_TOP);
            fillColor(i==5?242.f:gy[0],i==5?155.f:gy[1],i==5?42.f:gy[2]); text(cx,cy+R+8,fLabel[i],nullptr);
            static const char* stn[17]={"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO","TRAP","BOOM","UKG","JERSEY","BOUNCE","SOUL","LOFI","FUNK","REGGAE","DANCE","KAW"};
            static const char* kn[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
            char buf[16];
            if(i==0) std::snprintf(buf,16,"%s",names[(int)fValue[0]<0?0:((int)fValue[0]>26?26:(int)fValue[0])]);
            else if(i==1) std::snprintf(buf,16,"%s",kn[(int)fValue[1]]);
            else if(i==2) std::snprintf(buf,16,"%s",fValue[2]>0.5f?"major":"minor");
            else if(i==10){int gp=(int)fValue[10];std::snprintf(buf,16,"%s %d",gp<9?"DARK":(gp<18?"LIGHT":"GALAXY"),gp%9+1);}
            else std::snprintf(buf,16,"%.0f%%",fValue[i]*100.f);
            fillColor(tx[0],tx[1],tx[2]); text(cx,cy+R+21,buf,nullptr);
        }
        // onderregel
        fontSize(8.5f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
        fillColor(gy[0],gy[1],gy[2]);
        text(W/2,H-10,"MIDI-keyboard = 808 live spelen · legato = glijdt · DICE = nieuwe beat",nullptr);
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if(ev.press&&ev.button==1){
            const float W=getWidth();
            for(int i=0;i<27;i++){
                int prow=i/8, pcol=i%8; float bw=44.f;
                float px=W-48.f-((prow<3?8:3)-pcol)*(bw+4.f), py=12.f+prow*20.f;
                if(ev.pos.getX()>=px&&ev.pos.getX()<=px+bw&&ev.pos.getY()>=py&&ev.pos.getY()<=py+17){
                    setParameterValue(14,(float)i);fPreset=i;repaint();return true;}}
            if(ev.pos.getX()>=14&&ev.pos.getX()<=40&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                setParameterValue(11,1.f);return true;}
            if(ev.pos.getX()>=44&&ev.pos.getX()<=86&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                fAuto=fAuto>0.5f?0.f:1.f;setParameterValue(12,fAuto);repaint();return true;}
            if(ev.pos.getX()>=90&&ev.pos.getX()<=132&&ev.pos.getY()>=48&&ev.pos.getY()<=65){
                setParameterValue(16,1.f);return true;}
            if(ev.pos.getX()>=W-40&&ev.pos.getX()<=W-14&&ev.pos.getY()>=34&&ev.pos.getY()<=51){
                fLight=((int)fLight+1)%8;setParameterValue(13,fLight);repaint();return true;}
            for(int i=0;i<14;i++){
                int row=i/7, col=i%7;
                float cx=40+(W-80)/7.f*(col+0.5f),cy=252+row*95.f,R=24;
                float dx=ev.pos.getX()-cx,dy=ev.pos.getY()-cy;
                if(dx*dx+dy*dy<(R+8)*(R+8)){fDrag=i;fLastY=ev.pos.getY();return true;}
            }
        }
        if(fDrag>=0&&ev.press==false){fDrag=-1;repaint();return true;}
        return false;
    }
    bool onMotion(const MotionEvent& ev) override
    {
        if(fDrag<0)return false;
        float dy=fLastY-ev.pos.getY(); fLastY=ev.pos.getY();
        float range=fMax[fDrag]-fMin[fDrag];
        float v=fValue[fDrag]+dy*range/200.f;
        if(v<fMin[fDrag])v=fMin[fDrag];if(v>fMax[fDrag])v=fMax[fDrag];
        fValue[fDrag]=v; setParameterValue(fParamId[fDrag],v); repaint(); return true;
    }

private:
    float fValue[14],fMin[14],fMax[14];
    const char* fLabel[14]; int fParamId[14];
    int fDrag; float fLastY;
    int fStep; float fAuto,fLight,fPreset;
    char fMidMsg[96]={0}; int fMidT=0;
};

UI* createUI(){ return new GliderUI(); }
END_NAMESPACE_DISTRHO
