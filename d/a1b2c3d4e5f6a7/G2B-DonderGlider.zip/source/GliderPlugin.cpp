// G2B Donder Glider — de G2B all-in-one beat-machine:
// drums + GLIJDENDE 808 + akkoorden + melodie, één scherm.
// 808-engine met echte pitch-slide (portamento), pitch-drop en sub/drive-blend.
// MIDI-bespeelbaar: speel de 808 live met je keyboard (legato = glijdt).
// Bouwt op de Song-engine + OchoOcho-808. © G2B (good2better) — MIT.
#include "DistrhoPlugin.hpp"
#include <cmath>
#include <cstring>
#include <cstdio>

START_NAMESPACE_DISTRHO

static const char kScaleM[7]={0,2,3,5,7,8,10};
static const char kScaleJ[7]={0,2,4,5,7,9,11};
static const char kPat[17][3][17]={
    {"x...x...x...x...","....x.......x...","x.x.x.x.x.x.x.x."}, // DEMBOW
    {"x.....x..x......","....x.......x...","x.xxx..x.xx.x.x."}, // DRILL
    {"x.....x...x.....","....x.......x...","x..x..x..x..x..x"}, // RNB
    {"x...x...x...x...","....x.......x...","..x...x...x...x."}, // HOUSE
    {"x..x....x..x....","....x.......x...","x.x..x.x.x.x..x."}, // AFRO
    {"x........x......","....x...x....x..","x.x.x.x.x.xxxxxx"}, // TRAP
    {"x...............","..x......x......","x..x..x..x..x.x."}, // BOOM
    {"x..x....x..x.x..","....x.....x..x..","..x..x.x..x..x.x"}, // UKG
    {"x..x..x...x...x.","....x..x........","x.x.xx.x.xx..x.."}, // JERSEY
    {"x...x.....x...x.","....x.x.....x...","x..x..x..x..x.x."}, // BOUNCE
    {"x.....x.........","....x....x......","x..x....x..x...."}, // SOUL
    {"x....x....x.....","....x.......x...","x.x..x..x.x..x.."}, // LOFI
    {"x..x....x..x..x.","....x...x..x....","x.x..x.xx.x..x.x"}, // FUNK
    {"x.....x.....x...","..x..........x..","x..x..x..x..x..."}, // REGGAE
    {"x...x...x...x...","....x.......x...","x.x..x.x..x.x..x"}, // DANCEHALL
    {"x..x....x...x..x","....x..x........","x..xx..x..x..x.x"}, // AMA-sort
    {"x..x.x..x..x.x..","....x.....x.x...","x.x.xx.x.x.xx.x."}  // KAWINA
};
static const char kBasPat[17][8]={
    {0,-1,0,-1,3,-1,0,-1},  // DEMBOW
    {0,-1,-1,5,-1,0,-1,-1}, // DRILL
    {0,-1,-1,-1,5,-1,-1,-1},// RNB
    {0,0,-1,-1,0,-1,5,-1},  // HOUSE
    {0,-1,3,-1,0,-1,5,-1},  // AFRO
    {0,-1,-1,0,-1,-1,5,-1}, // TRAP
    {0,-1,-1,-1,0,-1,-1,-1},// BOOM
    {0,-1,2,-1,0,-1,5,-1},  // UKG
    {0,-1,0,3,-1,0,-1,5},   // JERSEY
    {0,-1,0,-1,3,-1,0,-1},  // BOUNCE
    {0,-1,-1,-1,-1,-1,0,-1},// SOUL
    {0,-1,3,-1,0,-1,-1,-1}, // LOFI
    {0,0,-1,3,-1,0,-1,5},   // FUNK
    {0,-1,-1,5,-1,-1,0,-1}, // REGGAE
    {0,-1,0,-1,3,-1,0,-1},  // DANCEHALL
    {0,-1,-1,0,-1,5,-1,-1}, // AMA-sort
    {0,-1,0,-1,3,-1,2,-1}   // KAWINA
};
static const char kChr[4]={0,3,10,14};

class GliderPlugin : public Plugin
{
public:
    GliderPlugin() : Plugin(14, 0, 0) {}

protected:
    const char* getLabel() const override { return "G2B Donder Glider"; }
    const char* getDescription() const override
    { return "G2B all-in-one beat-machine: drums + glijdende 808 + akkoorden + melodie. Echte pitch-slide, MIDI-bespeelbaar."; }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "MIT"; }
    uint32_t getVersion() const override { return d_version(1,1,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','D','g'); }

    void initState(uint32_t, String&, String&) override {}
    void setState(const char*, const char*) override {}

    enum { kStijl, kKey, kScale, kDrums, kBas, kChord, kMel,
           kGlide, kDrop, kSub, kDice, kAuto, kLight, kPreset };

    void initParameter(uint32_t i, Parameter& p) override {
        p.hints = kParameterIsAutomable;
        switch(i){
        case kStijl: p.name="STYLE"; p.symbol="style"; p.ranges.min=0; p.ranges.max=4; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kKey:   p.name="KEY";   p.symbol="key";   p.ranges.min=0; p.ranges.max=11; p.ranges.def=9; p.hints|=kParameterIsInteger; break;
        case kScale: p.name="SCALE"; p.symbol="scale"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kDrums: p.name="DRUMS"; p.symbol="drums"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.8f; break;
        case kBas:   p.name="808";   p.symbol="bas";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.7f; break;
        case kChord: p.name="CHORD"; p.symbol="chord"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.6f; break;
        case kMel:   p.name="MEL";   p.symbol="mel";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.6f; break;
        case kGlide: p.name="GLIDE"; p.symbol="glide"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.35f; break;
        case kDrop:  p.name="DROP";  p.symbol="drop";  p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.55f; break;
        case kSub:   p.name="SUB";   p.symbol="sub";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.35f; break;
        case kDice:  p.name="DICE";  p.symbol="dice";  p.ranges.min=0; p.ranges.max=1; p.hints|=kParameterIsTrigger; break;
        case kAuto:  p.name="AUTO";  p.symbol="auto";  p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kLight: p.name="SKIN"; p.symbol="skin"; p.ranges.min=0; p.ranges.max=7; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kPreset:p.name="PRESET";p.symbol="preset";p.ranges.min=0; p.ranges.max=16; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        }
    }

    float getParameterValue(uint32_t i) const override {
        switch(i){case kStijl:return fStijl;case kKey:return fKey;case kScale:return fScale;
                  case kDrums:return fDrums;case kBas:return fBas;case kChord:return fChord;
                  case kMel:return fMel;case kGlide:return fGlide;case kDrop:return fDrop;
                  case kSub:return fSub;case kDice:return fDice;case kAuto:return fAuto;
                  case kLight:return fLight;case kPreset:return fPreset;}return 0.f;
    }

    void setParameterValue(uint32_t i, float v) override {
        switch(i){
        case kStijl:fStijl=v;break; case kKey:fKey=v;break; case kScale:fScale=v;break;
        case kDrums:fDrums=v;break; case kBas:fBas=v;break; case kChord:fChord=v;break;
        case kMel:fMel=v;break; case kGlide:fGlide=v;break; case kDrop:fDrop=v;break;
        case kSub:fSub=v;break;
        case kDice:if(v>0.5f)rollDice();fDice=0;break;
        case kAuto:fAuto=v;break; case kLight:fLight=v;break;
        case kPreset:if(v!=fPreset)applyPreset((int)v);fPreset=v;break;
        }
    }

    void run(const float** in, float** out, uint32_t frames, const MidiEvent* evs, uint32_t nev) override {
        const float sr=getSampleRate();
        double bpm=100.0;
        const TimePosition& tp=getTimePosition();
        if(tp.playing && tp.bbt.valid && tp.bbt.beatsPerMinute>1.0) bpm=tp.bbt.beatsPerMinute;
        const double stepLen=60.0/bpm/4.0;
        const int st=clampi(fStijl,0,16);
        uint32_t ei=0;
        for(uint32_t i=0;i<frames;i++){
            // MIDI-note events op exacte sample-positie
            while(ei<nev && evs[ei].frame<=i){
                const MidiEvent& e=evs[ei++];
                if(e.size>=3){
                    uint8_t st2=e.data[0]&0xF0, nt=e.data[1], vel=e.data[2];
                    if(st2==0x90 && vel>0) bassMidi(nt,vel/127.f);
                    else if(st2==0x80 || (st2==0x90 && vel==0)) bassOff(nt);
                }
            }
            fPhase+=1.0/sr;
            if(fPhase>=stepLen){
                fPhase=0; fStep++;
                int s=(int)fStep%16;
                if(fAuto>0.5f && s==0 && (fStep%64)==0) rollDice();
                if(kPat[st][0][s]!='.')kick();
                if(kPat[st][1][s]!='.')snare();
                if(kPat[st][2][s]!='.')hat();
                int b8=(s/2)%8;
                if(s%2==0 && kBasPat[st][b8]>=0)bass(deg2midi(kBasPat[st][b8]),0.9f);
                if(s==0)chord();
                if(s%4==0)melody();
                char sb[8];std::snprintf(sb,sizeof(sb),"%d",s);setState("step",sb);
            }
            float o=drumRender()+basRender(sr)+chordRender(sr)+melRender(sr);
            o=tanhf(o*1.4f)*0.8f;
            out[0][i]=o; out[1][i]=o;
        }
    }

private:
    static int clampi(float v,int a,int b){int x=(int)(v+0.5f);return x<a?a:(x>b?b:x);}
    float frand(uint32_t& s){s=s*1664525u+1013904223u;return (s>>9)*(1.f/8388608.f);}
    static float m2f(int m){return 440.f*powf(2.f,(m-69)/12.f);}

    int deg2midi(int deg){
        const char* sc=fScale>0.5f?kScaleJ:kScaleM;
        int d=deg%7; if(d<0)d+=7;
        return 36+(int)fKey+sc[d]+12*(deg/7);
    }

    // ---- drums ----
    struct DV{bool on;int type;float t,f0,f1,dec,amp;DV():on(false),type(0),t(0),f0(0),f1(0),dec(.1f),amp(.5f){}};
    DV dv_[3];
    void dv(int i,int ty,float f0,float f1,float dec,float amp){DV&v=dv_[i];v.on=true;v.type=ty;v.t=0;v.f0=f0;v.f1=f1;v.dec=dec;v.amp=amp;}
    void kick(){dv(0,0,150.f,48.f,.28f,.9f);}
    void snare(){dv(1,1,190.f,170.f,.16f,.5f);}
    void hat(){dv(2,2,0.f,0.f,.05f,.3f);}
    float drumRender(){
        float o=0;
        for(auto&v:dv_){if(!v.on)continue;v.t+=1.f/getSampleRate();
            float e=expf(-v.t/v.dec*5.f),s=0;
            if(v.type==0){float f=v.f1+(v.f0-v.f1)*expf(-v.t*30.f);s=sinf(2*M_PI*f*v.t)*e;}
            else if(v.type==1){s=(frand(fNs)*2-1)*e*0.7f+sinf(2*M_PI*v.f0*v.t)*e*0.4f;}
            else{s=(frand(fNs)*2-1)*e*0.8f;}
            o+=s*v.amp; if(e<0.001)v.on=false;}
        return o*fDrums;
    }

    // ---- GLIJDENDE 808 ----
    // f = huidige pitch, fT = doel-pitch; legato → glijdt, verse noot → pitch-drop
    struct BV{bool on,rel;float t,f,fT,vel,ph,relT;int note;
              BV():on(false),rel(false),t(0),f(55),fT(55),vel(.8f),ph(0),relT(0),note(-1){}};
    BV bv_;
    void bass(int m,float vel){
        float fT=m2f(m);
        if(!bv_.on || fGlide<0.01f){
            // verse noot: start boven doel (klassieke 808 pitch-drop)
            bv_.f=fT*(1.f+fDrop*0.6f);
            bv_.on=true;bv_.rel=false;bv_.t=0;bv_.vel=vel;
        }else{
            // legato: glijd van huidige pitch naar doel — dé drill-slide
            bv_.on=true;bv_.rel=false;bv_.vel=vel;
        }
        bv_.fT=fT;bv_.note=m;
    }
    void bassMidi(int m,float vel){bass(m,0.55f+0.45f*vel);} // keyboard: velocity mee
    void bassOff(int m){if(bv_.on && bv_.note==m){bv_.rel=true;bv_.relT=bv_.t;}}
    float basRender(float sr){
        if(!bv_.on)return 0;
        bv_.t+=1.f/sr;
        // pitch-slide: exponentieel naar doel, tempo uit GLIDE (20ms..400ms)
        float gsec=0.02f+fGlide*0.38f;
        bv_.f+= (bv_.fT-bv_.f)*(1.f-expf(-1.f/(sr*gsec)));
        bv_.ph+=bv_.f/sr; if(bv_.ph>1.f)bv_.ph-=1.f;
        // lange 808-uithaal + release bij note-off
        float e=expf(-bv_.t*2.6f);
        if(bv_.rel)e*=expf(-(bv_.t-bv_.relT)*14.f);
        float s=sinf(2.f*M_PI*bv_.ph);
        // SUB-blend: 0=puur sine → 1=tanh-drive (meer body/harmonischen)
        s=(1.f-fSub)*s + fSub*tanhf(s*(1.f+2.4f))*0.75f;
        if(e<0.0015)bv_.on=false;
        return s*e*bv_.vel*fBas*0.62f;
    }

    // ---- akkoorden ----
    struct CV{bool on;float t;float f[4];CV():on(false),t(0){f[0]=f[1]=f[2]=f[3]=0;}};
    CV cv_;
    void chord(){
        cv_.on=true;cv_.t=0;
        for(int j=0;j<4;j++)cv_.f[j]=m2f(deg2midi(kChr[j])+12);
    }
    float chordRender(float sr){
        if(!cv_.on)return 0;
        cv_.t+=1.f/sr;
        float e=expf(-cv_.t*0.9f);
        float s=0;for(int j=0;j<4;j++)s+=sinf(2*M_PI*cv_.f[j]*cv_.t)*0.22f+sinf(2*M_PI*cv_.f[j]*2*cv_.t)*e*0.06f;
        if(e<0.004)cv_.on=false;
        return s*fChord;
    }

    // ---- melodie ----
    struct MV{bool on;float t,f,amp;MV():on(false),t(0),f(440),amp(.5f){}};
    MV mv_;int fMelDeg=0;
    void melody(){
        int mv=(int)(frand(fRs)*4)-1;
        fMelDeg+=mv; if(fMelDeg<0)fMelDeg+=7; if(fMelDeg>10)fMelDeg-=7;
        int oct=(fMelDeg/7)*12; int d=fMelDeg%7;
        const char* sc=fScale>0.5f?kScaleJ:kScaleM;
        mv_.f=m2f((int)fKey+sc[d]+oct+12+36);
        mv_.on=true;mv_.t=0;
    }
    float melRender(float sr){
        if(!mv_.on)return 0;
        mv_.t+=1.f/sr;
        float e=expf(-mv_.t*2.4f);
        float s=(sinf(2*M_PI*mv_.f*mv_.t)+0.3f*sinf(2*M_PI*mv_.f*2*mv_.t)*e)*e;
        if(e<0.003)mv_.on=false;
        return s*fMel*0.5f;
    }

    void rollDice(){
        for(int b=0;b<6;b++)frand(fRs);
        setParameterValue(kStijl,(int)(frand(fRs)*17));
        setParameterValue(kDrums,0.6f+frand(fRs)*0.4f);
        setParameterValue(kBas,0.5f+frand(fRs)*0.5f);
        setParameterValue(kChord,0.4f+frand(fRs)*0.6f);
        setParameterValue(kMel,0.4f+frand(fRs)*0.6f);
        setParameterValue(kGlide,0.2f+frand(fRs)*0.5f);
        fMelDeg=(int)(frand(fRs)*7);
    }
    void applyPreset(int i){
        i=clampi(i,0,16);
        setParameterValue(kStijl,i);
        setParameterValue(kDrums,0.8f); setParameterValue(kBas,0.7f);
        setParameterValue(kChord,0.6f); setParameterValue(kMel,0.6f);
        setParameterValue(kGlide,i==1?0.55f:0.35f); // DRILL = meer slide
    }

    float fStijl=0,fKey=9,fScale=0,fDrums=.8f,fBas=.7f,fChord=.6f,fMel=.6f;
    float fGlide=.35f,fDrop=.55f,fSub=.35f;
    float fDice=0,fAuto=0,fLight=0,fPreset=0;
    double fPhase=1.0; uint64_t fStep=0;
    uint32_t fNs=1234,fRs=777;
};

Plugin* createPlugin(){ return new GliderPlugin(); }
END_NAMESPACE_DISTRHO
