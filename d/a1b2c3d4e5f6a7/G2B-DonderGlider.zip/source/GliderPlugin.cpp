// G2B Donder Glider — de G2B all-in-one beat-machine:
// drums + GLIJDENDE 808 + akkoorden + melodie, één scherm.
// 808-engine met echte pitch-slide (portamento), pitch-drop en sub/drive-blend.
// MIDI-bespeelbaar: speel de 808 live met je keyboard (legato = glijdt).
// Bouwt op de Song-engine + OchoOcho-808. © G2B (good2better) — MIT.
#include "DistrhoPlugin.hpp"
#include "vendor/MidiFile.h"
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#endif

START_NAMESPACE_DISTRHO

static const char kScaleM[7]={0,2,3,5,7,8,10};
static const char kScaleJ[7]={0,2,4,5,7,9,11};
static const char kPat[27][3][17]={
    {"x...x...x...x...","....x.......x...","x.x.x.x.x.x.x.x."}, // DEMBOW
    {"x.....x..x......","....x.......x...","x.xxx..x.xx.x.x."}, // DRILL
    {"x.....x...x.....","....x.......x...","x..x..x..x..x..x"}, // RNB
    {"x...x...x...x...","....x.......x...","..x...x...x...x."}, // HOUSE
    {"x..x....x..x....","....x.......x...","x.x..x.x.x.x..x."}, // AFRO
    {"x........x......","....x...x....x..","x.x.x.x.x.xxxxxx"}, // TRAP
    {"x...............","..x......x......","x..x..x..x..x.x."}, // BOOM
    {"x..x....x..x.x..","....x.....x..x..","..x..x.x..x..x.x"}, // UKG
    {"x..x..x...x...x.","....x..x........","x.x.xx.x.xx..x.."}, // JERSEY
    {"x...x.....x...x.","....x.x.....x...","x..x..x..x..x.x."}, // BOUNCE
    {"x.....x.........","....x....x......","x..x....x..x...."}, // SOUL
    {"x....x....x.....","....x.......x...","x.x..x..x.x..x.."}, // LOFI
    {"x..x....x..x..x.","....x...x..x....","x.x..x.xx.x..x.x"}, // FUNK
    {"x.....x.....x...","..x..........x..","x..x..x..x..x..."}, // REGGAE
    {"x...x...x...x...","....x.......x...","x.x..x.x..x.x..x"}, // DANCEHALL
    {"x..x....x...x..x","....x..x........","x..xx..x..x..x.x"}, // AMA-sort
    {"x..x.x..x..x.x..","....x.....x.x...","x.x.xx.x.x.xx.x."}, // KAWINA
    {"x..x....x..x....","....x.......x...","x.x.x.x.x.x.x.xx"}, // DNB
    {"x..x.....x......","......x....x....","x..xx..x..x..x.."}, // GRIME
    {"x...x...x...x...","....x.......x...","x..x..x.xx..x..x"}, // AFROTECH
    {"x..x..x...x..x..","....x..x....x...","x.x.x.xx.x.x.x.x"}, // LATIN
    {"x.....x...x.....","......x....x....","x..x..x..x..x.x."}, // ZOUK
    {"x..x..x.x..x..x.","....x.......x...","x.xx.xx.xx.xx.xx"}, // BUBBLE
    {"x...x...x...x...","....x.......x...","x.x.x.x.x.x.x.x."}, // EDM
    {"x...x...x...x...","....x.......x...","x..x..x..x..x..x"}, // POP
    {"x..x..x....x..x.","....x.......x...","x.x.xx.x.x.xx.x."}, // FUNKY
    {"x..x.x..x..x..x.","....x..x.....x..","x..x.x.x.x.x.x.x"}   // SURIN
};
static const char kBasPat[27][8]={
    {0,-1,0,-1,3,-1,0,-1},  // DEMBOW
    {0,-1,-1,5,-1,0,-1,-1}, // DRILL
    {0,-1,-1,-1,5,-1,-1,-1},// RNB
    {0,0,-1,-1,0,-1,5,-1},  // HOUSE
    {0,-1,3,-1,0,-1,5,-1},  // AFRO
    {0,-1,-1,0,-1,-1,5,-1}, // TRAP
    {0,-1,-1,-1,0,-1,-1,-1},// BOOM
    {0,-1,2,-1,0,-1,5,-1},  // UKG
    {0,-1,0,3,-1,0,-1,5},   // JERSEY
    {0,-1,0,-1,3,-1,0,-1},  // BOUNCE
    {0,-1,-1,-1,-1,-1,0,-1},// SOUL
    {0,-1,3,-1,0,-1,-1,-1}, // LOFI
    {0,0,-1,3,-1,0,-1,5},   // FUNK
    {0,-1,-1,5,-1,-1,0,-1}, // REGGAE
    {0,-1,0,-1,3,-1,0,-1},  // DANCEHALL
    {0,-1,-1,0,-1,5,-1,-1}, // AMA-sort
    {0,-1,0,-1,3,-1,2,-1},  // KAWINA
    {0,-1,-1,-1,5,-1,0,-1}, // DNB
    {0,-1,5,-1,-1,3,-1,-1}, // GRIME
    {0,0,-1,3,-1,0,-1,-1},  // AFROTECH
    {0,-1,3,-1,0,-1,2,-1},  // LATIN
    {0,-1,-1,3,-1,0,-1,-1}, // ZOUK
    {0,-1,3,5,-1,3,-1,0},   // BUBBLE
    {0,0,0,0,0,0,0,0},      // EDM
    {0,-1,0,-1,0,-1,3,-1},  // POP
    {0,-1,2,-1,3,-1,5,-1},  // FUNKY
    {0,-1,3,-1,2,-1,0,-1}   // SURIN
};
static const char kChr[4]={0,3,10,14};
static const char kProg[27][4]={ // v110: echte akkoord-progressies per stijl
    {0,5,3,4},{0,5,3,4},{0,5,2,4},{0,3,5,4},{0,5,3,6},{0,5,3,6},{0,3,5,4},
    {0,3,1,4},{0,5,3,6},{0,6,3,5},{0,5,6,3},{3,0,4,5},{1,4,0,3},{0,3,0,4},
    {0,4,3,5},{0,5,3,6},{0,5,3,4},{0,5,1,4},{0,2,5,4},{0,3,5,6},{0,4,3,5},
    {0,3,5,4},{0,6,3,5},{0,5,3,6},{0,4,5,3},{0,3,4,5},{0,5,3,4}};



// ---- GALAXY-knop (bron: backend/app/galaxy_fx.py, devin-test) — 27 posities ----
// 0-8=DARK (octaaf ONDER+donker), 9-17=LIGHT (octaaf BOVEN+helder), 18-26=GALAXY (+kwint, kosmisch)
struct GxShifter { // pitch-shift via gemoduleerde delay, 2 taps + driehoek-window
    static const int N=2048; float buf[N]; int wp=0; float ph=0;
    void reset(){std::memset(buf,0,sizeof buf);wp=0;ph=0;}
    float tick(float in,float rate){
        buf[wp]=in; float acc=0;
        for(int t=0;t<2;t++){
            float p=ph+0.5f*t; if(p>=1.f)p-=1.f;
            float rd=(float)wp-p*(float)N;
            int i0=(int)floorf(rd); float fr=rd-i0;
            float a=buf[((i0%N)+N)%N],b=buf[(((i0+1)%N)+N)%N];
            float w=p<0.5f?p*2.f:2.f-p*2.f;
            acc+=(a+(b-a)*fr)*w;
        }
        ph+=(1.f-rate)/(float)N; if(ph<0)ph+=1.f; if(ph>=1.f)ph-=1.f;
        wp=(wp+1)%N;
        return acc;
    }
};
struct Galaxy {
    GxShifter sh[4]; // 2 = shimmer L/R, 2 = kwint L/R
    static const int CN=2200;
    float cb[4][CN]; int cw[4];
    float ap[2][600]; int aw[2];
    float lp[2];
    int gpos=-1; float grate=2.f,gfb=0.5f,gfc=6500.f,gwet=0.6f,gdd=0.2f; int gmode=2; float keyMul=1.f; // v91: key-follow shimmer
    void reset(){for(int i=0;i<4;i++)sh[i].reset();std::memset(cb,0,sizeof cb);std::memset(ap,0,sizeof ap);
                 std::memset(cw,0,sizeof cw);std::memset(aw,0,sizeof aw);lp[0]=lp[1]=0;}
    void setPos(int pos){
        if(pos==gpos)return; gpos=pos;
        gmode=pos/9; int dim=pos%9;
        uint32_t sd=(gmode==0?10007u:(gmode==1?20011u:30017u))*9u+dim;
        auto rng=[&](){sd^=sd<<13;sd^=sd>>17;sd^=sd<<5;return (sd&0xFFFFFFu)/16777216.f;};
        grate=powf(2.f,(gmode==0?-12.f:12.f)/12.f);
        gdd=(gmode==0?0.20f:(gmode==1?0.16f:0.24f))*(0.8f+0.4f*rng());
        gfb=(gmode==0?0.50f:(gmode==1?0.40f:0.55f))*(0.85f+0.3f*rng()); if(gfb>0.72f)gfb=0.72f;
        gfc=(gmode==0?2600.f:(gmode==1?9000.f:6500.f))*(0.85f+0.35f*rng());
        gwet=(gmode==0?0.55f:(gmode==1?0.50f:0.62f));
    }
    void tick(float& L,float& R,float sr){
        float in[2]={L,R},shim[2]={0,0};
        for(int c=0;c<2;c++){
            float x=sh[c].tick(in[c],grate*keyMul);
            if(gmode==2)x+=0.6f*sh[2+c].tick(in[c],1.4983f);
            float a=expf(-6.283f*(gmode==0?gfc:320.f)/sr);
            lp[c]=(1.f-a)*x+a*lp[c];
            x=(gmode==0)?lp[c]:(x-lp[c]);
            int dd=(int)(gdd*sr); if(dd<64)dd=64; if(dd>CN-8)dd=CN-8;
            float tail=0;
            for(int k=0;k<4;k++){
                int rp=(cw[k]-dd-(dd*k/4)+CN*8)%CN;
                float e=cb[k][rp]; tail+=e*0.25f;
                cb[k][cw[k]]=x+e*gfb; cw[k]=(cw[k]+1)%CN;
            }
            const float g=0.5f;
            float av=ap[c][aw[c]];
            float y=-g*tail+av;
            ap[c][aw[c]]=tail+g*y; aw[c]=(aw[c]+1)%600;
            shim[c]=y;
        }
        L=in[0]+gwet*shim[0]*0.5f; R=in[1]+gwet*shim[1]*0.5f;
        if(L>0.98f)L=0.98f; else if(L<-0.98f)L=-0.98f;
        if(R>0.98f)R=0.98f; else if(R<-0.98f)R=-0.98f;
    }
};

class GliderPlugin : public Plugin
{
public:
    GliderPlugin() : Plugin(14, 0, 0) {}

protected:
    const char* getLabel() const override { return "G2B Donder Glider"; }
    const char* getDescription() const override
    { return "G2B all-in-one beat-machine: drums + glijdende 808 + akkoorden + melodie. Echte pitch-slide, MIDI-bespeelbaar."; }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "MIT"; }
    uint32_t getVersion() const override { return d_version(1,1,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','D','g'); }

    void initState(uint32_t, String&, String&) override {}
    void setState(const char*, const char*) override {}

    enum { kStijl, kKey, kScale, kDrums, kBas, kChord, kMel,
           kGlide, kDrop, kSub,kGalaxy, kDice, kAuto, kLight, kPreset, kMidi, kExport, kDens, kSwing, kHuman };

    void initParameter(uint32_t i, Parameter& p) override {
        p.hints = kParameterIsAutomable;
        switch(i){
        case kStijl: p.name="STYLE"; p.symbol="style"; p.ranges.min=0; p.ranges.max=26; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kKey:   p.name="KEY";   p.symbol="key";   p.ranges.min=0; p.ranges.max=11; p.ranges.def=9; p.hints|=kParameterIsInteger; break;
        case kScale: p.name="SCALE"; p.symbol="scale"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kDrums: p.name="DRUMS"; p.symbol="drums"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.8f; break;
        case kBas:   p.name="808";   p.symbol="bas";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.7f; break;
        case kChord: p.name="CHORD"; p.symbol="chord"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.6f; break;
        case kMel:   p.name="MEL";   p.symbol="mel";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.6f; break;
        case kGlide: p.name="GLIDE"; p.symbol="glide"; p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.35f; break;
        case kDrop:  p.name="DROP";  p.symbol="drop";  p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.55f; break;
        case kSub:   p.name="SUB";   p.symbol="sub";   p.ranges.min=0; p.ranges.max=1; p.ranges.def=0.35f; break;
        case kGalaxy:p.name="GALAXY"; p.symbol="galaxy";p.ranges.min=0; p.ranges.max=26; p.ranges.def=9; p.hints|=kParameterIsInteger; break;
        case kDice:  p.name="DICE";  p.symbol="dice";  p.ranges.min=0; p.ranges.max=1; p.hints|=kParameterIsTrigger; break;
        case kAuto:  p.name="AUTO";  p.symbol="auto";  p.ranges.min=0; p.ranges.max=1; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kLight: p.name="SKIN"; p.symbol="skin"; p.ranges.min=0; p.ranges.max=7; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kPreset:p.name="PRESET";p.symbol="preset";p.ranges.min=0; p.ranges.max=26; p.ranges.def=0; p.hints|=kParameterIsInteger; break;
        case kMidi:  p.name="MIDI OUT";p.symbol="midiout";p.ranges.min=0;p.ranges.max=1;p.ranges.def=1;p.hints|=kParameterIsBoolean; break;
        case kExport:p.name="EXPORT .MID";p.symbol="exportmid";p.ranges.min=0;p.ranges.max=1;p.hints|=kParameterIsTrigger; break;
        case kDens:  p.name="DENS";p.symbol="dens";p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.7f; break;
        case kSwing: p.name="SWING";p.symbol="swing";p.ranges.min=0;p.ranges.max=2;p.ranges.def=1.f; break;
        case kHuman: p.name="HUMAN";p.symbol="human";p.ranges.min=0;p.ranges.max=2;p.ranges.def=1.f; break;
        }
    }

    float getParameterValue(uint32_t i) const override {
        switch(i){case kStijl:return fStijl;case kKey:return fKey;case kScale:return fScale;
                  case kDrums:return fDrums;case kBas:return fBas;case kChord:return fChord;
                  case kMel:return fMel;case kGlide:return fGlide;case kDrop:return fDrop;
                  case kSub:return fSub;case kGalaxy:return fGalaxy;case kDice:return fDice;case kAuto:return fAuto;
                  case kLight:return fLight;case kPreset:return fPreset;case kMidi:return fMidi;case kExport:return 0.f;case kDens:return fDens;case kSwing:return fSwing;case kHuman:return fHuman;}return 0.f;
    }

    void setParameterValue(uint32_t i, float v) override {
        switch(i){
        case kStijl:fStijl=v;break; case kKey:fKey=v;break; case kScale:fScale=v;break;
        case kDrums:fDrums=v;break; case kBas:fBas=v;break; case kChord:fChord=v;break;
        case kMel:fMel=v;break; case kGlide:fGlide=v;break; case kDrop:fDrop=v;break;
        case kSub:fSub=v;break; case kGalaxy:fGalaxy=v;galaxy.setPos((int)v);break;
        case kDice:if(v>0.5f)rollDice();fDice=0;break;
        case kAuto:fAuto=v;break; case kLight:fLight=v;break; case kMidi:fMidi=v;break;
        case kExport:if(v>0.5f)writeMid_();break;
        case kPreset:if(v!=fPreset)applyPreset((int)v);fPreset=v;break;
        case kDens:fDens=v;break; case kSwing:fSwing=v;break; case kHuman:fHuman=v;break;
        }
    }

    void run(const float** in, float** out, uint32_t frames, const MidiEvent* evs, uint32_t nev) override {
        const float sr=getSampleRate();
        double bpm=100.0;
        const TimePosition& tp=getTimePosition();
        if(tp.playing && tp.bbt.valid && tp.bbt.beatsPerMinute>1.0) bpm=tp.bbt.beatsPerMinute;
        fBpm=bpm;
        const double stepLen=60.0/bpm/4.0;
        if(fStepLen<=0)fStepLen=stepLen; // swing: oneven stappen iets later — menselijke feel
        float stF=(fStijl<0?0:(fStijl>26?26:fStijl)); const int st=(int)stF; const float morphF=stF-st;
        if(st!=fMutStyle && fAuto>0.5f && pendSt_<0){pendSt_=st;}
        if(st!=fMutStyle || fabsf(morphF-fMorphF)>0.02f){if(fAuto>0.5f&&fStep%16!=0)goto skipSeed; fMutStyle=st;fMorphF=morphF;for(int l2=0;l2<3;l2++)mtLane_[l2]=(int)((frand(fRs)-0.5f)*fStepLen*(fStepLen>0?1.f/fStepLen:1.f)*0.f);for(int l2=0;l2<3;l2++)mtLane_[l2]=(int)((frand(fRs)-0.5f)*sr*0.010f);const int stB=(st<26)?st+1:0;for(int a=0;a<3;a++)for(int b=0;b<17;b++)mut_[a][b]=(frand(fRs)<morphF?kPat[stB][a][b]:kPat[st][a][b]);for(int b=0;b<8;b++)mutBas_[b]=(frand(fRs)<morphF?kBasPat[stB][b]:kBasPat[st][b]);phn_=0;}
        skipSeed:
        uint32_t ei=0;
        for(uint32_t i=0;i<frames;i++){
            // MIDI-note events op exacte sample-positie
            while(ei<nev && evs[ei].frame<=i){
                const MidiEvent& e=evs[ei++];
                if(e.size>=3){
                    uint8_t st2=e.data[0]&0xF0, ch=e.data[0]&0x0F, nt=e.data[1], vel=e.data[2];
                    if(st2==0x90 && vel>0){
                        if(ch==0){ bassMidi(nt,vel/127.f);
                            int rel=nt-36-(int)fKey; rel=((rel%12)+12)%12;
                            int sc2[7]={0,2,3,5,7,8,10}; int bd=0,bdD=99;
                            for(int d=0;d<7;d++){int dd=abs(rel-sc2[d]);if(dd<bdD){bdD=dd;bd=d;}}
                            mutBas_[(fStep/2)%8]=bd; // jouw bass-noot → bascel
                            // RESPOND: engine antwoordt een 16e later, een interval omhoog in de toonsoort
                            int rd=bd+(frand(fRs)<.5f?2:3); int oct2=rd/7; rd%=7;
                            respN_=nt+sc2[rd]-sc2[bd]+12*oct2; respAt_=i+(uint32_t)(stepLen*sr);
                        }
                        else if(ch==1){cv2_.on=true;cv2_.t=0;cv2_.f=m2f(nt);} // akkoord-stab live
                        else if(ch==2){mv_.f=m2f(nt);mv_.on=true;mv_.t=0;lastMel_=nt;hookM_[(fStep/16)%4][(fStep%16)/4]=nt;} // jouw noot → hook-cel
                        else { // ch3: drums live — jouw taps schrijven direct in het patroon
                            int rs=fStep%16;
                            if(nt==36){dv(0,0,kitKf0,kitKf1,kitKdec,kitKamp*vel/127.f);fDuck=0.f;mut_[0][rs]='1';}
                            else if(nt==38){dv(1,1,kitSf0,kitSf1,kitSdec,kitSamp*vel/127.f);mut_[1][rs]='1';}
                            else if(nt==45||nt==47){dv(1,2,nt==47?95.f:110.f,nt==47?72.f:80.f,.10f,.22f*vel/127.f);mut_[2][rs]='1';}
                            else if(nt==49){dv(2,3,0.f,0.f,kitHdec*6.f,.34f*vel/127.f);} // crash
                            else if(nt==51){dv(2,2,0.f,0.f,kitHdec*2.5f,.20f*vel/127.f);} // ride
                            else {dv(2,2,0.f,0.f,kitHdec,kitHamp*vel/127.f);mut_[2][rs]='1';}
                        }
                    }
                    else if(st2==0x80 || (st2==0x90 && vel==0)){ if(ch==0)bassOff(nt); }
                }
            }
            fPhase+=1.0/sr;
            // MIDI note-offs die deze sample vallen
            for(int k=0;k<phn_;k++)if(ph_[k].at<=i){dv(ph_[k].t,ph_[k].v,ph_[k].f0,ph_[k].f1,ph_[k].dec,ph_[k].amp);ph_[k].at=0xFFFFFFFFu;}
            while(offr_!=offw_){PendingOff& o=offq_[offr_];if(o.at>i)break;emitMidi(0x80|o.ch,o.note,0,i);offr_=(offr_+1)%64;}
            if(respAt_==i){bass(respN_,0.55f);midiHit(respN_,1,75,i,stepLen*sr*1.5f);respAt_=0xFFFFFFFFu;} // RESPOND-answer
            if(fPhase>=fStepLen){
                fPhase=0; fStep++;
                int s=(int)fStep%16;
                if(pendSt_>=0&&s==0){int ps=pendSt_;pendSt_=-1;fMutStyle=-1;setParameterValue(kStijl,ps);} int mtK=(int)((frand(fRs)+frand(fRs)+frand(fRs)-1.5f)*sr*0.010f*fHuman); // v161 drummer-jitter · v164 HUMAN-knop
                int mtS=(int)((frand(fRs)+frand(fRs)+frand(fRs)-1.5f)*sr*0.012f*fHuman);
                int mtH=(int)((frand(fRs)+frand(fRs)+frand(fRs)-1.5f)*sr*0.018f*fHuman);
                const float sw=((st==16||st==0||st==1||st==15||st==25||st==26)?0.19f:((st==17||st==18||st==23||st==24)?0.03f:0.14f))*fSwing; // v163 SWING-knop schaalt stijl-swing
                if(fAuto>0.5f && s==0 && (fStep%64)==0) rollDice();
                int bar=(int)(fStep/16)%8; bool fill=(bar==7 && s>=12);
                                const int root=kProg[st][bar%4]; root_=root; // v110: huidige akkoord-grondtoon
                if(s==0 && fStep>0 && (fStep%(16*8))==0){
                    if(frand(fRs)<.3f)hookM_[(int)(frand(fRs)*3.99f)][(int)(frand(fRs)*3.99f)]=0; // v98 hook-cel vrij → nieuwe noot mag
                 // evolutie: nieuwe sectie muteert 1-2 cellen + bas
                    {int b2=(int)(frand(fRs)*7.99f); mutBas_[b2]=(mutBas_[b2]<0)?(int)(frand(fRs)*6.99f):-1;}
                    for(int m=0;m<2;m++){int a=(int)(frand(fRs)*2.99f),b=(int)(frand(fRs)*15.99f);
                        if(!(a==0&&(b==0||b==8))) mut_[a][b]=(mut_[a][b]=='.')?'X':'.';}
                    phn_=0;
                }
                // stijl-eigen kit: elke dimensie klinkt anders (deterministisch per stijl)
                uint32_t ks=1000u+(uint32_t)st*61u;
                auto kr=[&](){ks^=ks<<13;ks^=ks>>17;ks^=ks<<5;return (ks&0xFFFFFFu)/16777216.f;};
                const float kf0=140.f+kr()*60.f,kf1=42.f+kr()*18.f,kdec=.20f+kr()*.16f,kamp=.78f+kr()*.24f;
                const float sf0=175.f+kr()*40.f,sf1=150.f+kr()*45.f,sdec=.11f+kr()*.09f,samp=.40f+kr()*.22f;
                const float hdec=.032f+kr()*.05f,hamp=.22f+kr()*.18f;
                kitKf0=kf0;kitKf1=kf1;kitKdec=kdec;kitKamp=kamp;kitSf0=sf0;kitSf1=sf1;kitSdec=sdec;kitSamp=samp;kitHdec=hdec;kitHamp=hamp;
                float jv=(0.88f+0.24f*frand(fRs))*((s==4||s==12)?1.15f:1.f); // humanize + accent op backbeat
                jv=1.f+(jv-1.f)*fHuman; // v164 HUMAN schaalt velocity-jitter
                // AUTO-arrange: intro spaars (bar0), break (bar3), fill (bar7)
                const int sec=(int)(fStep/16)%16; // v39: 16-bar form
                const float arc=(fStep>0)?(0.72f+0.28f*sinf(6.28318f*((float)(fStep%1024))/1024.f+1.57f)):1.f; // v69: energie-boog over 64 bars
                const int songB=(int)(fStep/16)%64; // v111 AUTO-SONG: 0-7 intro,8-23 verse,24-31 chorus,32-47 verse2,48-55 chorus2,56-63 brug
                const bool chorus=(songB>=24&&songB<32)||(songB>=48&&songB<56);
                const bool intro=songB<8; const bool outro=songB>=56;
                const float secE=intro?0.55f:(chorus?1.25f:(outro?0.7f:1.f));
                const bool bd=(sec>=8&&sec<12); // breakdown
                const bool choke=(songB==23||songB==47)&&s>=14; // v151 stilte voor de drop
                const bool gKick=(bar!=3&&!(bd&&s%8!=0&&s%8!=4))&&(bar!=0||s==0||s==8)&&(intro?(s%8==0||s%8==4):true)&&!choke;
                const bool gSnare=bar>0&&bar!=3&&!intro&&!choke;
                const bool gHat=(bar!=0||s%2==1||chorus)&&!(bd&&s%4!=0&&!chorus)&&!choke;
                const bool gBass=bar>0;
                if((songB==23||songB==47)&&s>=12&&s%2==0&&phn_<21){ // v113 riser naar chorus
                    ph_[phn_++]={2,2,9000.f+600.f*(s-12),11000.f,hdec*.5f,.12f+(s-12)*.03f,i};}
                if((st==5||st==16||st==20||st==26)&&s%4==3&&phn_<21&&frand(fRsD)<fDens){ // v121 polyrhythm tripel-perc · v162 DENS
                    uint32_t trd=(uint32_t)(stepLen*sr/3.f);
                    for(int k=0;k<2;k++)ph_[phn_++]={2,2,0.f,0.f,hdec*.8f,hamp*.30f,i+trd*(k+1)};
                }
                if(fill){ // v46: cycli — snare-roll / tom-fill / EUCLIDEAN / cascade
                    if(((int)(fStep/128)%4)==3){if(s>=13&&phn_<21){uint32_t trd2=(uint32_t)(stepLen*sr/3.f);float tp2=230.f-(s-13)*36.f;for(int k=0;k<3;k++){ph_[phn_++]={1,2,tp2,tp2*.7f,.10f,.28f,i+trd2*k};midiHit(45,0,66,i+trd2*k,stepLen*sr*0.2f);}}}
                    else
                    if(((int)(fStep/128)%3)==2){
                        const int eucl[5]={0,0,1,0,1}; // e(3,5) over s=11..15
                        if(s>=11&&s<=15&&eucl[s-11]){dv(1,1,sf0,sf1*1.1f,sdec*.9f,samp*.55f);midiHit(38,0,72,i,stepLen*sr*0.4f);
                            dv(2,2,0.f,0.f,hdec*.7f,hamp*.4f);midiHit(42,0,48,i,stepLen*sr*0.25f);}
                    }
                    else if(((int)(fStep/128)%2)==0){dv(1,1,sf0,sf1,sdec,samp*(.5f+.13f*(s-12))); midiHit(38,0,60+(s-12)*9,i,stepLen*sr*0.4f);
                        dv(2,2,0.f,0.f,hdec,hamp*.5f);           midiHit(42,0,45,i,stepLen*sr*0.3f);}
                    else{float tp=130.f-(s-12)*18.f;dv(1,2,tp,tp*.8f,.09f,.26f+.05f*(s-12));midiHit(45,0,65,i,stepLen*sr*0.35f);
                        dv(2,2,0.f,0.f,hdec*.8f,hamp*.35f);     midiHit(42,0,40,i,stepLen*sr*0.25f);}
                    if((st==5||st==17||st==18)&&s>=14&&phn_<22){ // trap/dnb/grime hat-roll
                        uint32_t third=(uint32_t)(stepLen*sr/3.f);
                        for(int k=0;k<2;k++){ph_[phn_++]={2,2,0.f,0.f,hdec*.5f,hamp*.4f,i+third*(k+1)};midiHit(42,0,40,i+third*(k+1),stepLen*sr*0.25f);}}
                } else {
                if((st==8||st==9) && s%4==2 && gKick && frand(fRsD)<fDens){dv(0,0,kf0*1.4f,kf1,kdec*.5f,kamp*.22f*jv);} // v77 jersey ghost-kick
                if(songB>=48&&songB<56&&s%4==2&&gKick&&!choke&&frand(fRsD)<fDens){dv(0,0,kf0*1.25f,kf1,kdec*.4f,kamp*.20f*jv);midiHit(36,0,50,i,stepLen*sr*0.3f);} // v153 2e chorus extra
                if(arc>.78f && s%8==6 && frand(fRsD)<fDens){dv(1,2,110.f,80.f,.10f,.20f*jv*arc);midiHit(45,0,(int)(55*arc),i+mtH,stepLen*sr*0.5f);} // tom
                if((st==12||st==11||st==13)&&frand(fRs)<.07f&&frand(fRsD)<fDens){dv(2,2,0.f,0.f,.008f,.07f);} // v156 vinyl-knetsers
                { // v32 shaker-bed: 16e perc onder de beat
                    float shA=(st==16||st==20||st==25||st==0)?.16f:((st==6||st==2)?.05f:.10f); shA*=arc*secE*fDens; // shaker ademt met boog+sectie · v162 DENS
                    dv(2,2,0.f,0.f,hdec*.6f,shA*((s%2==0)?1.f:.45f)*jv*((st==20||st==16||st==26)&&(s%8==2)?1.4f:1.f));}
                if((st==1||st==5||st==18||st==2)&&gKick && mut_[0][s]!='.'&&phn_<22){ph_[phn_++]={3,3,35.f,32.f,.5f,.30f,i+2};} // v38 sub
                if(gKick && mut_[0][s]!='.'){if(chorus||phn_>9){dv(0,0,kf0,kf1,kdec,kamp*jv*(s==0?1.14f:1.f));}else{ph_[phn_++]={0,0,kf0,kf1,kdec,kamp*jv*(s==0?1.14f:1.f),i+(uint32_t)(sr*0.004f)};}midiHit(36,0,(int)(105*jv),i+mtH,stepLen*sr*0.9f);fDuck=0.f;} // v158 laid-back kick
                if(gSnare && mut_[1][s]!='.'){dv(1,1,sf0,sf1,sdec,samp*jv);midiHit(38,0,(int)(95*jv),i+mtH,stepLen*sr*0.9f);}
                    if(phn_<22&&frand(fRsD)<fDens){uint32_t dly=(uint32_t)(sr*.09f);ph_[phn_++]={1,1,sf0*.9f,sf1,sdec*3.2f,samp*.12f*jv,i+dly};} // v34 staart
                if(s==0 && (bar==0||bar==4)){dv(2,2,0.f,0.f,.7f,.14f);midiHit(49,0,80,i,stepLen*sr*4.f);} // crash op sectie-start
                if(gHat && s%4==2 && bar>0 && frand(fRsD)<fDens && (((int)fStijl==4||(int)fStijl==20||(int)fStijl==15)?true:(frand(fRs)<.4f))){int ho=mtH+mtLane_[2];if(phn_<22){ph_[phn_++]={2,2,0.f,0.f,hdec*4.5f,hamp*.55f*jv,i+(uint32_t)(ho>0?ho:0)};}else{dv(2,2,0.f,0.f,hdec*4.5f,hamp*.55f*jv);}midiHit(46,0,(int)(55*jv),i+mtH,stepLen*sr*0.8f);} // open hat
                if(gHat && mut_[2][s]!='.' && !((st==6||st==13||st==2)&&s%2==1&&frand(fRs)<.42f)){dv(2,2,0.f,0.f,hdec*((st==4||st==23||st==20)?1.6f:1.f),hamp*jv*((st==1||st==2||st==6||st==18)?0.72f:1.f)); // v141 hat-kleur
                    midiHit(42,0,(int)(75*jv),i+mtH,stepLen*sr*0.5f);}
                else if(frand(fRsD)<fDens&&(fRs=fRs*1664525u+1013904223u,(fRs>>9)&15)<2){dv(2,2,0.f,0.f,.04f,.09f);midiHit(42,0,30,i,stepLen*sr*0.4f);} // ghost-hat
                if(s%4==2 && mut_[1][s]=='.' && frand(fRsD)<fDens && ((fRs>>9)&31)<3){dv(1,1,190.f,170.f,.10f,.14f);midiHit(38,0,28,i,stepLen*sr*0.5f);} // ghost-snare
                }
                int b8=(s/2)%8;
                if(gBass && s%2==0 && mutBas_[b8]>=0){int nm=deg2midi(mutBas_[b8]+root)+(((int)fStep/16%8)==7&&s>=14?-7:0);bass(nm,0.9f*jv*(s==0||s==8?1.08f:1.f));midiHit(nm,1,110,i,stepLen*sr*(2.f+fGlide*2.f));}
                // syncopatie: odden stappen een octaaf-akkoord op dichte stijlen
                if(outro&&bar>=6&&s==0){int nm=deg2midi(root);bass(nm,0.8f);midiHit(nm,1,100,i,stepLen*sr*3.f);} // v130 outro-tag
                if(gBass && s%2==1 && mutBas_[b8]>=0 && (st%3==0||st%5==0) && frand(fRsD)<fDens){int nm=deg2midi(mutBas_[b8]+root)+12;bass(nm,0.42f*jv);midiHit(nm,1,60,i,stepLen*sr*0.9f);}
                if((s==8&&((int)fStijl==4||(int)fStijl==23||(int)fStijl==20||(int)fStijl==24))||(chorus&&s==8)){chord();for(int j=0;j<4;j++)midiHit(chordDeg(j,(lastBD_>=0?lastBD_:bar)%4,root)+12,2,50,i,stepLen*sr*1.5f);} // 2e stoot (voice-led)
                if((s==4||s==12)&&((int)fStijl==4||(int)fStijl==23||(int)fStijl==24)&&frand(fRsD)<fDens){ // v33 arp-stoot
                    int j2=(s==4?1:2); midiHit(chordDeg(j2,bar%4,root)+24,2,45,i,stepLen*sr*0.8f);
                    {CV2&c2=cv2_; c2.on=true;c2.t=0;c2.f=m2f(chordDeg(j2,bar%4,root)+24);}}
                if(s==0&&(songB==24||songB==48)){dv(3,3,70.f,38.f,1.1f,.85f);fDuck=0.f;} // v139 drop-impact
                if(s==0&&(songB==24||songB==32||songB==48||songB==56)){dv(2,3,0.f,0.f,hdec*6.f,.30f);midiHit(49,0,80,i,stepLen*sr*2.f);} // v122 sectie-crash
                if(s==0){chord();for(int j=0;j<4;j++)midiHit(chordDeg(j,(lastBD_>=0?lastBD_:bar)%4,root)+(((int)fStijl==1||(int)fStijl==5||(int)fStijl==18||(int)fStijl==6)?0:12),2,60,i,stepLen*sr*((st==4||st==23||st==20)?1.4f:3.f));} // voice-led + stijl-release
                if(s%4==2&&bar>4&&!intro&&frand(fRs)<.28f&&frand(fRsD)<fDens){melody();midiHit(lastMel_,3,45,i,stepLen*sr*.8f);} // v36 call-response
                if(s%4==0&&bar!=3){ // v47 hook: per 4 bars herhaalt de melodie zich
                    int hb=bar%4;
                    if(bar<4&&!intro){melody();hookM_[hb][s/4]=lastMel_;}
                    else if(hookM_[hb][s/4]>0&&frand(fRs)<.8f){mv_.f=m2f(lastMel_=hookM_[hb][s/4]+(frand(fRs)<.2f?12:0)+(outro?-12:0));mv_.on=true;mv_.t=0;
                        if(!(st==4||st==23||st==20||st==21)){cv2_.on=true;cv2_.t=0;cv2_.f=m2f(lastMel_-5);}} // v116 duet-stem
                        midiHit(lastMel_,3,70,i,stepLen*sr*1.5f);}
                char sb[8];std::snprintf(sb,sizeof(sb),"%d",s);setState("step",sb);
                fStepLen=stepLen*(s%2==0?1.f+sw:1.f-sw); // swing-gap
            }
            fDuck+=1.f/sr;
            const int stD=(int)fStijl; const float duckAmt=(stD==4||stD==23||stD==20)?0.44f:((stD==6||stD==13||stD==2)?0.16f:0.32f);
            float duck=1.f-duckAmt*expf(-fDuck*5.5f);
            fDrumsS+=(fDrums-fDrumsS)/sr*40.f; fBasS+=(fBas-fBasS)/sr*40.f;
            fChordS+=(fChord-fChordS)/sr*40.f; fMelS+=(fMel-fMelS)/sr*40.f;
            float wide=(chordRender(sr)+arpRender(sr)+melRender(sr))*duck;
            float oC=drumRender()+basRender(sr)*(0.80f+0.20f*duck);
            float mixx=oC+wide;
            {const int RD=3970; float rd=roomB_[roomW_%RD]; roomB_[roomW_%RD]=mixx*0.45f; roomW_++; oC+=rd*0.12f;}
            const int WD=530; float wd=wideB_[wideW_%WD]; wideB_[wideW_%WD]=wide*0.55f; wideW_++;
            float Lo=oC+wide*0.62f, Ro=oC+wide*0.30f+wd*0.62f;
            out[0][i]=tanhf(Lo*1.4f)*0.8f; out[1][i]=tanhf(Ro*1.4f)*0.8f; // v146 stereo-breedte
        }
        for(uint32_t i=0;i<frames;i++){
            float L=out[0][i],R=out[1][i];
            galaxy.tick(L,R,getSampleRate());
            out[0][i]=L; out[1][i]=R;
        }
        fAbsFrames+=frames;
    }

private:
    // MIDI-uitsturing: gegenereerde hits als MIDI naar de DAW (sleep/routeerbaar)
    struct PendingOff{uint8_t note,ch;uint32_t at;};
    PendingOff offq_[64]; int offw_=0,offr_=0;
    char mut_[3][17]; int mutBas_[8]; struct PendHit{int t,v;float f0,f1,dec,amp;uint32_t at;} ph_[24]; int phn_=0; int mtLane_[3]={0,0,0}; int pendSt_=-1; int root_=0; int lastBD_=-1; int respN_=-1; uint32_t respAt_=0xFFFFFFFFu;
    double fStepLen=0; int lastMel_=60;
    void emitMidi(uint8_t st,uint8_t nt,uint8_t vel,uint32_t fr){
        MidiEvent e{}; e.frame=fr; e.size=3;
        e.data[0]=st; e.data[1]=nt; e.data[2]=vel;
        writeMidiEvent(e);
    }
    void midiHit(int note,int ch,int vel,uint32_t i,double dur){
        // neem op voor .mid-export (altijd, ook met MIDI OUT uit)
        MidiRec& r=rec_[recW_];
        r.fr=fAbsFrames+i; r.note=(uint8_t)note; r.ch=(uint8_t)ch; r.vel=(uint8_t)vel;
        r.dur=(uint16_t)(dur>60000.0?60000.0:(dur<1.0?1.0:dur));
        recW_=(recW_+1)%8192; recN_++;
        if(fMidi<0.5f)return;
        emitMidi(0x90|ch,(uint8_t)note,(uint8_t)vel,i);
        PendingOff& o=offq_[offw_]; o.note=(uint8_t)note; o.ch=(uint8_t)ch; o.at=i+(uint32_t)dur;
        offw_=(offw_+1)%64;
    }
    // ---- EXPORT .MID: opgenomen hits als echt midi-bestand wegschrijven ----
    struct MidiRec{uint64_t fr;uint8_t note,ch,vel;uint16_t dur;};
    MidiRec rec_[8192]; int recW_=0; uint64_t recN_=0, fAbsFrames=0; double fBpm=100.0;
    void writeMid_(){
        const double sr=getSampleRate();
        const double fpt=sr*60.0/(fBpm*480.0); // frames per tick @480 tpq
        smf::MidiFile mf; mf.setTicksPerQuarterNote(480); mf.addTrack(1);
        const uint64_t n=recN_<8192?recN_:8192;
        const int start=(recN_<=8192)?0:recW_;
        int seq=0;
        for(uint64_t k=0;k<n;k++){
            const MidiRec& r=rec_[(start+(int)k)%8192];
            if(r.note==0&&r.vel==0&&r.fr==0)continue;
            smf::MidiEvent on(0x90|r.ch,r.note,r.vel); on.tick=(int)(r.fr/fpt); on.seq=seq++;
            smf::MidiEvent off(0x80|r.ch,r.note,0); off.tick=(int)((r.fr+r.dur)/fpt); off.seq=seq++;
            mf[0].push_back(on); mf[0].push_back(off);
        }
        mf.sortTracks();
        const char* home=std::getenv("USERPROFILE");
        if(!home||!*home)home=std::getenv("HOME");
        char dir[520],path[600];
        if(home&&*home)std::snprintf(dir,sizeof(dir),"%s\\Music\\G2B",home);
        else std::snprintf(dir,sizeof(dir),".");
#ifdef _WIN32
        _mkdir(dir);
#else
        mkdir(dir,0755);
#endif
        std::snprintf(path,sizeof(path),"%s\\G2B-DonderGlider.mid",dir);
        if(mf.write(path))setState("midifile",".mid opgeslagen: Music\\G2B\\G2B-DonderGlider.mid");
        else setState("midifile",".mid NIET gelukt — map niet schrijfbaar");
    }

    static int clampi(float v,int a,int b){int x=(int)(v+0.5f);return x<a?a:(x>b?b:x);}
    float frand(uint32_t& s){s=s*1664525u+1013904223u;return (s>>9)*(1.f/8388608.f);}
    static float m2f(int m){return 440.f*powf(2.f,(m-69)/12.f);}

    int deg2midi(int deg){
        const char* sc=fScale>0.5f?kScaleJ:kScaleM;
        int d=deg%7; if(d<0)d+=7;
        return 36+(int)fKey+sc[d]+12*(deg/7);
    }

    // ---- drums ----
    struct DV{bool on;int type;float t,f0,f1,dec,amp;DV():on(false),type(0),t(0),f0(0),f1(0),dec(.1f),amp(.5f){}};
    DV dv_[3];
    void dv(int i,int ty,float f0,float f1,float dec,float amp){DV&v=dv_[i];v.on=true;v.type=ty;v.t=0;v.f0=f0;v.f1=f1;v.dec=dec;v.amp=amp;}
    void kick(){dv(0,0,150.f,48.f,.28f,.9f);}
    void snare(){dv(1,1,190.f,170.f,.16f,.5f);}
    void hat(){dv(2,2,0.f,0.f,.05f,.3f);}
    float drumRender(){
        float o=0;
        for(auto&v:dv_){if(!v.on)continue;v.t+=1.f/getSampleRate();
            float e=expf(-v.t/v.dec*5.f),s=0;
            if(v.type==0){float f=v.f1+(v.f0-v.f1)*expf(-v.t*30.f);s=sinf(2*M_PI*f*v.t)*e;}
            else if(v.type==1){s=(frand(fNs)*2-1)*e*0.7f+sinf(2*M_PI*v.f0*v.t)*e*0.4f;}
            else{s=(frand(fNs)*2-1)*e*0.8f;}
            o+=s*v.amp; if(e<0.001)v.on=false;}
        return o*fDrumsS;
    }

    // ---- GLIJDENDE 808 ----
    // f = huidige pitch, fT = doel-pitch; legato → glijdt, verse noot → pitch-drop
    struct BV{bool on,rel;float t,f,fT,vel,ph,relT;int note;
              BV():on(false),rel(false),t(0),f(55),fT(55),vel(.8f),ph(0),relT(0),note(-1){}};
    BV bv_;
    void bass(int m,float vel){
        float fT=m2f(m); galaxy.keyMul=powf(2.f,log2f(fT/220.f)*0.5f); // shimmer volgt de 808
        
        if(!bv_.on || fGlide<0.01f){
            // verse noot: start boven doel (klassieke 808 pitch-drop)
            bv_.f=fT*(1.f+fDrop*0.6f);
            bv_.on=true;bv_.rel=false;bv_.t=0;bv_.vel=vel;
        }else{
            // legato: glijd van huidige pitch naar doel — dé drill-slide
            bv_.on=true;bv_.rel=false;bv_.vel=vel;
            if(fMidi>0.5f&&bv_.note>0){ // MIDI pitch-bend voor de slide in de DAW
                int st=(int)roundf(12.f*log2f(m2f(m)/m2f(bv_.note)));
                if(st<-2)st=-2; if(st>2)st=2;
                int bend=8192+(int)(st*4096.f/2.f);
                MidiEvent e{}; e.frame=0; e.size=3;
                e.data[0]=0xE0|1; e.data[1]=(uint8_t)(bend&0x7F); e.data[2]=(uint8_t)(bend>>7);
                writeMidiEvent(e);
            }
        }
        bv_.fT=fT;bv_.note=m;
    }
    void bassMidi(int m,float vel){bass(m,0.55f+0.45f*vel);} // keyboard: velocity mee
    void bassOff(int m){if(bv_.on && bv_.note==m){bv_.rel=true;bv_.relT=bv_.t;}}
    float basRender(float sr){
        if(!bv_.on)return 0;
        bv_.t+=1.f/sr;
        // pitch-slide: exponentieel naar doel, tempo uit GLIDE (20ms..400ms)
        float gsec=0.02f+fGlide*0.38f;
        bv_.f+= (bv_.fT-bv_.f)*(1.f-expf(-1.f/(sr*gsec)));
        bv_.ph+=bv_.f/sr; if(bv_.ph>1.f)bv_.ph-=1.f;
        // lange 808-uithaal + release bij note-off
        float e=expf(-bv_.t*2.6f);
        if(bv_.rel)e*=expf(-(bv_.t-bv_.relT)*14.f);
        float s=sinf(2.f*M_PI*bv_.ph);
        // SUB-blend: 0=puur sine → 1=tanh-drive (meer body/harmonischen)
        s=(1.f-fSub)*s + fSub*tanhf(s*(1.f+2.4f))*0.75f;
        if(e<0.0015)bv_.on=false;
        return s*e*bv_.vel*fBasS*0.62f;
    }

    // ---- akkoorden ----
    struct CV{bool on;float t;float f[4];CV():on(false),t(0){f[0]=f[1]=f[2]=f[3]=0;}};
    CV cv_; struct CV2{bool on=false;float t,f;} cv2_;
    int chordDeg(int j,int vo,int root=0){ // voicings + progressie-root
        int d=kChr[j]+root;
        if(vo==1&&j==0)d+=12; else if(vo==2&&j==3)d+=12; else if(vo==3&&j==1)d+=1;
        return deg2midi(d);
    }
    void chord(){
        cv_.on=true;cv_.t=0;
        int vo=(int)(fStep/16)%4;
        int co=((int)fStijl==1||(int)fStijl==5||(int)fStijl==18||(int)fStijl==6)?0:12; // v42 donker=-12
        for(int j=0;j<4;j++)cv_.f[j]=m2f(chordDeg(j,vo,root_)+co);
    }
    float arpRender(float sr){
        if(!cv2_.on)return 0; cv2_.t+=1.f/sr; float e=expf(-cv2_.t*3.2f);
        float s=(sinf(2*M_PI*cv2_.f*cv2_.t)+.25f*sinf(2*M_PI*cv2_.f*3*cv2_.t)*e)*e;
        if(e<0.004)cv2_.on=false; return s*fChordS*.5f;
    }
    float chordRender(float sr){
        float dr=1.f+0.0023f*sinf(2*M_PI*fDrift+.7f);
        if(!cv_.on)return 0;
        cv_.t+=1.f/sr;
        float e=expf(-cv_.t*0.9f);
        float s=0;for(int j=0;j<4;j++)s+=sinf(2*M_PI*cv_.f[j]*dr*cv_.t)*0.22f+sinf(2*M_PI*cv_.f[j]*2*cv_.t)*e*0.06f;
        if(e<0.004)cv_.on=false;
        return s*fChordS;
    }

    // ---- melodie ----
    struct MV{bool on;float t,f,amp;MV():on(false),t(0),f(440),amp(.5f){}};
    MV mv_;int fMelDeg=0; int hookM_[4][4]={{0}};
    void melody(){
        int bar32=(int)(fStep/16)%32;
        if(bar32>=24&&bar32<28){ // v82 brug: melodie improviseert op akkoord-tonen
            lastMel_=chordDeg((int)(frand(fRs)*3.99f),(lastBD_>=0?lastBD_:0)%4,root_)+24;
            mv_.f=m2f(lastMel_); mv_.on=true; mv_.t=0; return;
        }
        int mv=(int)(frand(fRs)*4)-1;
        fMelDeg+=mv; if(fMelDeg<0)fMelDeg+=7; if(fMelDeg>10)fMelDeg-=7;
        int oct=(fMelDeg/7)*12 + (((int)fStijl==19||(int)fStijl==24||(int)fStijl==20||(int)fStijl==23)?12:0); if(((int)(fStep/16)%8)==4)oct-=12; int d=fMelDeg%7;
        const char* sc=fScale>0.5f?kScaleJ:kScaleM;
        d=(d+root_)%14; // v137: melodie beweegt mee met de progressie
        lastMel_=(int)fKey+sc[d%7]+oct+12+36+12*(d/7);
        mv_.f=m2f(lastMel_);
        mv_.on=true;mv_.t=0;
    }
    float melRender(float sr){
        fDrift+=1.f/sr*.13f; float dr=1.f+0.0023f*sinf(2*M_PI*fDrift);
        if(!mv_.on)return 0;
        mv_.t+=1.f/sr;
        float e=expf(-mv_.t*2.4f);
        float s=(sinf(2*M_PI*mv_.f*dr*mv_.t)+0.3f*sinf(2*M_PI*mv_.f*2*mv_.t)*e)*e;
        if(e<0.003)mv_.on=false;
        return s*fMelS*0.5f;
    }

    void rollDice(){
        for(int m=0;m<4;m++){int a=(int)(frand(fRs)*2.99f),b=(int)(frand(fRs)*15.99f);
            if(!(a==0&&(b==0||b==8))) mut_[a][b]=(mut_[a][b]=='.')?'X':'.';}
        for(int b=0;b<6;b++)frand(fRs);
        setParameterValue(kStijl,(int)(frand(fRs)*27));
        setParameterValue(kDrums,0.6f+frand(fRs)*0.4f);
        setParameterValue(kBas,0.5f+frand(fRs)*0.5f);
        setParameterValue(kChord,0.4f+frand(fRs)*0.6f);
        setParameterValue(kMel,0.4f+frand(fRs)*0.6f);
        setParameterValue(kGlide,0.2f+frand(fRs)*0.5f);
        fMelDeg=(int)(frand(fRs)*7);
    }
    void applyPreset(int i){
        i=clampi(i,0,26);
        setParameterValue(kStijl,i);
        setParameterValue(kDrums,0.8f); setParameterValue(kBas,0.7f);
        setParameterValue(kChord,0.6f); setParameterValue(kMel,0.6f);
        setParameterValue(kGlide,i==1?0.55f:0.35f); // DRILL = meer slide
    }

    float fStijl=0,fKey=9,fScale=0,fDrums=.8f,fBas=.7f,fChord=.6f,fMel=.6f;
    float fGlide=.35f,fDrop=.55f,fSub=.35f;
    int fMutStyle=-1;
    float fMorphF=0; float kitKf0=150,kitKf1=48,kitKdec=.28,kitKamp=.9,kitSf0=190,kitSf1=170,kitSdec=.16,kitSamp=.5,kitHdec=.05,kitHamp=.3; float fDrift=0; float roomB_[4000]; uint32_t roomW_=0; float fDrumsS=1,fBasS=1,fChordS=1,fMelS=1; float fDice=0,fAuto=0,fDuck=9,fLight=0,fPreset=0,fGalaxy=9,fMidi=1; float wideB_[640]; uint32_t wideW_=0;
    Galaxy galaxy;
    double fPhase=1.0; uint64_t fStep=0;
    uint32_t fNs=1234,fRs=777,fRsD=24601; float fDens=0.7f; float fSwing=1.f; float fHuman=1.f;
};

Plugin* createPlugin(){ return new GliderPlugin(); }
END_NAMESPACE_DISTRHO
