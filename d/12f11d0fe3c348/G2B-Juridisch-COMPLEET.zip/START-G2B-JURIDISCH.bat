@echo off
title G2B Juridisch
cd /d "%~dp0"
echo ============================================
echo   G2B JURIDISCH - je wetboek, 100%% lokaal
echo ============================================
echo.

REM Python vinden of installeren
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo Python niet gevonden. Installeer eerst Python 3.11+ van python.org
    echo (vink "Add Python to PATH" aan tijdens installatie!)
    pause & exit /b 1
)

REM Virtuele omgeving maken (eenmalig)
if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Eenmalige installatie - even geduld...
    python -m venv .venv
    call .venv\Scripts\pip.exe install -q -r backend\requirements.txt
) else (
    echo [1/3] Installatie al gedaan.
)

echo [2/3] App starten op http://localhost:8020 ...
start "" http://localhost:8020
echo [3/3] Klaar! Sluit dit venster NIET (of de app stopt).
cd backend
call ..\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8020
pause
