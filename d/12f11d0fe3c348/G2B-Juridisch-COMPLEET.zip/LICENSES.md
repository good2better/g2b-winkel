# Licenties — G2B Juridisch (regel 1: alles open source + commercieel vrij)

| Onderdeel | Licentie | Commercieel? |
|---|---|---|
| Wetteksten via vrijewetgeving.nl | CC0 (publiek domein) | ✅ onbeperkt |
| fastapi | MIT | ✅ |
| uvicorn | BSD-3 | ✅ |
| reportlab | BSD | ✅ |

Geen GPL/AGPL, geen cloud-API's, geen AI-diensten, geen kosten.
