"""G2B Juridisch — lokale Nederlandse wetboek-app. Poort 8020."""
import json
import threading
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from . import importer, pdf, uitspraken
from .koppeling import KOPPELING
from .wetlijst import BASIS_WETTEN, INDEX_URL

ROOT = Path(__file__).resolve().parent.parent
STATIC = Path(__file__).resolve().parent / "static"

app = FastAPI(title="G2B Juridisch")
_import_status = {"bezig": False, "laatste": None, "fout": None}


@app.get("/api/status")
def status():
    return {**importer.stats(importer.db()), "import": _import_status}


@app.get("/api/wetten")
def wetten():
    con = importer.db()
    rows = con.execute(
        "SELECT id, citeertitel, titel, datum, "
        "(SELECT COUNT(*) FROM artikelen WHERE wet=wetten.id) AS n "
        "FROM wetten ORDER BY citeertitel").fetchall()
    return [{"id": r[0], "citeertitel": r[1], "titel": r[2],
             "datum": r[3], "artikelen": r[4]} for r in rows]


@app.get("/api/wet/{wet_id}/artikelen")
def artikelen(wet_id: str):
    con = importer.db()
    rows = con.execute(
        "SELECT a.nummer, a.context, a.tekst FROM artikelen a "
        "JOIN wetten w ON w.id=a.wet WHERE w.id=? OR w.citeertitel=? "
        "ORDER BY CAST(a.nummer AS REAL), a.nummer",
        (wet_id, wet_id)).fetchall()
    if not rows:
        raise HTTPException(404, "wet niet gevonden of nog niet geïmporteerd")
    return [{"nummer": r[0], "context": r[1], "tekst": r[2]} for r in rows]


@app.get("/api/zoek")
def zoek(q: str = Query(min_length=2), modus: str = "auto"):
    return importer.zoek(importer.db(), q, modus=modus)


@app.get("/api/artikel")
def artikel(wet: str, nummer: str):
    con = importer.db()
    r = con.execute(
        "SELECT w.titel, w.citeertitel, a.context, a.tekst, w.bron "
        "FROM artikelen a JOIN wetten w ON w.id=a.wet "
        "WHERE (w.id=? OR w.citeertitel=?) AND a.nummer=?",
        (wet, wet, nummer)).fetchone()
    if not r:
        raise HTTPException(404, "artikel niet gevonden")
    return {"titel": r[0], "citeertitel": r[1], "context": r[2],
            "tekst": r[3], "bron": r[4]}


@app.get("/api/wet/{wet_id}/pdf")
def wet_pdf_ep(wet_id: str):
    con = importer.db()
    w = con.execute("SELECT titel, citeertitel, bron FROM wetten "
                    "WHERE id=? OR citeertitel=?", (wet_id, wet_id)).fetchone()
    if not w:
        raise HTTPException(404, "wet niet gevonden")
    arts = artikelen(wet_id)
    data = pdf.wet_pdf(w[1], w[0], w[2], arts)
    naam = f"{w[1]}-bundel.pdf".replace(" ", "-")
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{naam}"'})


@app.get("/api/artikel/pdf")
def artikel_pdf_ep(wet: str, nummer: str):
    a = artikel(wet, nummer)
    data = pdf.artikel_pdf(a["titel"], a["citeertitel"], nummer,
                           a["context"], a["tekst"], a["bron"])
    naam = f"{a['citeertitel']}-artikel-{nummer}.pdf".replace(" ", "-")
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{naam}"'})


@app.post("/api/bewijspakket")
def bewijspakket(body: dict):
    """Bewijs-pakket PDF: beschrijving + stappen + artikelen + instanties."""
    tekst = (body.get("tekst") or "").strip()
    if not tekst:
        raise HTTPException(400, "geen beschrijving")
    arts, niet = [], []
    for h in (body.get("hits") or [])[:12]:
        try:
            arts.append(artikel(h["wet"], h["nummer"]) |
                        {"nummer": h["nummer"]})
        except Exception:
            niet.append(h)
    inst = [INST_MAP[i] for i in (body.get("inst_ids") or [])
            if i in INST_MAP]
    data = pdf.bewijspakket_pdf(tekst, body.get("stappen") or [],
                                arts, inst)
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition":
                             'attachment; filename="bewijspakket.pdf"'})


@app.get("/api/koppeling")
def koppeling():
    return KOPPELING


@app.get("/api/changelog")
def changelog_ep():
    return importer.changelog()


@app.get("/api/check_update")
def check_update_ep():
    return importer.check_update(importer.db())


@app.get("/api/categorieen")
def categorieen_ep():
    return importer.categorieen()


@app.post("/api/import")
def start_import(identifiers: list[str] | None = None):
    if _import_status["bezig"]:
        return {"ok": True, "bezig": True}

    def run():
        _import_status.update(bezig=True, fout=None)
        try:
            res = importer.importeer(identifiers, log=print)
            _import_status["laatste"] = res
        except Exception as e:  # noqa: BLE001
            _import_status["fout"] = str(e)
        finally:
            _import_status["bezig"] = False

    threading.Thread(target=run, daemon=True).start()
    return {"ok": True}


@app.get("/api/basiswetten")
def basiswetten():
    return [{"id": i, "waarom": w} for i, w in BASIS_WETTEN]


# ---------- Uitspraken (rechtspraak.nl Open Data, CC-0) ----------
_uimport = {"bezig": False, "laatste": None, "fout": None}


@app.get("/api/rechtsgebieden")
def rechtsgebieden_ep():
    return [{"id": i, "naam": n} for i, n in uitspraken.RECHTSGEBIEDEN]


@app.post("/api/uitspraken_import")
def uitspraken_import(body: dict):
    """Haalt recente uitspraken binnen in een achtergrond-thread."""
    if _uimport["bezig"]:
        return {"ok": True, "bezig": True}
    rg = body.get("rechtsgebied") or None
    dagen = int(body.get("dagen", 180))
    max_ = int(body.get("max", 150))

    def run():
        _uimport.update(bezig=True, fout=None)
        try:
            _uimport["laatste"] = uitspraken.importeer_uitspraken(
                rg, dagen, max_)
        except Exception as e:  # noqa: BLE001
            _uimport["fout"] = str(e)
        finally:
            _uimport["bezig"] = False

    threading.Thread(target=run, daemon=True).start()
    return {"ok": True}


@app.get("/api/uitspraken_status")
def uitspraken_status():
    return {**_uimport, **uitspraken.uitspraak_stats(importer.db())}


@app.get("/api/uitspraken_zoek")
def uitspraken_zoek(q: str = Query(min_length=3)):
    return uitspraken.zoek_uitspraken(importer.db(), q)


@app.get("/api/uitspraak/{ecli:path}")
def uitspraak_detail(ecli: str):
    con = importer.db()
    uitspraken._db(con)
    r = con.execute("SELECT ecli, instantie, datum, titel, indicatie, "
                    "tekst, link FROM uitspraken WHERE ecli=?",
                    (ecli,)).fetchone()
    if not r:  # nog niet lokaal → ophalen
        try:
            return uitspraken.haal_uitspraak(ecli)
        except Exception:
            raise HTTPException(404, "uitspraak niet gevonden")
    return {"ecli": r[0], "instantie": r[1], "datum": r[2], "titel": r[3],
            "indicatie": r[4], "tekst": r[5], "link": r[6]}


@app.get("/api/uitspraken_recent")
def uitspraken_recent(limiet: int = 30):
    con = importer.db()
    uitspraken._db(con)
    rows = con.execute("SELECT ecli, instantie, datum, titel, indicatie "
                       "FROM uitspraken ORDER BY datum DESC LIMIT ?",
                       (limiet,)).fetchall()
    return [{"ecli": r[0], "instantie": r[1], "datum": r[2],
             "titel": r[3], "indicatie": r[4]} for r in rows]


# ---------- Instanties (NL hulp-organisaties met QR naar Maps) ----------

INSTANTIES = json.loads(
    (ROOT / "app" / "data" / "instanties.json").read_text(encoding="utf-8"))
INST_MAP = {i["id"]: i for i in INSTANTIES}


@app.get("/api/instanties")
def instanties(categorie: str = ""):
    if categorie:
        return [i for i in INSTANTIES if i["categorie"] == categorie]
    return INSTANTIES


@app.get("/api/instanties_match")
def instanties_match(q: str = Query(min_length=3)):
    """Matcht instantie-tags op de probleem-tekst → passende hulp erbij."""
    tekst = q.lower()
    hits = []
    for i in INSTANTIES:
        score = sum(1 for t in i.get("tags", []) if t in tekst)
        if score:
            hits.append((score, i))
    hits.sort(key=lambda x: -x[0])
    return [i for _, i in hits[:4]]


@app.get("/api/instantie/{iid}/qr")
def instantie_qr(iid: str):
    """QR-code (PNG) → Google Maps-zoekopdracht op naam + adres."""
    i = INST_MAP.get(iid)
    if not i:
        raise HTTPException(404)
    import io
    import urllib.parse

    import segno
    doel = i["adres"] if "http" not in i["adres"] else i["site"]
    if "http" not in doel:
        doel = f"https://www.google.com/maps/search/{urllib.parse.quote(i['naam'] + ' ' + doel)}"
    buf = io.BytesIO()
    segno.make(doel).save(buf, kind="png", scale=6, dark="#0D0F0E")
    return Response(content=buf.getvalue(), media_type="image/png")


app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
