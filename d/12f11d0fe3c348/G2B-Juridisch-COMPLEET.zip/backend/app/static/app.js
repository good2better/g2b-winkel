/* G2B Juridisch — frontend */
const $ = s => document.querySelector(s);

document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.remove('actief'));
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('zichtbaar'));
  b.classList.add('actief');
  $('#tab-' + b.dataset.tab).classList.add('zichtbaar');
  if (b.dataset.tab === 'wetboek') laadWetboek();
  if (b.dataset.tab === 'contracten') laadKoppeling();
  if (b.dataset.tab === 'instanties') laadInstanties();
  if (b.dataset.tab === 'uitspraken') laadUitspraken();
  if (b.dataset.tab === 'updates') laadUpdates();
});

function toast(t) {
  const el = $('#toast'); el.textContent = t; el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 3500);
}
const esc = s => (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

async function api(pad, opt) {
  const r = await fetch(pad, opt);
  if (!r.ok) throw new Error((await r.json().catch(()=>({detail:r.status}))).detail || r.status);
  return r.json();
}

/* ---------- status ---------- */
async function laadStatus() {
  try {
    const s = await api('/api/status');
    $('#status').textContent =
      `${s.wetten} wetten · ${s.artikelen} artikelen · laatste import: ${s.laatste_import}` +
      (s.import.bezig ? ' · ⏳ bezig met binnenhalen…' : '');
    if (s.wetten === 0 && !s.import.bezig) {
      $('#probleemUit').innerHTML = `<div class="kaart">Nog geen wetten binnengehaald — ga naar <b>🔄 Updates</b> en klik <b>Wetten binnenhalen</b> (eenmalig, ~1 minuut).</div>`;
    }
  } catch (e) { $('#status').textContent = 'backend niet bereikbaar'; }
}
setInterval(laadStatus, 8000);

/* ---------- leg je probleem uit ---------- */
const PROBLEEM_STAPPEN = [
  {re:/gestol|gekopie|inbreuk|piraat|ripped|gebruikt.{0,20}zonder|stiekem|zonder.{0,15}(toestemming|vragen|licentie)|plagiaat/i, stap:'📌 Mogelijk inbreuk op jouw auteursrecht. Stappen: 1) Bewaar bewijs (screenshots, link, datum). 2) Stuur de ander een schriftelijke sommatie: stoppen + jouw licentievoorwaarden. 3) Platform? Vraag een takedown aan. 4) Bij grote schade: jurist/juridisch loket.'},
  {re:/betaal|betaling|factuur|wanbetaling|schuld/i, stap:'📌 Niet-betaald = wanprestatie. Stappen: 1) Herinnering sturen. 2) Aanmaning met betaaltermijn (bijv. 14 dagen). 3) Daarna: incassobureau of kantonrechter — kleine zaken kan je zelf.'},
  {re:/exclus|buy.?out|overdr|verkoop.{0,20}rechten/i, stap:'📌 Exclusieve licentie of overdracht moet SCHRIFTELIJK (Auteurswet art. 2). Jouw contract in Bedrijfsmiddelen dekt dit — gebruik het altijd.'},
  {re:/contract|overeenkomst|afspraak|deal/i, stap:'📌 Mondeling geldt ook als overeenkomst — maar schriftelijk = bewijs. Zet afspraken altijd op papier (of gebruik je contract-generator).'},
  {re:/buma|stemra|royalt|collectiev|sen\b/i, stap:'📌 Royalties lopen via collectieve beheerorganisaties (Buma/Stemra). Registreer je werken daar — de wet toezicht CBO regelt hun werking.'},
  {re:/naam.{0,20}(gebruikt|misbruikt|behand)|merk|handelsnaam|logo/i, stap:'📌 Jouw handelsnaam/merk is beschermd — een ander mag geen verwarrende naam voeren. Check de Handelsnaamwet art. 1 en 5.'},
  {re:/abonnement|opzeg|looptijd|automatisch.{0,15}verleng/i, stap:'📌 Opzeggen/verlengen van overeenkomsten valt onder BW 6 — check de opzegtermijn in het contract en artikelen hieronder.'},
  {re:/sample.{0,20}(pack|gestol|gebruikt)|loop|kit|preset/i, stap:'📌 Samples in een pack verkopen mag alleen als jij er de rechten op hebt — zelfgemaakte (gelayerde/bewerkte) sounds zijn jouw originele werk.'},
];

async function legUit() {
  const t = $('#probleem').value.trim();
  if (t.length < 5) { toast('Schrijf eerst kort wat er aan de hand is'); return; }
  const uit = $('#probleemUit');
  uit.innerHTML = '<div class="kaart klein">zoeken in de wetten…</div>';

  const hits = await api('/api/zoek?q=' + encodeURIComponent(t)).catch(() => []);
  const inst = await api('/api/instanties_match?q=' + encodeURIComponent(t)).catch(() => []);
  const stappen = PROBLEEM_STAPPEN.filter(s => s.re.test(t)).map(s => s.stap);

  let html = '';
  if (stappen.length || hits.length) html += '<div class="kaart"><div class="titel">🧭 Wat geldt er voor jou:</div>';
  stappen.forEach(s => html += `<div class="stap">${esc(s)}</div>`);
  if (hits.length) {
    html += `<div class="klein" style="margin:10px 0 4px">Relevante wetsartikelen (klik om te lezen):</div>`;
    hits.slice(0, 12).forEach(h => {
      html += `<div class="resultaat" onclick="toonArtikel('${esc(h.wet)}','${esc(h.artikel)}')">
        <b>${esc(h.wet)} — artikel ${esc(h.artikel)}</b>
        <div class="klein">${esc(h.context)}</div><div>${h.snippet}</div></div>`;
    });
  } else {
    html += '<div class="stap">Geen directe treffers — probeer andere woorden (bijv. "inbreuk", "betaling", "licentie") of gebruik de 🔍 Zoeken-tab.</div>';
  }
  if (inst.length) {
    html += `<div class="klein" style="margin:12px 0 6px">📇 Instanties die bij jouw probleem passen:</div>
             <div class="instlijst">${instKaarten(inst)}</div>`;
  }
  html += `<button id="bewijsBtn" class="knop" style="margin-top:12px">📄 Bewijs-pakket downloaden (PDF)</button>`;
  uit.innerHTML = html + '</div>' +
    '<div class="legenda">⚠️ Dit is hulp-op-weg, geen juridisch advies — lees altijd het echte artikel.</div>';
  $('#bewijsBtn').onclick = () => downloadBewijs(t, stappen, hits.slice(0, 12), inst);
}

async function downloadBewijs(tekst, stappen, hits, inst) {
  toast('Bewijs-pakket wordt gemaakt…');
  const res = await fetch('/api/bewijspakket', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      tekst, stappen,
      hits: hits.map(h => ({wet: h.wet, nummer: h.artikel})),
      inst_ids: inst.map(i => i.id)}),
  });
  if (!res.ok) { toast('Kon pakket niet maken'); return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(await res.blob());
  a.download = 'bewijspakket.pdf';
  a.click();
  toast('📄 Bewijs-pakket gedownload');
}

/* ---------- uitspraken ---------- */
let _rg = '';
async function laadUitspraken() {
  const rg = await api('/api/rechtsgebieden').catch(() => []);
  $('#rgTags').innerHTML = `<span class="tag" data-rg="">Alle gebieden</span>` +
    rg.map(r => `<span class="tag" data-rg="${r.id}">${esc(r.naam)}</span>`).join('');
  $('#rgTags').querySelectorAll('.tag').forEach(t => t.onclick = () => {
    _rg = t.dataset.rg;
    $('#rgTags').querySelectorAll('.tag').forEach(x => x.style.opacity = 0.5);
    t.style.opacity = 1;
  });
  const st = await api('/api/uitspraken_status').catch(() => null);
  $('#uStatus').textContent = st ? `${st.uitspraken} uitspraken lokaal` : '';
  const recent = await api('/api/uitspraken_recent').catch(() => []);
  $('#uUit').innerHTML = recent.length
    ? '<div class="klein" style="margin-bottom:6px">Nieuwste binnengehaalde uitspraken:</div>' +
      recent.map(u => `<div class="resultaat" onclick="toonUitspraak('${esc(u.ecli)}')">
        <b>${esc(u.instantie)} · ${esc(u.datum)}</b>
        <div class="klein">${esc(u.titel)}</div>
        ${u.indicatie ? `<div class="klein" style="opacity:.8">${esc(u.indicatie.slice(0, 160))}…</div>` : ''}
      </div>`).join('')
    : '<div class="kaart klein">Nog geen uitspraken — klik 📥 Recente uitspraken binnenhalen (eenmalig).</div>';
}

async function importUitspraken() {
  await api('/api/uitspraken_import', {method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({rechtsgebied: _rg || null, dagen: 180, max: 150})}).catch(() => {});
  toast('Uitspraken worden binnengehaald… (~1–2 min)');
  const tick = setInterval(async () => {
    const st = await api('/api/uitspraken_status').catch(() => null);
    if (!st) return;
    $('#uStatus').textContent = st.bezig
      ? `⏳ bezig… ${st.uitspraken} uitspraken lokaal`
      : `${st.uitspraken} uitspraken lokaal ✅`;
    if (!st.bezig) { clearInterval(tick); laadUitspraken(); }
  }, 2500);
}

async function zoekUitspraken() {
  const q = $('#uZoek').value.trim();
  if (q.length < 3) return;
  const hits = await api('/api/uitspraken_zoek?q=' + encodeURIComponent(q)).catch(() => []);
  $('#uUit').innerHTML = hits.length
    ? hits.map(h => `<div class="resultaat" onclick="toonUitspraak('${esc(h.ecli)}')">
        <b>${esc(h.instantie)} · ${esc(h.datum)}</b>
        <div class="klein">${esc(h.titel)}</div>
        ${h.indicatie ? `<div class="klein" style="opacity:.8">${esc(h.indicatie.slice(0, 200))}…</div>` : ''}
        <div>${h.snippet}</div></div>`).join('')
    : '<div class="kaart klein">Geen treffers in de binnengehaalde uitspraken — haal er eerst meer binnen.</div>';
}

async function toonUitspraak(ecli) {
  const u = await api('/api/uitspraak/' + encodeURIComponent(ecli)).catch(e => { toast('Niet gevonden'); });
  if (!u) return;
  const popup = window.open('', '_blank', 'width=760,height=640');
  popup.document.write(`<html><head><title>${esc(u.ecli)}</title>
    <style>body{font-family:Segoe UI,sans-serif;background:#0D0F0E;color:#E8EDE9;padding:24px;line-height:1.6}
    h1{color:#2FBF71;font-size:17px} .c{color:#8A938C;font-size:12px} pre{white-space:pre-wrap;font-family:inherit;font-size:13px}
    .ind{background:#16241C;border:1px solid #2FBF71;border-radius:8px;padding:10px;margin:10px 0;font-size:13px}
    a{color:#2FBF71}</style></head>
    <body><h1>${esc(u.instantie)} — ${esc(u.datum)}</h1>
    <div class="c">${esc(u.ecli)} · ${esc(u.titel)}</div>
    <div class="c"><a href="${esc(u.link)}" target="_blank">🔗 Officiële pagina op uitspraken.rechtspraak.nl</a></div>
    ${u.indicatie ? `<div class="ind"><b>Kern (inhoudsindicatie):</b><br>${esc(u.indicatie)}</div>` : ''}
    ${u.tekst ? `<pre>${esc(u.tekst.slice(0, 12000))}${u.tekst.length > 12000 ? '\n\n… [tekst ingekort — zie officiële pagina]' : ''}</pre>` : '<div class="c">Deze uitspraak publiceert alleen de samenvatting (sleutelgegevens) — volledige tekst via de officiële pagina hierboven.</div>'}
    </body></html>`);
}

/* ---------- zoeken ---------- */
async function doeZoek() {
  const q = $('#zoek').value.trim();
  if (q.length < 2) return;
  const hits = await api('/api/zoek?q=' + encodeURIComponent(q) + '&modus=and').catch(() => []);
  $('#zoekUit').innerHTML = hits.length
    ? hits.map(h => `<div class="resultaat" onclick="toonArtikel('${esc(h.wet)}','${esc(h.artikel)}')">
        <b>${esc(h.wet)} — artikel ${esc(h.artikel)}</b>
        <div class="klein">${esc(h.context)}</div><div>${h.snippet}</div></div>`).join('')
    : '<div class="kaart klein">Geen resultaten — importeer eerst wetten bij 🔄 Updates.</div>';
}

/* ---------- wetboek ---------- */
async function laadWetboek() {
  const lijst = await api('/api/wetten').catch(() => []);
  $('#wetboekLijst').innerHTML = lijst.map(w =>
    `<div class="kaart wet">
      <div onclick="openWet('${w.id}')" style="cursor:pointer">
        <div class="titel">${esc(w.citeertitel)}</div>
        <div class="klein">${w.artikelen} artikelen · ${esc(w.id)} · geldig sinds ${esc(w.datum)}</div>
      </div>
      <div style="margin-top:8px">
        <button class="knop sec" style="padding:5px 12px;font-size:12px" onclick="pdfWet('${w.id}')">📖 Hele wet als PDF-bundel</button>
      </div>
    </div>`).join('') ||
    '<div class="kaart klein">Nog geen wetten — ga naar 🔄 Updates.</div>';
}

async function openWet(id) {
  const arts = await api('/api/wet/' + encodeURIComponent(id) + '/artikelen').catch(() => []);
  $('#wetboekInhoud').innerHTML =
    `<div class="kaart"><div class="titel">${arts.length} artikelen</div>` +
    arts.map(a => `<div class="artikel">
      <span class="nummer" onclick="pdfArtikel('${id}','${esc(a.nummer)}')">Artikel ${esc(a.nummer)} 📄</span>
      <div class="klein">${esc(a.context)}</div>
      <pre>${esc(a.tekst.slice(0, 1200))}${a.tekst.length > 1200 ? '…' : ''}</pre></div>`).join('') +
    '</div>';
  $('#wetboekInhoud').scrollIntoView({behavior: 'smooth'});
}

/* ---------- artikel + pdf ---------- */
const mdLinks = s => esc(s).replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g,
  '<a href="$2" target="_blank" style="color:#2FBF71">$1</a>');

async function toonArtikel(wet, nummer) {
  const a = await api(`/api/artikel?wet=${encodeURIComponent(wet)}&nummer=${encodeURIComponent(nummer)}`).catch(e => { toast(e.message); });
  if (!a) return;
  const popup = window.open('', '_blank', 'width=700,height=600');
  popup.document.write(`<html><head><title>${esc(a.citeertitel)} art. ${esc(nummer)}</title>
    <style>body{font-family:Segoe UI,sans-serif;background:#0D0F0E;color:#E8EDE9;padding:24px;line-height:1.6}
    h1{color:#2FBF71;font-size:18px} .c{color:#8A938C;font-size:12px} pre{white-space:pre-wrap;font-family:inherit}
    a{color:#2FBF71} button{margin-top:14px;padding:10px 16px;background:#2FBF71;border:0;border-radius:8px;font-weight:600;cursor:pointer}</style></head>
    <body><h1>${esc(a.citeertitel)} — artikel ${esc(nummer)}</h1><div class="c">${esc(a.context)}</div>
    <div class="c"><a href="${esc(a.bron)}" target="_blank">🔗 Officiële tekst op wetten.overheid.nl</a></div>
    <pre>${mdLinks(a.tekst)}</pre>
    <button onclick="window.location='/api/artikel/pdf?wet=${encodeURIComponent(wet)}&nummer=${encodeURIComponent(nummer)}'">📄 Download als PDF</button>
    </body></html>`);
}

function pdfArtikel(wet, nummer) {
  window.open(`/api/artikel/pdf?wet=${encodeURIComponent(wet)}&nummer=${encodeURIComponent(nummer)}`, '_blank');
}
function pdfWet(id) {
  window.open(`/api/wet/${encodeURIComponent(id)}/pdf`, '_blank');
}

/* ---------- koppeling ---------- */
async function laadKoppeling() {
  const k = await api('/api/koppeling').catch(() => []);
  $('#koppeling').innerHTML = k.map(item => `
    <div class="kl">
      <div class="clau">${esc(item.clausule)}</div>
      <div class="waarom">${esc(item.uitleg)}</div>
      ${item.artikelen.map(([w, nums]) => nums.map(n =>
        `<span class="tag" onclick="toonArtikel('${esc(w)}','${esc(n)}')">${esc(w)} · art. ${esc(n)}</span>`).join('')).join('')}
    </div>`).join('');
}

/* ---------- updates ---------- */
async function laadUpdates() {
  const s = await api('/api/status').catch(() => null);
  const basis = await api('/api/basiswetten').catch(() => []);
  if (s) $('#importStatus').innerHTML =
    `In je lokale wetboek: <b>${s.wetten}</b> wetten · <b>${s.artikelen}</b> artikelen · laatste import: <b>${s.laatste_import}</b>` +
    (s.import.bezig ? '<br>⏳ Bezig met binnenhalen… dit duurt ~1 minuut.' : '') +
    (s.import.fout ? `<br>❌ Fout: ${esc(s.import.fout)}` : '');
  $('#basisLijst').innerHTML = '<div class="klein">Standaard binnengehaald:</div>' +
    basis.map(b => `<div class="klein">· <b>${b.id}</b> — ${esc(b.waarom)}</div>`).join('');
  const cats = await api('/api/categorieen').catch(() => []);
  $('#catLijst').innerHTML = cats.length
    ? '<div class="klein" style="margin:8px 0 4px">Extra bundels (per categorie importeren):</div>' +
      cats.slice(0, 14).map(c =>
        `<span class="tag" onclick="importCat('${esc(c.categorie)}')" title="importeer ${c.aantal} wetten">${esc(c.categorie)} (${c.aantal})</span>`).join('')
    : '';
  const ch = await api('/api/changelog').catch(() => []);
  $('#changelog').innerHTML = ch.length
    ? ch.slice(0, 20).map(c => `<div>· ${esc(c.datum || '')} — ${esc(c.titel || c.identifier || JSON.stringify(c)).slice(0, 110)}</div>`).join('')
    : 'Geen recente wijzigingen gevonden (of offline).';
}

async function importCat(cat) {
  const cats = await api('/api/categorieen').catch(() => []);
  const c = cats.find(x => x.categorie === cat);
  if (!c) return;
  if (!confirm(`Importeer ${c.aantal} wetten in categorie "${cat}"?`)) return;
  await api('/api/import', {method: 'POST', headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify(c.identifiers)}).catch(e => toast(e.message));
  toast(`⏳ Bezig met binnenhalen van "${cat}"…`);
  const t = setInterval(async () => {
    const s = await api('/api/status');
    if (!s.import.bezig) { clearInterval(t); laadUpdates(); laadStatus();
      toast(s.import.fout ? '❌ ' + s.import.fout : `✅ "${cat}" binnengehaald!`); }
  }, 3000);
}

async function startImport() {
  $('#importKnop').disabled = true;
  await api('/api/import', {method: 'POST'}).catch(e => toast(e.message));
  toast('⏳ Bezig met binnenhalen — ~1 minuut');
  const t = setInterval(async () => {
    const s = await api('/api/status');
    if (!s.import.bezig) {
      clearInterval(t);
      $('#importKnop').disabled = false;
      laadUpdates(); laadStatus();
      toast(s.import.fout ? '❌ ' + s.import.fout : '✅ Wetten binnengehaald!');
    }
  }, 2000);
}

/* ---------- instanties ---------- */
const INST_CATS = [['', 'Alle'], ['juridisch', '⚖️ Juridisch'], ['veilig', '🚨 Veilig & misdaad'], ['geestelijk', '🧠 Geestelijk & zorg'], ['geld', '💰 Geld & schulden'], ['overheid', '🏛️ Overheid & zakelijk'], ['muziek', '🎵 Muziek & rechten']];

function instKaarten(lijst) {
  return lijst.map(i => `
    <div class="inst">
      <img src="/api/instantie/${i.id}/qr" alt="QR naar Maps" title="Scan met je telefoon → Google Maps" loading="lazy">
      <h4>${esc(i.naam)} ${i.spoed ? '<span class="spoedt">SPOED</span>' : ''} ${i.gratis ? '<span class="gratis">GRATIS</span>' : ''}</h4>
      <div class="klein"><span class="catb">${esc(i.categorie)}</span></div>
      <div class="wat">${esc(i.wat)}</div>
      <div class="ri">📞 ${esc(i.telefoon)}</div>
      <div class="ri">📍 ${esc(i.adres)}</div>
      <div class="ri"><a href="${esc(i.site)}" target="_blank">🌐 ${esc(i.site.replace('https://', ''))}</a></div>
    </div>`).join('');
}

async function laadInstanties() {
  $('#catTags').innerHTML = INST_CATS.map(([k, n]) => `<span class="tag" data-cat="${k}">${n}</span>`).join('');
  $('#catTags').querySelectorAll('.tag').forEach(t => t.onclick = () => filterInst(t.dataset.cat));
  $('#instlijst').innerHTML = instKaarten(await api('/api/instanties'));
}
async function filterInst(c) {
  $('#instlijst').innerHTML = instKaarten(await api('/api/instanties' + (c ? '?categorie=' + c : '')));
}

/* ---------- achtergrond update-check bij opstart ---------- */
async function checkUpdate() {
  const c = await api('/api/check_update').catch(() => null);
  if (c && c.update) {
    $('#updateBanner').style.display = 'block';
    $('#updateInfo').textContent = `bron ${c.bron || '?'} · jij ${c.lokaal || '?'}`;
  }
}

laadStatus();
checkUpdate();
