"""Rechtbank-uitspraken van rechtspraak.nl Open Data (CC-0, publiek domein).

Twee stappen volgens de officiële API: eerst de ECLI-index bevragen
(metadata-filters: datum, rechtsgebied, instantie), dan per ECLI het
uitspraak-document ophalen. Alles wordt lokaal in SQLite+FTS5 opgeslagen —
daarna zoek je full-text, óók offline. Rate-limit: max ~10 req/sec; wij
houden 0,15 s aan tussen document-calls en halen bewust kleine batches.
"""
import re
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date, timedelta

from . import importer

INDEX = "https://data.rechtspraak.nl/uitspraken/zoeken"
DOC = "https://data.rechtspraak.nl/uitspraken/content"
DETAILS = "https://uitspraken.rechtspraak.nl/details?id="

RG_BASE = "http://psi.rechtspraak.nl/rechtsgebied#"
RECHTSGEBIEDEN = [
    ("civielRecht", "⚖️ Civiel recht"),
    ("strafrecht", "🔨 Strafrecht"),
    ("bestuursrecht", "🏛️ Bestuursrecht"),
    ("internationaalPubliekrecht", "🌍 Internationaal publiekrecht"),
]

ATOM = "{http://www.w3.org/2005/Atom}"
DC = "{http://purl.org/dc/terms/}"
NS = {"a": "http://www.w3.org/2005/Atom", "d": "http://purl.org/dc/terms/"}


def _haal(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "G2B-Juridisch/1.0"})
    return urllib.request.urlopen(req, timeout=timeout).read()


def _db(con=None):
    con = con or importer.db()
    con.execute("""CREATE TABLE IF NOT EXISTS uitspraken(
        ecli TEXT PRIMARY KEY, instantie TEXT, datum TEXT, titel TEXT,
        indicatie TEXT, tekst TEXT, link TEXT)""")
    con.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS fts_u USING fts5(
        ecli UNINDEXED, indicatie, tekst)""")
    return con


def index_lijst(rechtsgebied: str | None = None, dagen: int = 180,
                max_: int = 150) -> list[dict]:
    """ECLI-index: recentste uitspraken in de laatste `dagen` dagen."""
    van = date.today() - timedelta(days=dagen)
    params = {"date": [van.isoformat(), date.today().isoformat()],
              "type": "uitspraak", "max": str(min(max_, 1000)),
              "return": "DOC"}  # DOC → <summary> met inhoudsindicatie
    if rechtsgebied:
        params["subject"] = RG_BASE + rechtsgebied
    qs = urllib.parse.urlencode(params, doseq=True)
    root = ET.fromstring(_haal(f"{INDEX}?{qs}"))
    out = []
    for e in root.findall("a:entry", NS):
        ecli = e.findtext(f"{ATOM}id") or ""
        titel = e.findtext(f"{ATOM}title") or ""
        sam = (e.findtext(f"{ATOM}summary") or "").strip()
        link = e.find(f"{ATOM}link")
        out.append({"ecli": ecli, "titel": titel,
                    "datum": (e.findtext(f"{ATOM}updated") or "")[:10],
                    "indicatie": "" if sam == "-" else sam,
                    "link": link.get("href") if link is not None
                            else DETAILS + ecli})
    return out


def _inner(el: ET.Element | None) -> str:
    """Alle platte tekst uit een XML-element (para/section) samenvoegen."""
    if el is None:
        return ""
    paras = []
    for p in el.iter():
        if p.tag.split("}")[-1] == "para" and (p.text or "").strip():
            paras.append(" ".join(p.itertext()).strip())
    return "\n\n".join(paras) if paras else " ".join(el.itertext()).strip()


def haal_uitspraak(ecli: str, fallback: dict | None = None) -> dict:
    """Eén uitspraak ophalen + in lokale DB zetten. Geeft de record terug.

    Veel documenten publiceren alleen sleutelgegevens — dan is de
    inhoudsindicatie uit de index-feed (fallback) alsnog de inhoud.
    """
    fb = fallback or {}
    root = ET.fromstring(_haal(f"{DOC}?id={urllib.parse.quote(ecli)}"))
    titel = datum = instantie = ""
    for d in root.iter(f"{DC}title"):
        titel = (d.text or "").strip()
    for d in root.iter(f"{DC}date"):
        datum = (d.text or "")[:10]
    for d in root.iter(f"{DC}creator"):
        instantie = (d.text or "").strip() or d.get(
            "{http://www.w3.org/2000/01/rdf-schema#}label", "")
    indicatie = _inner(root.find("inhoudsindicatie")) or fb.get("indicatie", "")
    tekst = _inner(root.find("uitspraak"))
    rec = {"ecli": ecli, "instantie": instantie or fb.get("instantie", ""),
           "datum": datum or fb.get("datum", ""),
           "titel": titel or fb.get("titel") or ecli,
           "indicatie": indicatie, "tekst": tekst,
           "link": DETAILS + urllib.parse.quote(ecli)}
    con = _db()
    con.execute("INSERT OR REPLACE INTO uitspraken VALUES(?,?,?,?,?,?,?)",
                (rec["ecli"], rec["instantie"], rec["datum"], rec["titel"],
                 rec["indicatie"], rec["tekst"], rec["link"]))
    con.execute("DELETE FROM fts_u WHERE ecli=?", (ecli,))
    con.execute("INSERT INTO fts_u VALUES(?,?,?)",
                (ecli, rec["indicatie"], rec["tekst"]))
    con.commit()
    return rec


def importeer_uitspraken(rechtsgebied: str | None = None, dagen: int = 180,
                         max_: int = 150, log=print) -> dict:
    """Haalt recente uitspraken binnen (beleefd tempo). Slaat bekende over."""
    lijst = index_lijst(rechtsgebied, dagen, max_)
    con = _db()
    bekend = {r[0] for r in con.execute("SELECT ecli FROM uitspraken")}
    nieuw = fout = 0
    for i, e in enumerate(lijst):
        if e["ecli"] in bekend:
            continue
        try:
            haal_uitspraak(e["ecli"], e)
            nieuw += 1
        except Exception as ex:  # noqa: BLE001
            log(f"  ! {e['ecli']}: {ex}")
            fout += 1
        if i % 10 == 9:
            log(f"  … {nieuw} nieuwe uitspraken")
        time.sleep(0.15)
    return {"nieuw": nieuw, "fouten": fout, "index": len(lijst)}


def zoek_uitspraken(con, q: str, limiet: int = 50) -> list[dict]:
    """Lokale full-text search over binnengehaalde uitspraken."""
    _db(con)
    words = [w for w in re.findall(r"\w+", q.lower()) if len(w) > 2]
    if not words:
        return []
    match = " OR ".join(f'"{w}"*' for w in words[:8])
    rows = con.execute(
        "SELECT u.ecli, u.instantie, u.datum, u.titel, u.indicatie, u.link, "
        "snippet(fts_u, 2, '<b>', '</b>', '…', 30) AS snip "
        "FROM fts_u JOIN uitspraken u ON u.ecli = fts_u.ecli "
        "WHERE fts_u MATCH ? ORDER BY rank LIMIT ?", (match, limiet)).fetchall()
    return [{"ecli": r[0], "instantie": r[1], "datum": r[2], "titel": r[3],
             "indicatie": r[4], "link": r[5], "snippet": r[6]} for r in rows]


def uitspraak_stats(con) -> dict:
    _db(con)
    n = con.execute("SELECT COUNT(*) FROM uitspraken").fetchone()[0]
    return {"uitspraken": n}
