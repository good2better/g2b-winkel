# G2B Juridisch — lokale Nederlandse wetboek-app
