# Welke wetten G2B Juridisch standaard lokaal binnenhaalt.
# Alleen wat voor een muziekproducent/ZZP'er relevant is — de rest kan via
# "meer wetten" uit een categorie worden bijgehaald.
#
# Voor elk: (BWBR-identifier, korte toelichting waarom)

BASIS_WETTEN = [
    # Auteursrecht & naburige rechten — kern van zijn beats/licenties
    ("BWBR0001886", "Auteurswet — wie eigenaar is, licentie/overdracht, naamsvermelding"),
    ("BWBR0005921", "Wet op de naburige rechten — rechten op de opname (master)"),
    ("BWBR0010591", "Databankenwet — bescherming van databases (o.a. sample-packs met structuur)"),
    ("BWBR0001906", "Handelsnaamwet — bescherming van je bedrijfsnaam Good2Better"),
    ("BWBR0014779", "Toezicht collectieve beheersorganisaties — regels voor Buma/Stemra e.a."),

    # Contracten & zakelijk
    ("BWBR0005291", "Burgerlijk Wetboek Boek 3 — eigendom & overdracht van rechten"),
    ("BWBR0005289", "Burgerlijk Wetboek Boek 6 — overeenkomsten, wanprestatie, onrechtmatige daad"),
    ("BWBR0005290", "Burgerlijk Wetboek Boek 7 — bijzondere contracten (koop, opdracht, licentie)"),
    ("BWBR0003045", "Burgerlijk Wetboek Boek 2 — rechtspersonen (BV/eenmanszaak-regels)"),
]

BASE = "https://vrijewetgeving.nl"
INDEX_URL = f"{BASE}/index.json"
CHANGELOG_URL = f"{BASE}/changelog.json"
META_URL = f"{BASE}/meta.json"
