"""Downloadt wetteksten van vrijewetgeving.nl (CC0) en zet ze in SQLite + FTS5.

Data is publiek domein — 100% regel-1-vrij. Werkt daarna volledig offline.
"""
import json
import re
import sqlite3
import urllib.request
from pathlib import Path

from .wetlijst import BASE, BASIS_WETTEN, INDEX_URL, CHANGELOG_URL, META_URL

DB = Path(__file__).resolve().parent.parent / "storage" / "wetten.db"

ART_RE = re.compile(r"^#####\s+[Aa][Rr][Tt][Ii][Kk][Ee][Ll]\s+(\S+?)\s*$", re.M)
HOF_RE = re.compile(r"^#{3,4}\s+(.+?)\s*$", re.M)  # ### Hoofdstuk / #### paragraaf
FRONT_RE = re.compile(r"^---\n(.*?)\n---\n", re.S)


def _haal(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "G2B-Juridisch/1.0"})
    return urllib.request.urlopen(req, timeout=timeout).read()


def _frontmatter(md: str) -> dict:
    m = FRONT_RE.match(md)
    if not m:
        return {}
    out = {}
    for regel in m.group(1).splitlines():
        if ":" in regel:
            k, v = regel.split(":", 1)
            out[k.strip()] = v.strip().strip('"')
    return out


def db() -> sqlite3.Connection:
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS wetten(
        id TEXT PRIMARY KEY, titel TEXT, citeertitel TEXT, pad TEXT,
        bron TEXT, datum TEXT, status TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS artikelen(
        wet TEXT, nummer TEXT, context TEXT, tekst TEXT,
        PRIMARY KEY(wet, nummer))""")
    con.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS fts USING fts5(
        citeertitel, nummer, context, tekst)""")
    con.execute("CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT)")
    return con


def _set_meta(con, k, v):
    con.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (k, str(v)))


def get_meta(con, k, default=None):
    r = con.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
    return r[0] if r else default


def importeer(identifiers=None, log=print) -> dict:
    """Haalt index + gekozen wetten binnen en parst artikelen. Geeft tellingen."""
    identifiers = identifiers or [i for i, _ in BASIS_WETTEN]
    index = json.loads(_haal(INDEX_URL))
    per_id = {w["identifier"]: w for w in index}

    con = db()
    n_art = 0
    gedaan, gemist = [], []
    for bid in identifiers:
        w = per_id.get(bid)
        if not w or not w.get("pad"):
            gemist.append(bid)
            continue
        try:
            md = _haal(f"{BASE}/{w['pad']}").decode("utf-8", "replace")
        except Exception as e:  # noqa: BLE001
            log(f"  ! {bid}: {e}")
            gemist.append(bid)
            continue

        fm = _frontmatter(md)
        citeertitel = fm.get("citeertitel") or w["titel"]
        bron = fm.get("bron") or f"https://wetten.overheid.nl/{bid}"

        # splits op artikel-koppen, onthoud huidige hoofdstuk/paragraaf
        pos = [(m.start(), HOF_RE, m) for m in HOF_RE.finditer(md)] + \
              [(m.start(), ART_RE, m) for m in ART_RE.finditer(md)]
        pos.sort(key=lambda x: x[0])
        context = ""
        arts = []
        for i, (p, kind, m) in enumerate(pos):
            if kind is HOF_RE:
                context = m.group(1).strip()
                continue
            einde = pos[i + 1][0] if i + 1 < len(pos) else len(md)
            # tekst loopt tot de volgende kop (artikel of hoofdstuk)
            tekst = md[m.end():einde].strip()
            arts.append((m.group(1), context, tekst))

        con.execute("""INSERT OR REPLACE INTO wetten VALUES(?,?,?,?,?,?,?)""",
                    (bid, w["titel"], citeertitel, w["pad"], bron,
                     w.get("datum", ""), w.get("status", "")))
        con.execute("DELETE FROM artikelen WHERE wet=?", (bid,))
        con.execute("DELETE FROM fts WHERE citeertitel=?", (citeertitel,))
        for nummer, ctx, tekst in arts:
            con.execute("INSERT OR REPLACE INTO artikelen VALUES(?,?,?,?)",
                        (bid, nummer, ctx, tekst))
            con.execute("INSERT INTO fts(citeertitel,nummer,context,tekst) "
                        "VALUES(?,?,?,?)", (citeertitel, nummer, ctx, tekst))
            n_art += 1
        gedaan.append(citeertitel)
        log(f"  ✓ {citeertitel}: {len(arts)} artikelen")

    _set_meta(con, "laatste_import", __import__("datetime").date.today().isoformat())
    con.commit()
    return {"wetten": len(gedaan), "artikelen": n_art, "gemist": gemist,
            "namen": gedaan}


STOPWOORDEN = {"de", "het", "een", "en", "of", "van", "in", "op", "te", "voor",
               "met", "dat", "die", "dit", "is", "was", "zijn", "heeft", "heb",
               "ik", "je", "jij", "hij", "ze", "we", "wij", "mij", "mijn", "aan",
               "bij", "door", "maar", "niet", "ook", "om", "uit", "dan", "als",
               "wat", "wie", "hoe", "waar", "iemand", "iets", "er", "nog",
               "meer", "kan", "kunnen", "wil", "willen", "heeft", "had", "had",
               "moet", "mag", "zou", "zullen", "deze", "die", "hun", "hem",
               "haar", "ons", "jullie", "al", "wel", "naar", "over", "onder",
               "tussen", "tegen", "tot", "per", "via", "zelf", "eigen"}


# Informele/bedrijfs-woorden → juridische termen (synoniemen voor 'auto'-zoeken)
SYNONIEMEN = {
    "beat": ["werk", "muziekwerk"], "beats": ["werk"], "muziek": ["werk", "muziekwerk"],
    "song": ["werk", "lied"], "nummer": ["werk"], "sound": ["werk", "opname"],
    "sample": ["werk", "fragment"], "gestolen": ["inbreuk", "onrechtmatig"],
    "steel": ["inbreuk"], "gestolen": ["inbreuk", "onrechtmatig"],
    "gekopieerd": ["verveelvoudigen", "inbreuk"], "kopie": ["verveelvoudiging"],
    "gekocht": ["koop"], "verkoop": ["koop"], "verkopen": ["verkoop"],
    "contract": ["overeenkomst"], "afspraak": ["overeenkomst"],
    "betaald": ["betaling"], "betaalt": ["betaling"], "factuur": ["betaling", "vordering"],
    "licentie": ["licentie"], "eigenaar": ["eigendom", "rechthebbende"],
    "rechten": ["recht", "auteursrecht"], "koper": ["koper"],
    "producer": ["maker"], "artiest": ["maker", "uitvoerende"],
    "naam": ["naamsvermelding", "handelsnaam"], "merk": ["merk"],
    "webshop": ["koop", "overeenkomst"], "download": ["openbaarmaking"],
    "stream": ["openbaarmaking"], "exclusief": ["exclusieve", "licentie"],
    "pakket": ["werk"], "pack": ["werk", "databank"],
}


def zoek(con, q: str, limiet: int = 60, modus: str = "auto") -> list[dict]:
    """FTS5-zoeken.

    modus='and' → alle woorden verplicht (precies zoeken).
    modus='auto' → bij vrije tekst (bv. probleem-uitleg) worden stopwoorden
    weggefilterd en OR gezocht op kernwoorden + juridische synoniemen.
    """
    woorden = [w for w in re.findall(r"[\w.°-]+", q.lower()) if len(w) > 1]
    if not woorden:
        return []
    kern = [w for w in woorden if w not in STOPWOORDEN]
    if modus == "and":
        terms = woorden[:8]
        op = " AND "
    else:
        terms = list(kern or woorden)
        for w in kern:
            terms += SYNONIEMEN.get(w, [])
        terms = terms[:12]
        op = " OR "
    query = op.join(f'"{w}"' for w in terms)
    sql = """SELECT citeertitel, nummer, context,
             snippet(fts, 3, '<b>', '</b>', '…', 24) AS snip
             FROM fts WHERE fts MATCH ? ORDER BY rank LIMIT ?"""
    try:
        rows = con.execute(sql, (query, limiet)).fetchall()
    except sqlite3.OperationalError:
        return []
    return [{"wet": r[0], "artikel": r[1], "context": r[2], "snippet": r[3]}
            for r in rows]


def changelog() -> list[dict]:
    """Wat wijzigde er recent bij de bron? (gratis, dagelijks vers)"""
    try:
        data = json.loads(_haal(CHANGELOG_URL, timeout=20))
    except Exception:  # noqa: BLE001
        return []
    if isinstance(data, list):
        items = data
    else:
        items = data.get("recent") or data.get("wijzigingen") or []
    return items[:30]


def check_update(con) -> dict:
    """Zijn er nieuwere wetteksten bij de bron? (kleine check, 1 JSON)"""
    lokaal = get_meta(con, "laatste_import", "")
    try:
        meta = json.loads(_haal(META_URL, timeout=15))
    except Exception:  # noqa: BLE001
        return {"update": False, "reden": "bron onbereikbaar (offline ok)",
                "lokaal": lokaal}
    bron_datum = str(meta.get("gegenereerd") or meta.get("datum") or
                     meta.get("generated") or "")[:10]
    return {"update": bool(bron_datum and bron_datum > (lokaal or "0000")),
            "bron": bron_datum, "lokaal": lokaal,
            "bron_wetten": meta.get("aantal_wetten") or meta.get("aantal")}


def categorieen() -> list[dict]:
    """Welke categorieën heeft de bron + hoeveel wetten elk (voor bundel-import)."""
    try:
        index = json.loads(_haal(INDEX_URL, timeout=30))
    except Exception:  # noqa: BLE001
        return []
    cats: dict[str, int] = {}
    ids: dict[str, list[str]] = {}
    for w in index:
        if w.get("status") != "Geldig":
            continue
        c = w.get("categorie") or "Overig"
        cats[c] = cats.get(c, 0) + 1
        ids.setdefault(c, []).append(w["identifier"])
    return [{"categorie": c, "aantal": n, "identifiers": ids[c]}
            for c, n in sorted(cats.items(), key=lambda x: -x[1])]


def stats(con) -> dict:
    return {
        "wetten": con.execute("SELECT COUNT(*) FROM wetten").fetchone()[0],
        "artikelen": con.execute("SELECT COUNT(*) FROM artikelen").fetchone()[0],
        "laatste_import": get_meta(con, "laatste_import", "nog nooit"),
    }
