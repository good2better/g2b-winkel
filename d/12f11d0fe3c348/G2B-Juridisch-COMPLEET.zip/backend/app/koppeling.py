"""Koppeling tussen G2B-contractclausules en de echte wetsartikelen.

Dit maakt de app meer dan een wetboek: bij elke clausule in zijn
Bedrijfsmiddelen-contracten zie je welk artikel er juridisch onder zit.
"""

# Elke regel: clausule-in-zijn-contract → relevante artikelen (wet-citeertitel + nummers)
KOPPELING = [
    {
        "clausule": "Licentie (koper krijgt gebruiksrecht, jij blijft eigenaar)",
        "uitleg": "Een licentie mag voor een deel van het auteursrecht — jij hoeft nooit alles weg te geven.",
        "artikelen": [("Auteurswet", ["2"]), ("Burgerlijk Wetboek Boek 6", ["3", "248"])],
    },
    {
        "clausule": "Exclusieve licentie / exclusieve beat",
        "uitleg": "Een exclusieve licentie moet SCHRIFTELIJK — precies wat jouw contract-PDF is.",
        "artikelen": [("Auteurswet", ["2"])],
    },
    {
        "clausule": "Buy-out (volledige overdracht van exploitatierechten)",
        "uitleg": "Overdracht kan — maar geldt alleen voor wat uitdrukkelijk in de overeenkomst staat. Daarom is jouw contract zo uitgebreid.",
        "artikelen": [("Auteurswet", ["2"]), ("Burgerlijk Wetboek Boek 3", ["83", "95", "98"])],
    },
    {
        "clausule": "Naamsvermelding ('Produced by Good2Better') — nooit weggeeft",
        "uitleg": "Jouw persoonlijkheidsrecht: het recht op naamsvermelding kan in NL NIET worden overgedragen — zelfs niet bij een buy-out.",
        "artikelen": [("Auteurswet", ["25"])],
    },
    {
        "clausule": "Eigendom blijft 100% bij jou (master + auteursrecht)",
        "uitleg": "Het auteursrecht is van de maker (jij) en je master-opname valt onder naburige rechten.",
        "artikelen": [("Auteurswet", ["1", "4"]), ("Wet op de naburige rechten", ["1", "2"])],
    },
    {
        "clausule": "Koper mag beat niet doorverkopen / in eigen pack stoppen",
        "uitleg": "Wat de licentie niet uitdrukkelijk toestaat, mag de koper niet — en inbreuk is verboden.",
        "artikelen": [("Auteurswet", ["1", "31"]), ("Burgerlijk Wetboek Boek 6", ["162"])],
    },
    {
        "clausule": "Geschillen → Nederlandse rechter",
        "uitleg": "Partijen mogen kiezen welk recht geldt en welke rechter beslist — jij kiest Nederland.",
        "artikelen": [("Burgerlijk Wetboek Boek 6", ["248", "258"])],
    },
    {
        "clausule": "Buma/Stemra — collectieve beheerorganisaties",
        "uitleg": "Jouw royalties lopen via collectieve beheerders; deze wet regelt hun toezicht.",
        "artikelen": [("Wet toezicht en geschillenbeslechting collectieve beheersorganisaties auteurs- en naburige rechten", ["1", "3"])],
    },
    {
        "clausule": "Jouw bedrijfsnaam 'Good2Better' is beschermd",
        "uitleg": "Een ander mag geen verwarrende handelsnaam voeren in jouw regio/branche.",
        "artikelen": [("Handelsnaamwet", ["1", "5"])],
    },
]
