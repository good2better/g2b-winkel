"""Artikel → PDF in de G2B-huisstijl (groen), reportlab."""
import io
from datetime import date

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas

GROEN = HexColor("#1A5D3A")
DONKER = HexColor("#0D0F0E")
GRIJS = HexColor("#666666")


def artikel_pdf(wet_titel: str, citeertitel: str, nummer: str,
                context: str, tekst: str, bron: str) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    W, H = A4
    m = 20 * mm

    # kop
    c.setFillColor(GROEN)
    c.rect(0, H - 28 * mm, W, 28 * mm, stroke=0, fill=1)
    c.setFillColor(HexColor("#FFFFFF"))
    c.setFont("Helvetica-Bold", 15)
    c.drawString(m, H - 13 * mm, citeertitel)
    c.setFont("Helvetica", 11)
    c.drawString(m, H - 21 * mm, f"Artikel {nummer}")

    # context-regel
    y = H - 40 * mm
    if context:
        c.setFillColor(GRIJS)
        c.setFont("Helvetica-Oblique", 9)
        c.drawString(m, y, context[:110])
        y -= 7 * mm

    # officiële titel klein
    c.setFillColor(GRIJS)
    c.setFont("Helvetica", 8)
    c.drawString(m, y, wet_titel[:120])
    y -= 10 * mm

    # tekst (simpele wrap)
    c.setFillColor(DONKER)
    c.setFont("Helvetica", 10.5)
    for para in tekst.split("\n\n"):
        for regel in _wrap(para, 95):
            if y < 25 * mm:
                _voettekst(c, W, m, bron)
                c.showPage()
                y = H - 20 * mm
                c.setFont("Helvetica", 10.5)
            c.drawString(m, y, regel)
            y -= 5 * mm
        y -= 2.5 * mm

    _voettekst(c, W, m, bron)
    c.showPage()
    c.save()
    return buf.getvalue()


def _wrap(tekst: str, breedte: int) -> list[str]:
    regels, cur = [], ""
    for woord in tekst.split():
        if len(cur) + len(woord) + 1 > breedte:
            regels.append(cur)
            cur = woord
        else:
            cur = f"{cur} {woord}".strip()
    if cur:
        regels.append(cur)
    return regels or [""]


def wet_pdf(citeertitel: str, wet_titel: str, bron: str,
            artikelen: list[dict]) -> bytes:
    """Hele wet als bundel-PDF (voor offline lezen/printen)."""
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    W, H = A4
    m = 18 * mm
    y = H - 25 * mm

    c.setFillColor(GROEN)
    c.rect(0, H - 30 * mm, W, 30 * mm, stroke=0, fill=1)
    c.setFillColor(HexColor("#FFFFFF"))
    c.setFont("Helvetica-Bold", 18)
    c.drawString(m, H - 15 * mm, citeertitel)
    c.setFont("Helvetica", 9)
    c.drawString(m, H - 24 * mm, f"{len(artikelen)} artikelen · bundel")
    y = H - 42 * mm

    for art in artikelen:
        regels = [f"ARTIKEL {art['nummer']}"] + \
                 [r for para in art["tekst"].split("\n\n") for r in _wrap(para, 100)]
        if art.get("context"):
            regels.insert(1, art["context"])
        ruimte = (len(regels) * 4.6 + 8) * mm
        if y - ruimte < 22 * mm:
            _voettekst(c, W, m, bron)
            c.showPage()
            y = H - 20 * mm
        c.setFillColor(GROEN)
        c.setFont("Helvetica-Bold", 11)
        c.drawString(m, y, regels[0])
        y -= 5.5 * mm
        c.setFillColor(DONKER)
        c.setFont("Helvetica", 9)
        start = 2 if art.get("context") and len(regels) > 1 else 1
        if art.get("context") and len(regels) > 1:
            c.setFillColor(GRIJS)
            c.drawString(m, y, regels[1][:120])
            y -= 4.6 * mm
            c.setFillColor(DONKER)
        for regel in regels[start:]:
            c.drawString(m, y, regel)
            y -= 4.6 * mm
            if y < 22 * mm:
                _voettekst(c, W, m, bron)
                c.showPage()
                y = H - 20 * mm
                c.setFont("Helvetica", 9)
        y -= 3 * mm

    _voettekst(c, W, m, bron)
    c.showPage()
    c.save()
    return buf.getvalue()


def bewijspakket_pdf(tekst: str, stappen: list[str],
                     artikelen: list[dict], instanties: list[dict]) -> bytes:
    """Bewijs-pakket: probleem + stappen + volledige artikelen + instanties."""
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    W, H = A4
    m = 18 * mm
    BRON = "jouw G2B Juridisch app"

    def kop(titel, sub=""):
        c.setFillColor(GROEN)
        c.rect(0, H - 30 * mm, W, 30 * mm, stroke=0, fill=1)
        c.setFillColor(HexColor("#FFFFFF"))
        c.setFont("Helvetica-Bold", 17)
        c.drawString(m, H - 15 * mm, titel)
        if sub:
            c.setFont("Helvetica", 9)
            c.drawString(m, H - 24 * mm, sub)
        return H - 42 * mm

    def sectie(y, titel):
        if y < 35 * mm:
            _voettekst(c, W, m, BRON); c.showPage()
            y = H - 20 * mm
        c.setFillColor(GROEN)
        c.setFont("Helvetica-Bold", 12)
        c.drawString(m, y, titel)
        return y - 7 * mm

    def tekstblok(y, tekst, font=9, breedte=100, kleur=None):
        c.setFillColor(kleur or DONKER)
        c.setFont("Helvetica", font)
        for para in tekst.split("\n"):
            for regel in _wrap(para, breedte):
                if y < 24 * mm:
                    _voettekst(c, W, m, BRON); c.showPage()
                    y = H - 20 * mm
                    c.setFillColor(kleur or DONKER)
                    c.setFont("Helvetica", font)
                c.drawString(m, y, regel)
                y -= (font * 0.45 + 0.6) * mm
            y -= 2 * mm
        return y

    # --- pagina 1: beschrijving + stappen ---
    y = kop("Bewijs-pakket", f"Gemaakt {date.today():%d-%m-%Y} · hulp-op-weg, geen juridisch advies")
    y = sectie(y, "1 · Jouw beschrijving")
    y = tekstblok(y, tekst)
    if stappen:
        y = sectie(y, "2 · Wat geldt er voor jou (stappen)")
        for s in stappen:
            y = tekstblok(y, "• " + s)
    if instanties:
        y = sectie(y, "3 · Instanties die je kunt bellen")
        for i in instanties:
            regels = f"{i['naam']} — {i['telefoon']}\n{i['adres']} · {i['site']}\n{i['wat']}"
            y = tekstblok(y, regels)
            y -= 1.5 * mm
    _voettekst(c, W, m, BRON)
    c.showPage()

    # --- artikelen: elk op eigen pagina ---
    for a in artikelen:
        y = kop(f"{a['citeertitel']} — artikel {a['nummer']}",
                (a.get("context") or "")[:110])
        y = tekstblok(y, a["tekst"], font=10, breedte=95)
        _voettekst(c, W, m, BRON)
        c.showPage()

    c.save()
    return buf.getvalue()


def _voettekst(c, W, m, bron):
    c.setFillColor(GRIJS)
    c.setFont("Helvetica", 7.5)
    c.drawString(m, 12 * mm, f"Bron: {bron} · via vrijewetgeving.nl (CC0) · "
                             f"gegenereerd {date.today():%d-%m-%Y} · geen juridisch advies")
    c.drawRightString(W - m, 12 * mm, "G2B Juridisch")
