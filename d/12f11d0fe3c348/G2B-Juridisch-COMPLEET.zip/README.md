# ⚖️ G2B Juridisch

Jouw eigen Nederlandse wetboek — 100% lokaal op je pc. Zoek in echte wetteksten,
leg je juridische probleem uit in gewone woorden, en zie welke wetten achter je
G2B-contracten zitten.

## Wat zit erin

- 🗣️ **Leg je probleem uit** — typ wat er aan de hand is ("iemand heeft mijn beat
  gestolen") → de app zoekt de relevante wetsartikelen en laat de stappen zien.
- 🔍 **Zoeken** — doorzoek álle geïmporteerde artikelen (snelle SQLite-zoekindex).
- 📚 **Wetboek** — blader door de wetten en lees artikelen; elk artikel is te
  downloaden als nette PDF.
- 🔗 **Jouw contracten** — elke clausule uit je Bedrijfsmiddelen-contracten met de
  echte wetsartikelen erachter (bijv. "naamsvermelding kan nooit weg" → Auteurswet
  art. 25).
- 🔄 **Updates** — één klik haalt de nieuwste wetteksten binnen; toont ook recente
  wetswijzigingen bij de overheid.

## Welke wetten haalt hij binnen?

Standaard de delen die voor een muziekproducent/ZZP'er relevant zijn:
Auteurswet · Wet op de naburige rechten (master) · Databankenwet ·
Handelsnaamwet · Toezicht collectieve beheerorganisaties (Buma/Stemra) ·
BW Boek 2, 3, 6 en 7 (eigendom, overeenkomsten, bijzondere contracten).

## Bronnen & licenties (regel 1)

- **Wetteksten**: vrijewetgeving.nl — publiek domein (CC0), dagelijks vers vanuit
  het officiële Basis Wetten Bestand van de overheid. 100% commercieel vrij.
- FastAPI (MIT) · uvicorn (BSD) · reportlab (BSD) — geen GPL, geen cloud, geen
  AI-kosten.

## Starten (Windows)

Dubbelklik `START-G2B-JURIDISCH.bat` → de browser opent op
`http://localhost:8020`. Bij de eerste start: ga naar **🔄 Updates** en klik
**Wetten binnenhalen** (eenmalig internet nodig, ~1 minuut). Daarna werkt alles
volledig offline.

⚠️ Deze app helpt je op weg maar is **geen juridisch advies** — lees altijd het
echte wetsartikel en raadpleeg bij grote zaken een jurist.
