@echo off
title G2B Psychologie
cd /d "%~dp0backend"
if not exist ..\.venv\Scripts\python.exe (
  echo Eerste keer: Python-omgeving wordt klaargemaakt...
  python -m venv ..\.venv
  ..\.venv\Scripts\python.exe -m pip install -q -r requirements.txt
)
..\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8030
pause
