# Licenties (regel 1: alles gratis + 100% commercieel vrij)

G2B Psychologie gebruikt uitsluitend open-source componenten met commercieel-vrije licenties:

| Pakket | Licentie | Voor |
|---|---|---|
| FastAPI | MIT | API-backend |
| Uvicorn | BSD-3-Clause | Lokale server |
| ReportLab | BSD (ReportLab-derived, commercieel vrij voor eigen PDF's) | PDF-generatie |
| Segno | MIT | QR-codes (100% lokaal, geen cloud-QR-dienst) |
| Pydantic | MIT | Data-validatie |

**Data**: instantie- en onderwerp-lijsten zijn eigen redactionele data van Good2Better, verzameld uit publieke officiële bronnen (okt 2026). Geen cloud-API's, geen betalingen, geen tracking — alles draait lokaal.
