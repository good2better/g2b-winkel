/* G2B Psychologie — frontend */
const $ = s => document.querySelector(s);

async function api(pad, opt) {
  const r = await fetch(pad, opt);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
function toast(t) { const el = $('#toast'); el.textContent = t; el.style.display = 'block'; setTimeout(() => el.style.display = 'none', 2600); }
function esc(t) { const d = document.createElement('div'); d.textContent = t ?? ''; return d.innerHTML; }

/* ---------- tabs ---------- */
document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.remove('actief'));
  b.classList.add('actief');
  document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
  $('#tab-' + b.dataset.tab).style.display = 'block';
  if (b.dataset.tab === 'instanties') laadInstanties();
  if (b.dataset.tab === 'begrijp') laadBegrijp();
  if (b.dataset.tab === 'brieven') laadBrieven();
});

/* ---------- status + onderwerp-tags ---------- */
async function laadStatus() {
  const s = await api('/api/status');
  $('#status').textContent = `${s.onderwerpen} onderwerpen · ${s.instanties} instanties · ${s.brieven} brief-templates`;
  const ond = await api('/api/onderwerpen');
  $('#onderwerpTags').innerHTML = ond.map(o => `<span class="tag" onclick="openOnderwerp('${o.id}')">${esc(o.titel)}</span>`).join('');
}

/* ---------- leg je situatie uit ---------- */
async function legUit() {
  const tekst = $('#probleem').value.trim();
  if (!tekst) { toast('✍️ Schrijf eerst wat er speelt'); return; }
  const out = $('#situatieOut');
  out.innerHTML = '<div class="kaart klein">bezig…</div>';
  const r = await api('/api/situatie', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({tekst})});
  let html = '';
  if (r.spoed && r.spoed_info) {
    html += `<div class="kaart spoedkaart"><h3>⚠️ Spoed — lees dit eerst</h3><p class="wat">${esc(r.spoed_info.uitleg)}</p>${instKaarten(r.spoed_info.instanties)}</div>`;
  }
  if (r.matches && r.matches.length) {
    for (const m of r.matches.slice(0, 2)) {
      const o = await api('/api/onderwerp/' + m.onderwerp);
      html += renderOnderwerp(o);
    }
  } else if (!r.spoed) {
    html += `<div class="kaart"><h3>Geen directe match</h3><p class="wat">${esc(r.fallback)}</p></div>`;
  }
  out.innerHTML = html;
}

function renderOnderwerp(o) {
  return `<div class="kaart">
    <h3>${esc(o.titel)}</h3>
    <p class="wat">${esc(o.uitleg)}</p>
    <h3 style="margin-top:10px">Stappen die je kunt nemen</h3>
    <ol>${o.stappen.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
    <h3 style="margin-top:10px">Instanties die hierbij passen</h3>
    ${instKaarten(o.instanties)}
  </div>`;
}

function instKaarten(lijst) {
  return `<div class="instlijst">${lijst.map(i => `
    <div class="inst">
      <img src="/api/instantie/${i.id}/qr" alt="QR naar Maps" title="Scan met je telefoon → opent Google Maps">
      <h4>${esc(i.naam)} ${i.spoed ? '<span class="spoedt">SPOED</span>' : ''} ${i.gratis ? '<span class="gratis">GRATIS</span>' : ''}</h4>
      <div class="klein"><span class="cat">${esc(i.categorie)}</span></div>
      <div class="wat">${esc(i.wat)}</div>
      <div class="ri">📞 ${esc(i.telefoon)}</div>
      <div class="ri">📍 ${esc(i.adres)}</div>
      <div class="ri"><a href="${esc(i.site)}" target="_blank">🌐 ${esc(i.site.replace('https://', ''))}</a></div>
    </div>`).join('')}</div>`;
}

async function openOnderwerp(id) {
  const o = await api('/api/onderwerp/' + id);
  $('#popupIn').innerHTML = renderOnderwerp(o) + '<button class="knop" style="margin-top:8px" onclick="sluitPopup()">Sluiten</button>';
  $('#popup').style.display = 'flex';
}
function sluitPopup() { $('#popup').style.display = 'none'; }
$('#popup').onclick = e => { if (e.target.id === 'popup') sluitPopup(); };

/* ---------- instanties-tab ---------- */
const CATS = [['', 'Alle'], ['veilig', '🚨 Veilig & misdaad'], ['geestelijk', '🧠 Geestelijk & zorg'], ['juridisch', '⚖️ Juridisch'], ['geld', '💰 Geld & schulden'], ['overheid', '🏛️ Overheid & zakelijk'], ['muziek', '🎵 Muziek & rechten']];
async function laadInstanties() {
  $('#catTags').innerHTML = CATS.map(([k, n]) => `<span class="tag" onclick="filterCat('${k}')">${n}</span>`).join('');
  const lijst = await api('/api/instanties');
  $('#instlijst').innerHTML = instKaarten(lijst);
}
async function filterCat(c) {
  const lijst = await api('/api/instanties' + (c ? '?categorie=' + c : ''));
  $('#instlijst').innerHTML = instKaarten(lijst);
}

/* ---------- begrijp mensen ---------- */
async function laadBegrijp() {
  const ond = await api('/api/onderwerpen');
  $('#begrijpLijst').innerHTML = '';
  for (const o of ond) {
    const vol = await api('/api/onderwerp/' + o.id);
    const d = document.createElement('div');
    d.className = 'kaart';
    d.innerHTML = `<h3>${esc(vol.titel)}</h3><p class="wat">${esc(vol.uitleg)}</p>
      <button class="knop2" onclick="openOnderwerp('${o.id}')">Bekijk stappen + instanties →</button>`;
    $('#begrijpLijst').appendChild(d);
  }
}

/* ---------- brieven ---------- */
async function laadBrieven() {
  const bs = await api('/api/brieven');
  $('#briefLijst').innerHTML = '';
  for (const b of bs) {
    const d = document.createElement('div');
    d.className = 'kaart';
    d.innerHTML = `<h3>✉️ ${esc(b.titel)}</h3><p class="klein">${esc(b.uitleg)}</p>
      ${b.velden.map(v => `<input id="bv_${b.id}_${v.id}" placeholder="${esc(v.label)}">`).join('')}
      <button class="knop" data-brief="${b.id}">📄 Download PDF</button>`;
    $('#briefLijst').appendChild(d);
    d.querySelector('[data-brief]').onclick = () => dlBrief(b.id, b.velden.map(v => v.id));
  }
}
async function dlBrief(id, veldIds) {
  const velden = {};
  veldIds.forEach(v => velden[v] = $('#bv_' + id + '_' + v).value.trim());
  const r = await fetch('/api/brief/pdf', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id, velden})});
  const blob = await r.blob();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = id + '-brief.pdf'; a.click();
  toast('📄 Brief gedownload!');
}

laadStatus();
