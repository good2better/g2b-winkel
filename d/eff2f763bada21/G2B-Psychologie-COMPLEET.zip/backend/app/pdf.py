"""Maakt nette PDF's in de G2B-huisstijl — groen, ruim, leesbaar."""
import io
from datetime import date

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

GROEN = (0.10, 0.36, 0.23)
TEKST = (0.12, 0.12, 0.12)
GRIS = (0.45, 0.45, 0.45)
BREEDTE, HOOGTE = A4
MARGE = 56


def _wrap(c, tekst: str, breedte: float, font: str, grootte: int) -> list[str]:
    regels = []
    for par in tekst.split("\n"):
        if not par.strip():
            regels.append("")
            continue
        woorden, regel = par.split(), ""
        for w in woorden:
            test = f"{regel} {w}".strip()
            if c.stringWidth(test, font, grootte) <= breedte:
                regel = test
            else:
                regels.append(regel)
                regel = w
        regels.append(regel)
    return regels


def brief_pdf(titel: str, tekst: str, ondertitel: str = "") -> bytes:
    """Eén nette brief als PDF (groene kop + footer met disclaimer)."""
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = HOOGTE - MARGE

    c.setFillColorRGB(*GROEN)
    c.rect(0, HOOGTE - 70, BREEDTE, 70, fill=1, stroke=0)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(MARGE, HOOGTE - 44, titel)
    if ondertitel:
        c.setFont("Helvetica", 10)
        c.drawString(MARGE, HOOGTE - 60, ondertitel)
    y = HOOGTE - 100

    c.setFillColorRGB(*GRIS)
    c.setFont("Helvetica", 9)
    c.drawString(MARGE, y, date.today().strftime("%d-%m-%Y"))
    y -= 24

    c.setFillColorRGB(*TEKST)
    c.setFont("Helvetica", 11)
    regels = _wrap(c, tekst, BREEDTE - 2 * MARGE, "Helvetica", 11)
    for regel in regels:
        if y < MARGE + 40:
            _voettekst(c)
            c.showPage()
            y = HOOGTE - MARGE
            c.setFillColorRGB(*TEKST)
            c.setFont("Helvetica", 11)
        c.drawString(MARGE, y, regel)
        y -= 16
    _voettekst(c)
    c.save()
    return buf.getvalue()


def _voettekst(c):
    c.setFillColorRGB(*GRIS)
    c.setFont("Helvetica", 8)
    c.drawString(MARGE, 30, f"G2B Psychologie · gegenereerd {date.today().isoformat()} · geen officieel/juridisch document · Good2Better")
