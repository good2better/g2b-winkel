"""G2B Psychologie — lokale hulp-app: situatie uitleggen → uitleg + stappen + echte NL-instanties."""
import json
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import pdf

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "app" / "data"

ONDERWERPEN = json.loads((DATA / "onderwerpen.json").read_text(encoding="utf-8"))
INSTANTIES = json.loads((DATA / "instanties.json").read_text(encoding="utf-8"))
BRIEVEN = json.loads((DATA / "brieven.json").read_text(encoding="utf-8"))
INST_MAP = {i["id"]: i for i in INSTANTIES}
OND_MAP = {o["id"]: o for o in ONDERWERPEN}

app = FastAPI(title="G2B Psychologie", docs_url=None, redoc_url=None)


class SituatieIn(BaseModel):
    tekst: str


class BriefIn(BaseModel):
    id: str
    velden: dict


@app.get("/api/status")
def status():
    return {"onderwerpen": len(ONDERWERPEN) - 1, "instanties": len(INSTANTIES),
            "brieven": len(BRIEVEN), "versie": "1.0"}


@app.get("/api/onderwerpen")
def onderwerpen():
    return [{"id": o["id"], "titel": o["titel"]} for o in ONDERWERPEN if not o.get("spoed")]


@app.get("/api/onderwerp/{oid}")
def onderwerp(oid: str):
    o = OND_MAP.get(oid)
    if not o:
        raise HTTPException(404)
    return {**o, "instanties": [INST_MAP[i] for i in o["instanties"] if i in INST_MAP]}


@app.post("/api/situatie")
def situatie(inp: SituatieIn):
    tekst = inp.tekst.lower()
    spoed = OND_MAP["spoed"]
    spoed_hit = any(w in tekst for w in spoed["woorden"])

    scores = []
    for o in ONDERWERPEN:
        if o.get("spoed"):
            continue
        hits = sum(1 for w in o["woorden"] if w in tekst)
        if hits:
            scores.append({"onderwerp": o["id"], "titel": o["titel"], "score": hits})
    scores.sort(key=lambda s: -s["score"])

    return {
        "spoed": spoed_hit,
        "spoed_info": {"uitleg": spoed["uitleg"],
                       "instanties": [INST_MAP[i] for i in spoed["instanties"]]} if spoed_hit else None,
        "matches": scores[:4],
        "fallback": "Kies hieronder het onderwerp dat het beste past." if not scores else None,
    }


@app.get("/api/instanties")
def instanties(categorie: str = ""):
    if categorie:
        return [i for i in INSTANTIES if i["categorie"] == categorie]
    return INSTANTIES


@app.get("/api/instantie/{iid}")
def instantie(iid: str):
    i = INST_MAP.get(iid)
    if not i:
        raise HTTPException(404)
    return i


@app.get("/api/instantie/{iid}/qr")
def instantie_qr(iid: str):
    """QR-code (PNG) die naar de Google Maps-zoekopdracht van het adres/link wijst."""
    i = INST_MAP.get(iid)
    if not i:
        raise HTTPException(404)
    import io
    import urllib.parse

    import segno
    doel = i["adres"] if "http" not in i["adres"] else i["site"]
    if "http" not in doel:
        doel = f"https://www.google.com/maps/search/{urllib.parse.quote(i['naam'] + ' ' + doel)}"
    buf = io.BytesIO()
    segno.make(doel).save(buf, kind="png", scale=6, dark="#0D0F0E")
    return Response(content=buf.getvalue(), media_type="image/png")


@app.get("/api/brieven")
def brieven():
    return [{"id": b["id"], "titel": b["titel"], "uitleg": b["uitleg"],
             "velden": b["velden"]} for b in BRIEVEN]


@app.post("/api/brief/pdf")
def brief_pdf_ep(inp: BriefIn):
    b = next((x for x in BRIEVEN if x["id"] == inp.id), None)
    if not b:
        raise HTTPException(404)
    tekst = b["tekst"]
    for v in b["velden"]:
        tekst = tekst.replace("{" + v["id"] + "}", inp.velden.get(v["id"], "…"))
    data = pdf.brief_pdf(b["titel"], tekst, "G2B Psychologie")
    fn = f"{b['id']}-brief.pdf"
    return Response(content=data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{fn}"'})


app.mount("/", StaticFiles(directory=str(BASE / "app" / "static"), html=True), name="static")
