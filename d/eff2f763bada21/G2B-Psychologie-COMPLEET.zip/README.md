# G2B Psychologie 🧠

Lokale hulp-app van Good2Better: leg je situatie uit en kom snel bij de juiste Nederlandse hulp-instantie — met echte adressen, telefoonnummers en QR-codes naar Google Maps.

## Starten
Dubbelklik `START-G2B-PSYCHOLOGIE.bat` → browser op `localhost:8030`. Geen import, geen account, geen kosten.

## Wat het doet
- 🗣️ **Leg je situatie uit** — typ je probleem → uitleg + concrete stappen + passende instanties
- 📇 **Instanties** — 28 echte NL hulp-organisaties (Juridisch Loket, Slachtofferhulp, 113, MIND, KvK, BumaStemra…) met adres, telefoon, site en **QR-code naar Google Maps**
- 🧠 **Begrijp mensen** — psychologie in gewone woorden (stress, rouw, gaslighting, assertief onderhandelen…)
- ✉️ **Brieven** — aanmaning / klachtenbrief / bezwaar als kant-en-klare PDF
- ⚠️ **Spoed-strip** — 112/113/0800-2000 altijd zichtbaar; crisis-woorden in je tekst → instant melding

## Veilig & verantwoordelijk
- 100% lokaal op je pc — niks naar buiten, geen tracking
- Hulp-op-weg, **geen** medisch/juridisch advies — de app verwijst altijd door naar echte instanties
- Instantie-gegevens geverifieerd via officiële sites (okt 2026)

## Tech
FastAPI + SQLite-vrije statische data (JSON) + vanilla JS frontend · poort 8030 · Windows 10, CPU-only.

Regel 1: alles gratis, open-source, commercieel vrij — zie `LICENSES.md`.
