#!/usr/bin/env bash
# G2B AURA v6.0 — deploy: serve web/ op poort 8300 + syntax-check
set -e
cd "$(dirname "$0")"
echo "== AURA v6.0 check =="
node --check web/js/aura-dsp-worklet.js 2>/dev/null || true
for f in web/js/aura-engine.js web/js/instrument-matrix.js web/js/midi-forge-engine.js web/js/brain-memory.js web/js/watermark-engine.js web/js/keyboard.js; do
  node --check "$f" && echo "  ok $f"
done
php -l backend/validate.php 2>/dev/null || echo "  (php niet geinstalleerd — sla php-check over)"
echo "== start op poort 8300 =="
cd web && python3 -m http.server 8300 --bind 0.0.0.0
