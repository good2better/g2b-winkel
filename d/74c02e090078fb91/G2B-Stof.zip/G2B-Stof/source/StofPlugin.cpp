#include "DistrhoPlugin.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
// KRAAK, WOBBLE, TOON, CRUSH, MIX, OUT
static const float kPresetParams[6][6] = {
    {0.25f,0.20f,0.35f,0.15f,1.0f,0.f},   // G2B — subtiel stof
    {0.30f,0.25f,0.45f,0.20f,1.0f,0.f},   // DEMBOW
    {0.40f,0.30f,0.55f,0.30f,1.0f,-1.f},  // DRILL — donker lo-fi
    {0.20f,0.15f,0.30f,0.10f,1.0f,0.f},   // RNB — zacht
    {0.15f,0.10f,0.20f,0.10f,1.0f,0.f},   // HOUSE — licht
    {0.35f,0.35f,0.45f,0.25f,1.0f,0.f},   // AFRO
};

class StofPlugin : public Plugin {
public:
    enum Params { kKraak,kWobble,kToon,kCrush,kMix,kOut,kDice,kPreset,kNumParams };
    StofPlugin() : Plugin(kNumParams,0,2) {}
protected:
    const char* getLabel() const override { return "G2B Stof"; }
    const char* getDescription() const override { return "Lo-fi machine: vinyl-kraak, wow/flutter, donkere toon en bit-crush"; }
    const char* getMaker() const override { return "G2B"; }
    const char* getLicense() const override { return "Proprietary"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','S','f'); }

    void initParameter(uint32_t i, Parameter& p) override {
        p.hints=kParameterIsAutomatable;
        switch(i){
        case kKraak: p.name="KRAAK";  p.symbol="kraak"; p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.25f;break;
        case kWobble:p.name="WOBBLE"; p.symbol="wobble";p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.2f;break;
        case kToon:  p.name="TOON";   p.symbol="toon";  p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.35f;break;
        case kCrush: p.name="CRUSH";  p.symbol="crush"; p.ranges.min=0;p.ranges.max=1;p.ranges.def=0.15f;break;
        case kMix:   p.name="MIX";    p.symbol="mix";   p.ranges.min=0;p.ranges.max=1;p.ranges.def=1.0f;break;
        case kOut:   p.name="OUTPUT"; p.symbol="out";   p.ranges.min=-24;p.ranges.max=12;p.ranges.def=0;p.unit="dB";break;
        case kDice:  p.name="DICE";   p.symbol="dice";  p.hints|=kParameterIsInteger|kParameterIsTrigger;p.ranges.min=0;p.ranges.max=1;p.ranges.def=0;break;
        case kPreset:p.name="PRESET"; p.symbol="preset";p.hints|=kParameterIsInteger;p.ranges.min=0;p.ranges.max=5;p.ranges.def=0;break;
        }
    }
    float getParameterValue(uint32_t i) const override {
        switch(i){case kKraak:return fKraak;case kWobble:return fWobble;case kToon:return fToon;case kCrush:return fCrush;case kMix:return fMix;case kOut:return fOut;case kDice:return fDice;case kPreset:return fPreset;}return 0.f;
    }
    void setParameterValue(uint32_t i, float v) override {
        if(i==kPreset){applyPreset((int)(v+0.5f));return;}
        switch(i){
        case kKraak:fKraak=v;break;case kWobble:fWobble=v;break;case kToon:fToon=v;break;
        case kCrush:fCrush=v;break;case kMix:fMix=v;break;case kOut:fOut=v;break;
        case kDice:fDice=v;if(v>0.5f)rollDice();fDice=0.f;break;
        }
    }
    void initState(uint32_t index, String& name, String& def) override {
        if(index==0){name="scope";def="";}
        else{name="presetnames";def="";for(int i=0;i<6;i++){def+=kPresetNames[i];if(i<5)def+=";";}}
    }
    void setState(const char* k, const char* v) override {(void)k;(void)v;}

    void run(const float** in, float** out, uint32_t frames) override {
        const float sr=getSampleRate();
        const float outG=powf(10.f,fOut*0.05f);
        const float lpA=1.f-expf(-2.f*M_PI*(12000.f-fToon*9500.f)/sr); // donkerder bij meer TOON
        const float bits=powf(2.f,12.f-fCrush*8.f);                    // 12→4 bit
        const float wobA=2.f*M_PI*0.6f/sr;                             // wow ~0.6Hz
        const float wobD=fWobble*0.004f;                               // ±0.4% pitch
        for(uint32_t i=0;i<frames;i++){
            // --- WOBBLE: pitch-modulatie via mini-delay ---
            fWobPh+=wobA; if(fWobPh>2.f*M_PI)fWobPh-=2.f*M_PI;
            float wob=sinf(fWobPh)*wobD*sr*0.5f; // in samples
            float rd=(float)fWPos+wob+4096.f;
            int rp=((int)rd)%4096; int rp2=(rp+1)%4096; float frac=rd-(int)rd;
            float x0=fRingL[rp]+(fRingL[rp2]-fRingL[rp])*frac;
            float x1=fRingR[rp]+(fRingR[rp2]-fRingR[rp])*frac;
            fRingL[fWPos%4096]=in[0][i]; fRingR[fWPos%4096]=in[1][i]; fWPos++;
            // --- KRAAK: vinyl ruis + pops ---
            fRnd=fRnd*1664525u+1013904223u;
            float noise=((fRnd>>8)%1000/1000.f-0.5f);
            fLpNoise+=0.15f*(noise-fLpNoise); // licht gefilterd
            x0+=fLpNoise*fKraak*0.10f;
            x1+=fLpNoise*fKraak*0.10f;
            if((fRnd>>9)%100000<3){ // sporadische pop
                float pop=((fRnd>>7)%1000/1000.f-0.5f)*fKraak*0.6f;
                x0+=pop;x1+=pop;
            }
            // --- TOON: donkerder ---
            fLp0+=lpA*(x0-fLp0); fLp1+=lpA*(x1-fLp1);
            x0=fLp0; x1=fLp1;
            // --- CRUSH: bit-depth ---
            if(fCrush>0.001f){
                x0=floorf(x0*bits+0.5f)/bits;
                x1=floorf(x1*bits+0.5f)/bits;
            }
            float o0=(in[0][i]*(1.f-fMix)+x0*fMix)*outG;
            float o1=(in[1][i]*(1.f-fMix)+x1*fMix)*outG;
            out[0][i]=o0;out[1][i]=o1;
            if(++fDecim>=3){fDecim=0;if(fScopeN<40)fScope[fScopeN++]=o0;}
        }
        if(fScopeN>=40){
            char buf[256];int pos=0;
            for(uint32_t s=0;s<fScopeN&&pos<230;++s)pos+=snprintf(buf+pos,sizeof(buf)-pos,"%.3f;",fScope[s]);
            buf[pos]=0;setState("scope",buf);fScopeN=0;
        }
    }
private:
    void rollDice(){
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kKraak,((fRnd>>8)%100)/100.f*0.6f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kWobble,((fRnd>>8)%100)/100.f*0.5f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kToon,0.1f+((fRnd>>8)%100)/100.f*0.6f);
        fRnd=fRnd*1664525u+1013904223u; setParameterValue(kCrush,((fRnd>>8)%100)/100.f*0.4f);
    }
    void applyPreset(int i){
        if(i<0)i=0;if(i>5)i=5;fPreset=(float)i;
        setParameterValue(kKraak,kPresetParams[i][0]);
        setParameterValue(kWobble,kPresetParams[i][1]);
        setParameterValue(kToon,kPresetParams[i][2]);
        setParameterValue(kCrush,kPresetParams[i][3]);
        setParameterValue(kMix,kPresetParams[i][4]);
        setParameterValue(kOut,kPresetParams[i][5]);
    }
    float fKraak=0.25f,fWobble=0.2f,fToon=0.35f,fCrush=0.15f,fMix=1.0f,fOut=0.f;
    float fLp0=0,fLp1=0,fLpNoise=0,fWobPh=0;
    float fRingL[4096]={0},fRingR[4096]={0};uint32_t fWPos=0;
    float fDice=0.f,fPreset=0.f;
    unsigned fRnd=424242;
    float fScope[40];uint32_t fScopeN=0;int fDecim=0;
    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StofPlugin)
};
Plugin* createPlugin(){return new StofPlugin();}
END_NAMESPACE_DISTRHO
