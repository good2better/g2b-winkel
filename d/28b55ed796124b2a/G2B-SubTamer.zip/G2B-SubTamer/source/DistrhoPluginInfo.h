/*
 * G2B SubTamer — sub-band leveler + mono control
 * Plugin info for DISTRHO Plugin Framework.
 */

#ifndef DISTRHO_PLUGIN_INFO_H_INCLUDED
#define DISTRHO_PLUGIN_INFO_H_INCLUDED

#define DISTRHO_PLUGIN_BRAND   "G2B"
#define DISTRHO_PLUGIN_NAME    "G2B SubTamer"
#define DISTRHO_PLUGIN_URI     "https://github.com/good2better/g2b-subtamer"
#define DISTRHO_PLUGIN_CLAP_ID "nl.g2b.subtamer"

#define DISTRHO_PLUGIN_BRAND_ID  G2Bt
#define DISTRHO_PLUGIN_UNIQUE_ID G2St

#define DISTRHO_PLUGIN_HAS_UI        1
#define DISTRHO_PLUGIN_IS_RT_SAFE    1
#define DISTRHO_PLUGIN_NUM_INPUTS    2
#define DISTRHO_PLUGIN_NUM_OUTPUTS   2
#define DISTRHO_PLUGIN_WANT_PROGRAMS 0
#define DISTRHO_UI_FILE_BROWSER      0
#define DISTRHO_UI_USER_RESIZABLE    1
#define DISTRHO_UI_USE_NANOVG        1
#define DISTRHO_UI_DEFAULT_WIDTH     560
#define DISTRHO_UI_DEFAULT_HEIGHT    280

#endif // DISTRHO_PLUGIN_INFO_H_INCLUDED
