/*
 * G2B SubTamer — "sub always on the right spot".
 * DSP: splits the sub band (below VANAF Hz) with a two-stage one-pole LP,
 * then levels it with a soft compressor (envelope follower, TEM sets how
 * hard it pulls the sub back to a steady level), forces the sub toward
 * mono (MONO), and trims it (STERKTE). Everything above the split passes
 * through untouched, stereo intact.
 */

#include "DistrhoPlugin.hpp"

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;
static const float kPresetParams[6][5] = {
    { 55, 120, -3, 100, 0 },
    { 65, 110, -3.5, 100, 0 },
    { 70, 90, -4, 100, 0 },
    { 50, 130, -2.5, 90, 0 },
    { 60, 120, -3, 100, 0 },
    { 55, 100, -3, 100, 0 },
};


class SubTamerPlugin : public Plugin
{
public:
    enum Parameters {
        kTem = 0,     // TEM % — hoe hard de sub wordt getemd
        kVanaf,       // VANAF Hz — alles hieronder is "de sub"
        kSterkte,     // STERKTE dB — hoe luid de sub zit
        kMono,        // MONO % — hoe mono de sub wordt
        kOut,         // OUTPUT dB
        kPreset,
        kParameterCount
    };

    SubTamerPlugin()
        : Plugin(kParameterCount, 0, 0),
          fTem(50.0f), fVanaf(100.0f), fSterkte(0.0f),
          fMono(100.0f), fOutDb(0.0f),
          fLp1L(0.0f), fLp2L(0.0f), fLp1R(0.0f), fLp2R(0.0f), fEnv(0.0f),
          fAlpha(0.0f), fEnvAtk(0.0f), fEnvRel(0.0f),
          fThr(0.0f), fKneeK(0.0f), fSubGain(1.0f), fOutGain(1.0f)
    {
        recalc();
    }

protected:
    const char* getLabel() const override { return "G2B SubTamer"; }
    const char* getDescription() const override
    {
        return "Sub always on the right spot: temt de sub-band naar een "
               "vast niveau en houdt die mono — nooit te wild, nooit uit "
               "balans.";
    }
    const char* getMaker() const override { return "G2B (good2better)"; }
    const char* getHomePage() const override { return "https://github.com/good2better"; }
    const char* getLicense() const override { return "ISC"; }
    uint32_t getVersion() const override { return d_version(1,0,0); }
    int64_t getUniqueId() const override { return d_cconst('G','2','S','t'); }

    void initParameter(uint32_t index, Parameter& parameter) override
    {
        parameter.hints = kParameterIsAutomatable;
        switch (index)
        {
        case kTem:
            parameter.name = "Tem";
            parameter.shortName = "Tem";
            parameter.symbol = "tem";
            parameter.unit = "%";
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 100.0f;
            parameter.ranges.def = 50.0f;
            break;
        case kVanaf:
            parameter.name = "Sub vanaf";
            parameter.shortName = "Vanaf";
            parameter.symbol = "vanaf";
            parameter.unit = "Hz";
            parameter.ranges.min = 60.0f;
            parameter.ranges.max = 160.0f;
            parameter.ranges.def = 100.0f;
            break;
        case kSterkte:
            parameter.name = "Sterkte";
            parameter.shortName = "Sterkte";
            parameter.symbol = "sterkte";
            parameter.unit = "dB";
            parameter.ranges.min = -12.0f;
            parameter.ranges.max = 6.0f;
            parameter.ranges.def = 0.0f;
            break;
        case kMono:
            parameter.name = "Mono";
            parameter.shortName = "Mono";
            parameter.symbol = "mono";
            parameter.unit = "%";
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 100.0f;
            parameter.ranges.def = 100.0f;
            break;
        case kOut:
            parameter.name = "Output";
            parameter.shortName = "Output";
            parameter.symbol = "out";
            parameter.unit = "dB";
            parameter.ranges.min = -6.0f;
            parameter.ranges.max = 6.0f;
            parameter.ranges.def = 0.0f;
            break;
        case kPreset:
            parameter.name = "Preset";
            parameter.symbol = "preset";
            parameter.unit = "";
            parameter.hints = kParameterIsInteger;
            parameter.ranges.min = 0.0f;
            parameter.ranges.max = 5.0f;
            parameter.ranges.def = 0.0f;
            break;
        }
    }

    float getParameterValue(uint32_t index) const override
    {
        switch (index)
        {
        case kTem:     return fTem;
        case kVanaf:   return fVanaf;
        case kSterkte: return fSterkte;
        case kMono:    return fMono;
        case kOut:     return fOutDb;
        case kPreset: return fPreset;
        }
        return 0.0f;
    }

    void setParameterValue(uint32_t index, float value) override
    {
        if (index == kPreset) { fPreset = value; applyPreset((int)value); return; }
        switch (index)
        {
        case kTem:     fTem = value; break;
        case kVanaf:   fVanaf = value; break;
        case kSterkte: fSterkte = value; break;
        case kMono:    fMono = value; break;
        case kOut:     fOutDb = value; break;
        }
        recalc();
    }

    void activate() override
    {
        fLp1L = fLp2L = fLp1R = fLp2R = fEnv = 0.0f;
    }

    void run(const float** inputs, float** outputs, uint32_t frames) override
    {
        const float* inL = inputs[0];
        const float* inR = inputs[1];
        float* outL = outputs[0];
        float* outR = outputs[1];

        const float a    = fAlpha;
        const float atk  = fEnvAtk;
        const float rel  = fEnvRel;
        const float thr  = fThr;
        const float kk   = fKneeK;
        const float mono = fMono / 100.0f;
        const float sg   = fSubGain;
        const float g    = fOutGain;

        float lp1l = fLp1L, lp2l = fLp2L;
        float lp1r = fLp1R, lp2r = fLp2R;
        float env  = fEnv;

        for (uint32_t i = 0; i < frames; ++i)
        {
            const float l = inL[i], r = inR[i];

            // sub-splits: tweepools LP per kanaal
            lp1l += a * (l - lp1l);
            lp2l += a * (lp1l - lp2l);
            lp1r += a * (r - lp1r);
            lp2r += a * (lp1r - lp2r);
            const float subL = lp2l, subR = lp2r;
            const float topL = l - subL, topR = r - subR;

            // enveloppe van de sub → hoe wild is-ie nu
            const float lvl = std::fabs(subL) + std::fabs(subR);
            env += (lvl > env ? atk : rel) * (lvl - env);

            // tem-gain: alles boven thr wordt zacht teruggetrokken
            float gain = 1.0f;
            if (env > thr && env > 1e-6f)
                gain = std::pow(thr / env, kk);

            // mono onder de split: sub mag niet breed worden
            const float mSub = (subL + subR) * 0.5f;
            const float sL = subL + (mSub - subL) * mono;
            const float sR = subR + (mSub - subR) * mono;

            outL[i] = (topL + sL * gain * sg) * g;
            outR[i] = (topR + sR * gain * sg) * g;
        }

        fLp1L = lp1l; fLp2L = lp2l;
        fLp1R = lp1r; fLp2R = lp2r;
        fEnv  = env;
    }

private:
    float fTem, fVanaf, fSterkte, fMono, fOutDb;
    float fLp1L, fLp2L, fLp1R, fLp2R, fEnv;
    float fAlpha, fEnvAtk, fEnvRel, fThr, fKneeK, fSubGain, fOutGain;

    float fPreset = 0.0f;

    void applyPreset(int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        const float* p = kPresetParams[i];
        setParameterValue(kTem, p[0]);
        setParameterValue(kVanaf, p[1]);
        setParameterValue(kSterkte, p[2]);
        setParameterValue(kMono, p[3]);
        setParameterValue(kOut, p[4]);
        recalc();
    }

    void recalc()
    {
        const float sr = (float)getSampleRate();
        const float pi = 3.14159265358979f;
        fAlpha   = std::exp(-2.0f * pi * fVanaf / sr);
        fEnvAtk  = 1.0f - std::exp(-1.0f / (sr * 0.005f));  // ~5 ms
        fEnvRel  = 1.0f - std::exp(-1.0f / (sr * 0.150f));  // ~150 ms
        // TEM: hoger = lagere drempel + sterkere terugtrekking
        fThr     = 0.35f - 0.20f * (fTem / 100.0f);         // ~-9..-15 dBFS
        fKneeK   = 0.75f * (fTem / 100.0f);
        fSubGain = std::pow(10.0f, fSterkte / 20.0f);
        fOutGain = std::pow(10.0f, fOutDb / 20.0f);
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SubTamerPlugin)
};

Plugin* createPlugin() { return new SubTamerPlugin(); }

END_NAMESPACE_DISTRHO
