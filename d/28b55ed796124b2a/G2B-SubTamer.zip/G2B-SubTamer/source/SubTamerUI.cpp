/*
 * G2B SubTamer — UI (NanoVG): donkergroen paneel, 5 draaiknoppen.
 * Zelfde G2B-huisstijl als Glans. Verticaal slepen = waarde; scroll = fijn.
 */

#include "DistrhoUI.hpp"

START_NAMESPACE_DISTRHO

static const char* kPresetNames[6] = {"G2B","DEMBOW","DRILL","RNB","HOUSE","AFRO"};
static const int kNumPresets = 6;



class SubTamerUI : public UI
{
public:
    SubTamerUI()
        : UI(DISTRHO_UI_DEFAULT_WIDTH, DISTRHO_UI_DEFAULT_HEIGHT)
    {
        loadSharedResources();
        std::memset(fValue, 0, sizeof(fValue));
        std::memset(fMin,   0, sizeof(fMin));
        std::memset(fMax,   0, sizeof(fMax));
        fDrag = -1;
        fLastY = 0.0f;

        // gespiegelde ranges (dezelfde als in de plugin)
        fMin[0]=0.0f;    fMax[0]=100.0f;
        fMin[1]=60.0f;   fMax[1]=160.0f;
        fMin[2]=-12.0f;  fMax[2]=6.0f;
        fMin[3]=0.0f;    fMax[3]=100.0f;
        fMin[4]=-6.0f;   fMax[4]=6.0f;
        fLabel[0]="TEM";      fUnit[0]="%";
        fLabel[1]="VANAF";    fUnit[1]="Hz";
        fLabel[2]="STERKTE";  fUnit[2]="dB";
        fLabel[3]="MONO";     fUnit[3]="%";
        fLabel[4]="OUTPUT";   fUnit[4]="dB";
    }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        fValue[index] = value;
        repaint();
    }

    void onNanoDisplay() override
    {
        const float W = getWidth(), H = getHeight();

        beginPath();
        rect(0, 0, W, H);
        fillColor(13, 15, 14);
        fill();

        fontSize(20.0f);
        textAlign(ALIGN_LEFT | ALIGN_MIDDLE);
        fillColor(47, 191, 113);
        text(18.0f, 26.0f, "G2B SUBTAMER", nullptr);
        fontSize(12.0f);
        fillColor(143, 160, 152);
        text(18.0f, 46.0f, "sub always on the right spot — G2B", nullptr);

        const int n = 5;
        const float step = (W - 40.0f) / n;
        for (int i = 0; i < n; ++i)
        {
            const float cx = 40.0f + step * (i + 0.5f);
            const float cy = 120.0f;
            const float R  = 34.0f;
            const float norm = (fValue[i] - fMin[i]) / (fMax[i] - fMin[i]);
            const float ang = -2.4f + norm * 4.8f;

            beginPath();
            circle(cx, cy, R);
            fillColor(30, 34, 33);
            fill();
            strokeColor(42, 47, 45);
            strokeWidth(2.0f);
            stroke();

            beginPath();
            arc(cx, cy, R - 4.0f, -2.4f - 1.5708f, ang - 1.5708f, CW);
            strokeColor(47, 191, 113);
            strokeWidth(3.0f);
            stroke();

            beginPath();
            moveTo(cx, cy);
            lineTo(cx + std::sin(ang) * (R - 9.0f),
                   cy - std::cos(ang) * (R - 9.0f));
            strokeColor(232, 236, 234);
            strokeWidth(3.0f);
            stroke();

            fontSize(11.0f);
            fillColor(143, 160, 152);
            textAlign(ALIGN_CENTER | ALIGN_TOP);
            text(cx, cy + R + 8.0f, fLabel[i], nullptr);

            fontSize(12.5f);
            fillColor(232, 236, 234);
            char buf[32];
            if (fMax[i] <= 2.5f)
                snprintf(buf, sizeof(buf), "%.2f %s", fValue[i], fUnit[i]);
            else
                snprintf(buf, sizeof(buf), "%.0f %s", fValue[i], fUnit[i]);
            text(cx, cy + R + 24.0f, buf, nullptr);
        }

        fontSize(10.5f);
        fillColor(90, 100, 94);
        textAlign(ALIGN_CENTER | ALIGN_BOTTOM);
        
        // preset-knoppen
        {
            float bx = W - 14.0f;
            for (int i = kNumPresets - 1; i >= 0; --i)
            {
                const float bw = 62.0f, bh = 17.0f;
                bx -= bw + 5.0f;
                const bool on = (i == fProg);
                beginPath(); roundedRect(bx, 62.0f, bw, bh, 4.0f);
                if (on) { fillColor(29, 122, 72); fill(); }
                strokeColor(42, 47, 45); strokeWidth(1.0f); stroke();
                fontSize(10.0f); textAlign(ALIGN_CENTER | ALIGN_MIDDLE);
                fillColor(on ? Color(232, 236, 234) : Color(143, 160, 152));
                text(bx + bw * 0.5f, 62.0f + bh * 0.5f, kPresetNames[i], nullptr);
            }
        }

        text(W * 0.5f, H - 10.0f,
             "sleep omhoog/omlaag om te draaien — scroll = fijn", nullptr);

        {
            float bx2 = 14.0f;
            beginPath(); roundedRect(bx2, 48.0f, 26.0f, 17.0f, 4.0f);
            fillColor(fLight ? Color(214,220,217) : Color(24,28,27)); fill();
            strokeColor(42,47,45); strokeWidth(1.0f); stroke();
            fontSize(11.0f); textAlign(ALIGN_CENTER|ALIGN_MIDDLE);
            fillColor(fLight ? Color(28,34,31) : Color(232,236,234));
            text(bx2+13.0f, 56.5f, "\xF0\x9F\x8E\xB2", nullptr);
            const float tx = W - 40.0f;
            beginPath(); roundedRect(tx, 34.0f, 26.0f, 17.0f, 4.0f);
            fillColor(fLight ? Color(214,220,217) : Color(24,28,27)); fill();
            strokeColor(42,47,45); strokeWidth(1.0f); stroke();
            fontSize(10.0f);
            text(tx+13.0f, 42.5f, fLight ? "\xF0\x9F\x8C\x99" : "\xE2\x98\x80", nullptr);
        }
    }

    bool onMouse(const MouseEvent& ev) override
    {
        if (ev.button != 1) return false;
        const float W = getWidth();
        const float step = (W - 40.0f) / 5;
        if (ev.press)
        {
            if (ev.pos.getX() >= 14.0f && ev.pos.getX() <= 40.0f &&
                ev.pos.getY() >= 48.0f && ev.pos.getY() <= 65.0f)
            { setParameterValue(5, 1.0f); repaint(); return true; }
            if (ev.pos.getX() >= W-40.0f && ev.pos.getX() <= W-14.0f &&
                ev.pos.getY() >= 34.0f && ev.pos.getY() <= 51.0f)
            { fLight = !fLight; repaint(); return true; }

            // preset-klik?
            {
                float bx = W - 14.0f;
                for (int i = kNumPresets - 1; i >= 0; --i)
                {
                    const float bw = 62.0f, bh = 17.0f;
                    bx -= bw + 5.0f;
                    if (ev.pos.getX() >= bx && ev.pos.getX() <= bx + bw &&
                        ev.pos.getY() >= 62.0f && ev.pos.getY() <= 62.0f + bh)
                    {
                        setParameterValue(6, (float)i);
                        fProg = i;
                        repaint();
                        return true;
                    }
                }
            }

            for (int i = 0; i < 5; ++i)
            {
                const float cx = 40.0f + step * (i + 0.5f);
                const float cy = 120.0f;
                const float dx = ev.pos.getX() - cx;
                const float dy = ev.pos.getY() - cy;
                if (dx*dx + dy*dy <= 34.0f * 34.0f + 64.0f)
                {
                    fDrag = i;
                    fLastY = ev.pos.getY();
                    editParameter(i, true);
                    return true;
                }
            }
        }
        else if (fDrag >= 0)
        {
            editParameter(fDrag, false);
            fDrag = -1;
        }
        return true;
    }

    bool onMotion(const MotionEvent& ev) override
    {
        if (fDrag < 0) return false;
        const float dy = fLastY - ev.pos.getY();
        fLastY = ev.pos.getY();
        const float range = fMax[fDrag] - fMin[fDrag];
        float v = fValue[fDrag] + dy * range / 200.0f;
        if (v < fMin[fDrag]) v = fMin[fDrag];
        if (v > fMax[fDrag]) v = fMax[fDrag];
        fValue[fDrag] = v;
        setParameterValue(fDrag, v);
        repaint();
        return true;
    }

    bool onScroll(const ScrollEvent& ev) override
    {
        const float W = getWidth();
        const float step = (W - 40.0f) / 5;
        for (int i = 0; i < 5; ++i)
        {
            const float cx = 40.0f + step * (i + 0.5f);
            const float cy = 120.0f;
            const float dx = ev.pos.getX() - cx;
            const float dy = ev.pos.getY() - cy;
            if (dx*dx + dy*dy <= 34.0f * 34.0f + 64.0f)
            {
                const float range = fMax[i] - fMin[i];
                float v = fValue[i] + ev.delta.getY() * range / 100.0f;
                if (v < fMin[i]) v = fMin[i];
                if (v > fMax[i]) v = fMax[i];
                fValue[i] = v;
                editParameter(i, true);
                setParameterValue(i, v);
                editParameter(i, false);
                repaint();
                return true;
            }
        }
        return true;
    }

private:
    float fValue[5], fMin[5], fMax[5];
    const char* fLabel[5];
    const char* fUnit[5];
    int fDrag;
    float fLastY;
    int fProg = -1;
    bool fLight = false;

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SubTamerUI)
};

UI* createUI() { return new SubTamerUI(); }

END_NAMESPACE_DISTRHO
